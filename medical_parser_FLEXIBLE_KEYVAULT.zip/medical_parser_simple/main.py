"""
MEDICAL DOCUMENT PARSER - MAIN APPLICATION
With Detailed Logging and Error Handling
"""

import os
import sys
import json
import logging
import argparse
from datetime import datetime
from typing import Dict, List, Any

# Setup detailed logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'parser_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


def print_section(title: str, char: str = "="):
    """Print a formatted section header"""
    logger.info("")
    logger.info(char * 80)
    logger.info(title)
    logger.info(char * 80)


def load_configuration(config_path: str = "config.json") -> Dict:
    """
    Load and validate configuration file
    
    Returns:
        Dict: Configuration dictionary
    """
    print_section("STEP 1: LOADING CONFIGURATION")
    
    try:
        logger.info(f"📁 Looking for config file: {config_path}")
        
        if not os.path.exists(config_path):
            logger.error(f"❌ Config file not found: {config_path}")
            logger.error(f"   Current directory: {os.getcwd()}")
            logger.error(f"   Files in directory: {os.listdir('.')}")
            raise FileNotFoundError(f"Config file not found: {config_path}")
        
        logger.info(f"✓ Config file found")
        
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        logger.info(f"✓ Config file loaded successfully")
        logger.info(f"   File size: {os.path.getsize(config_path)} bytes")
        
        # Validate structure
        logger.info("📋 Validating config structure...")
        
        required_keys = ['azure_keyvault', 'azure_blob', 'doctypes', 'processing']
        missing_keys = [k for k in required_keys if k not in config]
        
        if missing_keys:
            logger.error(f"❌ Missing required config sections: {missing_keys}")
            raise ValueError(f"Config missing sections: {missing_keys}")
        
        logger.info(f"✓ All required config sections present")
        
        # Check doctypes
        if 'doctypes' not in config:
            logger.error("❌ Config missing 'doctypes' section")
            logger.error("   Found keys: " + ", ".join(config.keys()))
            raise ValueError("Config missing 'doctypes' section")
        
        logger.info(f"✓ Found {len(config['doctypes'])} doctypes: {', '.join(config['doctypes'].keys())}")
        
        return config
        
    except FileNotFoundError as e:
        logger.error(f"❌ Config file error: {str(e)}")
        raise
    except json.JSONDecodeError as e:
        logger.error(f"❌ Invalid JSON in config file: {str(e)}")
        logger.error(f"   Line {e.lineno}, Column {e.colno}")
        raise
    except Exception as e:
        logger.error(f"❌ Unexpected error loading config: {str(e)}")
        logger.exception("Full traceback:")
        raise


def validate_doctype_config(config: Dict, doctype: str) -> Dict:
    """
    Validate doctype-specific configuration
    
    Returns:
        Dict: Doctype configuration
    """
    print_section(f"STEP 2: VALIDATING DOCTYPE '{doctype}' CONFIG")
    
    try:
        logger.info(f"📋 Checking doctype: {doctype}")
        
        if doctype not in config['doctypes']:
            logger.error(f"❌ Doctype '{doctype}' not found in config")
            logger.error(f"   Available doctypes: {', '.join(config['doctypes'].keys())}")
            raise ValueError(f"Doctype '{doctype}' not configured")
        
        logger.info(f"✓ Doctype '{doctype}' found in config")
        
        doctype_config = config['doctypes'][doctype]
        
        # Validate required sections
        required_sections = ['azure_openai', 'azure_openai_embedding', 'azure_ai_search', 'prompt_module']
        
        for section in required_sections:
            if section not in doctype_config:
                logger.error(f"❌ Missing section '{section}' in doctype '{doctype}'")
                raise ValueError(f"Doctype '{doctype}' missing '{section}' section")
            logger.info(f"   ✓ Section '{section}' present")
        
        # Log configuration details
        logger.info(f"📝 Doctype configuration:")
        logger.info(f"   Prompt module: {doctype_config.get('prompt_module')}")
        logger.info(f"   Description: {doctype_config.get('description', 'N/A')}")
        
        return doctype_config
        
    except Exception as e:
        logger.error(f"❌ Doctype validation failed: {str(e)}")
        raise


def load_prompt_module(prompt_module_path: str):
    """
    Load prompt module dynamically
    
    Returns:
        Module: Loaded prompt module
    """
    print_section("STEP 3: LOADING PROMPT MODULE")
    
    try:
        logger.info(f"📦 Loading prompt module: {prompt_module_path}")
        
        # Dynamic import
        module_parts = prompt_module_path.split('.')
        module_name = module_parts[-1]
        
        logger.info(f"   Module path: {prompt_module_path}")
        logger.info(f"   Module name: {module_name}")
        
        # Try to import
        try:
            module = __import__(prompt_module_path, fromlist=[module_name])
            logger.info(f"✓ Prompt module loaded successfully")
        except ImportError as e:
            logger.error(f"❌ Failed to import prompt module: {str(e)}")
            logger.error(f"   Make sure prompts/{module_name}.py exists")
            logger.error(f"   Current directory: {os.getcwd()}")
            
            if os.path.exists('prompts'):
                logger.error(f"   Files in prompts/: {os.listdir('prompts')}")
            else:
                logger.error(f"   prompts/ directory not found!")
            
            raise
        
        # Validate module has FIELD_LIBRARY
        if not hasattr(module, 'FIELD_LIBRARY'):
            logger.error(f"❌ Module missing FIELD_LIBRARY")
            logger.error(f"   Available attributes: {dir(module)}")
            raise ValueError(f"Prompt module missing FIELD_LIBRARY")
        
        field_count = len(module.FIELD_LIBRARY)
        logger.info(f"✓ FIELD_LIBRARY loaded with {field_count} fields")
        logger.info(f"   Fields: {', '.join(list(module.FIELD_LIBRARY.keys())[:5])}...")
        
        return module
        
    except Exception as e:
        logger.error(f"❌ Prompt module loading failed: {str(e)}")
        logger.exception("Full traceback:")
        raise


def initialize_azure_services(config: Dict, doctype_config: Dict):
    """
    Initialize Azure service connections
    
    Returns:
        Dict: Initialized service clients
    """
    print_section("STEP 4: INITIALIZING AZURE SERVICES")
    
    services = {}
    
    try:
        # 1. Key Vault Manager (flexible - works with OR without Key Vault)
        logger.info("🔐 Initializing Key Vault Manager...")
        try:
            from keyvault_manager import KeyVaultManager, resolve_config_values
            
            # Get vault URL (string or None)
            vault_url = config.get('azure_keyvault', {}).get('vault_url')
            
            # Initialize (pass vault_url as string)
            kv_manager = KeyVaultManager(vault_url)
            services['keyvault'] = kv_manager
            
            # Resolve all configuration values
            logger.info("📝 Resolving configuration values...")
            resolve_config_values(config, kv_manager)
            resolve_config_values(doctype_config, kv_manager)
            
            logger.info(f"✓ Configuration values resolved")
            
        except ImportError as e:
            logger.error(f"❌ Cannot import KeyVaultManager: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"❌ Configuration resolution failed: {str(e)}")
            logger.exception("Full traceback:")
            raise
        
        # 2. Blob Storage
        logger.info("💾 Initializing Azure Blob Storage...")
        try:
            from helper import BlobManager
            
            # Value already resolved by resolve_config_values()
            conn_string = config['azure_blob']['connection_string']
            
            blob_manager = BlobManager(conn_string)
            services['blob'] = blob_manager
            logger.info(f"✓ Blob Storage initialized")
            
            # Test containers
            input_container = config['azure_blob']['inputcontainer']
            logger.info(f"   Input container: {input_container}")
            
        except ImportError as e:
            logger.error(f"❌ Cannot import BlobManager: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"❌ Blob Storage initialization failed: {str(e)}")
            raise
        
        # 3. Document Intelligence
        logger.info("📄 Initializing Document Intelligence...")
        try:
            from documentintelligence_ocr import DocumentIntelligenceOCR
            
            # Values already resolved by resolve_config_values()
            doc_intel_config = config['azure_document_intelligence']
            
            doc_intel_config_resolved = {
                'endpoint': doc_intel_config['endpoint'],
                'key': doc_intel_config['key'],
                'api_version': doc_intel_config.get('api_version', '2024-07-31-preview')
            }
            
            ocr_manager = DocumentIntelligenceOCR(doc_intel_config_resolved)
            services['ocr'] = ocr_manager
            logger.info(f"✓ Document Intelligence initialized")
            logger.info(f"   API Version: {doc_intel_config_resolved['api_version']}")
            
        except ImportError as e:
            logger.error(f"❌ Cannot import DocumentIntelligenceOCR: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"❌ Document Intelligence initialization failed: {str(e)}")
            raise
        
        # 4. OpenAI (GPT)
        logger.info("🤖 Initializing Azure OpenAI (GPT)...")
        try:
            # Values already resolved by resolve_config_values()
            openai_config = doctype_config['azure_openai']['general']
            
            services['openai'] = {
                'endpoint': openai_config['endpoint'],
                'api_key': openai_config['api_key'],
                'deployment': openai_config['deployment_name'],
                'model': openai_config['model_name']
            }
            
            logger.info(f"✓ OpenAI initialized")
            logger.info(f"   Model: {openai_config['model_name']}")
            logger.info(f"   Deployment: {openai_config['deployment_name']}")
            
        except Exception as e:
            logger.error(f"❌ OpenAI initialization failed: {str(e)}")
            raise
        
        # 5. Embeddings
        logger.info("🔤 Initializing Azure OpenAI (Embeddings)...")
        try:
            embedding_config = doctype_config['azure_openai_embedding']
            
            services['embeddings'] = {
                'deployment': embedding_config['deployment_name'],
                'model': embedding_config['model_name'],
                'dimensions': embedding_config.get('dimensions', 1536)
            }
            
            logger.info(f"✓ Embeddings initialized")
            logger.info(f"   Model: {embedding_config['model_name']}")
            logger.info(f"   Dimensions: {embedding_config.get('dimensions', 1536)}")
            
        except Exception as e:
            logger.error(f"❌ Embeddings initialization failed: {str(e)}")
            raise
        
        # 6. AI Search
        logger.info("🔍 Initializing Azure AI Search...")
        try:
            # Values already resolved by resolve_config_values()
            search_config = doctype_config['azure_ai_search']
            
            services['search'] = {
                'endpoint': search_config['endpoint'],
                'key': search_config['key'],
                'index_name': search_config['index_name']
            }
            
            logger.info(f"✓ AI Search initialized")
            logger.info(f"   Index: {search_config['index_name']}")
            
        except Exception as e:
            logger.error(f"❌ AI Search initialization failed: {str(e)}")
            raise
        
        logger.info("")
        logger.info(f"✓ All Azure services initialized successfully!")
        
        return services
        
    except Exception as e:
        logger.error(f"❌ Azure services initialization failed: {str(e)}")
        logger.exception("Full traceback:")
        raise


def discover_providers(blob_manager, input_container: str) -> List[str]:
    """
    Discover all providers in input container
    
    Returns:
        List: Provider names
    """
    print_section("STEP 5: DISCOVERING PROVIDERS")
    
    try:
        logger.info(f"📂 Scanning container: {input_container}")
        
        folder_structure = blob_manager.get_folder_structure(input_container)
        
        providers = list(folder_structure.keys())
        provider_count = len(providers)
        
        logger.info(f"✓ Found {provider_count} providers")
        
        if provider_count == 0:
            logger.warning(f"⚠️  No providers found in container '{input_container}'")
            logger.warning(f"   Make sure your input container has providers in format:")
            logger.warning(f"   inputcontainer/Provider_Name/Folder/document.pdf")
            return []
        
        # Show first few providers
        for i, provider in enumerate(providers[:5], 1):
            folders = folder_structure[provider]
            logger.info(f"   {i}. {provider} ({len(folders)} folders)")
        
        if provider_count > 5:
            logger.info(f"   ... and {provider_count - 5} more providers")
        
        return providers
        
    except Exception as e:
        logger.error(f"❌ Provider discovery failed: {str(e)}")
        logger.exception("Full traceback:")
        raise


def process_providers(providers: List[str], config: Dict, services: Dict, doctype: str):
    """
    Process all providers in batches
    """
    print_section("STEP 6: PROCESSING PROVIDERS")
    
    try:
        batch_size = config['processing'].get('batch_size', 10)
        total_providers = len(providers)
        total_batches = (total_providers + batch_size - 1) // batch_size
        
        logger.info(f"📊 Processing configuration:")
        logger.info(f"   Total providers: {total_providers}")
        logger.info(f"   Batch size: {batch_size}")
        logger.info(f"   Total batches: {total_batches}")
        logger.info("")
        
        if total_providers == 0:
            logger.warning("⚠️  No providers to process!")
            return
        
        # Process in batches
        for batch_num in range(total_batches):
            start_idx = batch_num * batch_size
            end_idx = min(start_idx + batch_size, total_providers)
            batch_providers = providers[start_idx:end_idx]
            
            logger.info(f"")
            logger.info(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            logger.info(f"BATCH {batch_num + 1}/{total_batches} (Providers {start_idx + 1}-{end_idx})")
            logger.info(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            
            for provider_idx, provider in enumerate(batch_providers, 1):
                global_idx = start_idx + provider_idx
                logger.info(f"")
                logger.info(f"Provider {global_idx}/{total_providers}: {provider}")
                logger.info(f"─────────────────────────────────────────────────────────────────────────────────")
                
                try:
                    # TODO: Actual processing logic here
                    logger.info(f"   ⚠️  Document processing not yet implemented (template only)")
                    logger.info(f"   This is where document_processor.py integration would happen")
                    logger.info(f"   See RAG_INTEGRATION_STATUS.md for implementation guide")
                    
                except Exception as e:
                    logger.error(f"   ❌ Provider processing failed: {str(e)}")
                    logger.exception("   Full traceback:")
                    continue
        
        logger.info("")
        logger.info(f"✓ Batch processing complete")
        
    except Exception as e:
        logger.error(f"❌ Provider processing failed: {str(e)}")
        logger.exception("Full traceback:")
        raise


def main():
    """Main application entry point"""
    
    try:
        # CLI arguments
        parser = argparse.ArgumentParser(description='Medical Document Parser')
        parser.add_argument('--doctype', required=True, help='Document type (cred, bus, claim)')
        parser.add_argument('--apitype', required=True, help='API type (general, batch)')
        parser.add_argument('--archive', default='false', help='Enable archiving (true, false)')
        
        args = parser.parse_args()
        
        print_section("MEDICAL DOCUMENT PARSER - PRODUCTION SYSTEM", "═")
        logger.info(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Arguments:")
        logger.info(f"   Doctype: {args.doctype}")
        logger.info(f"   API Type: {args.apitype}")
        logger.info(f"   Archive: {args.archive}")
        
        # Step 1: Load configuration
        config = load_configuration()
        
        # Step 2: Validate doctype config
        doctype_config = validate_doctype_config(config, args.doctype)
        
        # Step 3: Load prompt module
        prompt_module = load_prompt_module(doctype_config['prompt_module'])
        
        # Step 4: Initialize Azure services
        services = initialize_azure_services(config, doctype_config)
        
        # Step 5: Discover providers
        providers = discover_providers(
            services['blob'],
            config['azure_blob']['inputcontainer']
        )
        
        # Step 6: Process providers
        process_providers(providers, config, services, args.doctype)
        
        # Summary
        print_section("PROCESSING COMPLETE", "═")
        logger.info(f"End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"✓ System ran successfully!")
        logger.info(f"⚠️  Note: Document processing logic needs implementation")
        logger.info(f"   See document_processor.py for integration template")
        
    except KeyboardInterrupt:
        logger.warning("")
        logger.warning("⚠️  Process interrupted by user (Ctrl+C)")
        sys.exit(1)
    except Exception as e:
        logger.error("")
        logger.error("❌ FATAL ERROR")
        logger.error(f"   {str(e)}")
        logger.exception("Full traceback:")
        sys.exit(1)


if __name__ == "__main__":
    main()
