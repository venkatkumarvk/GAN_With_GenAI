"""
MEDICAL DOCUMENT PARSER - PRODUCTION WITH RAG
Includes complete RAG-based extraction workflow from POC
"""

import os
import sys
import json
import logging
import argparse
from datetime import datetime
from typing import Dict, List, Any

# Fix encoding for Windows
if sys.platform == 'win32':
    if sys.stdout.encoding != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')
    if sys.stderr.encoding != 'utf-8':
        sys.stderr.reconfigure(encoding='utf-8')

# Create logs directory
logs_dir = 'logs'
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)
    print(f"Created logs directory: {logs_dir}/")

# Setup logging
log_filename = os.path.join(logs_dir, f'parser_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_filename, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


def print_section(title: str, char: str = "="):
    """Print a formatted section header"""
    logger.info("")
    logger.info(char * 80)
    logger.info(title)
    logger.info(char * 80)


def load_configuration(config_path: str = "config.json") -> Dict:
    """Load and validate configuration file"""
    print_section("STEP 1: LOADING CONFIGURATION")
    
    try:
        logger.info(f"Looking for config file: {config_path}")
        
        if not os.path.exists(config_path):
            logger.error(f"Config file not found: {config_path}")
            raise FileNotFoundError(f"Config file not found: {config_path}")
        
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        logger.info(f"Config file loaded successfully")
        logger.info(f"Found {len(config['doctypes'])} doctypes: {', '.join(config['doctypes'].keys())}")
        
        return config
        
    except Exception as e:
        logger.error(f"Configuration loading failed: {str(e)}")
        raise


def validate_doctype_config(config: Dict, doctype: str) -> Dict:
    """Validate doctype-specific configuration"""
    print_section(f"STEP 2: VALIDATING DOCTYPE '{doctype}' CONFIG")
    
    try:
        logger.info(f"Checking doctype: {doctype}")
        
        if doctype not in config['doctypes']:
            raise ValueError(f"Doctype '{doctype}' not configured")
        
        doctype_config = config['doctypes'][doctype]
        folders = list(doctype_config['folder_configs'].keys())
        logger.info(f"Doctype '{doctype}' found with folders: {', '.join(folders)}")
        
        return doctype_config
        
    except Exception as e:
        logger.error(f"Doctype validation failed: {str(e)}")
        raise


def load_prompt_module(prompt_module_path: str):
    """Load prompt module dynamically"""
    print_section("STEP 3: LOADING PROMPT MODULE")
    
    try:
        logger.info(f"Loading prompt module: {prompt_module_path}")
        
        module_parts = prompt_module_path.split('.')
        module_name = module_parts[-1]
        
        module = __import__(prompt_module_path, fromlist=[module_name])
        
        field_count = len(module.FIELD_LIBRARY)
        logger.info(f"Prompt module loaded - {field_count} fields available")
        
        return module
        
    except Exception as e:
        logger.error(f"Prompt module loading failed: {str(e)}")
        raise


def initialize_azure_services(config: Dict, doctype_config: Dict):
    """Initialize Azure service connections"""
    print_section("STEP 4: INITIALIZING AZURE SERVICES")
    
    services = {}
    
    try:
        from keyvault_manager import KeyVaultManager, resolve_config_values
        from helper import BlobManager, OpenAIManager, SearchManager
        from documentintelligence_ocr import DocumentIntelligenceOCR
        from costtracking import CostTracker
        
        # Key Vault
        logger.info("Initializing Key Vault Manager...")
        vault_url = config.get('azure_keyvault', {}).get('vault_url')
        kv_manager = KeyVaultManager(vault_url)
        services['keyvault'] = kv_manager
        
        logger.info("Resolving configuration values...")
        resolve_config_values(config, kv_manager)
        resolve_config_values(doctype_config, kv_manager)
        logger.info("Configuration values resolved")
        
        # Blob Storage
        logger.info("Initializing Blob Storage...")
        blob_manager = BlobManager(config['azure_blob']['connection_string'])
        services['blob'] = blob_manager
        logger.info("Blob Storage initialized")
        
        # Document Intelligence (OCR)
        logger.info("Initializing Document Intelligence...")
        doc_intel_config = config['azure_document_intelligence']
        ocr_manager = DocumentIntelligenceOCR({
            'endpoint': doc_intel_config['endpoint'],
            'key': doc_intel_config['key'],
            'api_version': doc_intel_config.get('api_version', '2024-07-31-preview')
        })
        services['ocr'] = ocr_manager
        logger.info("Document Intelligence initialized")
        
        # OpenAI Manager (for extraction + embeddings)
        logger.info("Initializing OpenAI Manager...")
        openai_config = doctype_config['azure_openai']['general']
        embedding_config = doctype_config['azure_openai_embedding']
        
        # Get batch config if available
        batch_config = doctype_config['azure_openai'].get('batch')
        
        openai_manager = OpenAIManager(
            openai_config=openai_config,
            embedding_config=embedding_config,
            batch_config=batch_config  # Optional - for Batch API
        )
        services['openai'] = openai_manager
        
        if batch_config:
            logger.info(f"OpenAI Manager initialized - General: {openai_config['model_name']}, Batch: {batch_config['model_name']}")
        else:
            logger.info(f"OpenAI Manager initialized - Model: {openai_config['model_name']} (Batch API: disabled)")
        
        # AI Search Manager (for RAG)
        logger.info("Initializing AI Search...")
        search_config = doctype_config['azure_ai_search']
        search_manager = SearchManager(
            endpoint=search_config['endpoint'],
            api_key=search_config['key'],  # Fixed: api_key parameter
            index_name=search_config['index_name']
        )
        
        # Auto-create index if it doesn't exist (PRODUCTION READY!)
        logger.info(f"Checking if index '{search_config['index_name']}' exists...")
        try:
            created = search_manager.create_universal_index()
            if created:
                logger.info(f"✅ Created new index: {search_config['index_name']}")
            else:
                logger.info(f"✅ Index already exists: {search_config['index_name']}")
        except Exception as e:
            logger.warning(f"Index check/creation: {e}")
            logger.info("Continuing with existing index...")
        
        services['search'] = search_manager
        logger.info(f"AI Search initialized - Index: {search_config['index_name']}")
        
        # Cost Tracker
        cost_tracker = CostTracker(config.get('costs', {}))
        services['cost_tracker'] = cost_tracker
        logger.info("Cost Tracker initialized")
        
        logger.info("All Azure services initialized successfully!")
        
        return services
        
    except Exception as e:
        logger.error(f"Azure services initialization failed: {str(e)}")
        raise


def discover_providers(blob_manager, input_container: str):
    """Discover all providers"""
    print_section("STEP 5: DISCOVERING PROVIDERS")
    
    try:
        logger.info(f"Scanning container: {input_container}")
        
        folder_structure = blob_manager.get_folder_structure(input_container)
        providers = list(folder_structure.keys())
        
        logger.info(f"Found {len(providers)} providers")
        
        if len(providers) == 0:
            logger.warning("No providers found")
            return [], {}
        
        for i, provider in enumerate(providers[:5], 1):
            folders = folder_structure[provider]
            logger.info(f"   {i}. {provider} ({len(folders)} folders)")
        
        if len(providers) > 5:
            logger.info(f"   ... and {len(providers) - 5} more providers")
        
        return providers, folder_structure
        
    except Exception as e:
        logger.error(f"Provider discovery failed: {str(e)}")
        raise


def process_document_with_rag(doc_blob, provider: str, folder: str, fields: List[str],
                              services: Dict, config: Dict, prompt_module) -> Dict:
    """
    Process a single document using MULTIMODAL RAG-based extraction
    
    Workflow:
    1. Download document
    2. Convert to images (PDF → images per page, DOCX → PDF → images)
    3. Convert images to base64
    4. Generate embeddings from images
    5. Index in AI Search
    6. RAG search for similar documents
    7. Build prompt with RAG examples
    8. GPT-4o Vision extraction (processes images directly)
    
    This is BETTER than OCR because:
    - Vision model sees layout, forms, tables
    - No information loss
    - Handles handwriting better
    - Understands visual context
    """
    doc_name = doc_blob.name.split('/')[-1]
    
    try:
        # Import multimodal RAG module
        from multimodal_rag import process_multimodal_rag
        from document_converter import DocumentConverter
        
        # Get document extension
        _, ext = os.path.splitext(doc_name)
        
        # Download document
        logger.info(f"      Step 1: Downloading {doc_name}...")
        doc_bytes = services['blob'].download_blob(
            config['azure_blob']['inputcontainer'],
            doc_blob.name
        )
        
        if not doc_bytes:
            logger.error(f"      Failed to download {doc_name}")
            return None
        
        logger.info(f"      Downloaded {len(doc_bytes)} bytes")
        
        # Prepare document info
        doc_info = {
            'name': doc_name,
            'filename': doc_name,
            'extension': ext,
            'blob_name': doc_blob.name,
            'provider': provider,
            'folder': folder
        }
        
        # Prepare folder config
        folder_config = {
            'fields': fields,
            'description': 'Medical credentials extraction'
        }
        
        # Process with MULTIMODAL RAG
        extracted_data, success = process_multimodal_rag(
            doc_bytes=doc_bytes,  # Pass original document bytes
            doc_info=doc_info,
            provider=provider,
            folder=folder,
            folder_config=folder_config,
            ocr=services['ocr'],
            openai_manager=services['openai'],
            search_manager=services['search'],
            cost_tracker=services['cost_tracker'],
            config=config,
            prompt_module=prompt_module,  # Pass prompt_module
            logger=logger
        )
        
        if not success:
            logger.error(f"      RAG extraction failed for {doc_name}")
            return None
        
        return extracted_data
        
    except Exception as e:
        logger.error(f"      Document processing failed: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return None


def calculate_best_values(documents: List[Dict], fields: List[str], folder_name: str) -> Dict:
    """
    Calculate best values using BOTH frequency and confidence (POC logic)
    
    Strategy:
    1. Group values by frequency (most common value wins)
    2. If tie in frequency, choose highest confidence
    3. Track source file and folder for each field
    
    Args:
        documents: List of processed documents with fields
        fields: List of field names
        folder_name: Folder name for source tracking
    
    Returns:
        Dict with best values including source tracking
    """
    from collections import Counter
    
    best_values = {}
    
    for field in fields:
        field_occurrences = []  # List of (value, confidence, file) tuples
        
        for doc in documents:
            if field in doc['fields']:
                field_data = doc['fields'][field]
                
                if isinstance(field_data, dict):
                    value = field_data.get('value', 'NA')
                    confidence = field_data.get('confidence', 0)
                    
                    if confidence is not None and value != 'NA':
                        field_occurrences.append((
                            value,
                            float(confidence),
                            doc.get('document_name', 'Unknown')
                        ))
        
        if field_occurrences:
            # Count frequency of each value
            value_counts = Counter([v[0] for v in field_occurrences])
            
            # Get most common value
            most_common_value, max_frequency = value_counts.most_common(1)[0]
            
            # Get all occurrences of the most common value
            candidates = [occ for occ in field_occurrences if occ[0] == most_common_value]
            
            # Pick the one with highest confidence
            best_occurrence = max(candidates, key=lambda x: x[1])
            best_value, best_confidence, source_file = best_occurrence
            
            # Calculate average confidence for this value
            confidences_for_value = [occ[1] for occ in candidates]
            avg_confidence = sum(confidences_for_value) / len(confidences_for_value)
            
            best_values[field] = {
                'value': best_value,
                'confidence': round(avg_confidence, 2),
                'source_folder': folder_name,
                'source_file': source_file,
                'frequency': max_frequency,
                'total_documents': len(documents)
            }
        else:
            # Field not found in any document
            best_values[field] = {
                'value': 'NA',
                'confidence': 0.0,
                'source_folder': folder_name,
                'source_file': 'Not found',
                'frequency': 0,
                'total_documents': len(documents)
            }
    
    return best_values


def save_results(provider: str, extracted_data: Dict, output_container: str, blob_manager, 
                config: Dict, total_documents: int, folder_name: str):
    """
    Save extraction results to output container
    
    CSV Format: SINGLE ROW per provider with all fields as columns
    - provider_name, provider_id, extraction_datetime, total_documents_processed, folders_processed
    - field1, field1_confidence, field1_source_folder, field1_source_file
    - field2, field2_confidence, field2_source_folder, field2_source_file
    - ... (for all fields)
    """
    try:
        import csv
        from io import StringIO
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        extraction_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Calculate overall confidence
        confidences = []
        for field_data in extracted_data.values():
            if isinstance(field_data, dict) and 'confidence' in field_data:
                confidences.append(field_data.get('confidence', 0))
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0
        
        # Determine folder based on confidence
        confidence_threshold = config.get('extraction', {}).get('confidence_threshold', 0.70)
        if avg_confidence >= confidence_threshold:
            output_folder = "highconfidence"
        else:
            output_folder = "lowconfidence"
        
        # Provider ID = provider_timestamp (unique Azure AI Search ID)
        provider_id = f"{provider}_{timestamp}"
        
        # JSON output (same as before)
        json_path = f"{output_folder}/{provider}/ProcessedJSONResult/{provider}_{timestamp}.json"
        json_content = json.dumps(extracted_data, indent=2)
        blob_manager.upload_blob(output_container, json_path, json_content)
        logger.info(f"      Saved JSON: {json_path}")
        
        # CSV output - SINGLE ROW format (POC style)
        csv_lines = []
        
        # Get field order from extracted_data
        field_order = list(extracted_data.keys())
        
        # Build headers
        headers = [
            'provider_name',
            'provider_id',
            'extraction_datetime',
            'total_documents_processed',
            'folders_processed'
        ]
        
        # Add field columns (4 columns per field)
        for field in field_order:
            headers.append(f'{field}')
            headers.append(f'{field}_confidence')
            headers.append(f'{field}_source_folder')
            headers.append(f'{field}_source_file')
        
        csv_lines.append(','.join(headers))
        
        # Escape function for CSV values
        def escape_csv(value):
            """Escape CSV values - wrap in quotes if contains comma, quote, or newline"""
            value_str = str(value)
            if ',' in value_str or '"' in value_str or '\n' in value_str or '\r' in value_str:
                # Escape quotes by doubling them
                value_str = value_str.replace('"', '""')
                return f'"{value_str}"'
            return value_str
        
        # Build ONE row for the provider
        row_values = [
            escape_csv(provider),                    # provider_name
            escape_csv(provider_id),                 # provider_id (unique)
            escape_csv(extraction_datetime),         # extraction_datetime
            escape_csv(total_documents),             # total_documents_processed
            escape_csv(folder_name)                  # folders_processed
        ]
        
        # Add field values
        for field in field_order:
            field_data = extracted_data[field]
            if isinstance(field_data, dict):
                row_values.append(escape_csv(field_data.get('value', 'NA')))
                row_values.append(escape_csv(field_data.get('confidence', 0)))
                row_values.append(escape_csv(field_data.get('source_folder', folder_name)))
                row_values.append(escape_csv(field_data.get('source_file', 'multiple')))
            else:
                # Fallback if format is wrong
                row_values.append(escape_csv(field_data))
                row_values.append(escape_csv(0))
                row_values.append(escape_csv(folder_name))
                row_values.append(escape_csv('unknown'))
        
        csv_lines.append(','.join(row_values))
        
        # Save CSV
        csv_path = f"{output_folder}/{provider}/ProcessedCSVResult/{provider}_{timestamp}.csv"
        csv_content = '\n'.join(csv_lines)
        blob_manager.upload_blob(output_container, csv_path, csv_content)
        logger.info(f"      Saved CSV: {csv_path}")
        
        logger.info(f"      Average confidence: {avg_confidence:.2f} -> {output_folder}")
        
        return avg_confidence
        
    except Exception as e:
        logger.error(f"      Failed to save results: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        raise


def process_single_provider(provider: str, folder_structure: Dict, blob_manager, 
                            config: Dict, services: Dict, doctype: str, 
                            doctype_config: Dict, prompt_module):
    """Process a single provider's documents with RAG"""
    try:
        if provider not in folder_structure:
            logger.warning(f"   Provider not found")
            return
        
        provider_folders = folder_structure[provider]
        folder_configs = doctype_config['folder_configs']
        
        # Get folder names
        provider_folder_names = list(provider_folders.keys()) if isinstance(provider_folders, dict) else provider_folders
        
        # Find matching folder
        matching_folder = None
        for folder_name in folder_configs.keys():
            if folder_name in provider_folder_names:
                matching_folder = folder_name
                break
        
        if not matching_folder:
            logger.warning(f"   No matching folder found")
            logger.warning(f"   Expected: {list(folder_configs.keys())}")
            logger.warning(f"   Found: {provider_folder_names}")
            return
        
        logger.info(f"   Processing folder: {matching_folder}")
        
        # Get documents
        folder_path = f"{provider}/{matching_folder}"
        documents = blob_manager.list_blobs_in_folder(
            config['azure_blob']['inputcontainer'],
            folder_path
        )
        
        logger.info(f"   Found {len(documents)} documents (including all subfolders)")
        
        if len(documents) == 0:
            logger.warning(f"   No documents to process")
            return
        
        # Get fields
        fields = folder_configs[matching_folder]['fields']
        logger.info(f"   Extracting {len(fields)} fields using RAG approach")
        
        # Store ALL extracted data from all documents (not just aggregated)
        all_documents_data = []
        
        # Process each document with RAG
        for doc_idx, doc_blob in enumerate(documents, 1):
            # Extract subfolder path from blob name
            relative_path = doc_blob.name.replace(f"{provider}/", "")
            
            logger.info(f"   Document {doc_idx}/{len(documents)}: {relative_path}")
            
            extracted_data = process_document_with_rag(
                doc_blob,
                provider,
                matching_folder,
                fields,
                services,
                config,
                prompt_module  # Pass prompt_module
            )
            
            if not extracted_data:
                continue
            
            # Store document data with metadata
            all_documents_data.append({
                'document_name': doc_blob.name.split('/')[-1],
                'relative_path': relative_path,
                'fields': extracted_data
            })
            
            logger.info(f"      Document processed successfully with RAG")
        
        # Aggregate results using FREQUENCY + CONFIDENCE (POC logic)
        if all_documents_data:
            logger.info(f"   Aggregating results from {len(all_documents_data)} documents...")
            
            # Calculate best values using frequency and confidence
            final_results = calculate_best_values(
                all_documents_data, 
                fields,
                matching_folder
            )
            
            # Save aggregated results
            logger.info(f"   Saving aggregated results...")
            avg_confidence = save_results(
                provider,
                final_results,
                config['azure_blob']['outputcontainer'],
                services['blob'],
                config,
                len(documents),
                matching_folder
            )
            logger.info(f"   Provider processing complete - Confidence: {avg_confidence:.2f}")
        else:
            logger.warning(f"   No data extracted from any document")
        
    except Exception as e:
        logger.error(f"   Provider failed: {str(e)}")
        logger.exception("   Traceback:")


def process_providers(providers: List[str], folder_structure: Dict, config: Dict, 
                     services: Dict, doctype: str, doctype_config: Dict, prompt_module):
    """Process all providers in batches"""
    print_section("STEP 6: PROCESSING PROVIDERS WITH RAG")
    
    try:
        batch_size = config['processing'].get('batch_size', 10)
        total_providers = len(providers)
        total_batches = (total_providers + batch_size - 1) // batch_size
        
        logger.info(f"Processing configuration:")
        logger.info(f"   Total providers: {total_providers}")
        logger.info(f"   Batch size: {batch_size}")
        logger.info(f"   RAG mode: {config['rag']['mode']}")
        logger.info(f"   Total batches: {total_batches}")
        
        if total_providers == 0:
            logger.warning("No providers to process")
            return
        
        # Process in batches
        for batch_num in range(total_batches):
            start_idx = batch_num * batch_size
            end_idx = min(start_idx + batch_size, total_providers)
            batch_providers = providers[start_idx:end_idx]
            
            logger.info("")
            logger.info("=" * 80)
            logger.info(f"BATCH {batch_num + 1}/{total_batches} (Providers {start_idx + 1}-{end_idx})")
            logger.info("=" * 80)
            
            for provider_idx, provider in enumerate(batch_providers, 1):
                global_idx = start_idx + provider_idx
                logger.info("")
                logger.info(f"Provider {global_idx}/{total_providers}: {provider}")
                logger.info("-" * 80)
                
                process_single_provider(
                    provider,
                    folder_structure,
                    services['blob'], 
                    config, 
                    services, 
                    doctype,
                    doctype_config,
                    prompt_module
                )
        
        logger.info("")
        logger.info("Batch processing complete")
        
        # Show cost summary
        cost_summary = services['cost_tracker'].get_summary()
        logger.info("")
        logger.info("COST SUMMARY:")
        logger.info(f"   Total cost: ${cost_summary['total']:.2f}")
        logger.info(f"   OCR: ${cost_summary.get('ocr', 0):.2f}")
        logger.info(f"   GPT: ${cost_summary.get('gpt', 0):.2f}")
        logger.info(f"   Embeddings: ${cost_summary.get('embeddings', 0):.2f}")
        
    except Exception as e:
        logger.error(f"Processing failed: {str(e)}")
        raise


def main():
    """Main application entry point"""
    
    try:
        # Parse command-line arguments
        parser = argparse.ArgumentParser(description='Medical Document Parser with RAG')
        parser.add_argument('--apitype', required=True, choices=['general', 'batch'], 
                          help='API type: general (real-time) or batch (50%% cheaper)')
        parser.add_argument('--doctype', required=True, 
                          help='Document type (e.g., cred)')
        parser.add_argument('--archive', required=True, choices=['true', 'false'],
                          help='Enable archiving: true or false')
        
        args = parser.parse_args()
        
        # Convert string 'true'/'false' to boolean
        archive_enabled = args.archive.lower() == 'true'
        
        print_section("MEDICAL DOCUMENT PARSER - RAG-BASED PRODUCTION SYSTEM", "=")
        logger.info(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Log file: {log_filename}")
        logger.info(f"Arguments: --apitype {args.apitype} --doctype {args.doctype} --archive {args.archive}")
        
        # Load configuration
        config = load_configuration()
        
        # Override config with command-line arguments
        config['extraction']['api_type'] = args.apitype
        config['extraction']['archive'] = archive_enabled
        
        # Get RAG mode from config
        rag_mode = config.get('extraction', {}).get('rag_mode', 'text')
        logger.info(f"Settings: API={args.apitype} | RAG={rag_mode} | Archive={args.archive}")
        
        # Validate and initialize
        doctype_config = validate_doctype_config(config, args.doctype)
        prompt_module = load_prompt_module(doctype_config['prompt_module'])
        services = initialize_azure_services(config, doctype_config)
        providers, folder_structure = discover_providers(services['blob'], config['azure_blob']['inputcontainer'])
        process_providers(providers, folder_structure, config, services, args.doctype, doctype_config, prompt_module)
        
        print_section("PROCESSING COMPLETE", "=")
        logger.info(f"End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Log saved: {log_filename}")
        logger.info(f"Check output container for results!")
        
    except KeyboardInterrupt:
        logger.warning("Process interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error("FATAL ERROR")
        logger.error(f"   {str(e)}")
        logger.exception("Traceback:")
        sys.exit(1)


if __name__ == "__main__":
    main()
