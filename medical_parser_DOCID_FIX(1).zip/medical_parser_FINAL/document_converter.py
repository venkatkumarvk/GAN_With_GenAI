"""
Document to Image Converter
Converts any document type to images for multimodal processing
Uses ONLY PyMuPDF (fitz) - no other dependencies needed
"""

import fitz  # PyMuPDF
import base64
import logging
from io import BytesIO
from typing import List, Tuple
import os

logger = logging.getLogger(__name__)


class DocumentConverter:
    """
    Converts documents to images for multimodal RAG processing
    
    Supports:
    - PDF (multi-page)
    - Images (PNG, JPG, JPEG, TIFF, BMP, GIF, WEBP)
    - DOCX (convert to PDF first, then images)
    - DOC (convert to PDF first, then images)
    """
    
    def __init__(self, dpi: int = 200):
        """
        Initialize converter
        
        Args:
            dpi: Resolution for PDF to image conversion (default 200, good quality)
                 - 150 = fast, lower quality
                 - 200 = balanced (recommended)
                 - 300 = high quality, slower
        """
        self.dpi = dpi
        self.zoom = dpi / 72  # PDF standard is 72 DPI
        
    def convert_to_images(self, file_bytes: bytes, filename: str) -> List[Tuple[bytes, str]]:
        """
        Convert any document to list of images
        
        Args:
            file_bytes: Document bytes
            filename: Original filename (to determine type)
        
        Returns:
            List of (image_bytes, page_info) tuples
            page_info = "page_1", "page_2", etc. or "image" for single images
        """
        ext = os.path.splitext(filename)[1].lower()
        
        if ext == '.pdf':
            return self._convert_pdf_to_images(file_bytes)
        
        elif ext in ['.png', '.jpg', '.jpeg', '.tiff', '.tif', '.bmp', '.gif', '.webp']:
            return self._handle_image(file_bytes, ext)
        
        elif ext in ['.docx', '.doc']:
            # Convert DOCX/DOC to PDF first, then to images
            return self._convert_office_to_images(file_bytes, ext)
        
        else:
            logger.warning(f"Unsupported file type: {ext}")
            return []
    
    def _convert_pdf_to_images(self, pdf_bytes: bytes) -> List[Tuple[bytes, str]]:
        """
        Convert PDF to list of images (one per page)
        
        Returns:
            List of (image_bytes, "page_N") tuples
        """
        images = []
        
        try:
            # Open PDF from bytes
            doc = fitz.open(stream=pdf_bytes, filetype="pdf")
            
            # Convert each page to image
            for page_num in range(len(doc)):
                page = doc[page_num]
                
                # Render page to image
                mat = fitz.Matrix(self.zoom, self.zoom)
                pix = page.get_pixmap(matrix=mat, alpha=False)
                
                # Convert to PNG bytes
                img_bytes = pix.tobytes("png")
                
                images.append((img_bytes, f"page_{page_num + 1}"))
                
                logger.debug(f"Converted PDF page {page_num + 1} to image")
            
            doc.close()
            
            logger.info(f"Converted PDF to {len(images)} images")
            return images
            
        except Exception as e:
            logger.error(f"Error converting PDF to images: {e}")
            return []
    
    def _handle_image(self, image_bytes: bytes, ext: str) -> List[Tuple[bytes, str]]:
        """
        Handle image files (already in image format)
        
        For multi-page TIFFs, extract each page
        For single images, return as-is
        """
        images = []
        
        try:
            # For TIFF, check if multi-page
            if ext in ['.tiff', '.tif']:
                # PyMuPDF can handle multi-page TIFF
                doc = fitz.open(stream=image_bytes, filetype="tiff")
                
                for page_num in range(len(doc)):
                    page = doc[page_num]
                    pix = page.get_pixmap()
                    img_bytes = pix.tobytes("png")
                    images.append((img_bytes, f"page_{page_num + 1}"))
                
                doc.close()
                logger.info(f"Extracted {len(images)} pages from TIFF")
                
            else:
                # Single image - return as-is
                images.append((image_bytes, "image"))
                logger.debug(f"Loaded single image: {ext}")
            
            return images
            
        except Exception as e:
            logger.error(f"Error handling image: {e}")
            return []
    
    def _convert_office_to_images(self, doc_bytes: bytes, ext: str) -> List[Tuple[bytes, str]]:
        """
        Convert DOCX/DOC to images via PDF conversion
        
        Note: This requires LibreOffice or similar for DOC/DOCX → PDF
        Alternative: Use cloud conversion service or skip this format
        """
        logger.warning(f"DOCX/DOC conversion not implemented - requires LibreOffice")
        logger.warning(f"Recommendation: Ask users to provide PDFs instead of DOCX/DOC")
        return []
    
    def images_to_base64(self, images: List[Tuple[bytes, str]]) -> List[Tuple[str, str]]:
        """
        Convert image bytes to base64 for API calls
        
        Args:
            images: List of (image_bytes, page_info) tuples
        
        Returns:
            List of (base64_string, page_info) tuples
        """
        base64_images = []
        
        for img_bytes, page_info in images:
            b64_string = base64.b64encode(img_bytes).decode('utf-8')
            base64_images.append((b64_string, page_info))
        
        return base64_images


def test_converter():
    """Test the converter with sample files"""
    converter = DocumentConverter(dpi=200)
    
    # Test with sample PDF
    print("Document Converter Test")
    print("-" * 40)
    print("✓ PyMuPDF imported successfully")
    print("✓ Converter initialized (200 DPI)")
    print("")
    print("Supported formats:")
    print("  ✓ PDF (multi-page)")
    print("  ✓ Images (PNG, JPG, TIFF, etc.)")
    print("  ⚠ DOCX/DOC (requires LibreOffice)")


if __name__ == "__main__":
    test_converter()
