"""
Azure Helper Classes for Document Processing - OPTIMIZED
=========================================================
Manages: Blob Storage, OpenAI, Azure Search
OCR now in separate documentintelligence_ocr.py module
"""

import logging
import hashlib
import json
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta

from azure.storage.blob import BlobServiceClient, ContentSettings
from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SearchField,
    SearchFieldDataType,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile
)


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def sanitize_document_id(doc_id: str) -> str:
    """
    Sanitize document ID for Azure AI Search
    
    Azure AI Search keys can only contain:
    - Letters (a-z, A-Z)
    - Digits (0-9)
    - Underscore (_)
    - Dash (-)
    - Equal sign (=)
    
    Args:
        doc_id: Original document ID
        
    Returns:
        Sanitized document ID (valid for Azure AI Search)
        
    Examples:
        "ANAND-NICHOLS, SONIA_1. GEN & HR_file.pdf_hash"
        → "ANAND-NICHOLS_SONIA_1_GEN_HR_file_pdf_hash"
    """
    import re
    # Replace invalid characters with underscore
    sanitized = re.sub(r'[^a-zA-Z0-9_\-=]', '_', doc_id)
    
    # Remove consecutive underscores
    sanitized = re.sub(r'_+', '_', sanitized)
    
    # Remove leading/trailing underscores
    sanitized = sanitized.strip('_')
    
    # Ensure it's not empty
    if not sanitized:
        sanitized = "document"
    
    return sanitized


class BlobManager:
    """Manage Azure Blob Storage operations"""
    
    def __init__(self, connection_string: str):
        self.blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        self.logger = logging.getLogger(__name__)
    
    def get_folder_structure(self, container_name: str) -> Dict[str, List[str]]:
        """
        Get complete folder structure across all providers
        Returns only FIRST-LEVEL folders (not nested subfolders)
        
        Returns:
            Dict mapping provider -> list of first-level folders
            Example: {
                'Provider1': ['Licenses', 'Certifications', 'Personal'],
                'Provider2': ['Licenses', 'Education']
            }
        """
        try:
            container_client = self.blob_service_client.get_container_client(container_name)
            structure = {}
            
            for blob in container_client.list_blobs():
                # Parse blob path: Provider/Folder/Subfolder/file.pdf
                parts = blob.name.split('/')
                
                if len(parts) >= 2:  # At least Provider/file
                    provider = parts[0]
                    
                    # Get ONLY the first-level folder (not nested subfolders)
                    if len(parts) > 2:
                        # parts[1] is the first folder after provider
                        folder = parts[1]
                    else:
                        folder = "root"  # Files directly under provider
                    
                    if provider not in structure:
                        structure[provider] = set()
                    
                    structure[provider].add(folder)
            
            # Convert sets to sorted lists
            return {k: sorted(list(v)) for k, v in structure.items()}
            
        except Exception as e:
            self.logger.error(f"Error getting folder structure: {e}")
            return {}
    
    def list_folder_documents(self, container_name: str, provider: str, folder: str) -> List[Dict]:
        """
        List all documents in a specific provider/folder
        
        Args:
            container_name: Container name
            provider: Provider name
            folder: Folder path (can be nested like "Personal/2024")
        
        Returns:
            List of document info dicts
        """
        try:
            container_client = self.blob_service_client.get_container_client(container_name)
            documents = []
            
            # Construct search prefix
            if folder == "root":
                prefix = f"{provider}/"
            else:
                prefix = f"{provider}/{folder}/"
            
            for blob in container_client.list_blobs(name_starts_with=prefix):
                # Skip if it's a folder marker
                if blob.name.endswith('/'):
                    continue
                
                # Extract filename and extension
                filename = blob.name.split('/')[-1]
                extension = '.' + filename.split('.')[-1].lower() if '.' in filename else ''
                
                # Skip files directly under provider if we're looking in a specific folder
                if folder != "root":
                    path_parts = blob.name.split('/')
                    if len(path_parts) == 2:  # Provider/file.pdf (skip this)
                        continue
                
                documents.append({
                    'blob_name': blob.name,
                    'filename': filename,
                    'extension': extension,
                    'provider': provider,
                    'folder': folder,
                    'size': blob.size
                })
            
            return documents
            
        except Exception as e:
            self.logger.error(f"Error listing folder documents: {e}")
            return []
    
    def list_blobs_in_folder(self, container_name: str, folder_path: str) -> List:
        """
        List all blobs in a folder (including all subfolders recursively)
        
        Args:
            container_name: Container name
            folder_path: Folder path (e.g., "Provider/1. GEN & HR")
        
        Returns:
            List of blob objects
        """
        try:
            container_client = self.blob_service_client.get_container_client(container_name)
            blobs = []
            
            # Add trailing slash if not present
            prefix = folder_path if folder_path.endswith('/') else f"{folder_path}/"
            
            # List ALL blobs with this prefix (includes all subfolders!)
            for blob in container_client.list_blobs(name_starts_with=prefix):
                # Skip folder markers
                if blob.name.endswith('/'):
                    continue
                
                # Only include actual files (must have extension)
                if '.' in blob.name.split('/')[-1]:
                    blobs.append(blob)
                    self.logger.debug(f"Found blob: {blob.name}")
            
            self.logger.info(f"Found {len(blobs)} documents in {folder_path} (including subfolders)")
            
            return blobs
            
        except Exception as e:
            self.logger.error(f"Error listing blobs in folder: {e}")
            return []
    
    def download_blob(self, container_name: str, blob_name: str) -> bytes:
        """Download blob content as bytes"""
        try:
            blob_client = self.blob_service_client.get_blob_client(container_name, blob_name)
            return blob_client.download_blob().readall()
        except Exception as e:
            self.logger.error(f"Error downloading blob {blob_name}: {e}")
            return None
    
    def upload_blob(self, container_name: str, blob_name: str, data, content_type: str = None):
        """Upload data to blob storage"""
        try:
            blob_client = self.blob_service_client.get_blob_client(container_name, blob_name)
            
            content_settings = None
            if content_type:
                content_settings = ContentSettings(content_type=content_type)
            
            blob_client.upload_blob(data, overwrite=True, content_settings=content_settings)
            self.logger.info(f"Uploaded blob: {blob_name}")
            return True
        except Exception as e:
            self.logger.error(f"Error uploading blob {blob_name}: {e}")
            return False


class OpenAIManager:
    """Manage Azure OpenAI operations - supports BOTH General and Batch APIs"""
    
    def __init__(self, openai_config: dict, embedding_config: dict, batch_config: dict = None):
        """
        Initialize OpenAI Manager with support for General and Batch APIs
        
        Args:
            openai_config: General API config (for real-time extraction)
            embedding_config: Embedding API config
            batch_config: Optional Batch API config (for batch processing)
        """
        # General API client (real-time)
        self.gpt_client = AzureOpenAI(
            azure_endpoint=openai_config['endpoint'],
            api_key=openai_config['api_key'],
            api_version=openai_config['api_version']
        )
        self.gpt_deployment = openai_config['deployment_name']
        
        # Batch API client (optional)
        self.batch_client = None
        self.batch_deployment = None
        if batch_config:
            self.batch_client = AzureOpenAI(
                azure_endpoint=batch_config['endpoint'],
                api_key=batch_config['api_key'],
                api_version=batch_config['api_version']
            )
            self.batch_deployment = batch_config['deployment_name']
        
        # Embedding client
        self.embedding_client = AzureOpenAI(
            azure_endpoint=embedding_config['endpoint'],
            api_key=embedding_config['api_key'],
            api_version=embedding_config['api_version']
        )
        self.embedding_deployment = embedding_config['deployment_name']
        self.embedding_dimension = embedding_config.get('dimension', 3072)
        
        self.logger = logging.getLogger(__name__)
    
    def generate_embedding(self, text: str) -> Tuple[List[float], int]:
        """
        Generate embedding vector for text with proper validation
        
        Args:
            text: Text to embed (will be truncated if too long)
        
        Returns:
            Tuple of (embedding_vector, token_count)
        
        Raises:
            ValueError: If text is invalid
            Exception: If API call fails
        """
        # Validate input
        if not text or not isinstance(text, str):
            raise ValueError(f"Invalid text for embedding: {type(text)}")
        
        if len(text.strip()) == 0:
            raise ValueError("Cannot generate embedding for empty text")
        
        # Truncate if too long (max ~8000 tokens for ada-002)
        max_chars = 30000  # Roughly 8000 tokens
        if len(text) > max_chars:
            self.logger.warning(f"Text too long ({len(text)} chars), truncating to {max_chars}")
            text = text[:max_chars]
        
        try:
            response = self.embedding_client.embeddings.create(
                input=text,
                model=self.embedding_deployment
            )
            
            # Validate response
            if not response.data or len(response.data) == 0:
                raise ValueError("Embedding API returned empty response")
            
            vector = response.data[0].embedding
            
            # Validate vector
            if not vector or len(vector) == 0:
                raise ValueError("Embedding API returned empty vector")
            
            # Estimate tokens (rough approximation: 4 chars = 1 token)
            token_count = len(text) // 4
            
            self.logger.debug(f"Generated embedding: {len(vector)} dimensions, ~{token_count} tokens")
            
            return vector, token_count
            
        except Exception as e:
            self.logger.error(f"Error generating embedding: {e}")
            self.logger.error(f"Text length: {len(text)} chars, Deployment: {self.embedding_deployment}")
            raise  # Re-raise instead of returning None!
    
    def extract_fields(self, prompt: str, temperature: float = 0.0, 
                      max_tokens: int = 4000, use_vision: bool = False,
                      image_base64: str = None, image_format: str = 'jpeg') -> Tuple[Dict, Dict]:
        """
        Call GPT for field extraction (supports all models including o1/GPT-5)
        
        Args:
            prompt: Extraction prompt
            temperature: Sampling temperature (ignored for o1 models)
            max_tokens: Max response tokens (converted to max_completion_tokens for o1)
            use_vision: Whether to use multimodal vision
            image_base64: Base64 encoded image (if use_vision=True)
            image_format: Image format - 'jpeg', 'png', 'webp' (default: 'jpeg')
        
        Returns:
            Tuple of (extracted_data, token_usage)
        """
        try:
            # CRITICAL: System message enforcing format
            system_message = """YOU MUST RETURN JSON IN THIS EXACT FORMAT - NO EXCEPTIONS:

{
  "field_name": {
    "value": "extracted_value",
    "confidence": 0.95
  }
}

NEVER RETURN:
{
  "field_name": "value"  ← WRONG! SYSTEM WILL REJECT!
}

EVERY field MUST have BOTH "value" and "confidence" keys.
Confidence MUST be a number (0.00-1.00).
This is MANDATORY - responses without this format will be REJECTED."""

            # Detect if o1 model (o1, o1-preview, o1-mini, gpt-5)
            deployment_lower = self.gpt_deployment.lower()
            is_o1_model = any(x in deployment_lower for x in ['o1', 'gpt-5', 'gpt5'])
            
            if use_vision and image_base64:
                # Multimodal extraction with vision
                # Normalize image format (OpenAI accepts: jpeg, png, webp, gif)
                image_format_normalized = image_format.lower().replace('jpg', 'jpeg')
                
                if is_o1_model:
                    # o1 models: Use developer message instead of system
                    messages = [
                        {"role": "developer", "content": system_message},
                        {
                            "role": "user",
                            "content": [
                                {"type": "text", "text": prompt},
                                {
                                    "type": "image_url",
                                    "image_url": {
                                        "url": f"data:image/{image_format_normalized};base64,{image_base64}"
                                    }
                                }
                            ]
                        }
                    ]
                else:
                    # GPT-4/4.5: Use system message
                    messages = [
                        {"role": "system", "content": system_message},
                        {
                            "role": "user",
                            "content": [
                                {"type": "text", "text": prompt},
                                {
                                    "type": "image_url",
                                    "image_url": {
                                        "url": f"data:image/{image_format_normalized};base64,{image_base64}"
                                    }
                                }
                            ]
                        }
                    ]
            else:
                # Text-only extraction
                if is_o1_model:
                    # o1 models: Use developer message instead of system
                    messages = [
                        {"role": "developer", "content": system_message},
                        {"role": "user", "content": prompt}
                    ]
                else:
                    # GPT-4/4.5: Use system message
                    messages = [
                        {"role": "system", "content": system_message},
                        {"role": "user", "content": prompt}
                    ]
            
            # Build API call parameters based on model type
            if is_o1_model:
                # o1 models: No temperature, use max_completion_tokens
                api_params = {
                    "model": self.gpt_deployment,
                    "messages": messages,
                    "max_completion_tokens": max_tokens  # o1 uses this!
                }
                self.logger.info(f"Using o1/GPT-5 model parameters (no temperature, max_completion_tokens)")
            else:
                # GPT-4/4.5: Standard parameters
                api_params = {
                    "model": self.gpt_deployment,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens
                }
                self.logger.info(f"Using GPT-4/4.5 model parameters (temperature={temperature})")
            
            response = self.gpt_client.chat.completions.create(**api_params)
            
            content = response.choices[0].message.content
            
            # Parse JSON response
            try:
                # Remove markdown if present
                if "```json" in content:
                    content = content.split("```json")[1].split("```")[0]
                elif "```" in content:
                    content = content.split("```")[1].split("```")[0]
                
                extracted_data = json.loads(content.strip())
                
                # CRITICAL VALIDATION: Ensure proper format with confidence
                invalid_fields = []
                for field_name, field_value in extracted_data.items():
                    # Check if field is a dict
                    if not isinstance(field_value, dict):
                        invalid_fields.append(f"{field_name}:not_dict")
                    # Check if confidence exists
                    elif 'confidence' not in field_value:
                        invalid_fields.append(f"{field_name}:no_confidence")
                    # Check if confidence is numeric
                    elif not isinstance(field_value.get('confidence'), (int, float)):
                        invalid_fields.append(f"{field_name}:confidence_not_numeric")
                
                if invalid_fields:
                    error_msg = f"❌ GPT-4o INVALID FORMAT: {', '.join(invalid_fields)}\nResponse: {content[:300]}...\n"
                    error_msg += "\nGPT-4o is NOT returning proper format with confidence scores!\n"
                    error_msg += "CHECK:\n"
                    error_msg += f"1. Deployment name in config: '{self.gpt_deployment}'\n"
                    error_msg += "2. Verify deployment exists in Azure OpenAI Studio\n"
                    error_msg += "3. Check deployment uses GPT-4o model (not GPT-3.5)\n"
                    self.logger.error(error_msg)
                    raise ValueError(error_msg)
                    
            except json.JSONDecodeError as e:
                self.logger.error(f"Failed to parse JSON response: {e}")
                self.logger.error(f"Response: {content}")
                extracted_data = {}
            
            token_usage = {
                'input_tokens': response.usage.prompt_tokens,
                'output_tokens': response.usage.completion_tokens
            }
            
            return extracted_data, token_usage
            
        except Exception as e:
            error_msg = str(e)
            
            # Check for deployment not found error
            if "DeploymentNotFound" in error_msg or "deployment" in error_msg.lower():
                self.logger.error(f"❌ DEPLOYMENT ERROR!")
                self.logger.error(f"Deployment name in config: '{self.gpt_deployment}'")
                self.logger.error(f"Error: {e}")
                self.logger.error(f"\nSOLUTION:")
                self.logger.error(f"1. Go to Azure OpenAI Studio > Deployments")
                self.logger.error(f"2. Find YOUR deployment name (e.g., 'gpt-4o-2')")
                self.logger.error(f"3. Update config.json deployment_name to match EXACTLY")
                self.logger.error(f"   Current: '{self.gpt_deployment}'")
                self.logger.error(f"   Should be: YOUR deployment name from Azure")
            else:
                self.logger.error(f"Error in GPT extraction: {e}")
            
            return {}, {'input_tokens': 0, 'output_tokens': 0}
    
    def create_batch_request(self, custom_id: str, prompt: str, temperature: float = 0.0, 
                            max_tokens: int = 4000) -> dict:
        """
        Create a batch request object for Batch API (GPT-5 Batch)
        
        Args:
            custom_id: Unique identifier (e.g., "provider_folder_doc")
            prompt: Extraction prompt
            temperature: Sampling temperature (ignored for GPT-5)
            max_tokens: Max response tokens
        
        Returns:
            Batch request dict in JSONL format
        """
        system_message = """YOU MUST RETURN JSON IN THIS EXACT FORMAT:
{
  "field_name": {
    "value": "extracted value or NA",
    "confidence": 0.95
  }
}"""
        
        messages = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": prompt}
        ]
        
        # GPT-5 batch uses max_completion_tokens (no temperature)
        body = {
            "model": self.batch_deployment if self.batch_deployment else self.gpt_deployment,
            "messages": messages,
            "max_completion_tokens": max_tokens
        }
        
        return {
            "custom_id": custom_id,
            "method": "POST",
            "url": "/chat/completions",
            "body": body
        }


class SearchManager:
    """Manage Azure AI Search operations"""
    
    def __init__(self, endpoint: str, api_key: str, index_name: str, vector_dimensions: int = 3072):
        self.endpoint = endpoint
        self.api_key = api_key
        self.index_name = index_name
        self.vector_dimensions = vector_dimensions
        
        credential = AzureKeyCredential(api_key)
        self.index_client = SearchIndexClient(endpoint, credential)
        self.search_client = SearchClient(endpoint, index_name, credential)
        
        self.logger = logging.getLogger(__name__)
    
    def create_universal_index(self) -> bool:
        """Create universal search index if not exists"""
        try:
            # Check if index exists
            existing_indexes = [idx.name for idx in self.index_client.list_indexes()]
            if self.index_name in existing_indexes:
                self.logger.info(f"Index '{self.index_name}' already exists")
                return False
            
            # Define fields with provider and folder filters
            fields = [
                SearchField(name="id", type=SearchFieldDataType.String, key=True),
                SearchField(name="content", type=SearchFieldDataType.String, searchable=True),
                SearchField(name="provider", type=SearchFieldDataType.String, filterable=True, facetable=True),
                SearchField(name="folder", type=SearchFieldDataType.String, filterable=True, facetable=True),
                SearchField(name="document_name", type=SearchFieldDataType.String, filterable=True),
                SearchField(name="chunk_index", type=SearchFieldDataType.Int32, filterable=True),
                SearchField(name="total_chunks", type=SearchFieldDataType.Int32),
                SearchField(name="upload_timestamp", type=SearchFieldDataType.String, filterable=True, sortable=True),
                SearchField(
                    name="content_vector",
                    type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                    searchable=True,
                    vector_search_dimensions=self.vector_dimensions,
                    vector_search_profile_name="vector-profile"
                )
            ]
            
            # Vector search configuration
            vector_search = VectorSearch(
                profiles=[VectorSearchProfile(
                    name="vector-profile",
                    algorithm_configuration_name="hnsw-config"
                )],
                algorithms=[HnswAlgorithmConfiguration(name="hnsw-config")]
            )
            
            # Create index
            index = SearchIndex(
                name=self.index_name,
                fields=fields,
                vector_search=vector_search
            )
            
            self.index_client.create_index(index)
            self.logger.info(f"Created index '{self.index_name}'")
            return True
            
        except Exception as e:
            self.logger.error(f"Error creating index: {e}")
            return False
    
    def upload_document(self, doc_id: str, content: str, vector: List[float],
                       provider: str, folder: str, document_name: str,
                       chunk_index: int = 0, total_chunks: int = 1) -> bool:
        """Upload document chunk to search index"""
        try:
            document = {
                "id": doc_id,
                "content": content,
                "provider": provider,
                "folder": folder,
                "document_name": document_name,
                "chunk_index": chunk_index,
                "total_chunks": total_chunks,
                "upload_timestamp": datetime.utcnow().isoformat(),
                "content_vector": vector
            }
            
            self.logger.info(f"Uploading document to AI Search: {doc_id[:50]}...")
            result = self.search_client.upload_documents([document])
            self.logger.info(f"✅ Document uploaded successfully: {doc_id[:50]}...")
            return True
            
        except Exception as e:
            self.logger.error(f"❌ Error uploading document {doc_id[:50]}...: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
            return False
    
    def search_similar(self, vector: List[float], provider: str, folder: str = None, 
                      top_k: int = 3) -> List[Dict]:
        """
        Search for similar documents with provider/folder filtering
        
        Args:
            vector: Query embedding vector
            provider: Provider to filter by
            folder: Optional folder to filter by
            top_k: Number of results to return
        
        Returns:
            List of similar document contents
        """
        try:
            # Build filter expression
            filter_expr = f"provider eq '{provider}'"
            if folder:
                filter_expr += f" and folder eq '{folder}'"
            
            # Perform vector search
            from azure.search.documents.models import VectorizedQuery
            
            vector_query = VectorizedQuery(
                vector=vector,
                k_nearest_neighbors=top_k,
                fields="content_vector"
            )
            
            results = self.search_client.search(
                search_text=None,
                vector_queries=[vector_query],
                filter=filter_expr,
                top=top_k
            )
            
            return [{"content": r["content"], "score": r["@search.score"]} for r in results]
            
        except Exception as e:
            self.logger.error(f"Error searching: {e}")
            return []
    
    def delete_old_documents(self, days: int, provider: str = None) -> int:
        """Delete documents older than N days"""
        try:
            cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()
            
            # Build filter
            filter_expr = f"upload_timestamp lt '{cutoff}'"
            if provider:
                filter_expr += f" and provider eq '{provider}'"
            
            # Find old documents
            results = self.search_client.search(
                search_text="*",
                filter=filter_expr,
                select=["id"]
            )
            
            doc_ids = [{"id": r["id"]} for r in results]
            
            if doc_ids:
                self.search_client.delete_documents(doc_ids)
                self.logger.info(f"Deleted {len(doc_ids)} old documents")
            
            return len(doc_ids)
            
        except Exception as e:
            self.logger.error(f"Error deleting old documents: {e}")
            return 0


def generate_document_id(provider: str, folder: str, filename: str, chunk_index: int = 0, 
                         content_hash: str = None) -> str:
    """
    Generate unique document ID using hash
    
    Args:
        provider: Provider name
        folder: Folder path
        filename: Document filename
        chunk_index: Chunk index (default 0)
        content_hash: Optional content hash for uniqueness (recommended)
    
    Returns:
        Unique document ID
    
    Note:
        If content_hash is provided, the same filename with different content
        will generate different IDs. This prevents overwriting when re-processing
        the same filename with updated content.
    """
    if content_hash:
        # Include content hash for uniqueness (prevents overwrite on re-upload)
        combined = f"{provider}_{folder}_{filename}_{content_hash[:16]}_chunk{chunk_index}"
    else:
        # Simple version (may overwrite if same filename uploaded again)
        combined = f"{provider}_{folder}_{filename}_chunk{chunk_index}"
    
    return hashlib.md5(combined.encode()).hexdigest()
