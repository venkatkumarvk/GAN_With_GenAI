"""
Multimodal RAG Module - Handles multimodal (vision + text) extraction with RAG support

This module processes image documents using multimodal mode:
- OCR text extraction
- Image encoding to Base64
- Semantic chunking (text-based)
- Vector embedding generation (text-based)
- RAG search for similar documents (text-based)
- GPT-4o/4.5/5 Vision multimodal extraction (text + image)
"""

import logging
import base64
from typing import Dict, Tuple, List

def process_multimodal_rag(
    doc_bytes: bytes,
    doc_info: dict,
    provider: str,
    folder: str,
    folder_config: dict,
    ocr,
    openai_manager,
    search_manager,
    cost_tracker,
    config: dict,
    logger: logging.Logger
) -> Tuple[Dict, bool]:
    """
    Process document using MULTIMODAL RAG mode (Vision + Text)
    
    Note: RAG search is ALWAYS text-based, even in multimodal mode!
    The image is added to GPT input AFTER the text-based RAG search.
    
    Args:
        doc_bytes: Binary document content (image file)
        doc_info: Document metadata (name, extension, folder)
        provider: Provider name
        folder: Folder name
        folder_config: Folder configuration with fields
        ocr: OCR manager instance
        openai_manager: OpenAI manager instance
        search_manager: Search manager instance
        cost_tracker: Cost tracking instance
        config: System configuration
        logger: Logger instance
    
    Returns:
        Tuple of (extracted_data, success)
        - extracted_data: Dict with field values and confidences
        - success: Boolean indicating if extraction succeeded
    """
    
    doc_name = doc_info['name']
    rag_config = config['rag']
    
    try:
        # Step 1: OCR Extraction (SAME AS TEXT MODE)
        logger.info(f"Step 2: Running OCR on {doc_name}...")
        text, pages, success = ocr.extract_text(doc_bytes, doc_info['extension'])
        
        if not success:
            logger.error(f"❌ FAILED Step 2: OCR failed for {doc_name}")
            return {}, False
        
        logger.info(f"✓ Step 2 Complete: Extracted {len(text)} characters from {pages} pages")
        cost_tracker.add_ocr(pages)
        
        # Step 2: Text Validation (SAME AS TEXT MODE)
        min_length = config['extraction']['min_text_length']
        if len(text) < min_length:
            logger.warning(f"❌ FAILED Step 3: Insufficient text ({len(text)} < {min_length} chars) for {doc_name}")
            return {}, False
        
        logger.info(f"✓ Step 3 Complete: Text length sufficient ({len(text)} chars)")
        
        # Step 3: ADAPTIVE EXTRACTION STRATEGY (SAME AS TEXT MODE)
        extraction_config = config.get('extraction', {})
        strategy = extraction_config.get('strategy', 'adaptive')
        small_threshold = extraction_config.get('small_doc_threshold', 15000)
        medium_threshold = extraction_config.get('medium_doc_threshold', 50000)
        
        text_length = len(text)
        
        # TIER 1: Small docs - FULL TEXT (90% of docs)
        if text_length <= small_threshold:
            logger.info(f"Step 4: Using ADAPTIVE strategy - FULL_TEXT ({text_length} chars ≤ {small_threshold})")
            extraction_text = text
            needs_chunking = False
            chunks = None
            extraction_mode = "FULL_TEXT"
            logger.info(f"✓ Step 4 Complete: Full text extraction (no chunking needed)")
            
        # TIER 2: Medium docs - SMART CHUNKING (8% of docs)
        elif text_length <= medium_threshold:
            logger.info(f"Step 4: Using ADAPTIVE strategy - SMART_CHUNKING ({text_length} chars, {small_threshold}-{medium_threshold})")
            
            # Use larger chunks for better coverage
            chunk_size = extraction_config.get('large_doc_chunk_size', 12000)
            chunk_overlap = extraction_config.get('large_doc_overlap', 2000)
            max_extraction_chunks = extraction_config.get('max_chunks_for_extraction', 2)
            
            from semantic_chunker import process_for_chunking
            rag_config_override = rag_config.copy()
            rag_config_override['chunk_size'] = chunk_size
            rag_config_override['chunk_overlap'] = chunk_overlap
            
            needs_chunking, chunks, chunking_strategy = process_for_chunking(
                text, rag_config_override, f"{provider}_{folder}_{doc_name}"
            )
            
            if needs_chunking and chunks:
                extraction_text = chunks[0]['text']  # Primary chunk
                extraction_mode = f"SMART_CHUNKING_{max_extraction_chunks}_CHUNKS"
                logger.info(f"✓ Step 4 Complete: Created {len(chunks)} chunks, will extract from first {min(max_extraction_chunks, len(chunks))} chunks")
            else:
                extraction_text = text
                extraction_mode = "FULL_TEXT"
                logger.info(f"✓ Step 4 Complete: Document fits in single chunk")
                
        # TIER 3: Large docs - SECTION-BASED (2% of docs)
        else:
            logger.info(f"Step 4: Using ADAPTIVE strategy - LARGE_DOC ({text_length} chars > {medium_threshold})")
            
            # For very large docs, still use chunking but log warning
            from semantic_chunker import process_for_chunking
            chunk_size = extraction_config.get('large_doc_chunk_size', 12000)
            chunk_overlap = extraction_config.get('large_doc_overlap', 2000)
            
            rag_config_override = rag_config.copy()
            rag_config_override['chunk_size'] = chunk_size
            rag_config_override['chunk_overlap'] = chunk_overlap
            
            needs_chunking, chunks, chunking_strategy = process_for_chunking(
                text, rag_config_override, f"{provider}_{folder}_{doc_name}"
            )
            
            if needs_chunking and chunks:
                extraction_text = chunks[0]['text']
                extraction_mode = "LARGE_DOC_CHUNKED"
                logger.warning(f"Large document ({text_length} chars) - extracting from first {chunk_size} chars")
                logger.info(f"✓ Step 4 Complete: Large doc chunked into {len(chunks)} chunks")
            else:
                extraction_text = text
                extraction_mode = "FULL_TEXT"
                logger.info(f"✓ Step 4 Complete: Using full text")
            extraction_text = text
            logger.info(f"Using full text ({len(extraction_text)} chars) for extraction")
        
        # Step 5: Generate Embedding and Index (SAME AS TEXT MODE - text-based!)
        logger.info(f"Step 5: Generating embedding and indexing...")
        
        # Generate embedding from text (not image!)
        search_vector, embedding_tokens = openai_manager.generate_embedding(extraction_text)
        cost_tracker.add_embedding(embedding_tokens)
        
        # Index document (all chunks if chunked, else full text)
        # NOTE: We index TEXT, not image! RAG search is ALWAYS text-based!
        import hashlib
        content_hash = hashlib.md5(text.encode('utf-8', errors='ignore')).hexdigest()
        
        if needs_chunking and chunks:
            # Index all chunks (text-based)
            for i, chunk in enumerate(chunks):
                chunk_vector, _ = openai_manager.generate_embedding(chunk)
                search_manager.upload_document(
                    doc_id=f"{provider}_{folder}_{doc_name}_{content_hash}_chunk{i}",
                    content=chunk,
                    vector=chunk_vector,
                    provider=provider,
                    folder=folder,
                    document_name=doc_name,
                    chunk_index=i,
                    total_chunks=len(chunks)
                )
        else:
            # Index full document (text-based)
            search_manager.upload_document(
                doc_id=f"{provider}_{folder}_{doc_name}_{content_hash}",
                content=text,
                vector=search_vector,
                provider=provider,
                folder=folder,
                document_name=doc_name,
                chunk_index=0,
                total_chunks=1
            )
        
        logger.info(f"✓ Step 5 Complete: Indexed document (text-based)")
        
        # Step 5: RAG Search (SAME AS TEXT MODE - text-based search!)
        logger.info(f"Step 6: RAG search for similar documents (text-based)...")
        similar_docs = search_manager.search_similar(
            search_vector, provider, folder, rag_config['top_k']
        )
        logger.info(f"✓ Step 6 Complete: RAG search found {len(similar_docs)} similar docs")
        
        # Step 6: Encode Image to Base64 (ADDITIONAL STEP FOR MULTIMODAL!)
        logger.info(f"Step 6.5: Encoding image to Base64 for vision...")
        image_base64 = base64.b64encode(doc_bytes).decode('utf-8')
        logger.info(f"✓ Step 6.5 Complete: Image encoded ({len(image_base64)} chars base64)")
        
        # Step 7: Build Prompt (SAME AS TEXT MODE)
        logger.info(f"Step 7: Building extraction prompt...")
        from prompt_builder import build_extraction_prompt
        prompt = build_extraction_prompt(
            text=extraction_text,
            fields=folder_config['fields'],
            rag_examples=similar_docs,
            folder_description=folder_config.get('description', '')
        )
        logger.info(f"✓ Step 7 Complete: Prompt built ({len(prompt)} chars)")
        
        # Step 8: GPT Vision Extraction (MULTIMODAL MODE - text + image!)
        logger.info(f"Step 8: Calling GPT Vision for MULTIMODAL extraction...")
        extracted_data, tokens = openai_manager.extract_fields(
            prompt,
            use_vision=True,  # MULTIMODAL mode - include image!
            image_base64=image_base64  # Pass the encoded image
        )
        logger.info(f"✓ Step 8 Complete: Used MULTIMODAL RAG for {doc_name}")
        logger.info(f"GPT Vision tokens: input={tokens['input_tokens']}, output={tokens['output_tokens']}")
        
        # Debug: Log sample field to check format
        if extracted_data and len(extracted_data) > 0:
            first_field = list(extracted_data.keys())[0]
            first_value = extracted_data[first_field]
            logger.info(f"Sample field format - {first_field}: {type(first_value).__name__} = {first_value}")
        else:
            logger.error(f"❌ WARNING: extracted_data is empty or None!")
        
        cost_tracker.add_gpt4o(tokens['input_tokens'], tokens['output_tokens'])
        cost_tracker.add_embedding(len(extraction_text) // 4)  # Estimate
        
        return extracted_data, True
        
    except Exception as e:
        logger.error(f"Error in MULTIMODAL RAG processing for {doc_name}: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return {}, False
