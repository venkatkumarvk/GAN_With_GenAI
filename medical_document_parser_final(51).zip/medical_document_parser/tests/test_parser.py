"""
Test Suite - Medical Document Parser
=====================================
Tests all core functionality:
  - Configuration loading
  - Field library validation
  - Single-value aggregation
  - Multi-value aggregation & deduplication
  - Confidence routing
  - Empty value handling
  - Prompt building
  - CSV flattening

Run: python -m pytest tests/test_parser.py -v
  Or: python tests/test_parser.py
"""

import sys
import os
import json

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# =============================================================================
# TEST 1: Configuration Loading
# =============================================================================
def test_config_loads():
    """Config file loads without error and has required keys."""
    config = json.load(open('config/config.json'))
    
    assert 'extraction' in config, "Missing 'extraction' key"
    assert 'rag' in config, "Missing 'rag' key"
    assert 'doctypes' in config, "Missing 'doctypes' key"
    assert 'log' in config, "Missing 'log' key"
    assert 'sql_logging' in config, "Missing 'sql_logging' key"
    assert config['extraction']['confidence_threshold'] > 0
    assert config['extraction']['parallel_workers'] >= 1
    print("  PASS: config.json loads with all required keys")


def test_config_no_logging_key():
    """Config should have 'sql_logging' not 'logging' (avoids conflict)."""
    config = json.load(open('config/config.json'))
    assert 'logging' not in config, "Found 'logging' key -- should be 'sql_logging'"
    assert 'sql_logging' in config, "Missing 'sql_logging' key"
    print("  PASS: sql_logging key correct (no 'logging' conflict)")


# =============================================================================
# TEST 2: Field Library Validation
# =============================================================================
def test_field_library_structure():
    """All fields have required keys based on cardinality."""
    from prompts.cred_prompt import FIELD_LIBRARY
    
    for field_name, field_info in FIELD_LIBRARY.items():
        assert 'cardinality' in field_info, f"{field_name}: missing cardinality"
        assert 'description' in field_info, f"{field_name}: missing description"
        assert 'extraction_hints' in field_info, f"{field_name}: missing extraction_hints"
        
        if field_info['cardinality'] == 'multi':
            assert 'item_fields' in field_info, f"{field_name}: multi field missing item_fields"
            assert 'examples' in field_info, f"{field_name}: multi field missing examples"
            assert 'format' in field_info, f"{field_name}: multi field missing format"
            assert 'confidence_factors' in field_info, f"{field_name}: multi field missing confidence_factors"
            assert isinstance(field_info['examples'], list), f"{field_name}: examples should be list"
            assert isinstance(field_info['examples'][0], dict), f"{field_name}: multi examples should be list of dicts"
    
    print(f"  PASS: all {len(FIELD_LIBRARY)} fields have correct structure")


def test_field_library_counts():
    """Verify expected field counts."""
    from prompts.cred_prompt import FIELD_LIBRARY
    
    single = [f for f, v in FIELD_LIBRARY.items() if v['cardinality'] == 'single']
    multi = [f for f, v in FIELD_LIBRARY.items() if v['cardinality'] == 'multi']
    
    assert len(single) == 13, f"Expected 13 single fields, got {len(single)}"
    assert len(multi) == 5, f"Expected 5 multi fields, got {len(multi)}"
    assert len(FIELD_LIBRARY) == 18, f"Expected 18 total fields, got {len(FIELD_LIBRARY)}"
    print(f"  PASS: 13 single + 5 multi = 18 total fields")


def test_no_na_unknown_in_prompts():
    """Prompt should not use NA, Unknown, Not found as defaults."""
    from prompts.cred_prompt import SYSTEM_PROMPT_CONFIG
    
    rules_text = ' '.join(SYSTEM_PROMPT_CONFIG.get('extraction_rules', []))
    assert "'NA'" not in rules_text, "Found 'NA' in extraction_rules"
    assert "'Unknown'" not in rules_text, "Found 'Unknown' in extraction_rules"
    assert "'Not found'" not in rules_text, "Found 'Not found' in extraction_rules"
    print("  PASS: no NA/Unknown/Not found in prompt rules")


def test_multi_value_normalize_hints():
    """All multi-value fields have NORMALIZE and DEDUPLICATE hints."""
    from prompts.cred_prompt import FIELD_LIBRARY
    
    multi_fields = [f for f, v in FIELD_LIBRARY.items() if v['cardinality'] == 'multi']
    
    for field_name in multi_fields:
        hints = ' '.join(FIELD_LIBRARY[field_name].get('extraction_hints', []))
        assert 'NORMALIZE' in hints, f"{field_name}: missing NORMALIZE hint"
        assert 'DEDUPLICATE' in hints, f"{field_name}: missing DEDUPLICATE hint"
    
    print(f"  PASS: all {len(multi_fields)} multi-value fields have NORMALIZE + DEDUPLICATE hints")


# =============================================================================
# TEST 3: Single-Value Aggregation
# =============================================================================
def test_single_value_aggregation():
    """Best value selected by frequency + confidence."""
    from main import calculate_best_values
    from prompts import cred_prompt
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {
            'first_name': {'value': 'John', 'confidence': 0.95}
        }},
        {'document_name': 'doc2.pdf', 'fields': {
            'first_name': {'value': 'John', 'confidence': 0.90}
        }},
        {'document_name': 'doc3.pdf', 'fields': {
            'first_name': {'value': 'Jonathan', 'confidence': 0.70}
        }},
    ]
    
    result = calculate_best_values(documents, ['first_name'], 'Data', prompt_module=cred_prompt)
    
    assert result['first_name']['value'] == 'John', f"Expected 'John', got {result['first_name']['value']}"
    assert result['first_name']['frequency'] == 2, f"Expected frequency 2, got {result['first_name']['frequency']}"
    print("  PASS: single-value aggregation picks most frequent value")


def test_single_value_empty():
    """Empty values should not win over real values."""
    from main import calculate_best_values
    from prompts import cred_prompt
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {
            'email': {'value': '', 'confidence': 0.0}
        }},
        {'document_name': 'doc2.pdf', 'fields': {
            'email': {'value': '', 'confidence': 0.0}
        }},
        {'document_name': 'doc3.pdf', 'fields': {
            'email': {'value': 'john@test.com', 'confidence': 0.85}
        }},
    ]
    
    result = calculate_best_values(documents, ['email'], 'Data', prompt_module=cred_prompt)
    
    assert result['email']['value'] == 'john@test.com', f"Expected 'john@test.com', got {result['email']['value']}"
    print("  PASS: empty values don't win over real values")


# =============================================================================
# TEST 4: Multi-Value Aggregation & Deduplication
# =============================================================================
def test_multi_value_dedup_same_license():
    """Same license number + state from different docs = ONE entry."""
    from main import _aggregate_multi_field
    from prompts.cred_prompt import FIELD_LIBRARY
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {
            'state_licenses': [
                {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.96},
                 'license_state': {'value': 'KY', 'confidence': 0.96},
                 'license_issue_date': {'value': '', 'confidence': 0.0},
                 'license_expiration_date': {'value': '12/31/2025', 'confidence': 0.90},
                 'license_status': {'value': 'Active', 'confidence': 0.85}}
            ]
        }},
        {'document_name': 'doc2.pdf', 'fields': {
            'state_licenses': [
                {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.94},
                 'license_state': {'value': 'KY', 'confidence': 0.98},
                 'license_issue_date': {'value': '01/15/2020', 'confidence': 0.80},
                 'license_expiration_date': {'value': '', 'confidence': 0.0},
                 'license_status': {'value': '', 'confidence': 0.0}}
            ]
        }},
    ]
    
    result = _aggregate_multi_field('state_licenses', documents, 'Data', FIELD_LIBRARY.get('state_licenses'))
    
    assert len(result) == 1, f"Expected 1 deduplicated license, got {len(result)}"
    assert result[0]['license_number']['value'] == '56359'
    assert result[0]['license_number']['frequency'] == 2, f"Expected frequency 2, got {result[0]['license_number']['frequency']}"
    print("  PASS: same license from 2 docs = 1 entry with frequency 2")


def test_multi_value_dedup_different_licenses():
    """Different license numbers = separate entries."""
    from main import _aggregate_multi_field
    from prompts.cred_prompt import FIELD_LIBRARY
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {
            'state_licenses': [
                {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.96},
                 'license_state': {'value': 'KY', 'confidence': 0.96}},
                {'id': 2, 'license_number': {'value': 'MD-12345', 'confidence': 0.90},
                 'license_state': {'value': 'NY', 'confidence': 0.88}}
            ]
        }},
    ]
    
    result = _aggregate_multi_field('state_licenses', documents, 'Data', FIELD_LIBRARY.get('state_licenses'))
    
    assert len(result) == 2, f"Expected 2 licenses, got {len(result)}"
    print("  PASS: 2 different licenses = 2 separate entries")


def test_multi_value_empty():
    """No data = empty array []."""
    from main import _aggregate_multi_field
    from prompts.cred_prompt import FIELD_LIBRARY
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {'dea_licenses': []}},
        {'document_name': 'doc2.pdf', 'fields': {'dea_licenses': []}},
    ]
    
    result = _aggregate_multi_field('dea_licenses', documents, 'Data', FIELD_LIBRARY.get('dea_licenses'))
    
    assert result == [], f"Expected [], got {result}"
    print("  PASS: no multi-value data = empty []")


# =============================================================================
# TEST 5: Confidence Routing
# =============================================================================
def test_confidence_routing_high():
    """All high confidence = highconfidence routing."""
    extracted = {
        'first_name': {'value': 'John', 'confidence': 0.95},
        'last_name': {'value': 'Smith', 'confidence': 0.90},
    }
    
    confidences = []
    for field_data in extracted.values():
        if isinstance(field_data, dict) and 'confidence' in field_data:
            conf = field_data.get('confidence', 0)
            if isinstance(conf, (int, float)):
                confidences.append(conf)
    
    min_conf = min(confidences)
    assert min_conf >= 0.70, f"Expected high confidence, got min {min_conf}"
    print("  PASS: all high confidence → highconfidence routing")


def test_confidence_routing_skips_empty_multi():
    """Empty multi-value [] should not affect confidence routing."""
    extracted = {
        'first_name': {'value': 'John', 'confidence': 0.95},
        'state_licenses': [],  # empty - should be skipped
        'dea_licenses': [],    # empty - should be skipped
    }
    
    confidences = []
    for field_data in extracted.values():
        if isinstance(field_data, dict) and 'confidence' in field_data:
            conf = field_data.get('confidence', 0)
            if isinstance(conf, (int, float)):
                confidences.append(conf)
        elif isinstance(field_data, list):
            for item in field_data:
                if isinstance(item, dict):
                    item_confs = []
                    for key, val in item.items():
                        if key == 'id':
                            continue
                        if isinstance(val, dict) and 'confidence' in val:
                            conf = val.get('confidence')
                            if isinstance(conf, (int, float)):
                                item_confs.append(conf)
                    if item_confs:
                        confidences.append(sum(item_confs) / len(item_confs))
    
    assert len(confidences) == 1, f"Expected 1 confidence value, got {len(confidences)}"
    assert confidences[0] == 0.95
    print("  PASS: empty [] multi-value fields skipped in confidence routing")


def test_confidence_routing_real_low():
    """Real low confidence (0.15) should be counted, not skipped."""
    extracted = {
        'first_name': {'value': 'John', 'confidence': 0.95},
        'email': {'value': 'maybe@test.com', 'confidence': 0.15},
    }
    
    confidences = []
    for field_data in extracted.values():
        if isinstance(field_data, dict) and 'confidence' in field_data:
            conf = field_data.get('confidence', 0)
            if isinstance(conf, (int, float)):
                confidences.append(conf)
    
    min_conf = min(confidences)
    assert min_conf == 0.15, f"Expected 0.15, got {min_conf}"
    assert min_conf < 0.70, "Should route to lowconfidence"
    print("  PASS: real low confidence (0.15) counted → lowconfidence routing")


# =============================================================================
# TEST 6: JSON Output Structure
# =============================================================================
def test_json_uses_data_key():
    """Output JSON should use 'data' not 'fields'."""
    # Simulate what save_results builds
    json_output = {
        'provider_name': 'TEST-PROVIDER',
        'data': {
            'first_name': {'value': 'John'},
            'state_licenses': []
        }
    }
    
    assert 'data' in json_output, "Missing 'data' key"
    assert 'fields' not in json_output, "Should not have 'fields' key"
    print("  PASS: JSON output uses 'data' key, not 'fields'")


# =============================================================================
# TEST 7: Prompt Builder
# =============================================================================
def test_prompt_single_field():
    """Prompt builder works for single-value fields."""
    from extraction.text_rag import _build_field_prompt
    from prompts.cred_prompt import FIELD_LIBRARY, SYSTEM_PROMPT_CONFIG
    
    prompt = _build_field_prompt(
        field_name='first_name',
        field_info=FIELD_LIBRARY['first_name'],
        similar_docs=[{'content': 'Name: John Smith', 'score': 0.95}],
        fallback_text='',
        system_config=SYSTEM_PROMPT_CONFIG
    )
    
    assert 'first_name' in prompt
    assert 'FIELD DEFINITION' in prompt
    assert 'confidence' in prompt
    print("  PASS: prompt builder works for single-value field")


def test_prompt_multi_field():
    """Prompt builder works for multi-value fields with examples."""
    from extraction.text_rag import _build_field_prompt
    from prompts.cred_prompt import FIELD_LIBRARY, SYSTEM_PROMPT_CONFIG
    
    prompt = _build_field_prompt(
        field_name='state_licenses',
        field_info=FIELD_LIBRARY['state_licenses'],
        similar_docs=[{'content': 'License: 12345 State: NY', 'score': 0.90}],
        fallback_text='',
        system_config=SYSTEM_PROMPT_CONFIG
    )
    
    assert 'state_licenses' in prompt
    assert 'Do NOT return empty array' in prompt
    assert 'Sub-field descriptions' in prompt
    print("  PASS: prompt builder works for multi-value field with hints")


# =============================================================================
# TEST 8: SQL Logger
# =============================================================================
def test_sql_logger_disabled():
    """SQL Logger should handle disabled state gracefully."""
    from services.sql_logger import SQLLogger
    
    logger = SQLLogger({'sql_logging': {'enabled': False}})
    assert logger.enabled == False
    
    # These should return None without error
    result = logger.insert_begin('TEST', 'cred', 'general')
    assert result is None
    
    logger.update_status(None, 'TEST', 'test')
    logger.update_complete(None, 'TEST', 'test')
    print("  PASS: SQL Logger handles disabled state gracefully")


# =============================================================================
# TEST 9: Cost Tracker
# =============================================================================
def test_cost_tracker():
    """Cost tracker accumulates tokens correctly."""
    from services.cost_tracker import CostTracker
    
    config = {
        'costs': {
            'gpt_input_per_1k_tokens': 0.01,
            'gpt_output_per_1k_tokens': 0.03,
            'embedding_per_1k_tokens': 0.0001,
            'ocr_per_page': 0.01
        }
    }
    
    tracker = CostTracker(config)
    tracker.set_provider('TEST-PROVIDER')
    tracker.add_gpt_tokens(1000, 500)
    tracker.add_embedding(200)
    tracker.add_ocr(5)
    
    summary = tracker.get_summary()
    assert summary['usage']['gpt_input_tokens'] == 1000
    assert summary['usage']['gpt_output_tokens'] == 500
    assert summary['usage']['embedding_tokens'] == 200
    assert summary['usage']['ocr_pages'] == 5
    print("  PASS: cost tracker accumulates correctly")


# =============================================================================
# RUN ALL TESTS
# =============================================================================
if __name__ == '__main__':
    print("\n" + "=" * 60)
    print("MEDICAL DOCUMENT PARSER - TEST SUITE")
    print("=" * 60 + "\n")
    
    tests = [
        ("Config Loading", test_config_loads),
        ("Config No Logging Conflict", test_config_no_logging_key),
        ("Field Library Structure", test_field_library_structure),
        ("Field Library Counts", test_field_library_counts),
        ("No NA/Unknown in Prompts", test_no_na_unknown_in_prompts),
        ("Multi-Value Normalize Hints", test_multi_value_normalize_hints),
        ("Single-Value Aggregation", test_single_value_aggregation),
        ("Single-Value Empty Handling", test_single_value_empty),
        ("Multi-Value Dedup Same License", test_multi_value_dedup_same_license),
        ("Multi-Value Dedup Different Licenses", test_multi_value_dedup_different_licenses),
        ("Multi-Value Empty", test_multi_value_empty),
        ("Confidence Routing High", test_confidence_routing_high),
        ("Confidence Routing Skips Empty Multi", test_confidence_routing_skips_empty_multi),
        ("Confidence Routing Real Low", test_confidence_routing_real_low),
        ("JSON Uses Data Key", test_json_uses_data_key),
        ("Prompt Builder Single", test_prompt_single_field),
        ("Prompt Builder Multi", test_prompt_multi_field),
        ("SQL Logger Disabled", test_sql_logger_disabled),
        ("Cost Tracker", test_cost_tracker),
    ]
    
    passed = 0
    failed = 0
    errors = []
    
    for name, test_fn in tests:
        try:
            test_fn()
            passed += 1
        except Exception as e:
            failed += 1
            errors.append((name, str(e)))
            print(f"  FAIL: {name}: {e}")
    
    print(f"\n{'=' * 60}")
    print(f"RESULTS: {passed} passed, {failed} failed out of {len(tests)} tests")
    if errors:
        print(f"\nFailed tests:")
        for name, err in errors:
            print(f"  - {name}: {err}")
    print(f"{'=' * 60}\n")
