"""
MEDICAL DOCUMENT PARSER - PRODUCTION WITH RAG
"""

import os
import sys
import json
import logging
import argparse
from datetime import datetime
from typing import Dict, List, Any

from utils.logger_helper import setup_logger, get_logger, print_section

# Logger initialized lazily - setup_logger called in main() after args parsed
_logger = None

def _get_logger():
    """Get or create module logger."""
    global _logger
    if _logger is None:
        _logger = get_logger(__name__)
    return _logger

# For backward compatibility - property-like access
class _LazyLogger:
    """Proxy that delays logger creation until first use."""
    def __getattr__(self, name):
        return getattr(_get_logger(), name)

logger = _LazyLogger()


def load_configuration(config_path: str = "config/config.json") -> Dict:
    """Load and validate configuration file"""
    print_section("STEP 1: LOADING CONFIGURATION")
    
    try:
        logger.info(f"Looking for config file: {config_path}")
        
        if not os.path.exists(config_path):
            logger.error(f"Config file not found: {config_path}")
            raise FileNotFoundError(f"Config file not found: {config_path}")
        
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        logger.info(f"Config file loaded successfully")
        logger.info(f"Found {len(config['doctypes'])} doctypes: {', '.join(config['doctypes'].keys())}")
        
        return config
        
    except Exception as e:
        logger.error(f"Configuration loading failed: {str(e)}")
        raise


def validate_doctype_config(config: Dict, doctype: str) -> Dict:
    """Validate doctype-specific configuration"""
    print_section(f"STEP 2: VALIDATING DOCTYPE '{doctype}' CONFIG")
    
    try:
        logger.info(f"Checking doctype: {doctype}")
        
        if doctype not in config['doctypes']:
            raise ValueError(f"Doctype '{doctype}' not configured")
        
        doctype_config = config['doctypes'][doctype]
        folders = list(doctype_config['folder_configs'].keys())
        logger.info(f"Doctype '{doctype}' found with folders: {', '.join(folders)}")
        
        return doctype_config
        
    except Exception as e:
        logger.error(f"Doctype validation failed: {str(e)}")
        raise


def load_prompt_module(prompt_module_path: str):
    """Load prompt module dynamically"""
    print_section("STEP 3: LOADING PROMPT MODULE")
    
    try:
        logger.info(f"Loading prompt module: {prompt_module_path}")
        
        module_parts = prompt_module_path.split('.')
        module_name = module_parts[-1]
        
        module = __import__(prompt_module_path, fromlist=[module_name])
        
        field_count = len(module.FIELD_LIBRARY)
        logger.info(f"Prompt module loaded - {field_count} fields available")
        
        return module
        
    except Exception as e:
        logger.error(f"Prompt module loading failed: {str(e)}")
        raise


def initialize_azure_services(config: Dict, doctype_config: Dict):
    """Initialize Azure service connections"""
    print_section("STEP 4: INITIALIZING AZURE SERVICES")
    
    services = {}
    
    try:
        from services.keyvault_manager import KeyVaultManager, resolve_config_values
        from services.azure_clients import BlobManager, OpenAIManager, SearchManager
        from services.ocr import DocumentIntelligenceOCR
        from services.cost_tracker import CostTracker
        
        # Key Vault
        logger.info("Initializing Key Vault Manager...")
        vault_url = config.get('azure_keyvault', {}).get('vault_url')
        kv_manager = KeyVaultManager(vault_url)
        services['keyvault'] = kv_manager
        
        logger.info("Resolving configuration values...")
        resolve_config_values(config, kv_manager)
        resolve_config_values(doctype_config, kv_manager)
        logger.info("Configuration values resolved")
        
        # Blob Storage
        logger.info("Initializing Blob Storage...")
        blob_manager = BlobManager(config['azure_blob']['connection_string'])
        services['blob'] = blob_manager
        logger.info("Blob Storage initialized")
        
        # Document Intelligence (OCR)
        logger.info("Initializing Document Intelligence...")
        doc_intel_config = config['azure_document_intelligence']
        ocr_manager = DocumentIntelligenceOCR({
            'endpoint': doc_intel_config['endpoint'],
            'key': doc_intel_config['key'],
            'api_version': doc_intel_config.get('api_version', '2024-07-31-preview')
        })
        services['ocr'] = ocr_manager
        logger.info("Document Intelligence initialized")
        
        # OpenAI Manager (for extraction + embeddings)
        logger.info("Initializing OpenAI Manager...")
        openai_config = doctype_config['azure_openai']['general']
        embedding_config = doctype_config['azure_openai_embedding']
        
        # Get batch config if available
        batch_config = doctype_config['azure_openai'].get('batch')
        
        openai_manager = OpenAIManager(
            openai_config=openai_config,
            embedding_config=embedding_config,
            batch_config=batch_config  # Optional - for Batch API
        )
        services['openai'] = openai_manager
        
        if batch_config:
            logger.info(f"OpenAI Manager initialized - Model: {openai_config['model_name']}, Batch deployment: {batch_config['deployment_name']}")
        else:
            logger.info(f"OpenAI Manager initialized - Model: {openai_config['model_name']}")
        
        # AI Search Manager (for RAG)
        logger.info("Initializing AI Search...")
        search_config = doctype_config['azure_ai_search']
        
        # Get embedding dimensions from embedding config (must match!)
        embedding_dims = doctype_config['azure_openai_embedding'].get(
            'dimensions', doctype_config['azure_openai_embedding'].get('dimension', 1536)
        )
        
        search_manager = SearchManager(
            endpoint=search_config['endpoint'],
            api_key=search_config['key'],
            index_name=search_config['index_name'],
            vector_dimensions=embedding_dims
        )
        
        # Auto-create index if it doesn't exist (PRODUCTION READY!)
        logger.info(f"Checking if index '{search_config['index_name']}' exists...")
        try:
            created = search_manager.create_universal_index()
            if created:
                logger.info(f"OK Created new index: {search_config['index_name']}")
            else:
                logger.info(f"OK Index already exists: {search_config['index_name']}")
        except Exception as e:
            logger.warning(f"Index check/creation: {e}")
            logger.info("Continuing with existing index...")
        
        services['search'] = search_manager
        logger.info(f"AI Search initialized - Index: {search_config['index_name']}")
        
        # Cost Tracker (pass api_type for batch discount calculation)
        api_type = config.get('extraction', {}).get('api_type', 'general')
        cost_tracker = CostTracker(config.get('costs', {}), api_type=api_type)
        services['cost_tracker'] = cost_tracker
        logger.info(f"Cost Tracker initialized (api_type: {api_type})")
        
        # SQL Logger (optional - logs provider status to Azure SQL)
        from services.sql_logger import SQLLogger
        sql_logger = SQLLogger(config)
        services['sql_logger'] = sql_logger
        
        logger.info("All Azure services initialized successfully!")
        
        return services
        
    except Exception as e:
        logger.error(f"Azure services initialization failed: {str(e)}")
        raise


def discover_providers(blob_manager, input_container: str):
    """Discover all providers"""
    print_section("STEP 5: DISCOVERING PROVIDERS")
    
    try:
        logger.info(f"Scanning container: {input_container}")
        
        folder_structure = blob_manager.get_folder_structure(input_container)
        providers = list(folder_structure.keys())
        
        logger.info(f"Found {len(providers)} providers")
        
        if len(providers) == 0:
            logger.warning("No providers found")
            return [], {}
        
        for i, provider in enumerate(providers[:5], 1):
            folders = folder_structure[provider]
            logger.info(f"   {i}. {provider} ({len(folders)} folders)")
        
        if len(providers) > 5:
            logger.info(f"   ... and {len(providers) - 5} more providers")
        
        return providers, folder_structure
        
    except Exception as e:
        logger.error(f"Provider discovery failed: {str(e)}")
        raise


def process_document_with_rag(doc_blob, provider: str, folder: str, fields: List[str],
                              services: Dict, config: Dict, prompt_module) -> Dict:
    """
    Process document using RAG extraction.
    
    Routes to text or multimodal based on config['rag']['mode']:
      - "text": OCR text + text-only GPT extraction
      - "multimodal": OCR text + document image + GPT Vision extraction
    
    Both modes use field-specific RAG search internally for accuracy.
    """
    doc_name = doc_blob.name.split('/')[-1]
    rag_mode = config.get('rag', {}).get('mode', 'text')
    api_type = config.get('extraction', {}).get('api_type', 'general')
    
    logger.info(f"      Mode: {rag_mode.upper()} RAG | API: {api_type.upper()} ({len(fields)} fields)")
    
    try:
        # Download document
        doc_bytes = services['blob'].download_blob(
            config['azure_blob']['inputcontainer'],
            doc_blob.name
        )
        
        if not doc_bytes:
            logger.error(f"      Failed to download {doc_name}")
            return None
        
        # Get document extension
        _, ext = os.path.splitext(doc_name)
        
        # Common parameters for both modes
        rag_params = dict(
            doc_bytes=doc_bytes,
            doc_name=doc_name,
            extension=ext,
            provider=provider,
            folder=folder,
            fields=fields,
            ocr=services['ocr'],
            openai_manager=services['openai'],
            search_manager=services['search'],
            cost_tracker=services['cost_tracker'],
            prompt_module=prompt_module,
            api_type=api_type
        )
        
        # Route based on config mode
        if rag_mode == 'multimodal':
            from extraction.multimodal_rag import process_document_multimodal_rag
            extracted_data, success = process_document_multimodal_rag(**rag_params)
        else:
            from extraction.text_rag import process_document_text_rag
            extracted_data, success = process_document_text_rag(**rag_params)
        
        if not success:
            logger.error(f"      RAG extraction failed for {doc_name}")
            return None
        
        return extracted_data
        
    except Exception as e:
        logger.error(f"      Document processing failed: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return None


def calculate_best_values(documents: List[Dict], fields: List[str], folder_name: str,
                         prompt_module=None) -> Dict:
    """
    Calculate best values using frequency and confidence.
    
    Handles two types of fields:
      - single (cardinality="single"): pick best single value by frequency + confidence
      - multi (cardinality="multi"): merge arrays from all documents, deduplicate by sub-field values
    
    Args:
        documents: List of processed documents with fields
        fields: List of field names
        folder_name: Folder name for source tracking
        prompt_module: Prompt module with FIELD_LIBRARY (for cardinality info)
    
    Returns:
        Dict with best values including source tracking
    """
    from collections import Counter
    
    # Get FIELD_LIBRARY to check cardinality
    field_library = {}
    if prompt_module:
        field_library = getattr(prompt_module, 'FIELD_LIBRARY', {})
    
    best_values = {}
    
    for field in fields:
        cardinality = field_library.get(field, {}).get('cardinality', 'single')
        
        if cardinality == 'multi':
            field_info = field_library.get(field, {})
            best_values[field] = _aggregate_multi_field(
                field, documents, folder_name, field_info
            )
        else:
            best_values[field] = _aggregate_single_field(
                field, documents, folder_name
            )
    
    return best_values


def _aggregate_single_field(field: str, documents: List[Dict], folder_name: str) -> Dict:
    """Aggregate a single-value field using frequency + confidence."""
    from collections import Counter
    
    field_occurrences = []
    
    for doc in documents:
        if field in doc['fields']:
            field_data = doc['fields'][field]
            
            if isinstance(field_data, dict):
                value = field_data.get('value') or ''
                confidence = field_data.get('confidence') or 0
                
                if confidence is not None and value != '':
                    # Skip empty or "unknown" with low confidence
                    if (not value.strip() or str(value).lower() == 'unknown') and float(confidence) < 0.50:
                        continue
                    
                    field_occurrences.append((
                        value,
                        float(confidence),
                        doc.get('document_name', '')
                    ))
    
    if field_occurrences:
        value_counts = Counter([v[0] for v in field_occurrences])
        most_common_value, max_frequency = value_counts.most_common(1)[0]
        
        candidates = [occ for occ in field_occurrences if occ[0] == most_common_value]
        best_occurrence = max(candidates, key=lambda x: x[1])
        best_value, best_confidence, source_file = best_occurrence
        
        confidences_for_value = [occ[1] for occ in candidates]
        avg_confidence = sum(confidences_for_value) / len(confidences_for_value)
        
        return {
            'value': best_value,
            'confidence': round(avg_confidence, 2),
            'source_folder': folder_name,
            'source_file': source_file,
            'frequency': max_frequency,
            'total_documents': len(documents)
        }
    else:
        return {
            'value': '',
            'confidence': 0.0,
            'source_folder': folder_name,
            'source_file': '',
            'frequency': 0,
            'total_documents': len(documents)
        }


def _aggregate_multi_field(field: str, documents: List[Dict], folder_name: str,
                          field_info: dict = None) -> list:
    """
    Aggregate a multi-value field by merging arrays from all documents.
    
    Deduplicates by comparing sub-field values. If same item appears
    in multiple documents, picks the one with highest average confidence.
    Tracks frequency (how many documents had this item).
    
    If no data found, returns one skeleton item with empty values
    for consistent JSON structure.
    """
    all_items = []  # List of (item_dict, source_doc_name)
    
    for doc in documents:
        if field in doc['fields']:
            field_data = doc['fields'][field]
            
            # Field data should be a list for multi-value
            if isinstance(field_data, list):
                for item in field_data:
                    if isinstance(item, dict):
                        all_items.append((item, doc.get('document_name', '')))
            elif isinstance(field_data, dict) and field in field_data:
                # Nested: {"state_licenses": [...]}
                inner = field_data[field]
                if isinstance(inner, list):
                    for item in inner:
                        if isinstance(item, dict):
                            all_items.append((item, doc.get('document_name', '')))
    
    if not all_items:
        # Return skeleton with empty values for consistent structure
        return _build_empty_multi_item(field_info, folder_name, len(documents))
    
    # Deduplicate by creating a signature from sub-field values
    unique_items = {}  # signature -> (best_item, source_file, frequency)
    
    for item, source_file in all_items:
        # Build signature from all value fields (ignore id, confidence)
        sig_parts = []
        for key, val in sorted(item.items()):
            if key == 'id':
                continue
            if isinstance(val, dict):
                sig_parts.append(str(val.get('value', '')).strip().lower())
            elif isinstance(val, str):
                sig_parts.append(val.strip().lower())
        
        signature = '|'.join(sig_parts)
        
        if not signature or signature == '|'.join([''] * len(sig_parts)):
            continue  # Skip empty items
        
        if signature in unique_items:
            # Increment frequency
            existing = unique_items[signature]
            existing['frequency'] += 1
            
            # Keep item with higher avg confidence
            new_conf = _avg_item_confidence(item)
            old_conf = _avg_item_confidence(existing['item'])
            if new_conf > old_conf:
                existing['item'] = item
                existing['source_file'] = source_file
        else:
            unique_items[signature] = {
                'item': item,
                'source_file': source_file,
                'frequency': 1
            }
    
    # Build final array with sequential ids
    result = []
    for idx, (sig, data) in enumerate(unique_items.items(), 1):
        item = data['item']
        final_item = {'id': idx}
        
        for key, val in item.items():
            if key == 'id':
                continue
            
            if isinstance(val, dict):
                final_item[key] = {
                    'value': val.get('value', ''),
                    'confidence': round(float(val.get('confidence', 0)), 2),
                    'source_folder': folder_name,
                    'source_file': data['source_file'],
                    'frequency': data['frequency'],
                    'total_documents': len(documents)
                }
            else:
                final_item[key] = {
                    'value': val,
                    'confidence': 0.5,
                    'source_folder': folder_name,
                    'source_file': data['source_file'],
                    'frequency': data['frequency'],
                    'total_documents': len(documents)
                }
        
        result.append(final_item)
    
    return result


def _avg_item_confidence(item: dict) -> float:
    """Calculate average confidence across all sub-fields of a multi-value item."""
    confidences = []
    for key, val in item.items():
        if key == 'id':
            continue
        if isinstance(val, dict) and 'confidence' in val:
            confidences.append(float(val.get('confidence', 0)))
    return sum(confidences) / len(confidences) if confidences else 0.0


def _build_empty_multi_item(field_info: dict, folder_name: str, total_documents: int) -> list:
    """
    Build a skeleton multi-value item with empty values.
    Returns a list with one item where all sub-fields have empty values.
    This ensures consistent JSON structure even when no data is found.
    """
    if not field_info:
        return []
    
    item_fields = field_info.get('item_fields', {})
    if not item_fields:
        return []
    
    empty_item = {'id': 1}
    for sub_field in item_fields:
        empty_item[sub_field] = {
            'value': '',
            'confidence': '',
            'source_folder': '',
            'source_file': '',
            'frequency': 0,
            'total_documents': total_documents
        }
    
    return [empty_item]


def save_results(provider: str, extracted_data: Dict, output_container: str,
                input_container: str, blob_manager, 
                config: Dict, total_documents: int, folder_name: str,
                source_documents: list = None, cost_tracker=None, sql_doc_key=None):
    """
    Save extraction results to output container
    
    Output structure per provider:
      highconfidence/ or lowconfidence/
        PROVIDER_NAME_KEY/
          ProcessedJSONResult/provider_timestamp.json
          ProcessedCSVResult/provider_timestamp.csv
          ProcessedProviderCostEstimation/provider_timestamp.json
          SourceDocuments/original folder structure preserved
    """
    try:
        import csv
        from io import StringIO
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        extraction_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Calculate confidence metrics (handles both single and multi-value fields)
        confidences = []
        for field_data in extracted_data.values():
            if isinstance(field_data, dict) and 'confidence' in field_data:
                conf = field_data.get('confidence', 0)
                if isinstance(conf, (int, float)):
                    confidences.append(conf)
            elif isinstance(field_data, list):
                # Multi-value field: average confidence across all items
                for item in field_data:
                    if isinstance(item, dict):
                        item_confs = []
                        for key, val in item.items():
                            if key == 'id':
                                continue
                            if isinstance(val, dict) and 'confidence' in val:
                                conf = val.get('confidence')
                                # Skip empty string confidence (skeleton items only)
                                if isinstance(conf, (int, float)):
                                    item_confs.append(conf)
                        if item_confs:
                            confidences.append(sum(item_confs) / len(item_confs))
        
        # Calculate both for reporting
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0
        min_confidence = min(confidences) if confidences else 0
        
        # Determine folder based on MIN confidence (stricter!)
        # If ANY field is below threshold  ->  lowconfidence for review
        confidence_threshold = config.get('extraction', {}).get('confidence_threshold', 0.70)
        
        if min_confidence >= confidence_threshold:
            output_folder = "highconfidence"
            logger.info(f"      Routing: HIGH confidence (min: {min_confidence:.2f}, avg: {avg_confidence:.2f})")
        else:
            output_folder = "lowconfidence"
            logger.info(f"      Routing: LOW confidence (min: {min_confidence:.2f}, avg: {avg_confidence:.2f})")
        
        # Provider ID = provider_timestamp (unique Azure AI Search ID)
        provider_id = f"{provider}_{timestamp}"
        
        # Output folder name: provider_name_key (unique per run)
        if sql_doc_key:
            provider_folder = f"{provider}_{sql_doc_key}"
        else:
            provider_folder = provider
        
        # Prepare JSON output with metadata
        json_output = {
            'provider_name': provider,
            'provider_id': provider_id,
            'extraction_datetime': extraction_datetime,
            'total_documents_processed': total_documents,
            'folders_processed': folder_name,
            'confidence_metrics': {
                'min_confidence': round(min_confidence, 2),
                'avg_confidence': round(avg_confidence, 2),
                'threshold': confidence_threshold,
                'routing': output_folder
            },
            'fields': extracted_data
        }
        
        # JSON output
        json_path = f"{output_folder}/{provider_folder}/ProcessedJSONResult/{provider}_{timestamp}.json"
        json_content = json.dumps(json_output, indent=2)
        blob_manager.upload_blob(output_container, json_path, json_content)
        logger.info(f"      Saved JSON: {json_path}")
        
        # Provider Cost Estimation JSON
        # Uses actual tracked costs from CostTracker
        provider_cost_estimation = {
            'provider_name': provider,
            'provider_id': provider_id,
            'extraction_datetime': extraction_datetime,
            'total_documents_processed': total_documents,
            'confidence_metrics': {
                'min_confidence': round(min_confidence, 2),
                'avg_confidence': round(avg_confidence, 2),
                'threshold': confidence_threshold,
                'routing': output_folder
            }
        }
        
        # Add actual cost data if cost_tracker is available
        if cost_tracker is not None:
            summary = cost_tracker.get_summary()
            provider_data = summary.get('providers', {}).get(provider, {})
            
            if provider_data:
                tokens = provider_data.get('tokens', {})
                provider_cost_estimation['token_usage'] = {
                    'gpt_input_tokens': tokens.get('input', 0),
                    'gpt_output_tokens': tokens.get('output', 0),
                    'gpt_total_tokens': tokens.get('total', 0),
                    'embedding_tokens': tokens.get('embedding', 0)
                }
                provider_cost_estimation['pages_processed'] = provider_data.get('ocr_pages', 0)
                
                cost_bd = provider_data.get('cost_breakdown', {})
                provider_cost_estimation['estimated_cost'] = {
                    'api_type': summary.get('api_type', 'general'),
                    'ocr_cost': cost_bd.get('ocr', 0),
                    'embedding_cost': cost_bd.get('embedding', 0),
                    'gpt_cost': cost_bd.get('gpt', 0),
                    'total_cost': provider_data.get('cost', 0),
                    'note': 'Batch API cost is 50% reduced compared to general API'
                        if summary.get('api_type') == 'batch'
                        else 'Standard general API pricing'
                }
        
        cost_path = f"{output_folder}/{provider_folder}/ProcessedProviderCostEstimation/{provider}_{timestamp}.json"
        cost_content = json.dumps(provider_cost_estimation, indent=2)
        blob_manager.upload_blob(output_container, cost_path, cost_content)
        logger.info(f"      Saved Cost Estimation: {cost_path}")
        
        # CSV output - SINGLE ROW format with multi-value flattening
        csv_lines = []
        
        field_order = list(extracted_data.keys())
        
        # Escape function for CSV values
        def escape_csv(value):
            """Escape CSV values - wrap in quotes if contains comma, quote, or newline"""
            value_str = str(value)
            if ',' in value_str or '"' in value_str or '\n' in value_str or '\r' in value_str:
                value_str = value_str.replace('"', '""')
                return f'"{value_str}"'
            return value_str
        
        # Build headers
        headers = [
            'provider_name',
            'extraction_datetime',
            'total_documents_processed'
        ]
        
        # Build row values in parallel with headers
        row_values = [
            escape_csv(provider),
            escape_csv(extraction_datetime),
            escape_csv(total_documents)
        ]
        
        for field in field_order:
            field_data = extracted_data[field]
            
            if isinstance(field_data, list):
                # Multi-value field: flatten with _1_, _2_ suffixes
                for item_idx, item in enumerate(field_data, 1):
                    if not isinstance(item, dict):
                        continue
                    for sub_key, sub_val in item.items():
                        if sub_key == 'id':
                            continue
                        # Header: state_license_1_number, state_license_1_number_confidence, etc.
                        prefix = f"{field}_{item_idx}_{sub_key}" if '_' not in sub_key else f"{field[:-1]}_{item_idx}_{sub_key}"
                        # Simpler: just use field_idx_subfield
                        col_prefix = f"{field}_{item_idx}_{sub_key}"
                        
                        if isinstance(sub_val, dict):
                            headers.append(col_prefix)
                            headers.append(f"{col_prefix}_confidence")
                            headers.append(f"{col_prefix}_source_folder")
                            headers.append(f"{col_prefix}_source_file")
                            
                            row_values.append(escape_csv(sub_val.get('value', '')))
                            row_values.append(escape_csv(sub_val.get('confidence', 0)))
                            row_values.append(escape_csv(sub_val.get('source_folder', folder_name)))
                            row_values.append(escape_csv(sub_val.get('source_file', '')))
                        else:
                            headers.append(col_prefix)
                            row_values.append(escape_csv(sub_val))
            
            elif isinstance(field_data, dict):
                # Single-value field
                headers.append(f'{field}')
                headers.append(f'{field}_confidence')
                headers.append(f'{field}_source_folder')
                headers.append(f'{field}_source_file')
                
                row_values.append(escape_csv(field_data.get('value', '')))
                row_values.append(escape_csv(field_data.get('confidence', 0)))
                row_values.append(escape_csv(field_data.get('source_folder', folder_name)))
                row_values.append(escape_csv(field_data.get('source_file', '')))
            
            else:
                headers.append(f'{field}')
                row_values.append(escape_csv(field_data))
        
        csv_lines.append(','.join(headers))
        csv_lines.append(','.join(row_values))
        
        # Save CSV
        csv_path = f"{output_folder}/{provider_folder}/ProcessedCSVResult/{provider}_{timestamp}.csv"
        csv_content = '\n'.join(csv_lines)
        blob_manager.upload_blob(output_container, csv_path, csv_content)
        logger.info(f"      Saved CSV: {csv_path}")
        
        # Copy source documents to output container (preserve folder structure)
        if source_documents:
            source_count = 0
            for doc_blob in source_documents:
                try:
                    # Preserve folder structure relative to provider
                    # Input: SMITH-JOHN/1. GEN & HR/subfolder/file.pdf
                    # Output: highconfidence/SMITH-JOHN/SourceDocuments/1. GEN & HR/subfolder/file.pdf
                    relative_path = doc_blob.name.replace(
                        f"{provider}/", "", 1
                    )
                    doc_bytes = blob_manager.download_blob(
                        input_container, doc_blob.name
                    )
                    if doc_bytes:
                        source_path = f"{output_folder}/{provider_folder}/SourceDocuments/{relative_path}"
                        blob_manager.upload_blob(
                            output_container, source_path, doc_bytes
                        )
                        source_count += 1
                except Exception as e:
                    logger.warning(f"      Could not copy source doc {doc_blob.name}: {e}")
            logger.info(f"      Saved SourceDocuments: {source_count} files")
        
        logger.info(f"      Confidence: MIN={min_confidence:.2f}, AVG={avg_confidence:.2f} -> {output_folder}")
        
        return min_confidence
        
    except Exception as e:
        logger.error(f"      Failed to save results: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        raise


def process_single_provider(provider: str, folder_structure: Dict, blob_manager, 
                            config: Dict, services: Dict, doctype: str, 
                            doctype_config: Dict, prompt_module, archiver=None):
    """Process a single provider's documents with RAG"""
    sql_logger = services.get('sql_logger')
    sql_doc_id = None
    
    try:
        # Set current provider for cost tracking
        services['cost_tracker'].set_provider(provider)
        
        # SQL Log: BEGIN
        api_type = config.get('extraction', {}).get('api_type', 'general')
        source_path = f"{config.get('azure_blob', {}).get('inputcontainer', '')}/{provider}"
        
        if provider not in folder_structure:
            logger.warning(f"   Provider not found")
            return
        
        provider_folders = folder_structure[provider]
        folder_configs = doctype_config['folder_configs']
        
        # Get folder names
        provider_folder_names = list(provider_folders.keys()) if isinstance(provider_folders, dict) else provider_folders
        
        # Find matching folder
        matching_folder = None
        for folder_name in folder_configs.keys():
            if folder_name in provider_folder_names:
                matching_folder = folder_name
                break
        
        if not matching_folder:
            logger.warning(f"   No matching folder found")
            logger.warning(f"   Expected: {list(folder_configs.keys())}")
            logger.warning(f"   Found: {provider_folder_names}")
            return
        
        logger.info(f"   Processing folder: {matching_folder}")
        
        # Get documents
        folder_path = f"{provider}/{matching_folder}"
        documents = blob_manager.list_blobs_in_folder(
            config['azure_blob']['inputcontainer'],
            folder_path
        )
        
        logger.info(f"   Found {len(documents)} documents (including all subfolders)")
        
        # SQL Log: BEGIN with file count
        if sql_logger:
            sql_doc_id = sql_logger.insert_begin(
                provider_name=provider,
                document_type=doctype,
                api_type=api_type,
                source_folder_path=source_path,
                file_count=len(documents)
            )
        
        if len(documents) == 0:
            logger.warning(f"   No documents to process")
            return
        
        # Get fields
        fields = folder_configs[matching_folder]['fields']
        logger.info(f"   Extracting {len(fields)} fields using PER-FIELD RAG")
        logger.info(f"   Each field gets its own best 3 examples for maximum accuracy")
        
        # Store ALL extracted data from all documents (not just aggregated)
        all_documents_data = []
        
        # SQL Log: PROCESSING - starting document loop
        if sql_logger and sql_doc_id:
            sql_logger.update_status(sql_doc_id, "PROCESSING",
                f"Processing {len(documents)} documents with {len(fields)} fields")
        
        # Process each document with RAG
        for doc_idx, doc_blob in enumerate(documents, 1):
            # Extract subfolder path from blob name
            relative_path = doc_blob.name.replace(f"{provider}/", "")
            
            logger.info(f"   Document {doc_idx}/{len(documents)}: {relative_path}")
            
            # SQL Log: update progress
            if sql_logger and sql_doc_id and doc_idx % 5 == 0:
                sql_logger.update_status(sql_doc_id, "PROCESSING",
                    f"Document {doc_idx}/{len(documents)}",
                    ocr_status="IN_PROGRESS", ocr_desc=f"{doc_idx}/{len(documents)} docs OCR'd",
                    embedding_status="IN_PROGRESS", embedding_desc="Embedding chunks",
                    search_status="IN_PROGRESS", search_desc="Indexing in Azure AI Search",
                    parsing_status="IN_PROGRESS", parsing_desc=f"Extracting {len(fields)} fields per doc")
            
            extracted_data = process_document_with_rag(
                doc_blob,
                provider,
                matching_folder,
                fields,
                services,
                config,
                prompt_module  # Pass prompt_module
            )
            
            if not extracted_data:
                continue
            
            # Store document data with metadata
            all_documents_data.append({
                'document_name': doc_blob.name.split('/')[-1],
                'relative_path': relative_path,
                'fields': extracted_data
            })
            
            logger.info(f"      Document processed successfully with RAG")
            services['cost_tracker'].add_provider_document()
        
        # Aggregate results using FREQUENCY + CONFIDENCE (POC logic)
        if all_documents_data:
            logger.info(f"   Aggregating results from {len(all_documents_data)} documents...")
            
            # SQL Log: AGGREGATING
            if sql_logger and sql_doc_id:
                sql_logger.update_status(sql_doc_id, "AGGREGATING",
                    f"Aggregating {len(all_documents_data)} documents",
                    ocr_status="COMPLETED", ocr_desc=f"{len(documents)} documents OCR'd",
                    embedding_status="COMPLETED", embedding_desc="All chunks embedded",
                    search_status="COMPLETED", search_desc="All chunks indexed",
                    parsing_status="COMPLETED", parsing_desc=f"{len(fields)} fields extracted per doc")
            
            # Calculate best values using frequency and confidence
            final_results = calculate_best_values(
                all_documents_data, 
                fields,
                matching_folder,
                prompt_module=prompt_module
            )
            
            # Save aggregated results + source documents
            logger.info(f"   Saving aggregated results...")
            avg_confidence = save_results(
                provider,
                final_results,
                config['azure_blob']['outputcontainer'],
                config['azure_blob']['inputcontainer'],
                services['blob'],
                config,
                len(documents),
                matching_folder,
                documents,
                cost_tracker=services['cost_tracker'],
                sql_doc_key=sql_doc_id
            )
            logger.info(f"   Provider processing complete - Confidence: {avg_confidence:.2f}")
            
            # Determine routing for SQL log
            confidence_threshold = config.get('extraction', {}).get(
                'confidence_threshold', 0.70
            )
            confidences = [
                v.get('confidence', 0) for v in final_results.values()
                if isinstance(v, dict) and 'confidence' in v
            ]
            min_conf = min(confidences) if confidences else 0
            routing = "highconfidence" if min_conf >= confidence_threshold else "lowconfidence"
            
            # SQL Log: COMPLETED
            output_container = config['azure_blob']['outputcontainer']
            provider_out = f"{provider}_{sql_doc_id}" if sql_doc_id else provider
            target_path = f"{output_container}/{routing}/{provider_out}"
            if sql_logger and sql_doc_id:
                sql_logger.update_complete(sql_doc_id,
                    status="COMPLETED",
                    status_desc=f"Confidence: {avg_confidence:.2f}, Routing: {routing}",
                    target_folder_path=target_path
                )
            
            # Queue for archive if enabled (--archive true)
            archive_enabled = config.get('extraction', {}).get('archive', False)
            if archive_enabled and archiver is not None:
                archiver.add_provider(provider, documents, routing)
                
                # SQL Log: update archive path
                if sql_logger and sql_doc_id:
                    sql_logger.update_complete(sql_doc_id,
                        status="COMPLETED",
                        status_desc=f"Archived. Confidence: {avg_confidence:.2f}",
                        target_folder_path=target_path,
                        archive_folder_path=f"archivecontainer/{routing}/{provider_out}"
                    )
        else:
            logger.warning(f"   No data extracted from any document")
            
            # SQL Log: NO_DATA
            if sql_logger and sql_doc_id:
                sql_logger.update_complete(sql_doc_id,
                    status="NO_DATA",
                    status_desc="No data extracted from any document"
                )
            
            # Queue as unprocessed (processing failed, no data)
            archive_enabled = config.get('extraction', {}).get('archive', False)
            if archive_enabled and archiver is not None:
                archiver.add_provider(provider, documents, "unprocessed")
        
    except Exception as e:
        logger.error(f"   Provider failed: {str(e)}")
        logger.exception("   Traceback:")
        
        # SQL Log: FAILED
        if sql_logger and sql_doc_id:
            sql_logger.update_complete(sql_doc_id,
                status="FAILED",
                status_desc=str(e)[:200]
            )
        
        # Queue as unprocessed (exception during processing)
        archive_enabled = config.get('extraction', {}).get('archive', False)
        if archive_enabled and archiver is not None:
            try:
                folder_path = f"{provider}/{matching_folder}" if matching_folder else provider
                documents = blob_manager.list_blobs_in_folder(
                    config['azure_blob']['inputcontainer'], folder_path
                )
                if documents:
                    archiver.add_provider(provider, documents, "unprocessed")
            except Exception:
                pass


def process_providers(providers: List[str], folder_structure: Dict, config: Dict, 
                     services: Dict, doctype: str, doctype_config: Dict, prompt_module):
    """Process all providers in batches"""
    print_section("STEP 6: PROCESSING PROVIDERS WITH RAG")
    
    try:
        batch_size = config['processing'].get('batch_size', 10)
        total_providers = len(providers)
        total_batches = (total_providers + batch_size - 1) // batch_size
        
        logger.info(f"Processing configuration:")
        logger.info(f"   Total providers: {total_providers}")
        logger.info(f"   Batch size: {batch_size}")
        logger.info(f"   RAG mode: {config['rag']['mode']}")
        logger.info(f"   Total batches: {total_batches}")
        
        if total_providers == 0:
            logger.warning("No providers to process")
            return
        
        # Create archiver if archive is enabled
        archive_enabled = config.get('extraction', {}).get('archive', False)
        archiver = None
        if archive_enabled:
            from services.archive_manager import ArchiveManager
            archiver = ArchiveManager(
                blob_manager=services['blob'],
                config=config,
                doctype=doctype
            )
            logger.info(f"   Archive: ENABLED")
        
        # Process in batches
        for batch_num in range(total_batches):
            start_idx = batch_num * batch_size
            end_idx = min(start_idx + batch_size, total_providers)
            batch_providers = providers[start_idx:end_idx]
            
            logger.info("")
            logger.info("=" * 80)
            logger.info(f"BATCH {batch_num + 1}/{total_batches} (Providers {start_idx + 1}-{end_idx})")
            logger.info("=" * 80)
            
            for provider_idx, provider in enumerate(batch_providers, 1):
                global_idx = start_idx + provider_idx
                logger.info("")
                logger.info(f"Provider {global_idx}/{total_providers}: {provider}")
                logger.info("-" * 80)
                
                process_single_provider(
                    provider,
                    folder_structure,
                    services['blob'], 
                    config, 
                    services, 
                    doctype,
                    doctype_config,
                    prompt_module,
                    archiver=archiver
                )
        
        # Finalize archive (create single zip with all providers)
        if archiver is not None:
            logger.info("")
            logger.info("=" * 80)
            logger.info("ARCHIVING")
            logger.info("=" * 80)
            archiver.finalize()
        
        # ================================================================
        # FINAL SUMMARY
        # ================================================================
        cost_summary = services['cost_tracker'].get_summary()
        rag_mode = config.get('rag', {}).get('mode', 'text')
        api_type = config.get('extraction', {}).get('api_type', 'general')
        archive_enabled = config.get('extraction', {}).get('archive', False)
        provider_stats = cost_summary.get('providers', {})
        usage = cost_summary['usage']
        breakdown = cost_summary['breakdown']
        
        # Count processed vs unprocessed
        processed_list = [p for p, s in provider_stats.items() if s['documents'] > 0]
        unprocessed_list = [p for p, s in provider_stats.items() if s['documents'] == 0]
        total_docs = sum(s['documents'] for s in provider_stats.values())
        
        logger.info("")
        logger.info("=" * 80)
        logger.info("FINAL SUMMARY")
        logger.info("=" * 80)
        
        # Run info
        logger.info(f"  RAG mode        : {rag_mode.upper()}")
        logger.info(f"  API type        : {api_type.upper()}")
        logger.info(f"  Archive         : {'YES' if archive_enabled else 'NO'}")
        
        # Provider counts
        logger.info("")
        logger.info(f"  Providers       : {len(provider_stats)} total")
        logger.info(f"    Processed     : {len(processed_list)}")
        logger.info(f"    Unprocessed   : {len(unprocessed_list)}")
        if unprocessed_list:
            for p in unprocessed_list:
                logger.info(f"      - {p}")
        
        # Pages and docs
        logger.info("")
        logger.info(f"  Documents       : {total_docs}")
        logger.info(f"  Pages (OCR)     : {usage['ocr_pages']}")
        
        # Token consumption - overall
        logger.info("")
        logger.info(f"  Tokens (overall)")
        logger.info(f"    Input         : {usage['gpt_input_tokens']:,}")
        logger.info(f"    Output        : {usage['gpt_output_tokens']:,}")
        logger.info(f"    Total         : {usage['gpt_total_tokens']:,}")
        logger.info(f"    Embedding     : {usage['embedding_tokens']:,}")
        
        # Token consumption - per provider
        if provider_stats:
            logger.info("")
            logger.info(f"  Tokens (per provider)")
            for prov, stats in provider_stats.items():
                t = stats['tokens']
                logger.info(
                    f"    {prov}: "
                    f"{stats['documents']} docs, "
                    f"{stats['ocr_pages']} pages, "
                    f"input={t['input']:,}, "
                    f"output={t['output']:,}, "
                    f"embedding={t['embedding']:,}, "
                    f"cost=${stats['cost']:.4f}"
                )
        
        # Cost
        logger.info("")
        logger.info(f"  Cost ({api_type.upper()} API)")
        logger.info(f"    OCR           : ${breakdown['ocr']:.4f}")
        logger.info(f"    Embeddings    : ${breakdown['embedding']:.4f}")
        logger.info(f"    GPT           : ${breakdown['gpt4o']:.4f}")
        logger.info(f"    TOTAL         : ${cost_summary['total']:.4f}")
        
        logger.info("")
        logger.info("=" * 80)
        
    except Exception as e:
        logger.error(f"Processing failed: {str(e)}")
        raise


def main():
    """Main application entry point"""
    
    try:
        # Parse command-line arguments
        parser = argparse.ArgumentParser(description='Medical Document Parser with RAG')
        parser.add_argument('--apitype', required=True, choices=['general', 'batch'], 
                          help='API type: general (real-time) or batch (50%% cheaper)')
        parser.add_argument('--doctype', required=True, 
                          help='Document type (e.g., cred)')
        parser.add_argument('--archive', required=True, choices=['true', 'false'],
                          help='Enable archiving: true or false')
        
        args = parser.parse_args()
        
        # Load config first to get log settings
        config = load_configuration()
        
        # Setup logger with dynamic prefix: doctype_ragparser_datetime.log
        log_config = config.get('log', {})
        log_prefix = log_config.get('prefix', f"{args.doctype}_ragparser")
        log_dir = log_config.get('directory', 'logs')
        log_level = log_config.get('level', 'INFO')
        
        log_filename = setup_logger(
            log_level=log_level,
            log_dir=log_dir,
            log_prefix=log_prefix
        )
        logger = get_logger(__name__)
        
        # Convert string 'true'/'false' to boolean
        archive_enabled = args.archive.lower() == 'true'
        
        print_section("MEDICAL DOCUMENT PARSER - RAG-BASED PRODUCTION SYSTEM", "=")
        logger.info(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Log file: {log_filename}")
        logger.info(f"Arguments: --apitype {args.apitype} --doctype {args.doctype} --archive {args.archive}")
        
        # Override config with command-line arguments
        config['extraction']['api_type'] = args.apitype
        config['extraction']['archive'] = archive_enabled
        
        # Get RAG mode from config
        rag_mode = config.get('rag', {}).get('mode', 'text')
        logger.info(f"Settings: API={args.apitype} | RAG={rag_mode} | Archive={args.archive}")
        
        # Validate and initialize
        doctype_config = validate_doctype_config(config, args.doctype)
        prompt_module = load_prompt_module(doctype_config['prompt_module'])
        services = initialize_azure_services(config, doctype_config)
        providers, folder_structure = discover_providers(services['blob'], config['azure_blob']['inputcontainer'])
        process_providers(providers, folder_structure, config, services, args.doctype, doctype_config, prompt_module)
        
        print_section("PROCESSING COMPLETE", "=")
        logger.info(f"End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Log saved: {log_filename}")
        logger.info(f"Check output container for results!")
        
    except KeyboardInterrupt:
        logger.warning("Process interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error("FATAL ERROR")
        logger.error(f"   {str(e)}")
        logger.exception("Traceback:")
        sys.exit(1)


if __name__ == "__main__":
    main()
