"""
Result Saver - Save Extraction Results to Azure Blob
=====================================================

Handles:
  - Confidence routing (highconfidence / lowconfidence)
  - LLM-as-Judge evaluation (adds eval_score + eval_description)
  - JSON output with metadata
  - CSV flattened output
  - Cost estimation JSON
  - Source document preservation
"""

import json
import logging
from datetime import datetime
from typing import Dict

logger = logging.getLogger(__name__)


def save_results(provider: str, extracted_data: Dict, output_container: str,
                input_container: str, blob_manager, 
                config: Dict, total_documents: int, folder_name: str,
                source_documents: list = None, cost_tracker=None, sql_doc_key=None):
    """
    Save extraction results to output container.
    
    Output structure:
      highconfidence/ or lowconfidence/
        PROVIDER_NAME_KEY/
          ProcessedJSONResult/provider_timestamp.json
          ProcessedCSVResult/provider_timestamp.csv
          ProcessedProviderCostEstimation/provider_timestamp.json
          SourceDocuments/original folder structure preserved
    """
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        extraction_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Calculate confidence metrics
        confidences = _calculate_confidences(extracted_data)
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0
        min_confidence = min(confidences) if confidences else 0
        
        # Route based on MIN confidence
        confidence_threshold = config.get('extraction', {}).get('confidence_threshold', 0.70)
        
        if min_confidence >= confidence_threshold:
            output_folder = "highconfidence"
            logger.info(f"      Routing: HIGH confidence (min: {min_confidence:.2f}, avg: {avg_confidence:.2f})")
        else:
            output_folder = "lowconfidence"
            logger.info(f"      Routing: LOW confidence (min: {min_confidence:.2f}, avg: {avg_confidence:.2f})")
        
        provider_id = f"{provider}_{timestamp}"
        provider_folder = f"{provider}_{sql_doc_key}" if sql_doc_key else provider
        
        # Run evaluation metrics if enabled (under doctype config)
        doctype = config.get('_current_doctype', '')
        doctype_config = config.get('doctypes', {}).get(doctype, {})
        doctype_eval_config = doctype_config.get('evaluation', {})
        
        evaluation_summary = {}
        
        if doctype_eval_config.get('enabled', False):
            try:
                from evaluation.eval_runner import EvalRunner
                
                # Load eval prompt module
                eval_prompt_path = doctype_eval_config.get('eval_prompt_module', '')
                eval_module = None
                if eval_prompt_path:
                    try:
                        parts = eval_prompt_path.split('.')
                        eval_module = __import__(eval_prompt_path, fromlist=[parts[-1]])
                    except ImportError:
                        logger.warning(f"      Eval prompt not found: {eval_prompt_path}")
                
                # Build evaluation context
                eval_context = {
                    'provider_name': provider,
                    'ocr_texts': [],  # TODO: pass OCR texts from extraction
                }
                
                runner = EvalRunner(doctype_eval_config, eval_prompt_module=eval_module)
                extracted_data = runner.evaluate_and_enrich(extracted_data, context=eval_context)
                evaluation_summary = runner.get_provider_summary(extracted_data, context=eval_context)
                
                logger.info(f"      Evaluation complete: {len(runner.metrics)} metrics applied")
            except Exception as e:
                logger.warning(f"      Evaluation failed (skipped): {e}")
        
        # JSON output
        json_output = {
            'provider_name': provider,
            'provider_id': provider_id,
            'extraction_datetime': extraction_datetime,
            'total_documents_processed': total_documents,
            'folders_processed': folder_name,
            'confidence_metrics': {
                'min_confidence': round(min_confidence, 2),
                'avg_confidence': round(avg_confidence, 2),
                'threshold': confidence_threshold,
                'routing': output_folder
            },
            'data': extracted_data
        }
        
        # Add evaluation summary if evaluation ran
        if evaluation_summary:
            json_output['evaluation_summary'] = evaluation_summary
        
        json_path = f"{output_folder}/{provider_folder}/ProcessedJSONResult/{provider}_{timestamp}.json"
        blob_manager.upload_blob(output_container, json_path, json.dumps(json_output, indent=2))
        logger.info(f"      Saved JSON: {json_path}")
        
        # Cost estimation
        _save_cost_estimation(
            provider, provider_id, provider_folder, extraction_datetime,
            total_documents, min_confidence, avg_confidence, confidence_threshold,
            output_folder, output_container, timestamp, blob_manager, cost_tracker
        )
        
        # CSV output
        _save_csv(
            provider, extracted_data, provider_folder, extraction_datetime,
            total_documents, folder_name, output_folder, output_container,
            timestamp, blob_manager
        )
        
        # Source documents
        if source_documents:
            _save_source_documents(
                provider, provider_folder, source_documents,
                input_container, output_folder, output_container, blob_manager
            )
        
        logger.info(f"      Confidence: MIN={min_confidence:.2f}, AVG={avg_confidence:.2f} -> {output_folder}")
        
        return min_confidence
        
    except Exception as e:
        logger.error(f"      Failed to save results: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        raise


def _calculate_confidences(extracted_data: Dict) -> list:
    """Calculate confidence values from all fields."""
    confidences = []
    for field_data in extracted_data.values():
        if isinstance(field_data, dict) and 'confidence' in field_data:
            conf = field_data.get('confidence', 0)
            if isinstance(conf, (int, float)):
                confidences.append(conf)
        elif isinstance(field_data, list):
            for item in field_data:
                if isinstance(item, dict):
                    item_confs = []
                    for key, val in item.items():
                        if key == 'id':
                            continue
                        if isinstance(val, dict) and 'confidence' in val:
                            conf = val.get('confidence')
                            if isinstance(conf, (int, float)):
                                item_confs.append(conf)
                    if item_confs:
                        confidences.append(sum(item_confs) / len(item_confs))
    return confidences


def _run_evaluation(extracted_data: Dict, eval_config: dict) -> Dict:
    """Run LLM-as-Judge evaluation and enrich data with eval_score."""
    try:
        from evaluation.evaluator import LLMJudge
        
        eval_prompt_path = eval_config.get('eval_prompt_module', '')
        eval_module = None
        if eval_prompt_path:
            try:
                parts = eval_prompt_path.split('.')
                eval_module = __import__(eval_prompt_path, fromlist=[parts[-1]])
            except ImportError:
                logger.warning(f"      Eval prompt module not found: {eval_prompt_path}")
        
        judge = LLMJudge(config=eval_config, eval_prompt_module=eval_module)
        extracted_data = judge.evaluate_and_enrich(extracted_data)
        logger.info(f"      Evaluation complete: eval_score + eval_description added")
    except Exception as e:
        logger.warning(f"      Evaluation failed (skipped): {e}")
    
    return extracted_data


def _save_cost_estimation(provider, provider_id, provider_folder, extraction_datetime,
                          total_documents, min_confidence, avg_confidence, confidence_threshold,
                          output_folder, output_container, timestamp, blob_manager, cost_tracker):
    """Save cost estimation JSON."""
    cost_data = {
        'provider_name': provider,
        'provider_id': provider_id,
        'extraction_datetime': extraction_datetime,
        'total_documents_processed': total_documents,
        'confidence_metrics': {
            'min_confidence': round(min_confidence, 2),
            'avg_confidence': round(avg_confidence, 2),
            'threshold': confidence_threshold,
            'routing': output_folder
        }
    }
    
    if cost_tracker is not None:
        summary = cost_tracker.get_summary()
        provider_data = summary.get('providers', {}).get(provider, {})
        
        if provider_data:
            tokens = provider_data.get('tokens', {})
            cost_data['token_usage'] = {
                'gpt_input_tokens': tokens.get('input', 0),
                'gpt_output_tokens': tokens.get('output', 0),
                'gpt_total_tokens': tokens.get('total', 0),
                'embedding_tokens': tokens.get('embedding', 0)
            }
            cost_data['pages_processed'] = provider_data.get('ocr_pages', 0)
            
            cost_bd = provider_data.get('cost_breakdown', {})
            cost_data['estimated_cost'] = {
                'api_type': summary.get('api_type', 'general'),
                'ocr_cost': cost_bd.get('ocr', 0),
                'embedding_cost': cost_bd.get('embedding', 0),
                'gpt_cost': cost_bd.get('gpt', 0),
                'total_cost': provider_data.get('cost', 0),
                'note': 'Batch API cost is 50% reduced' if summary.get('api_type') == 'batch' else 'Standard pricing'
            }
    
    cost_path = f"{output_folder}/{provider_folder}/ProcessedProviderCostEstimation/{provider}_{timestamp}.json"
    blob_manager.upload_blob(output_container, cost_path, json.dumps(cost_data, indent=2))
    logger.info(f"      Saved Cost Estimation: {cost_path}")


def _save_csv(provider, extracted_data, provider_folder, extraction_datetime,
              total_documents, folder_name, output_folder, output_container,
              timestamp, blob_manager):
    """Save CSV output with multi-value flattening."""
    
    def escape_csv(value):
        value_str = str(value)
        if ',' in value_str or '"' in value_str or '\n' in value_str:
            value_str = value_str.replace('"', '""')
            return f'"{value_str}"'
        return value_str
    
    headers = ['provider_name', 'extraction_datetime', 'total_documents_processed']
    row_values = [escape_csv(provider), escape_csv(extraction_datetime), escape_csv(total_documents)]
    
    for field, field_data in extracted_data.items():
        if isinstance(field_data, list):
            for item_idx, item in enumerate(field_data, 1):
                if not isinstance(item, dict):
                    continue
                for sub_key, sub_val in item.items():
                    if sub_key == 'id':
                        continue
                    col_prefix = f"{field}_{item_idx}_{sub_key}"
                    if isinstance(sub_val, dict):
                        headers.extend([col_prefix, f"{col_prefix}_confidence"])
                        row_values.extend([
                            escape_csv(sub_val.get('value', '')),
                            escape_csv(sub_val.get('confidence', 0))
                        ])
                        # Add eval columns if present
                        if 'eval_score' in sub_val:
                            headers.extend([f"{col_prefix}_eval_score", f"{col_prefix}_eval_description"])
                            row_values.extend([
                                escape_csv(sub_val.get('eval_score', '')),
                                escape_csv(sub_val.get('eval_description', ''))
                            ])
                    else:
                        headers.append(col_prefix)
                        row_values.append(escape_csv(sub_val))
        elif isinstance(field_data, dict):
            headers.extend([field, f'{field}_confidence'])
            row_values.extend([
                escape_csv(field_data.get('value', '')),
                escape_csv(field_data.get('confidence', 0))
            ])
            # Add eval columns if present
            if 'eval_score' in field_data:
                headers.extend([f'{field}_eval_score', f'{field}_eval_description'])
                row_values.extend([
                    escape_csv(field_data.get('eval_score', '')),
                    escape_csv(field_data.get('eval_description', ''))
                ])
        else:
            headers.append(field)
            row_values.append(escape_csv(field_data))
    
    csv_content = ','.join(headers) + '\n' + ','.join(row_values)
    csv_path = f"{output_folder}/{provider_folder}/ProcessedCSVResult/{provider}_{timestamp}.csv"
    blob_manager.upload_blob(output_container, csv_path, csv_content)
    logger.info(f"      Saved CSV: {csv_path}")


def _save_source_documents(provider, provider_folder, source_documents,
                           input_container, output_folder, output_container, blob_manager):
    """Copy source documents preserving folder structure."""
    source_count = 0
    for doc_blob in source_documents:
        try:
            relative_path = doc_blob.name.replace(f"{provider}/", "", 1)
            doc_bytes = blob_manager.download_blob(input_container, doc_blob.name)
            if doc_bytes:
                source_path = f"{output_folder}/{provider_folder}/SourceDocuments/{relative_path}"
                blob_manager.upload_blob(output_container, source_path, doc_bytes)
                source_count += 1
        except Exception as e:
            logger.warning(f"      Could not copy source doc {doc_blob.name}: {e}")
    logger.info(f"      Saved SourceDocuments: {source_count} files")
