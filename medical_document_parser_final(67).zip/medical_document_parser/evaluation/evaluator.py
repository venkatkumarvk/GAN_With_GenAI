"""
LLM-as-Judge Evaluator - Field-Level Quality Assessment
=========================================================

Adds eval_score and eval_description to each field in the extraction JSON.
No separate report file -- evaluation is embedded in the same output JSON.

Output format (per field):
  Single:
    "first_name": {
        "value": "John", "confidence": 0.95, ...,
        "eval_score": 1.0, "eval_description": ""
    }
  
  Multi (per sub-field):
    "state_licenses": [
        {
            "id": 1,
            "license_number": {"value": "56359", "confidence": 0.96, ..., "eval_score": 1.0, "eval_description": ""},
            "license_state": {"value": "New York", "confidence": 0.96, ..., "eval_score": 0.5, "eval_description": "Use 2-letter abbreviation (NY)"}
        }
    ]

Config:
    "evaluation": {
        "enabled": true,
        "azure_openai": { "endpoint": "...", "deployment": "gpt-4o" }
    }

Usage:
  Called from main.py after aggregation, before save_results.
  Or standalone: python -m evaluation.evaluator --input results.json
"""

import json
import logging
import os
import sys
from typing import Dict

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

logger = logging.getLogger(__name__)


class LLMJudge:
    """LLM-as-Judge for field-level extraction quality evaluation."""
    
    def __init__(self, config: dict = None, eval_prompt_module=None):
        self.client = None
        self.deployment = None
        self.guidelines = {}
        self.system_prompt = ""
        
        # Load evaluation prompt module
        if eval_prompt_module:
            self.guidelines = getattr(eval_prompt_module, 'FIELD_EVALUATION_GUIDELINES', {})
            self.system_prompt = getattr(eval_prompt_module, 'JUDGE_SYSTEM_PROMPT', '')
            eval_config_from_prompt = getattr(eval_prompt_module, 'EVALUATION_CONFIG', {})
        else:
            eval_config_from_prompt = {}
        
        self.model = eval_config_from_prompt.get('model', 'gpt-4o')
        self.max_tokens = eval_config_from_prompt.get('max_tokens', 4000)
        self.temperature = eval_config_from_prompt.get('temperature', 0.0)
        
        if config:
            self._init_client(config)
    
    def _init_client(self, config: dict):
        """Initialize Azure OpenAI client for evaluation.
        Config comes from doctype-level evaluation.azure_openai."""
        try:
            from openai import AzureOpenAI
            
            eval_config = config.get('azure_openai', {})
            
            if eval_config.get('endpoint') and eval_config.get('api_key'):
                self.client = AzureOpenAI(
                    azure_endpoint=eval_config['endpoint'],
                    api_key=eval_config['api_key'],
                    api_version=eval_config.get('api_version', '2024-12-01-preview')
                )
                self.deployment = eval_config.get('deployment', self.model)
                logger.info(f"LLM Judge initialized: deployment={self.deployment}")
            else:
                logger.info("LLM Judge: rule-based only (no evaluation Azure OpenAI credentials)")
        except ImportError:
            logger.warning("LLM Judge: openai package not installed")
    
    def set_client(self, client, deployment: str):
        """Set client manually (reuse existing OpenAI client)."""
        self.client = client
        self.deployment = deployment
    
    def evaluate_and_enrich(self, extracted_data: dict) -> dict:
        """
        Evaluate fields and add eval_score + eval_description
        ONLY when evaluation finds something to report.
        Empty values get NO eval_score (not default 1.0).
        """
        for field_name, field_data in extracted_data.items():
            
            # Single-value field
            if isinstance(field_data, dict) and 'value' in field_data:
                eval_result = self._evaluate_field(field_name, field_data)
                if eval_result is not None:
                    field_data['eval_score'] = eval_result['score']
                    field_data['eval_description'] = '; '.join(eval_result['issues']) if eval_result['issues'] else ''
            
            # Multi-value field
            elif isinstance(field_data, list):
                for item in field_data:
                    if not isinstance(item, dict):
                        continue
                    for sub_field, sub_data in item.items():
                        if sub_field == 'id':
                            continue
                        if isinstance(sub_data, dict) and 'value' in sub_data:
                            eval_result = self._evaluate_sub_field(field_name, sub_field, sub_data)
                            if eval_result is not None:
                                sub_data['eval_score'] = eval_result['score']
                                sub_data['eval_description'] = '; '.join(eval_result['issues']) if eval_result['issues'] else ''
                
                # Check for duplicates
                dup_issues = self._check_duplicates(field_name, field_data)
                if dup_issues:
                    for item in field_data:
                        if isinstance(item, dict) and self._is_duplicate_item(item, field_data):
                            for sub_field, sub_data in item.items():
                                if sub_field == 'id':
                                    continue
                                if isinstance(sub_data, dict):
                                    sub_data['eval_score'] = 0.25
                                    sub_data['eval_description'] = 'Duplicate entry detected'
        
        return extracted_data
    
    def _evaluate_field(self, field_name: str, field_data: dict) -> dict:
        """Evaluate a single-value field. Returns None if nothing to evaluate."""
        value = field_data.get('value', '')
        
        # Nothing to evaluate if empty
        if not value:
            return None
        
        guidelines = self.guidelines.get(field_name, {})
        if not guidelines:
            return None
        
        score, issues = self._check_value_format(field_name, value, guidelines)
        
        # LLM judge for deeper analysis (only if issues found and client available)
        if self.client and issues:
            llm_result = self._llm_judge(field_name, field_data, guidelines)
            if llm_result:
                combined = list(set(issues + llm_result.get('issues', [])))
                return {
                    'score': min(score, llm_result.get('score', 1.0)),
                    'issues': combined
                }
        
        return {'score': round(score, 2), 'issues': issues}
    
    def _evaluate_sub_field(self, parent_field: str, sub_field: str, sub_data: dict) -> dict:
        """Evaluate a multi-value sub-field. Returns None if nothing to evaluate."""
        value = sub_data.get('value', '')
        
        if not value:
            return None
        
        guidelines = self.guidelines.get(parent_field, {})
        if not guidelines:
            return None
        
        score, issues = self._check_sub_field_format(parent_field, sub_field, value, guidelines)
        
        return {'score': round(score, 2), 'issues': issues}
    
    def _check_value_format(self, field_name: str, value: str, guidelines: dict) -> tuple:
        """Check single value format."""
        issues = []
        score = 1.0
        
        # State fields
        if field_name in ('birth_state_province',):
            if len(value) > 2 and value.upper() not in ('N/A',):
                issues.append(f"Use 2-letter abbreviation instead of '{value}'")
                score = 0.75
        
        # Date fields
        if 'date' in field_name or field_name == 'birth_date':
            if value and '/' not in value and '-' in value:
                issues.append(f"Date should be MM/DD/YYYY, got '{value}'")
                score = 0.50
        
        # Email
        if field_name == 'email' and value:
            if '@' not in value:
                issues.append(f"Invalid email: '{value}'")
                score = 0.0
        
        # SSN
        if field_name == 'ssn' and value:
            digits = ''.join(c for c in value if c.isdigit())
            if len(digits) not in (4, 9):
                issues.append(f"SSN should be 9 or last 4 digits, got {len(digits)}")
                score = 0.25
        
        # Names
        if field_name in ('first_name', 'last_name') and value:
            if any(t in value for t in ['Dr.', 'Mr.', 'Mrs.', 'Ms.']):
                issues.append(f"Name contains title: '{value}'")
                score = 0.50
            if not value[0].isupper():
                issues.append(f"Name not capitalized: '{value}'")
                score = 0.75
        
        # Gender
        if field_name == 'gender' and value:
            if value not in ('Male', 'Female'):
                if value.upper() in ('M', 'F'):
                    issues.append("Use 'Male'/'Female' not abbreviation")
                    score = 0.75
                else:
                    issues.append(f"Invalid gender: '{value}'")
                    score = 0.50
        
        return score, issues
    
    def _check_sub_field_format(self, parent_field: str, sub_field: str, value: str, guidelines: dict) -> tuple:
        """Check multi-value sub-field format."""
        issues = []
        score = 1.0
        
        # State sub-fields: 2-letter
        if 'state' in sub_field and value:
            if len(value) > 2:
                issues.append(f"Use 2-letter abbreviation, got '{value}'")
                score = 0.50
        
        # Date sub-fields: MM/DD/YYYY
        if 'date' in sub_field and value:
            if '/' not in value:
                issues.append(f"Date should be MM/DD/YYYY, got '{value}'")
                score = 0.50
        
        # DEA number: 2 letters + 7 digits
        if sub_field == 'dea_number' and value:
            if len(value) != 9:
                issues.append(f"DEA should be 9 chars (2 letters + 7 digits), got '{value}'")
                score = 0.25
        
        # Board name: full name not abbreviation
        if sub_field == 'board_name' and value:
            if len(value) <= 5 and value.isupper():
                issues.append(f"Use full board name, not abbreviation: '{value}'")
                score = 0.50
        
        return score, issues
    
    def _check_duplicates(self, field_name: str, items: list) -> list:
        """Check for duplicate entries."""
        issues = []
        signatures = []
        
        for item in items:
            if not isinstance(item, dict):
                continue
            sig_parts = []
            for key, val in sorted(item.items()):
                if key == 'id':
                    continue
                if isinstance(val, dict):
                    v = str(val.get('value', '')).strip().lower()
                    if v and 'date' not in key and 'status' not in key:
                        sig_parts.append(v)
            sig = '|'.join(sig_parts)
            if sig and sig in signatures:
                issues.append(f"Duplicate in {field_name}")
            elif sig:
                signatures.append(sig)
        
        return issues
    
    def _is_duplicate_item(self, item: dict, all_items: list) -> bool:
        """Check if this item is a duplicate (not the first occurrence)."""
        sig_parts = []
        for key, val in sorted(item.items()):
            if key == 'id':
                continue
            if isinstance(val, dict):
                v = str(val.get('value', '')).strip().lower()
                if v and 'date' not in key and 'status' not in key:
                    sig_parts.append(v)
        sig = '|'.join(sig_parts)
        
        # Check if this item's id is NOT the first with this signature
        for other in all_items:
            if not isinstance(other, dict):
                continue
            other_parts = []
            for key, val in sorted(other.items()):
                if key == 'id':
                    continue
                if isinstance(val, dict):
                    v = str(val.get('value', '')).strip().lower()
                    if v and 'date' not in key and 'status' not in key:
                        other_parts.append(v)
            if '|'.join(other_parts) == sig and other.get('id', 0) < item.get('id', 0):
                return True
        
        return False
    
    def _llm_judge(self, field_name: str, field_data, guidelines: dict) -> dict:
        """Call LLM for deeper evaluation."""
        if not self.client:
            return None
        
        try:
            prompt = f"""Evaluate this extracted field:
Field: {field_name}
Value: {json.dumps(field_data, indent=2)}
Guidelines:
  Format: {guidelines.get('expected_format', '')}
  Rules: {json.dumps(guidelines.get('validation_rules', []))}

Return JSON only:
{{"score": 0.0-1.0, "issues": ["list"], "suggestion": "fix"}}"""

            response = self.client.chat.completions.create(
                model=self.deployment,
                messages=[
                    {"role": "system", "content": self.system_prompt or "You are a data quality evaluator. Respond in JSON only."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            
            content = response.choices[0].message.content
            if not content:
                return None
            
            clean = content.strip()
            start = clean.find('{')
            end = clean.rfind('}')
            if start != -1 and end != -1:
                return json.loads(clean[start:end+1])
            return None
            
        except Exception as e:
            logger.warning(f"LLM Judge failed for {field_name}: {e}")
            return None


def load_eval_prompt_module(doctype: str):
    """Load evaluation prompt module for a doctype."""
    try:
        module_path = f"prompts.evaluation.{doctype}_eval_prompt"
        module = __import__(module_path, fromlist=[f"{doctype}_eval_prompt"])
        return module
    except ImportError:
        logger.warning(f"No evaluation prompt found for doctype '{doctype}', using defaults")
        return None


# =============================================================================
# CLI for standalone evaluation
# =============================================================================

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='LLM-as-Judge Evaluator')
    parser.add_argument('--input', required=True, help='Path to extraction results JSON')
    parser.add_argument('--doctype', default='cred', help='Document type (for loading eval prompts)')
    parser.add_argument('--llm', action='store_true', help='Enable LLM judge (costs tokens)')
    parser.add_argument('--config', default='config/config.json', help='Config file')
    
    args = parser.parse_args()
    
    # Load results
    with open(args.input) as f:
        results = json.load(f)
    
    # Load eval prompt module
    eval_module = load_eval_prompt_module(args.doctype)
    
    # Load config if LLM enabled
    config = None
    if args.llm and os.path.exists(args.config):
        with open(args.config) as f:
            config = json.load(f)
    
    # Evaluate
    judge = LLMJudge(config=config, eval_prompt_module=eval_module)
    data = results.get('data', {})
    enriched = judge.evaluate_and_enrich(data)
    results['data'] = enriched
    
    # Save back (overwrite with eval scores added)
    output_path = args.input.replace('.json', '_evaluated.json')
    with open(output_path, 'w') as f:
        json.dump(results, f, indent=2)
    
    # Print summary
    scores = []
    for field_data in enriched.values():
        if isinstance(field_data, dict) and 'eval_score' in field_data:
            scores.append(field_data['eval_score'])
        elif isinstance(field_data, list):
            for item in field_data:
                if isinstance(item, dict):
                    for k, v in item.items():
                        if k != 'id' and isinstance(v, dict) and 'eval_score' in v:
                            scores.append(v['eval_score'])
    
    if scores:
        print(f"\nEvaluation: {len(scores)} fields, avg_score={sum(scores)/len(scores):.3f}")
        print(f"Perfect: {sum(1 for s in scores if s == 1.0)}, Issues: {sum(1 for s in scores if s < 1.0)}")
    print(f"Saved: {output_path}")
