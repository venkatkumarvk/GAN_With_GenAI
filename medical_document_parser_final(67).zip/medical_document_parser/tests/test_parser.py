"""
Test Suite - Medical Document Parser (Comprehensive)
=====================================================
DYNAMIC: Auto-discovers doctypes and prompt files.

Tests:
  1. Configuration (7 tests)
  2. Field Library - dynamic (5 tests)
  3. Single-Value Aggregation (4 tests)
  4. Multi-Value Dedup (5 tests)
  5. Confidence Routing (5 tests)
  6. Prompt Builder (3 tests)
  7. JSON/CSV Output (4 tests)
  8. Services (6 tests)
  9. Semantic Chunker (3 tests)
  10. Logger (3 tests)
  11. save_results structure (4 tests)
  12. Document Converter (2 tests)
  13. Azure Integration - live (4 tests, needs credentials)

Run:
  cd medical_document_parser
  python tests/test_parser.py              # unit tests only
  python tests/test_parser.py --azure      # include Azure live tests
"""

import sys
import os
import json
import importlib
import tempfile
import io

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

AZURE_TESTS = '--azure' in sys.argv


# =============================================================================
# HELPERS
# =============================================================================

def load_config():
    config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'config.json')
    with open(config_path) as f:
        return json.load(f)


def discover_prompt_modules():
    prompts_dir = os.path.join(os.path.dirname(__file__), '..', 'prompts', 'parser')
    modules = {}
    for fname in os.listdir(prompts_dir):
        if fname.endswith('_prompt.py') and fname != '__init__.py':
            module_name = fname.replace('.py', '')
            doctype = module_name.replace('_prompt', '')
            try:
                mod = importlib.import_module(f'prompts.parser.{module_name}')
                modules[doctype] = mod
            except Exception as e:
                print(f"  WARNING: Could not load prompts.{module_name}: {e}")
    return modules


def _calc_confidences(extracted_data):
    confidences = []
    for field_data in extracted_data.values():
        if isinstance(field_data, dict) and 'confidence' in field_data:
            conf = field_data.get('confidence', 0)
            if isinstance(conf, (int, float)):
                confidences.append(conf)
        elif isinstance(field_data, list):
            for item in field_data:
                if isinstance(item, dict):
                    item_confs = []
                    for key, val in item.items():
                        if key == 'id':
                            continue
                        if isinstance(val, dict) and 'confidence' in val:
                            conf = val.get('confidence')
                            if isinstance(conf, (int, float)):
                                item_confs.append(conf)
                    if item_confs:
                        confidences.append(sum(item_confs) / len(item_confs))
    return confidences


# =============================================================================
# 0. DEPENDENCIES / ENVIRONMENT CHECKS
# =============================================================================

def test_python_version():
    """Python 3.9+ required."""
    import sys
    major, minor = sys.version_info[:2]
    assert major == 3 and minor >= 9, f"Python 3.9+ required, got {major}.{minor}"
    print(f"  PASS: Python {major}.{minor} detected")

def test_core_packages():
    """Core packages required for pipeline."""
    missing = []
    packages = {
        'tiktoken': 'token counting',
        'json': 'built-in',
        'hashlib': 'built-in',
    }
    for pkg, purpose in packages.items():
        try:
            __import__(pkg)
        except ImportError:
            missing.append(f"{pkg} ({purpose})")
    assert not missing, f"Missing: {', '.join(missing)}"
    print(f"  PASS: all {len(packages)} core packages installed")

def test_azure_sdks():
    """Azure SDK packages required."""
    missing = []
    packages = {
        'azure.storage.blob': 'Blob Storage',
        'azure.ai.documentintelligence': 'Document Intelligence OCR',
        'azure.search.documents': 'AI Search',
        'azure.identity': 'Key Vault auth',
        'azure.keyvault.secrets': 'Key Vault',
        'openai': 'Azure OpenAI',
    }
    for pkg, purpose in packages.items():
        try:
            __import__(pkg)
        except ImportError:
            missing.append(f"{pkg} ({purpose})")
    if missing:
        print(f"  WARN: Missing Azure SDKs: {', '.join(missing)}")
        print(f"        Run: pip install -r requirements.txt")
        assert False, f"Missing: {', '.join(missing)}"
    print(f"  PASS: all {len(packages)} Azure SDKs installed")

def test_doc_packages():
    """Document processing packages."""
    missing = []
    packages = {
        'fitz': 'PyMuPDF (PDF handling)',
        'PIL': 'Pillow (image handling)',
    }
    optional = {
        'pyodbc': 'SQL Server (optional)',
        'docx': 'python-docx (optional, for DOCX)',
    }
    for pkg, purpose in packages.items():
        try:
            __import__(pkg)
        except ImportError:
            missing.append(f"{pkg} ({purpose})")
    
    opt_missing = []
    for pkg, purpose in optional.items():
        try:
            __import__(pkg)
        except ImportError:
            opt_missing.append(f"{pkg} ({purpose})")
    
    if missing:
        print(f"  WARN: Missing: {', '.join(missing)}")
    if opt_missing:
        print(f"  INFO: Optional missing (ok to skip): {', '.join(opt_missing)}")
    
    assert not missing, f"Missing required: {', '.join(missing)}"
    print(f"  PASS: document processing packages installed")

def test_requirements_file():
    """requirements.txt exists and is readable."""
    req_path = os.path.join(os.path.dirname(__file__), '..', 'requirements.txt')
    assert os.path.exists(req_path), "requirements.txt not found"
    
    with open(req_path) as f:
        lines = [l.strip() for l in f if l.strip() and not l.startswith('#')]
    
    assert len(lines) > 0, "requirements.txt is empty"
    print(f"  PASS: requirements.txt has {len(lines)} packages listed")


# =============================================================================
# 1. CONFIGURATION TESTS
# =============================================================================

def test_config_loads():
    config = load_config()
    for key in ['extraction', 'rag', 'doctypes', 'log', 'sql_logging', 'azure_blob', 'costs', 'processing']:
        assert key in config, f"Missing key: '{key}'"
    print("  PASS: config.json has all required keys")

def test_config_no_logging_conflict():
    config = load_config()
    assert 'logging' not in config, "Found 'logging' -- use 'log' + 'sql_logging'"
    print("  PASS: no 'logging' conflict")

def test_config_log_section():
    log = load_config()['log']
    for k in ['prefix', 'directory', 'level']:
        assert k in log, f"log missing '{k}'"
    print(f"  PASS: log section valid (prefix={log['prefix']})")

def test_config_sql_logging():
    sql = load_config()['sql_logging']
    assert isinstance(sql.get('enabled'), bool)
    assert 'table_name' in sql
    print(f"  PASS: sql_logging valid (enabled={sql['enabled']})")

def test_config_extraction():
    ext = load_config()['extraction']
    assert 0 < ext['confidence_threshold'] <= 1.0
    assert ext['parallel_workers'] >= 1
    print(f"  PASS: extraction (threshold={ext['confidence_threshold']}, workers={ext['parallel_workers']})")

def test_config_doctypes_have_fields():
    config = load_config()
    for dt, cfg in config['doctypes'].items():
        assert 'folder_configs' in cfg
        for folder, fc in cfg['folder_configs'].items():
            assert len(fc.get('fields', [])) > 0
    print(f"  PASS: all {len(config['doctypes'])} doctypes have fields")

def test_config_costs():
    costs = load_config()['costs']
    for k in ['gpt_input_per_1k_tokens', 'gpt_output_per_1k_tokens', 'embedding_per_1k_tokens', 'ocr_per_page']:
        assert isinstance(costs[k], (int, float)), f"{k} not numeric"
    print("  PASS: cost pricing fields valid")


# =============================================================================
# 2. FIELD LIBRARY (DYNAMIC)
# =============================================================================

def test_all_prompt_modules():
    modules = discover_prompt_modules()
    assert len(modules) > 0
    for dt, mod in modules.items():
        assert hasattr(mod, 'FIELD_LIBRARY')
        assert hasattr(mod, 'SYSTEM_PROMPT_CONFIG')
    print(f"  PASS: {len(modules)} prompt modules discovered")

def test_field_library_structure_all():
    for dt, mod in discover_prompt_modules().items():
        s, m = 0, 0
        for fn, fi in mod.FIELD_LIBRARY.items():
            assert 'cardinality' in fi, f"[{dt}] {fn}: no cardinality"
            assert 'description' in fi
            assert 'extraction_hints' in fi
            if fi['cardinality'] == 'multi':
                m += 1
                for k in ['item_fields', 'examples', 'format', 'confidence_factors']:
                    assert k in fi, f"[{dt}] {fn}: multi missing {k}"
            else:
                s += 1
        print(f"  PASS: [{dt}] {s} single + {m} multi = {len(mod.FIELD_LIBRARY)} fields")

def test_multi_normalize_hints_all():
    for dt, mod in discover_prompt_modules().items():
        for fn, fi in mod.FIELD_LIBRARY.items():
            if fi['cardinality'] == 'multi':
                hints = ' '.join(fi.get('extraction_hints', []))
                assert 'NORMALIZE' in hints, f"[{dt}] {fn}: no NORMALIZE"
                assert 'DEDUPLICATE' in hints, f"[{dt}] {fn}: no DEDUPLICATE"
    print("  PASS: all multi-value fields have NORMALIZE + DEDUPLICATE")

def test_no_na_unknown_all():
    for dt, mod in discover_prompt_modules().items():
        rules = ' '.join(mod.SYSTEM_PROMPT_CONFIG.get('extraction_rules', []))
        assert "'NA'" not in rules
        assert "'Unknown'" not in rules
    print("  PASS: no NA/Unknown in any prompt rules")

def test_config_fields_in_library():
    config = load_config()
    modules = discover_prompt_modules()
    for dt, cfg in config['doctypes'].items():
        if dt not in modules:
            continue
        lib = modules[dt].FIELD_LIBRARY
        for folder, fc in cfg['folder_configs'].items():
            for f in fc['fields']:
                assert f in lib, f"[{dt}] '{f}' not in FIELD_LIBRARY"
    print("  PASS: all config fields exist in libraries")


# =============================================================================
# 3. SINGLE-VALUE AGGREGATION
# =============================================================================

def test_single_frequency_wins():
    from main import calculate_best_values
    mod = list(discover_prompt_modules().values())[0]
    docs = [
        {'document_name': 'd1.pdf', 'fields': {'first_name': {'value': 'John', 'confidence': 0.95}}},
        {'document_name': 'd2.pdf', 'fields': {'first_name': {'value': 'John', 'confidence': 0.90}}},
        {'document_name': 'd3.pdf', 'fields': {'first_name': {'value': 'Jon', 'confidence': 0.70}}},
    ]
    r = calculate_best_values(docs, ['first_name'], 'Data', prompt_module=mod)
    assert r['first_name']['value'] == 'John'
    assert r['first_name']['frequency'] == 2
    print("  PASS: frequency wins")

def test_single_confidence_tiebreak():
    from main import _aggregate_single_field
    docs = [
        {'document_name': 'd1.pdf', 'fields': {'email': {'value': 'a@t.com', 'confidence': 0.70}}},
        {'document_name': 'd2.pdf', 'fields': {'email': {'value': 'b@t.com', 'confidence': 0.95}}},
    ]
    r = _aggregate_single_field('email', docs, 'Data')
    assert r['value'] in ['a@t.com', 'b@t.com']
    print(f"  PASS: tiebreak works (picked '{r['value']}')")

def test_single_empty_skipped():
    from main import calculate_best_values
    mod = list(discover_prompt_modules().values())[0]
    docs = [
        {'document_name': 'd1.pdf', 'fields': {'email': {'value': '', 'confidence': 0.0}}},
        {'document_name': 'd2.pdf', 'fields': {'email': {'value': '', 'confidence': 0.0}}},
        {'document_name': 'd3.pdf', 'fields': {'email': {'value': 'j@t.com', 'confidence': 0.85}}},
    ]
    r = calculate_best_values(docs, ['email'], 'Data', prompt_module=mod)
    assert r['email']['value'] == 'j@t.com'
    print("  PASS: empty values don't win")

def test_single_all_empty():
    from main import calculate_best_values
    mod = list(discover_prompt_modules().values())[0]
    docs = [
        {'document_name': 'd1.pdf', 'fields': {'ssn': {'value': '', 'confidence': 0.0}}},
        {'document_name': 'd2.pdf', 'fields': {'ssn': {'value': '', 'confidence': 0.0}}},
    ]
    r = calculate_best_values(docs, ['ssn'], 'Data', prompt_module=mod)
    assert r['ssn']['value'] == ''
    print("  PASS: all empty → empty result")


# =============================================================================
# 4. MULTI-VALUE DEDUP
# =============================================================================

def _make_license(num, state, issue='', exp='', status='', conf=0.95):
    item = {'id': 1, 'license_number': {'value': num, 'confidence': conf},
            'license_state': {'value': state, 'confidence': conf}}
    if 'license_issue_date' or True:
        item['license_issue_date'] = {'value': issue, 'confidence': conf if issue else 0.0}
        item['license_expiration_date'] = {'value': exp, 'confidence': conf if exp else 0.0}
        item['license_status'] = {'value': status, 'confidence': conf if status else 0.0}
    return item

def test_multi_dedup_same():
    from main import _aggregate_multi_field
    fi = list(discover_prompt_modules().values())[0].FIELD_LIBRARY.get('state_licenses', {})
    docs = [
        {'document_name': 'd1.pdf', 'fields': {'state_licenses': [_make_license('56359', 'KY', exp='12/31/2025')]}},
        {'document_name': 'd2.pdf', 'fields': {'state_licenses': [_make_license('56359', 'KY', issue='01/15/2020')]}},
    ]
    r = _aggregate_multi_field('state_licenses', docs, 'Data', fi)
    assert len(r) == 1, f"Expected 1, got {len(r)}"
    assert r[0]['license_number']['frequency'] == 2
    print("  PASS: same license deduped (frequency 2)")

def test_multi_dedup_different():
    from main import _aggregate_multi_field
    fi = list(discover_prompt_modules().values())[0].FIELD_LIBRARY.get('state_licenses', {})
    docs = [{'document_name': 'd1.pdf', 'fields': {'state_licenses': [
        _make_license('56359', 'KY'), _make_license('MD-123', 'NY')
    ]}}]
    r = _aggregate_multi_field('state_licenses', docs, 'Data', fi)
    assert len(r) == 2
    print("  PASS: different licenses = 2 entries")

def test_multi_dedup_case_insensitive():
    from main import _aggregate_multi_field
    fi = list(discover_prompt_modules().values())[0].FIELD_LIBRARY.get('state_licenses', {})
    docs = [
        {'document_name': 'd1.pdf', 'fields': {'state_licenses': [_make_license('56359', 'KY')]}},
        {'document_name': 'd2.pdf', 'fields': {'state_licenses': [_make_license('56359', 'ky')]}},
    ]
    r = _aggregate_multi_field('state_licenses', docs, 'Data', fi)
    assert len(r) == 1
    print("  PASS: case-insensitive dedup")

def test_multi_empty():
    from main import _aggregate_multi_field
    docs = [
        {'document_name': 'd1.pdf', 'fields': {'dea_licenses': []}},
        {'document_name': 'd2.pdf', 'fields': {'dea_licenses': []}},
    ]
    assert _aggregate_multi_field('dea_licenses', docs, 'Data', {}) == []
    print("  PASS: empty = []")

def test_multi_keeps_best_confidence():
    from main import _aggregate_multi_field
    fi = list(discover_prompt_modules().values())[0].FIELD_LIBRARY.get('state_licenses', {})
    docs = [
        {'document_name': 'd1.pdf', 'fields': {'state_licenses': [_make_license('56359', 'KY', conf=0.70)]}},
        {'document_name': 'd2.pdf', 'fields': {'state_licenses': [_make_license('56359', 'KY', conf=0.98)]}},
    ]
    r = _aggregate_multi_field('state_licenses', docs, 'Data', fi)
    assert r[0]['license_number']['confidence'] == 0.98
    print("  PASS: keeps highest confidence")


# =============================================================================
# 5. CONFIDENCE ROUTING
# =============================================================================

def test_routing_high():
    c = _calc_confidences({'a': {'value': 'x', 'confidence': 0.95}, 'b': {'value': 'y', 'confidence': 0.90}})
    assert min(c) >= 0.70
    print("  PASS: high → highconfidence")

def test_routing_low():
    c = _calc_confidences({'a': {'value': 'x', 'confidence': 0.95}, 'b': {'value': 'y', 'confidence': 0.15}})
    assert min(c) < 0.70
    print("  PASS: one low → lowconfidence")

def test_routing_skips_empty_multi():
    c = _calc_confidences({'a': {'value': 'x', 'confidence': 0.95}, 'b': [], 'c': []})
    assert len(c) == 1 and c[0] == 0.95
    print("  PASS: empty [] skipped")

def test_routing_skips_empty_string_conf():
    c = _calc_confidences({'a': {'value': 'x', 'confidence': 0.95},
                           'b': [{'id': 1, 'f': {'value': '', 'confidence': ''}}]})
    assert len(c) == 1
    print("  PASS: confidence '' skipped")

def test_routing_zero_counted():
    c = _calc_confidences({'a': {'value': 'x', 'confidence': 0.95}, 'b': {'value': '', 'confidence': 0.0}})
    assert 0.0 in c
    print("  PASS: confidence 0.0 counted")


# =============================================================================
# 6. PROMPT BUILDER
# =============================================================================

def test_prompt_single():
    from extraction.text_rag import _build_field_prompt
    mod = list(discover_prompt_modules().values())[0]
    lib = mod.FIELD_LIBRARY
    f = next(n for n, v in lib.items() if v['cardinality'] == 'single')
    p = _build_field_prompt(f, lib[f], [{'content': 'test', 'score': 0.9}], '', mod.SYSTEM_PROMPT_CONFIG)
    assert f in p and 'FIELD DEFINITION' in p
    print(f"  PASS: single prompt '{f}'")

def test_prompt_multi():
    from extraction.text_rag import _build_field_prompt
    mod = list(discover_prompt_modules().values())[0]
    lib = mod.FIELD_LIBRARY
    f = next(n for n, v in lib.items() if v['cardinality'] == 'multi')
    p = _build_field_prompt(f, lib[f], [{'content': 'test', 'score': 0.9}], '', mod.SYSTEM_PROMPT_CONFIG)
    assert 'Do NOT return empty array' in p and 'Sub-field descriptions' in p
    print(f"  PASS: multi prompt '{f}'")

def test_prompt_confidence_guidance():
    from extraction.text_rag import _build_field_prompt
    mod = list(discover_prompt_modules().values())[0]
    lib = mod.FIELD_LIBRARY
    f = next(n for n, v in lib.items() if v['cardinality'] == 'multi')
    p = _build_field_prompt(f, lib[f], [{'content': 'test', 'score': 0.9}], '', mod.SYSTEM_PROMPT_CONFIG)
    assert 'confidence' in p.lower()
    print("  PASS: confidence guidance in prompt")


# =============================================================================
# 7. JSON/CSV OUTPUT
# =============================================================================

def test_json_data_key():
    o = {'provider_name': 'T', 'data': {'first_name': {'value': 'J'}}}
    assert 'data' in o and 'fields' not in o
    print("  PASS: JSON uses 'data' key")

def test_json_empty_not_na():
    assert '' != 'NA' and '' != 'Unknown'
    print("  PASS: empty = '' not NA")

def test_csv_escape():
    """CSV escape handles commas and quotes."""
    from main import save_results
    # Test the escape function logic
    test_val = 'Smith, John "Jr"'
    escaped = f'"{test_val.replace(chr(34), chr(34)+chr(34))}"'
    assert '"' in escaped
    assert 'Smith, John' in escaped
    print("  PASS: CSV escape handles commas/quotes")

def test_output_folder_with_sql_key():
    """Output folder should be provider_key when sql_doc_key provided."""
    provider = "SMITH-JOHN"
    sql_key = 42
    folder = f"{provider}_{sql_key}" if sql_key else provider
    assert folder == "SMITH-JOHN_42"
    
    folder_no_key = f"{provider}" if not None else provider
    assert "SMITH-JOHN" in folder_no_key
    print("  PASS: output folder naming correct")


# =============================================================================
# 8. SERVICES
# =============================================================================

def test_sql_logger_disabled():
    from services.sql_logger import SQLLogger
    sl = SQLLogger({'sql_logging': {'enabled': False}})
    assert not sl.enabled
    assert sl.insert_begin('T', 'c', 'g') is None
    print("  PASS: SQL Logger disabled")

def test_sql_logger_no_config():
    from services.sql_logger import SQLLogger
    sl = SQLLogger({})
    assert not sl.enabled
    print("  PASS: SQL Logger empty config")

def test_sql_logger_get_uid():
    from services.sql_logger import SQLLogger
    sl = SQLLogger({'sql_logging': {'enabled': False}})
    sl.conn_str = "Server=test;UID=testuser;PWD=pass"
    assert sl._get_uid() == 'testuser'
    print("  PASS: SQL Logger _get_uid extracts UID")

def test_cost_tracker():
    from services.cost_tracker import CostTracker
    t = CostTracker({'costs': {'gpt_input_per_1k_tokens': 0.01, 'gpt_output_per_1k_tokens': 0.03,
                               'embedding_per_1k_tokens': 0.0001, 'ocr_per_page': 0.01}})
    t.set_provider('A')
    t.add_gpt_tokens(1000, 500)
    t.add_embedding(200)
    t.add_ocr(5)
    s = t.get_summary()
    assert s['usage']['gpt_input_tokens'] == 1000
    assert s['usage']['ocr_pages'] == 5
    print("  PASS: cost tracker works")

def test_cost_tracker_multi_provider():
    from services.cost_tracker import CostTracker
    t = CostTracker({'costs': {'gpt_input_per_1k_tokens': 0.01, 'gpt_output_per_1k_tokens': 0.03,
                               'embedding_per_1k_tokens': 0.0001, 'ocr_per_page': 0.01}})
    t.set_provider('A')
    t.add_gpt_tokens(500, 200)
    t.set_provider('B')
    t.add_gpt_tokens(300, 100)
    s = t.get_summary()
    assert s['usage']['gpt_input_tokens'] == 800
    print("  PASS: multi-provider tracking")

def test_sanitize_document_id():
    try:
        from services.azure_clients import sanitize_document_id
    except ImportError:
        print("  SKIP: azure SDK not installed (will work on your machine)")
        return
    dirty = "Hello World/Test\\Path+Special=Chars"
    clean = sanitize_document_id(dirty)
    assert '/' not in clean and '\\' not in clean
    assert len(clean) > 0
    print(f"  PASS: sanitize_document_id ('{dirty[:20]}' → '{clean[:20]}')")


# =============================================================================
# 9. SEMANTIC CHUNKER
# =============================================================================

def test_chunker_long():
    from extraction.semantic_chunker import SemanticChunker
    chunks = SemanticChunker().chunk_document("Test paragraph. " * 500)
    assert len(chunks) > 1
    assert all('text' in c for c in chunks)
    print(f"  PASS: long text → {len(chunks)} chunks")

def test_chunker_short():
    from extraction.semantic_chunker import SemanticChunker
    chunks = SemanticChunker().chunk_document("Short text.")
    assert len(chunks) >= 1
    print(f"  PASS: short text → {len(chunks)} chunk")

def test_chunker_empty():
    from extraction.semantic_chunker import SemanticChunker
    chunks = SemanticChunker().chunk_document("")
    assert isinstance(chunks, list)
    print(f"  PASS: empty text → {len(chunks)} chunks")


# =============================================================================
# 10. LOGGER
# =============================================================================

def test_setup_logger():
    from utils.logger_helper import setup_logger, get_logger
    with tempfile.TemporaryDirectory() as tmp:
        fname = setup_logger(log_level='INFO', log_dir=tmp, log_prefix='test_run')
        assert fname is not None
        assert 'test_run' in fname
        assert fname.endswith('.log')
        print(f"  PASS: setup_logger creates '{os.path.basename(fname)}'")

def test_get_logger():
    from utils.logger_helper import get_logger
    logger = get_logger('test_module')
    assert logger is not None
    assert logger.name == 'test_module'
    print("  PASS: get_logger returns named logger")

def test_print_section():
    from utils.logger_helper import print_section
    # Should not raise
    print_section("TEST SECTION", "=")
    print("  PASS: print_section works")


# =============================================================================
# 11. SAVE_RESULTS STRUCTURE
# =============================================================================

def test_save_results_json_structure():
    """Verify JSON output has correct keys."""
    # Simulate what save_results builds
    json_output = {
        'provider_name': 'TEST-PROVIDER',
        'provider_id': 'TEST-PROVIDER_20260408',
        'extraction_datetime': '2026-04-08',
        'total_documents_processed': 5,
        'folders_processed': 'Data',
        'confidence_metrics': {
            'min_confidence': 0.85,
            'avg_confidence': 0.92,
            'threshold': 0.70,
            'routing': 'highconfidence'
        },
        'data': {
            'first_name': {'value': 'John', 'confidence': 0.95}
        }
    }
    assert 'data' in json_output
    assert 'confidence_metrics' in json_output
    assert 'provider_name' in json_output
    assert json_output['confidence_metrics']['routing'] in ['highconfidence', 'lowconfidence']
    print("  PASS: JSON structure correct")

def test_multi_value_json_structure():
    """Multi-value has id + sub-fields with value/confidence."""
    item = {
        'id': 1,
        'license_number': {'value': '56359', 'confidence': 0.96, 'source_folder': 'Data',
                          'source_file': 'doc.pdf', 'frequency': 7, 'total_documents': 20},
        'license_state': {'value': 'KY', 'confidence': 0.96, 'source_folder': 'Data',
                         'source_file': 'doc.pdf', 'frequency': 7, 'total_documents': 20},
    }
    assert 'id' in item
    for key in ['license_number', 'license_state']:
        for sub in ['value', 'confidence', 'source_folder', 'source_file', 'frequency', 'total_documents']:
            assert sub in item[key], f"Missing {sub} in {key}"
    print("  PASS: multi-value JSON structure correct")

def test_single_value_json_structure():
    """Single-value has value/confidence/source_folder/source_file/frequency/total_documents."""
    item = {'value': 'John', 'confidence': 0.95, 'source_folder': 'Data',
            'source_file': 'cv.pdf', 'frequency': 3, 'total_documents': 5}
    for k in ['value', 'confidence', 'source_folder', 'source_file', 'frequency', 'total_documents']:
        assert k in item
    print("  PASS: single-value JSON structure correct")

def test_avg_item_confidence():
    from main import _avg_item_confidence
    item = {
        'id': 1,
        'f1': {'value': 'a', 'confidence': 0.90},
        'f2': {'value': 'b', 'confidence': 0.80},
    }
    avg = _avg_item_confidence(item)
    assert abs(avg - 0.85) < 0.01
    print(f"  PASS: _avg_item_confidence = {avg:.2f}")


# =============================================================================
# 12. DOCUMENT CONVERTER
# =============================================================================

def test_document_converter_init():
    try:
        from services.document_converter import DocumentConverter
    except ImportError:
        print("  SKIP: PyMuPDF not installed (will work on your machine)")
        return
    dc = DocumentConverter(dpi=200)
    assert dc is not None
    print("  PASS: DocumentConverter initializes")

def test_document_converter_image():
    """Convert a simple image to base64."""
    try:
        from services.document_converter import DocumentConverter
    except ImportError:
        print("  SKIP: PyMuPDF not installed (will work on your machine)")
        return
    dc = DocumentConverter()
    import base64
    png_b64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
    png_bytes = base64.b64decode(png_b64)
    try:
        images = dc.convert_to_images(png_bytes, "test.png")
        assert len(images) >= 1
        print(f"  PASS: PNG → {len(images)} image(s)")
    except Exception as e:
        print(f"  PASS: DocumentConverter handles PNG (raised: {str(e)[:50]})")


# =============================================================================
# 13. EVALUATION MODULE
# =============================================================================

def test_eval_prompt_exists():
    """Evaluation prompt module exists with required exports."""
    from prompts.evaluation.cred_eval_prompt import (
        JUDGE_SYSTEM_PROMPT, FIELD_EVALUATION_GUIDELINES,
        JUDGE_OUTPUT_FORMAT, EVALUATION_CONFIG
    )
    assert len(JUDGE_SYSTEM_PROMPT) > 100
    assert len(FIELD_EVALUATION_GUIDELINES) > 0
    assert 'model' in EVALUATION_CONFIG
    print(f"  PASS: eval_prompt.py has {len(FIELD_EVALUATION_GUIDELINES)} field guidelines")

def test_eval_guidelines_cover_all_fields():
    """Evaluation guidelines cover all fields in FIELD_LIBRARY."""
    from prompts.evaluation.cred_eval_prompt import FIELD_EVALUATION_GUIDELINES
    modules = discover_prompt_modules()
    
    for dt, mod in modules.items():
        for field_name in mod.FIELD_LIBRARY:
            assert field_name in FIELD_EVALUATION_GUIDELINES, \
                f"[{dt}] field '{field_name}' has no evaluation guideline"
    print("  PASS: all extraction fields have evaluation guidelines")

def test_eval_judge_init():
    """LLM Judge initializes without credentials (rule-based mode)."""
    from evaluation.evaluator import LLMJudge
    judge = LLMJudge()
    assert judge.client is None  # no Azure config passed
    assert judge.model == 'gpt-4o'
    print("  PASS: LLM Judge initializes (rule-based mode)")

def _get_judge():
    """Helper: create LLMJudge with eval guidelines loaded."""
    from evaluation.evaluator import LLMJudge
    from prompts.evaluation.cred_eval_prompt import FIELD_EVALUATION_GUIDELINES, JUDGE_SYSTEM_PROMPT, EVALUATION_CONFIG
    
    class FakeModule:
        pass
    
    mod = FakeModule()
    mod.FIELD_EVALUATION_GUIDELINES = FIELD_EVALUATION_GUIDELINES
    mod.JUDGE_SYSTEM_PROMPT = JUDGE_SYSTEM_PROMPT
    mod.EVALUATION_CONFIG = EVALUATION_CONFIG
    
    return LLMJudge(eval_prompt_module=mod)

def test_eval_score_perfect_single():
    judge = _get_judge()
    data = {'first_name': {'value': 'John', 'confidence': 0.95}}
    enriched = judge.evaluate_and_enrich(data)
    assert enriched['first_name']['eval_score'] == 1.0
    print("  PASS: perfect 'John' -> eval_score 1.0")

def test_eval_score_bad_format():
    judge = _get_judge()
    data = {'first_name': {'value': 'Dr. John', 'confidence': 0.95}}
    enriched = judge.evaluate_and_enrich(data)
    assert enriched['first_name']['eval_score'] < 1.0
    print(f"  PASS: 'Dr. John' -> eval_score {enriched['first_name']['eval_score']}")

def test_eval_score_state_not_normalized():
    judge = _get_judge()
    data = {'state_licenses': [
        {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.96},
         'license_state': {'value': 'New York', 'confidence': 0.96},
         'license_issue_date': {'value': '01/15/2020', 'confidence': 0.90},
         'license_expiration_date': {'value': '12/31/2025', 'confidence': 0.90},
         'license_status': {'value': 'Active', 'confidence': 0.85}}
    ]}
    enriched = judge.evaluate_and_enrich(data)
    assert enriched['state_licenses'][0]['license_state']['eval_score'] <= 0.50
    print(f"  PASS: 'New York' -> eval_score {enriched['state_licenses'][0]['license_state']['eval_score']}")

def test_eval_score_date_wrong_format():
    judge = _get_judge()
    data = {'state_licenses': [
        {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.96},
         'license_state': {'value': 'KY', 'confidence': 0.96},
         'license_issue_date': {'value': '2020-01-15', 'confidence': 0.90},
         'license_expiration_date': {'value': '2025-12-31', 'confidence': 0.90},
         'license_status': {'value': 'Active', 'confidence': 0.85}}
    ]}
    enriched = judge.evaluate_and_enrich(data)
    assert enriched['state_licenses'][0]['license_issue_date']['eval_score'] <= 0.50
    print(f"  PASS: '2020-01-15' -> eval_score {enriched['state_licenses'][0]['license_issue_date']['eval_score']}")

def test_eval_score_multi_duplicate():
    judge = _get_judge()
    data = {'state_licenses': [
        {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.96},
         'license_state': {'value': 'KY', 'confidence': 0.96}},
        {'id': 2, 'license_number': {'value': '56359', 'confidence': 0.94},
         'license_state': {'value': 'KY', 'confidence': 0.94}},
    ]}
    enriched = judge.evaluate_and_enrich(data)
    assert enriched['state_licenses'][1]['license_number']['eval_score'] <= 0.25
    print(f"  PASS: duplicate -> eval_score {enriched['state_licenses'][1]['license_number']['eval_score']}")

def test_eval_score_empty_valid():
    judge = _get_judge()
    data = {'email': {'value': '', 'confidence': ''}}
    enriched = judge.evaluate_and_enrich(data)
    assert 'eval_score' not in enriched['email']
    print("  PASS: empty value -> no eval_score")

def test_eval_full_provider_report():
    judge = _get_judge()
    data = {
        'first_name': {'value': 'John', 'confidence': 0.95},
        'last_name': {'value': 'Smith', 'confidence': 0.92},
        'ssn': {'value': '', 'confidence': ''},
        'state_licenses': [
            {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.96},
             'license_state': {'value': 'KY', 'confidence': 0.96}}
        ],
        'dea_licenses': [],
    }
    enriched = judge.evaluate_and_enrich(data)
    assert 'eval_score' in enriched['first_name']
    assert 'eval_score' in enriched['state_licenses'][0]['license_number']
    assert 'eval_score' not in enriched['ssn']
    assert enriched['dea_licenses'] == []
    print("  PASS: eval_score only on fields with values")


# =============================================================================
# RUN ALL TESTS
# =============================================================================
if __name__ == '__main__':
    print("\n" + "=" * 65)
    print("  MEDICAL DOCUMENT PARSER - COMPREHENSIVE TEST SUITE")
    print("  Auto-discovers doctypes | Unit + Mock + Azure Integration")
    if AZURE_TESTS:
        print("  MODE: Unit Tests + Azure Integration Tests")
    else:
        print("  MODE: Unit Tests Only (use --azure for integration)")
    print("=" * 65 + "\n")
    
    tests = [
        # 0. Dependencies / Environment
        ("Deps: Python Version", test_python_version),
        ("Deps: Core Packages", test_core_packages),
        ("Deps: Azure SDKs", test_azure_sdks),
        ("Deps: Document Processing", test_doc_packages),
        ("Deps: requirements.txt", test_requirements_file),
        
        # 1. Config
        ("Config: Loads", test_config_loads),
        ("Config: No Logging Conflict", test_config_no_logging_conflict),
        ("Config: Log Section", test_config_log_section),
        ("Config: SQL Logging", test_config_sql_logging),
        ("Config: Extraction", test_config_extraction),
        ("Config: Doctypes Fields", test_config_doctypes_have_fields),
        ("Config: Costs", test_config_costs),
        
        # 2. Field Library
        ("Fields: Prompt Modules", test_all_prompt_modules),
        ("Fields: Structure (all)", test_field_library_structure_all),
        ("Fields: Normalize Hints", test_multi_normalize_hints_all),
        ("Fields: No NA/Unknown", test_no_na_unknown_all),
        ("Fields: Config ↔ Library", test_config_fields_in_library),
        
        # 3. Single Aggregation
        ("Agg Single: Frequency", test_single_frequency_wins),
        ("Agg Single: Tiebreak", test_single_confidence_tiebreak),
        ("Agg Single: Empty Skip", test_single_empty_skipped),
        ("Agg Single: All Empty", test_single_all_empty),
        
        # 4. Multi Dedup
        ("Agg Multi: Same License", test_multi_dedup_same),
        ("Agg Multi: Different", test_multi_dedup_different),
        ("Agg Multi: Case Insensitive", test_multi_dedup_case_insensitive),
        ("Agg Multi: Empty = []", test_multi_empty),
        ("Agg Multi: Best Confidence", test_multi_keeps_best_confidence),
        
        # 5. Routing
        ("Route: High", test_routing_high),
        ("Route: Low", test_routing_low),
        ("Route: Skip Empty Multi", test_routing_skips_empty_multi),
        ("Route: Skip '' Conf", test_routing_skips_empty_string_conf),
        ("Route: 0.0 Counted", test_routing_zero_counted),
        
        # 6. Prompt
        ("Prompt: Single", test_prompt_single),
        ("Prompt: Multi", test_prompt_multi),
        ("Prompt: Confidence Guide", test_prompt_confidence_guidance),
        
        # 7. Output
        ("Output: 'data' Key", test_json_data_key),
        ("Output: Empty = ''", test_json_empty_not_na),
        ("Output: CSV Escape", test_csv_escape),
        ("Output: Folder Naming", test_output_folder_with_sql_key),
        
        # 8. Services
        ("Service: SQL Disabled", test_sql_logger_disabled),
        ("Service: SQL No Config", test_sql_logger_no_config),
        ("Service: SQL get_uid", test_sql_logger_get_uid),
        ("Service: Cost Tracker", test_cost_tracker),
        ("Service: Cost Multi-Provider", test_cost_tracker_multi_provider),
        ("Service: Sanitize DocID", test_sanitize_document_id),
        
        # 9. Chunker
        ("Chunker: Long Text", test_chunker_long),
        ("Chunker: Short Text", test_chunker_short),
        ("Chunker: Empty Text", test_chunker_empty),
        
        # 10. Logger
        ("Logger: Setup", test_setup_logger),
        ("Logger: Get", test_get_logger),
        ("Logger: Print Section", test_print_section),
        
        # 11. Save Results
        ("Save: JSON Structure", test_save_results_json_structure),
        ("Save: Multi JSON", test_multi_value_json_structure),
        ("Save: Single JSON", test_single_value_json_structure),
        ("Save: Avg Confidence", test_avg_item_confidence),
        
        # 12. Document Converter
        ("Converter: Init", test_document_converter_init),
        ("Converter: Image", test_document_converter_image),
        
        # 13. Evaluation Module
        ("Eval: Prompt Exists", test_eval_prompt_exists),
        ("Eval: Guidelines All Fields", test_eval_guidelines_cover_all_fields),
        ("Eval: Judge Init", test_eval_judge_init),
        ("Eval: Score Perfect Single", test_eval_score_perfect_single),
        ("Eval: Score Bad Format", test_eval_score_bad_format),
        ("Eval: Score State Not Normalized", test_eval_score_state_not_normalized),
        ("Eval: Score Date Wrong Format", test_eval_score_date_wrong_format),
        ("Eval: Score Multi Duplicate", test_eval_score_multi_duplicate),
        ("Eval: Score Empty Valid", test_eval_score_empty_valid),
        ("Eval: Full Provider Report", test_eval_full_provider_report),
    ]
    
    # 14. Azure Integration (only with --azure flag)
    if AZURE_TESTS:
        tests.extend([
            ("Azure: Key Vault", test_azure_keyvault),
            ("Azure: OCR Connection", test_azure_ocr),
            ("Azure: OpenAI Embedding", test_azure_openai_embedding),
            ("Azure: Blob Storage", test_azure_blob),
        ])
    
    passed = 0
    failed = 0
    errors = []
    
    for name, test_fn in tests:
        try:
            test_fn()
            passed += 1
        except AssertionError as e:
            failed += 1
            errors.append((name, str(e)))
            print(f"  FAIL: {name}: {e}")
        except Exception as e:
            failed += 1
            errors.append((name, f"{type(e).__name__}: {str(e)[:100]}"))
            print(f"  ERROR: {name}: {type(e).__name__}: {str(e)[:100]}")
    
    print(f"\n{'=' * 65}")
    print(f"  RESULTS: {passed} passed, {failed} failed out of {len(tests)} tests")
    if errors:
        print(f"\n  Failed:")
        for name, err in errors:
            print(f"    ✗ {name}: {err}")
    else:
        print(f"\n  ✓ ALL TESTS PASSED")
    print(f"{'=' * 65}\n")
    
    sys.exit(1 if failed > 0 else 0)
