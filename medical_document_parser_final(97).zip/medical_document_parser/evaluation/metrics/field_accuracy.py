"""
Field Accuracy - Compares extracted values against ground truth.
Free, instant, no API call. Needs ground truth file.
"""

import json
import logging
from typing import Dict, Any
from evaluation.metrics.base_metric import BaseMetric

logger = logging.getLogger(__name__)


class FieldAccuracyMetric(BaseMetric):
    
    def __init__(self, ground_truth_path: str = None):
        self.ground_truth = {}
        if ground_truth_path:
            try:
                with open(ground_truth_path) as f:
                    self.ground_truth = json.load(f)
                logger.info(f"Ground truth loaded: {len(self.ground_truth)} providers")
            except Exception as e:
                logger.warning(f"Could not load ground truth: {e}")
    
    @property
    def name(self) -> str:
        return "field_accuracy"
    
    def evaluate_field(self, field_name: str, field_data: dict,
                       context: dict = None) -> Dict[str, Any]:
        """
        Compare extracted value against ground truth.
        
        Context must contain: {"provider_name": "SMITH-JOHN"}
        
        Returns:
            {"score": 1.0, "exact_match": true, "fuzzy_score": 1.0}
            {"score": 0.5, "exact_match": false, "fuzzy_score": 0.89}
        """
        value = field_data.get('value', '')
        if not value:
            return None
        
        if not context or 'provider_name' not in context:
            return None
        
        provider = context['provider_name']
        
        if provider not in self.ground_truth:
            return None
        
        gt = self.ground_truth[provider]
        
        if field_name not in gt:
            return None
        
        gt_value = str(gt[field_name]).strip()
        extracted_value = str(value).strip()
        
        if not gt_value:
            return None
        
        # Exact match
        exact = extracted_value.lower() == gt_value.lower()
        
        # Fuzzy match (Levenshtein ratio)
        fuzzy = self._fuzzy_ratio(extracted_value.lower(), gt_value.lower())
        
        if exact:
            score = 1.0
        elif fuzzy >= 0.90:
            score = 0.9
        elif fuzzy >= 0.80:
            score = 0.75
        elif fuzzy >= 0.50:
            score = 0.5
        else:
            score = 0.0
        
        return {
            "score": round(score, 2),
            "exact_match": exact,
            "fuzzy_score": round(fuzzy, 3),
            "ground_truth": gt_value
        }
    
    def _fuzzy_ratio(self, s1: str, s2: str) -> float:
        """Calculate Levenshtein similarity ratio (0.0 to 1.0)."""
        if s1 == s2:
            return 1.0
        if not s1 or not s2:
            return 0.0
        
        len1, len2 = len(s1), len(s2)
        
        # Simple Levenshtein distance
        matrix = [[0] * (len2 + 1) for _ in range(len1 + 1)]
        for i in range(len1 + 1):
            matrix[i][0] = i
        for j in range(len2 + 1):
            matrix[0][j] = j
        
        for i in range(1, len1 + 1):
            for j in range(1, len2 + 1):
                cost = 0 if s1[i-1] == s2[j-1] else 1
                matrix[i][j] = min(
                    matrix[i-1][j] + 1,
                    matrix[i][j-1] + 1,
                    matrix[i-1][j-1] + cost
                )
        
        distance = matrix[len1][len2]
        max_len = max(len1, len2)
        return 1.0 - (distance / max_len) if max_len > 0 else 1.0
