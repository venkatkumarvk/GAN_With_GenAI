"""
Custom AI Evaluation Metrics - Groundedness, Relevance, Retrieval
==================================================================

No azure-ai-evaluation SDK dependency. Uses Azure OpenAI directly.
Works with GPT-5 (max_completion_tokens, no temperature).

Metrics:
  - Groundedness: Is extracted value supported by the RAG chunks?
  - Relevance: Is extracted value relevant to the field query?
  - Retrieval: Did RAG search return relevant chunks for the query?

All scores normalized to 0.0 - 1.0.
"""

import json
import logging
from typing import Dict, Any
from evaluation.metrics.base_metric import BaseMetric

logger = logging.getLogger(__name__)


GROUNDEDNESS_PROMPT = """You are an evaluation judge. Determine if the Response is fully supported by the Context.

Context (RAG chunks used for extraction):
{context}

Query: {query}
Response: {response}

Score on a scale of 0.0 to 1.0:
  1.0 = Response is fully supported by the context
  0.8 = Mostly supported, minor details not in context
  0.6 = Partially supported
  0.4 = Weakly supported, most info not in context
  0.2 = Barely any support in context
  0.0 = Not supported at all, fabricated from context

Respond ONLY with JSON:
{{"score": 0.0-1.0, "label": "pass or fail", "reason": "brief reason"}}"""


RELEVANCE_PROMPT = """You are an evaluation judge. Determine if the Response is relevant to the Query.

Query: {query}
Response: {response}

Score on a scale of 0.0 to 1.0:
  1.0 = Perfectly relevant, directly answers the query
  0.8 = Mostly relevant
  0.6 = Somewhat relevant
  0.4 = Marginally relevant
  0.2 = Barely relevant
  0.0 = Not relevant at all

Respond ONLY with JSON:
{{"score": 0.0-1.0, "label": "pass or fail", "reason": "brief reason"}}"""


RETRIEVAL_PROMPT = """You are an evaluation judge. Determine if the retrieved Context is relevant to the Query.

Query: {query}

Retrieved Context (chunks from RAG search):
{context}

Score on a scale of 0.0 to 1.0:
  1.0 = All retrieved chunks are highly relevant to the query
  0.8 = Most chunks are relevant
  0.6 = Some chunks are relevant
  0.4 = Few chunks are relevant
  0.2 = Barely any relevant chunks
  0.0 = None of the chunks are relevant to the query

Respond ONLY with JSON:
{{"score": 0.0-1.0, "label": "pass or fail", "reason": "brief reason"}}"""


class CustomAIEvalMetric(BaseMetric):
    """
    Custom AI evaluation metrics using direct Azure OpenAI calls.
    No SDK dependency. Works with GPT-5.
    
    Config:
        {
            "enabled": true,
            "evaluators": ["groundedness", "relevance", "retrieval"]
        }
    """
    
    def __init__(self, config: dict = None, openai_config: dict = None):
        self.client = None
        self.deployment = None
        self.enabled_evaluators = []
        self.available = False
        
        if not config or not config.get('enabled'):
            return
        
        self.enabled_evaluators = config.get('evaluators', [])
        
        if not openai_config:
            logger.warning("Custom AI Eval: no openai_config provided")
            return
        
        try:
            from openai import AzureOpenAI
            
            endpoint = openai_config.get('endpoint', '')
            api_key = openai_config.get('api_key', '')
            
            if not endpoint or not api_key:
                logger.warning("Custom AI Eval: missing endpoint or api_key")
                return
            
            if '@azureKeyVault' in str(endpoint) or '@azureKeyVault' in str(api_key):
                logger.warning("Custom AI Eval: credentials not resolved from Key Vault")
                return
            
            self.client = AzureOpenAI(
                azure_endpoint=endpoint,
                api_key=api_key,
                api_version=openai_config.get('api_version', '2024-12-01-preview')
            )
            self.deployment = openai_config.get('deployment', 'gpt-5')
            self.available = True
            logger.info(f"Custom AI Eval initialized: {self.enabled_evaluators}, deployment={self.deployment}")
            
        except ImportError:
            logger.warning("Custom AI Eval: openai package not installed")
        except Exception as e:
            logger.warning(f"Custom AI Eval: init failed: {e}")
    
    @property
    def name(self) -> str:
        return "custom_ai_eval"
    
    def evaluate_field(self, field_name: str, field_data: dict,
                       context: dict = None) -> Dict[str, Any]:
        """
        Run enabled evaluators on a field.
        
        Context should contain:
            query: field search query text
            rag_context: RAG chunks text (joined)
        """
        if not self.available or not self.client:
            return None
        
        value = field_data.get('value', '')
        if not value:
            return None
        
        if not context:
            context = {}
        
        query = context.get('query', field_name.replace('_', ' '))
        rag_context = context.get('rag_context', '')
        
        results = {}
        
        if 'groundedness' in self.enabled_evaluators and rag_context:
            result = self._call_evaluator(
                GROUNDEDNESS_PROMPT.format(
                    context=rag_context[:3000],
                    query=query,
                    response=value
                )
            )
            if result:
                results['groundedness'] = result
        
        if 'relevance' in self.enabled_evaluators:
            result = self._call_evaluator(
                RELEVANCE_PROMPT.format(
                    query=query,
                    response=value
                )
            )
            if result:
                results['relevance'] = result
        
        if 'retrieval' in self.enabled_evaluators and rag_context:
            result = self._call_evaluator(
                RETRIEVAL_PROMPT.format(
                    query=query,
                    context=rag_context[:3000]
                )
            )
            if result:
                results['retrieval'] = result
        
        return results if results else None
    
    def _call_evaluator(self, prompt: str) -> dict:
        """Call LLM with evaluation prompt. GPT-5 compatible."""
        try:
            response = self.client.chat.completions.create(
                model=self.deployment,
                messages=[
                    {"role": "system", "content": "You are an evaluation judge. Respond ONLY with JSON."},
                    {"role": "user", "content": prompt}
                ],
                max_completion_tokens=500
            )
            
            content = response.choices[0].message.content
            if not content:
                return None
            
            clean = content.strip()
            start = clean.find('{')
            end = clean.rfind('}')
            if start != -1 and end != -1:
                result = json.loads(clean[start:end+1])
                score = result.get('score', 0)
                if isinstance(score, (int, float)):
                    score = max(0.0, min(1.0, float(score)))
                else:
                    score = 0.0
                return {
                    "score": round(score, 2),
                    "label": "pass" if score >= 0.6 else "fail",
                    "reason": result.get('reason', '')
                }
            return None
            
        except Exception as e:
            logger.warning(f"Custom AI Eval call failed: {str(e)[:100]}")
            return None
