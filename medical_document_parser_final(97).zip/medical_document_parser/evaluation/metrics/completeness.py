"""
Completeness - Measures what % of fields have actual values.
Free, instant, no API call. Works at provider level.
"""

import logging
from typing import Dict, Any, List
from evaluation.metrics.base_metric import BaseMetric

logger = logging.getLogger(__name__)


class CompletenessMetric(BaseMetric):
    
    @property
    def name(self) -> str:
        return "completeness"
    
    def evaluate_field(self, field_name: str, field_data: dict,
                       context: dict = None) -> Dict[str, Any]:
        """Not used at field level. Completeness is provider-level."""
        return None
    
    def evaluate_provider(self, extracted_data: dict) -> Dict[str, Any]:
        """
        Calculate completeness for entire provider.
        
        Returns:
            {
                "score": 0.82,
                "total_fields": 34,
                "extracted_fields": 28,
                "empty_fields": 6,
                "missing_field_names": ["ssn", "cds_licenses", ...]
            }
        """
        total = 0
        extracted = 0
        missing = []
        
        for field_name, field_data in extracted_data.items():
            total += 1
            
            if isinstance(field_data, dict):
                value = field_data.get('value', '')
                if value and str(value).strip():
                    extracted += 1
                else:
                    missing.append(field_name)
            elif isinstance(field_data, list):
                if field_data and len(field_data) > 0:
                    # Check if it's not just empty items
                    has_data = False
                    for item in field_data:
                        if isinstance(item, dict):
                            for k, v in item.items():
                                if k == 'id':
                                    continue
                                if isinstance(v, dict) and v.get('value'):
                                    has_data = True
                                    break
                        if has_data:
                            break
                    if has_data:
                        extracted += 1
                    else:
                        missing.append(field_name)
                else:
                    missing.append(field_name)
        
        score = round(extracted / total, 3) if total > 0 else 0
        
        return {
            "score": score,
            "total_fields": total,
            "extracted_fields": extracted,
            "empty_fields": len(missing),
            "missing_field_names": missing
        }
