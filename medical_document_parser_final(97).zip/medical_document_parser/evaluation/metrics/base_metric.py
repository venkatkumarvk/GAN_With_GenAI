"""
Base Metric - Abstract base class for all evaluation metrics.
All metrics inherit from this. Never edit this file for new metrics.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any


class BaseMetric(ABC):
    """Abstract base class for evaluation metrics."""
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Metric name used as key in evaluation output."""
        pass
    
    @abstractmethod
    def evaluate_field(self, field_name: str, field_data: dict, 
                       context: dict = None) -> Dict[str, Any]:
        """
        Evaluate a single field.
        
        Args:
            field_name: Name of the field
            field_data: Field dict with 'value', 'confidence', etc.
            context: Additional context (ocr_text, rag_chunks, ground_truth, etc.)
        
        Returns:
            {"score": float/int, ...additional_keys}
            or None if nothing to evaluate
        """
        pass
    
    def evaluate_multi_subfield(self, parent_field: str, sub_field: str,
                                sub_data: dict, context: dict = None) -> Dict[str, Any]:
        """
        Evaluate a multi-value sub-field. Default: same as evaluate_field.
        Override in subclass if different logic needed.
        """
        return self.evaluate_field(f"{parent_field}.{sub_field}", sub_data, context)
