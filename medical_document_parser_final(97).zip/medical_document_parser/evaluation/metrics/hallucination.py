"""
Hallucination Detection - Checks if extracted value exists in source OCR text.
Free, instant, no API call.
"""

import logging
from typing import Dict, Any
from evaluation.metrics.base_metric import BaseMetric

logger = logging.getLogger(__name__)


class HallucinationMetric(BaseMetric):
    
    @property
    def name(self) -> str:
        return "hallucination"
    
    def evaluate_field(self, field_name: str, field_data: dict,
                       context: dict = None) -> Dict[str, Any]:
        """
        Check if extracted value exists in source OCR text.
        
        Context must contain: {"ocr_texts": ["full ocr text of each document"]}
        If no ocr_texts provided, returns None (skip this metric).
        """
        value = field_data.get('value', '')
        if not value:
            return None
        
        if not context or not context.get('ocr_texts'):
            return None
        
        ocr_texts = context['ocr_texts']
        
        # Search value in all OCR texts (case-insensitive)
        value_lower = value.strip().lower()
        
        for ocr_text in ocr_texts:
            if not ocr_text:
                continue
            if value_lower in ocr_text.lower():
                return {"score": 1.0, "found_in_source": True}
        
        # Try partial match for multi-word values
        # "John Smith" might appear as "John" and "Smith" separately
        words = value_lower.split()
        if len(words) > 1:
            all_words_found = True
            for word in words:
                if len(word) < 3:  # skip short words
                    continue
                found = any(word in (ocr.lower() if ocr else '') for ocr in ocr_texts)
                if not found:
                    all_words_found = False
                    break
            if all_words_found:
                return {"score": 0.75, "found_in_source": True,
                        "note": "Individual words found but not exact phrase"}
        
        return {"score": 0.0, "found_in_source": False}
