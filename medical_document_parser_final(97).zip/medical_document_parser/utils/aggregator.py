"""
Aggregator - Cross-Document Value Aggregation
==============================================

Handles:
  - Single-value: frequency voting + confidence tiebreak
  - Multi-value: merge arrays, deduplicate by key fields, keep highest confidence
"""

import logging
from collections import Counter
from typing import Dict, List

logger = logging.getLogger(__name__)


def calculate_best_values(documents: List[Dict], fields: List[str], folder_name: str,
                         prompt_module=None) -> Dict:
    """
    Calculate best values using frequency and confidence.
    
    Handles two types:
      - single: pick best single value by frequency + confidence
      - multi: merge arrays, deduplicate by sub-field values
    """
    field_library = {}
    if prompt_module:
        field_library = getattr(prompt_module, 'FIELD_LIBRARY', {})
    
    best_values = {}
    
    for field in fields:
        cardinality = field_library.get(field, {}).get('cardinality', 'single')
        
        if cardinality == 'multi':
            field_info = field_library.get(field, {})
            best_values[field] = _aggregate_multi_field(
                field, documents, folder_name, field_info
            )
        else:
            best_values[field] = _aggregate_single_field(
                field, documents, folder_name
            )
    
    return best_values


def _aggregate_single_field(field: str, documents: List[Dict], folder_name: str) -> Dict:
    """Aggregate a single-value field using frequency + confidence."""
    field_occurrences = []
    
    for doc in documents:
        if field in doc['fields']:
            field_data = doc['fields'][field]
            
            if isinstance(field_data, dict):
                value = field_data.get('value') or ''
                confidence = field_data.get('confidence') or 0
                
                if confidence is not None and value != '':
                    if (not value.strip() or str(value).lower() == 'unknown') and float(confidence) < 0.50:
                        continue
                    
                    field_occurrences.append((
                        value,
                        float(confidence),
                        doc.get('document_name', ''),
                        field_data.get('_rag_context', ''),
                        field_data.get('_rag_query', '')
                    ))
    
    if field_occurrences:
        value_counts = Counter([v[0] for v in field_occurrences])
        most_common_value, max_frequency = value_counts.most_common(1)[0]
        
        candidates = [occ for occ in field_occurrences if occ[0] == most_common_value]
        best_occurrence = max(candidates, key=lambda x: x[1])
        best_value, best_confidence, source_file, rag_context, rag_query = best_occurrence
        
        confidences_for_value = [occ[1] for occ in candidates]
        avg_confidence = sum(confidences_for_value) / len(confidences_for_value)
        
        result = {
            'value': best_value,
            'confidence': round(avg_confidence, 2),
            'source_folder': folder_name,
            'source_file': source_file,
            'frequency': max_frequency,
            'total_documents': len(documents)
        }
        if rag_context:
            result['_rag_context'] = rag_context
            result['_rag_query'] = rag_query
        return result
    else:
        return {
            'value': '',
            'confidence': '',
            'source_folder': '',
            'source_file': '',
            'frequency': 0,
            'total_documents': len(documents)
        }


def _aggregate_multi_field(field: str, documents: List[Dict], folder_name: str,
                          field_info: dict = None) -> list:
    """
    Aggregate multi-value field. Deduplicates by key fields (not dates/status).
    """
    all_items = []
    
    for doc in documents:
        if field in doc['fields']:
            field_data = doc['fields'][field]
            
            if isinstance(field_data, list):
                for item in field_data:
                    if isinstance(item, dict):
                        all_items.append((item, doc.get('document_name', '')))
            elif isinstance(field_data, dict) and field in field_data:
                inner = field_data[field]
                if isinstance(inner, list):
                    for item in inner:
                        if isinstance(item, dict):
                            all_items.append((item, doc.get('document_name', '')))
    
    if not all_items:
        return []
    
    # Deduplicate by KEY sub-field values only (not dates/status)
    unique_items = {}
    
    SKIP_FOR_SIGNATURE = {
        'issue_date', 'expiration_date', 'expiration', 'issue',
        'status', 'license_status'
    }
    
    for item, source_file in all_items:
        sig_parts = []
        for key, val in sorted(item.items()):
            if key == 'id':
                continue
            if any(skip in key for skip in SKIP_FOR_SIGNATURE):
                continue
            if isinstance(val, dict):
                v = str(val.get('value', '')).strip().lower()
                if v:
                    sig_parts.append(v)
            elif isinstance(val, str):
                v = val.strip().lower()
                if v:
                    sig_parts.append(v)
        
        signature = '|'.join(sig_parts)
        
        if not signature:
            continue
        
        if signature in unique_items:
            existing = unique_items[signature]
            existing['frequency'] += 1
            
            new_conf = _avg_item_confidence(item)
            old_conf = _avg_item_confidence(existing['item'])
            if new_conf > old_conf:
                existing['item'] = item
                existing['source_file'] = source_file
        else:
            unique_items[signature] = {
                'item': item,
                'source_file': source_file,
                'frequency': 1
            }
    
    # Build final array
    result = []
    for idx, (sig, data) in enumerate(unique_items.items(), 1):
        item = data['item']
        final_item = {'id': idx}
        
        for key, val in item.items():
            if key == 'id':
                continue
            
            if isinstance(val, dict):
                extracted_value = val.get('value', '')
                
                if extracted_value and str(extracted_value).strip():
                    final_item[key] = {
                        'value': extracted_value,
                        'confidence': round(float(val.get('confidence', 0)), 2),
                        'source_folder': folder_name,
                        'source_file': data['source_file'],
                        'frequency': data['frequency'],
                        'total_documents': len(documents)
                    }
                    if val.get('_rag_context'):
                        final_item[key]['_rag_context'] = val['_rag_context']
                        final_item[key]['_rag_query'] = val.get('_rag_query', '')
                else:
                    # Empty value - use empty metadata
                    final_item[key] = {
                        'value': '',
                        'confidence': '',
                        'source_folder': '',
                        'source_file': '',
                        'frequency': 0,
                        'total_documents': len(documents)
                    }
            else:
                if val and str(val).strip():
                    final_item[key] = {
                        'value': val,
                        'confidence': 0.5,
                        'source_folder': folder_name,
                        'source_file': data['source_file'],
                        'frequency': data['frequency'],
                        'total_documents': len(documents)
                    }
                else:
                    final_item[key] = {
                        'value': '',
                        'confidence': '',
                        'source_folder': '',
                        'source_file': '',
                        'frequency': 0,
                        'total_documents': len(documents)
                    }
        
        result.append(final_item)
    
    return result


def _avg_item_confidence(item: dict) -> float:
    """Calculate average confidence across all sub-fields."""
    confidences = []
    for key, val in item.items():
        if key == 'id':
            continue
        if isinstance(val, dict) and 'confidence' in val:
            confidences.append(float(val.get('confidence', 0)))
    return sum(confidences) / len(confidences) if confidences else 0.0
