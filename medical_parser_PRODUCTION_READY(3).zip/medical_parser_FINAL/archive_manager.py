"""
Archive Manager - Handle document archiving
"""

import os
import zipfile
from datetime import datetime
from azure.storage.blob import BlobServiceClient
import logging

class ArchiveManager:
    def __init__(self, config, doctype):
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.doctype = doctype
        self.archive_config = config['archive']
        
        # Initialize blob client
        self.blob_service = BlobServiceClient.from_connection_string(
            config['azure_blob']['connection_string']
        )
        self.archive_container = self.blob_service.get_container_client(
            self.archive_config['container']
        )
    
    def archive_results(self, results):
        """
        Archive processed documents
        
        Structure:
        archivecontainer/
        ├── processed/{provider}/{doctype}_{timestamp}.zip
        └── unprocessed/{provider}/{doctype}_{timestamp}.zip
        """
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        for provider, provider_data in results.get('providers', {}).items():
            # Archive high confidence (processed)
            if provider_data.get('high_confidence_docs'):
                self._archive_provider_docs(
                    provider=provider,
                    docs=provider_data['high_confidence_docs'],
                    folder='processed',
                    timestamp=timestamp
                )
            
            # Archive low confidence (unprocessed)
            if provider_data.get('low_confidence_docs'):
                self._archive_provider_docs(
                    provider=provider,
                    docs=provider_data['low_confidence_docs'],
                    folder='unprocessed',
                    timestamp=timestamp
                )
    
    def _archive_provider_docs(self, provider, docs, folder, timestamp):
        """Create zip file and upload to blob"""
        archive_name_format = self.archive_config.get(
            'archive_name_format',
            '{doctype}_{timestamp}.zip'
        )
        zip_filename = archive_name_format.format(
            doctype=self.doctype,
            timestamp=timestamp
        )
        
        local_zip_path = f"/tmp/{zip_filename}"
        
        # Create zip file
        with zipfile.ZipFile(local_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for doc in docs:
                # Add original file if exists
                if doc.get('original_path') and os.path.exists(doc['original_path']):
                    zipf.write(doc['original_path'], doc.get('filename', 'unknown'))
                
                # Add JSON result
                if doc.get('json_result'):
                    json_filename = f"{doc.get('filename', 'unknown')}.json"
                    zipf.writestr(json_filename, doc['json_result'])
        
        # Upload to blob
        blob_path = f"{folder}/{provider}/{zip_filename}"
        
        self.logger.info(f"Uploading archive: {blob_path}")
        
        with open(local_zip_path, 'rb') as data:
            self.archive_container.upload_blob(
                name=blob_path,
                data=data,
                overwrite=True
            )
        
        # Clean up local file
        os.remove(local_zip_path)
        
        self.logger.info(f"Archived {len(docs)} documents to {blob_path}")
