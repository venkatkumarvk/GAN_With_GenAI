"""
PROMPT BUILDER - Builds extraction prompts dynamically
Receives prompt configuration from the prompt module loaded by main.py
"""

import json
from typing import List, Dict, Any


def build_extraction_prompt(text: str, fields: List[str], 
                           prompt_module,
                           rag_examples: List[Dict] = None,
                           folder_description: str = "") -> str:
    """
    Build extraction prompt from prompt module
    
    Args:
        text: Document text to extract from
        fields: List of field names to extract
        prompt_module: The loaded prompt module (e.g., prompts.cred_prompt)
        rag_examples: Optional list of RAG examples
        folder_description: Optional folder description
    
    Returns:
        Complete extraction prompt string
    """
    # Get configurations from prompt module
    FIELD_LIBRARY = getattr(prompt_module, 'FIELD_LIBRARY', {})
    SYSTEM_PROMPT_CONFIG = getattr(prompt_module, 'SYSTEM_PROMPT_CONFIG', {})
    
    # Build system prompt
    prompt_parts = []
    
    # Add role
    if 'role' in SYSTEM_PROMPT_CONFIG:
        prompt_parts.append(SYSTEM_PROMPT_CONFIG['role'])
        prompt_parts.append("")
    
    # Add extraction rules
    if 'extraction_rules' in SYSTEM_PROMPT_CONFIG:
        prompt_parts.append("EXTRACTION RULES:")
        for idx, rule in enumerate(SYSTEM_PROMPT_CONFIG['extraction_rules'], 1):
            prompt_parts.append(f"{idx}. {rule}")
        prompt_parts.append("")
    
    # Add confidence guide
    if 'confidence_guide' in SYSTEM_PROMPT_CONFIG:
        prompt_parts.append("CONFIDENCE SCORING:")
        for range_str, description in SYSTEM_PROMPT_CONFIG['confidence_guide'].items():
            prompt_parts.append(f"  {range_str}: {description}")
        prompt_parts.append("")
    
    # Add field definitions
    prompt_parts.append("FIELDS TO EXTRACT:")
    for field in fields:
        if field in FIELD_LIBRARY:
            info = FIELD_LIBRARY[field]
            prompt_parts.append(f"\n{field}:")
            prompt_parts.append(f"  Description: {info.get('description', 'N/A')}")
            prompt_parts.append(f"  Type: {info.get('type', 'string')}")
            if 'format' in info:
                prompt_parts.append(f"  Format: {info.get('format')}")
            if 'examples' in info:
                prompt_parts.append(f"  Examples: {', '.join(info['examples'])}")
            if 'validation' in info:
                prompt_parts.append(f"  Validation: {info.get('validation')}")
    prompt_parts.append("")
    
    # Add RAG examples if provided
    if rag_examples and len(rag_examples) > 0:
        prompt_parts.append(f"REFERENCE EXAMPLES ({len(rag_examples)} similar documents):")
        prompt_parts.append("These are examples from similar documents to guide extraction:")
        prompt_parts.append("")
        
        for idx, doc in enumerate(rag_examples, 1):
            prompt_parts.append(f"Example {idx}:")
            content = doc.get('content', '')
            # Show first 300 chars of content
            prompt_parts.append(f"Content: {content[:300]}...")
            prompt_parts.append("")
        
        prompt_parts.append("Use these examples to understand extraction patterns and field formats.")
        prompt_parts.append("")
    
    # Add document text
    prompt_parts.append("=" * 80)
    prompt_parts.append("DOCUMENT TO EXTRACT FROM:")
    prompt_parts.append("=" * 80)
    prompt_parts.append(text)
    prompt_parts.append("=" * 80)
    prompt_parts.append("")
    
    # Add output format
    if 'output_format' in SYSTEM_PROMPT_CONFIG:
        prompt_parts.append(SYSTEM_PROMPT_CONFIG['output_format'])
        prompt_parts.append("")
    
    # Add restrictions
    if 'restrictions' in SYSTEM_PROMPT_CONFIG:
        prompt_parts.append("IMPORTANT RESTRICTIONS:")
        prompt_parts.append(SYSTEM_PROMPT_CONFIG['restrictions'])
    
    return "\n".join(prompt_parts)


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def validate_prompt_module(prompt_module) -> bool:
    """
    Validate that prompt module has required attributes
    
    Args:
        prompt_module: The loaded prompt module
    
    Returns:
        True if valid, False otherwise
    """
    required_attrs = ['FIELD_LIBRARY', 'SYSTEM_PROMPT_CONFIG']
    
    for attr in required_attrs:
        if not hasattr(prompt_module, attr):
            print(f"FAILED ERROR: Prompt module missing '{attr}'")
            return False
    
    return True


def get_available_fields(prompt_module) -> List[str]:
    """
    Get list of available fields from prompt module
    
    Args:
        prompt_module: The loaded prompt module
    
    Returns:
        List of field names
    """
    FIELD_LIBRARY = getattr(prompt_module, 'FIELD_LIBRARY', {})
    return list(FIELD_LIBRARY.keys())


def get_field_info(prompt_module, field_name: str) -> Dict:
    """
    Get information about a specific field
    
    Args:
        prompt_module: The loaded prompt module
        field_name: Name of the field
    
    Returns:
        Field information dictionary
    """
    FIELD_LIBRARY = getattr(prompt_module, 'FIELD_LIBRARY', {})
    return FIELD_LIBRARY.get(field_name, {})
