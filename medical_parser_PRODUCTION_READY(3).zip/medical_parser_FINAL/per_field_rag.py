"""
PER-FIELD RAG EXTRACTION - PRODUCTION READY
============================================

Maximum accuracy by finding best examples for EACH field.

For 46 fields:
- 46 field-specific RAG searches
- Each field gets its own best 3 examples
- Much better accuracy

Example:
  Field "email": Searches for docs with email → finds CV, contact form
  Field "degree": Searches for docs with degree → finds transcript, diploma
  Field "license_number": Searches for docs with license → finds license cards

Cost: Higher but MUCH better accuracy!
"""

import logging
import hashlib
from typing import Dict, List, Tuple, Optional

logger = logging.getLogger(__name__)


def process_document_per_field_rag(
    doc_bytes: bytes,
    doc_name: str,
    extension: str,
    provider: str,
    folder: str,
    fields: List[str],
    ocr,
    openai_manager,
    search_manager,
    cost_tracker,
    prompt_module
) -> Tuple[Dict, bool]:
    """
    Extract fields using PER-FIELD RAG
    
    Each field gets:
    1. Field-specific RAG search
    2. Best 3 examples for that field
    3. Targeted extraction
    
    Args:
        doc_bytes: Document bytes
        doc_name: Document name
        extension: File extension
        provider: Provider name
        folder: Folder name
        fields: List of field names to extract
        ocr: OCR service
        openai_manager: OpenAI service
        search_manager: AI Search service
        cost_tracker: Cost tracker
        prompt_module: Prompt module with FIELD_LIBRARY
    
    Returns:
        (extracted_data, success)
    """
    logger.info(f"    Document: {doc_name} - Per-field RAG extraction")
    
    # ========================================================================
    # STEP 1: OCR
    # ========================================================================
    text, pages, success = ocr.extract_text(doc_bytes, extension)
    
    if not success or len(text) < 100:
        logger.warning(f"      FAILED: Insufficient text")
        return {}, False
    
    cost_tracker.add_ocr(pages)
    logger.info(f"      Step 1: OCR complete ({len(text)} chars)")
    
    # ========================================================================
    # STEP 2: GENERATE EMBEDDING & UPLOAD
    # ========================================================================
    doc_embedding, tokens = openai_manager.generate_embedding(text[:8000])
    cost_tracker.add_embedding(tokens)
    
    # Upload to AI Search
    content_hash = hashlib.md5(text.encode('utf-8')).hexdigest()
    doc_id = content_hash
    
    success = search_manager.upload_document(
        doc_id=doc_id,
        content=text,
        vector=doc_embedding,
        provider=provider,
        folder=folder,
        document_name=doc_name,
        chunk_index=0,
        total_chunks=1
    )
    
    if not success:
        logger.warning(f"      FAILED: Could not upload to AI Search")
        return {}, False
    
    logger.info(f"      Step 2: Uploaded to AI Search")
    
    # ========================================================================
    # STEP 3: EXTRACT EACH FIELD SEPARATELY
    # ========================================================================
    logger.info(f"      Step 3: Extracting {len(fields)} fields...")
    
    FIELD_LIBRARY = getattr(prompt_module, 'FIELD_LIBRARY', {})
    SYSTEM_PROMPT_CONFIG = getattr(prompt_module, 'SYSTEM_PROMPT_CONFIG', {})
    
    extracted_data = {}
    
    for field_idx, field_name in enumerate(fields, 1):
        try:
            # Get field info
            field_info = FIELD_LIBRARY.get(field_name, {})
            field_desc = field_info.get('description', field_name)
            
            logger.info(f"        Field {field_idx}/{len(fields)}: {field_name}")
            
            # ============================================================
            # STEP 3A: FIELD-SPECIFIC RAG SEARCH
            # ============================================================
            
            # Create field query
            # Examples:
            #   "first_name" → "first name given name"
            #   "email" → "email address contact"
            #   "degree" → "degree education qualification"
            
            field_query_text = f"{field_name.replace('_', ' ')} {field_desc}"
            
            # Generate embedding for field query
            field_embedding, query_tokens = openai_manager.generate_embedding(field_query_text)
            cost_tracker.add_embedding(query_tokens)
            
            # Search for documents with this specific field
            similar_docs = search_manager.search_similar(
                query_vector=field_embedding,
                provider=provider,
                folder=folder,
                top_k=3
            )
            
            logger.info(f"          RAG: {len(similar_docs)} examples found")
            
            # ============================================================
            # STEP 3B: BUILD FIELD-SPECIFIC PROMPT
            # ============================================================
            
            prompt_parts = []
            
            # System role
            system_role = SYSTEM_PROMPT_CONFIG.get('role', 'You are a data extraction assistant.')
            prompt_parts.append(system_role)
            prompt_parts.append("")
            
            # Task
            prompt_parts.append(f"TASK: Extract the '{field_name}' field from the document.")
            prompt_parts.append("")
            
            # Field definition
            prompt_parts.append(f"FIELD DEFINITION:")
            prompt_parts.append(f"  Name: {field_name}")
            prompt_parts.append(f"  Description: {field_desc}")
            prompt_parts.append(f"  Type: {field_info.get('type', 'string')}")
            
            if 'examples' in field_info:
                prompt_parts.append(f"  Valid examples: {', '.join(field_info['examples'])}")
            
            if 'validation' in field_info:
                prompt_parts.append(f"  Validation: {field_info['validation']}")
            
            prompt_parts.append("")
            
            # RAG examples - field-specific!
            if similar_docs:
                prompt_parts.append(f"REFERENCE EXAMPLES (documents containing {field_name}):")
                prompt_parts.append("")
                
                for idx, doc in enumerate(similar_docs, 1):
                    doc_content = doc.get('content', '')
                    doc_name_ref = doc.get('document_name', f'doc{idx}')
                    
                    # Show relevant snippet (300 chars)
                    snippet = doc_content[:300].replace('\n', ' ')
                    
                    prompt_parts.append(f"Example {idx} from '{doc_name_ref}':")
                    prompt_parts.append(f"  {snippet}...")
                    prompt_parts.append("")
            
            # Document to extract from
            prompt_parts.append("DOCUMENT TO EXTRACT FROM:")
            prompt_parts.append("-" * 40)
            
            # Limit text to avoid token overflow
            # Use first 3000 chars (should contain most relevant info)
            doc_text_limited = text[:3000]
            prompt_parts.append(doc_text_limited)
            
            if len(text) > 3000:
                prompt_parts.append(f"... [document continues, {len(text)} total chars]")
            
            prompt_parts.append("-" * 40)
            prompt_parts.append("")
            
            # Output format
            prompt_parts.append("OUTPUT FORMAT (JSON only, no markdown):")
            prompt_parts.append("IMPORTANT: Always extract a value. Never use 'NA' or 'Not Found'.")
            prompt_parts.append("If information is not clearly present, provide your best extraction with low confidence.")
            prompt_parts.append("")
            prompt_parts.append('{')
            prompt_parts.append(f'  "{field_name}": {{')
            prompt_parts.append('    "value": "extracted_value",')
            prompt_parts.append('    "confidence": 0.00-1.00')
            prompt_parts.append('  }')
            prompt_parts.append('}')
            prompt_parts.append("")
            prompt_parts.append("Examples:")
            prompt_parts.append('  - Field clearly present: {"value": "John Smith", "confidence": 0.95}')
            prompt_parts.append('  - Field partially visible: {"value": "J. Smith", "confidence": 0.60}')
            prompt_parts.append('  - Field inferred: {"value": "Smith", "confidence": 0.30}')
            prompt_parts.append('  - Field very unclear: {"value": "Unknown", "confidence": 0.10}')
            prompt_parts.append("")
            
            # Rules
            rules = SYSTEM_PROMPT_CONFIG.get('rules', [])
            if rules:
                prompt_parts.append("RULES:")
                for rule in rules[:3]:  # Top 3 rules
                    prompt_parts.append(f"  - {rule}")
                prompt_parts.append("")
            
            prompt = "\n".join(prompt_parts)
            
            # ============================================================
            # STEP 3C: GPT EXTRACTION FOR THIS FIELD
            # ============================================================
            
            result, tokens = openai_manager.extract_fields(
                prompt=prompt,
                temperature=0.1,
                use_vision=False
            )
            
            cost_tracker.add_gpt_tokens(
                input_tokens=tokens['input_tokens'],
                output_tokens=tokens['output_tokens']
            )
            
            # Extract field value
            if field_name in result:
                extracted_data[field_name] = result[field_name]
                value = result[field_name].get('value', 'Unknown')
                conf = result[field_name].get('confidence', 0.0)
                logger.info(f"          OK: {value} (conf: {conf:.2f})")
            else:
                # GPT didn't return the field - use Unknown with 0 confidence
                extracted_data[field_name] = {'value': 'Unknown', 'confidence': 0.0}
                logger.info(f"          WARNING: Field not in response, using Unknown")
        
        except Exception as e:
            logger.error(f"          ERROR: {e}")
            # Error occurred - use Unknown with 0 confidence
            extracted_data[field_name] = {'value': 'Unknown', 'confidence': 0.0}
    
    logger.info(f"      Step 3 complete: {len(extracted_data)}/{len(fields)} fields")
    
    return extracted_data, True


def process_provider_per_field_rag(
    provider: str,
    folder: str,
    folder_config: dict,
    documents: List,
    blob_manager,
    ocr,
    openai_manager,
    search_manager,
    cost_tracker,
    config: dict,
    prompt_module
) -> Dict:
    """
    Process provider with per-field RAG
    
    Workflow:
    1. Index all documents first (build AI Search index)
    2. For each document:
       - For each field:
         * Field-specific RAG search
         * Extract with field-specific examples
    3. Aggregate all results
    
    Args:
        provider: Provider name
        folder: Folder name
        folder_config: Folder configuration
        documents: List of document blobs
        blob_manager: Blob storage manager
        ocr: OCR service
        openai_manager: OpenAI service
        search_manager: AI Search service
        cost_tracker: Cost tracker
        config: System config
        prompt_module: Prompt module
    
    Returns:
        Aggregated extraction results
    """
    logger.info(f"  Provider: {provider}")
    logger.info(f"  Folder: {folder}")
    logger.info(f"  Documents: {len(documents)}")
    logger.info(f"  Method: PER-FIELD RAG (maximum accuracy)")
    logger.info("")
    
    fields = folder_config['fields']
    logger.info(f"  Fields to extract: {len(fields)}")
    logger.info(f"    {', '.join(fields[:5])}{'...' if len(fields) > 5 else ''}")
    logger.info("")
    
    # ========================================================================
    # PHASE 1: INDEX ALL DOCUMENTS
    # ========================================================================
    logger.info(f"  PHASE 1: Indexing all documents...")
    
    indexed_docs = []
    
    for doc_idx, doc_blob in enumerate(documents, 1):
        doc_name = doc_blob.name.split('/')[-1]
        
        try:
            # Download
            doc_bytes = blob_manager.download_blob(
                config['azure_blob']['inputcontainer'],
                doc_blob.name
            )
            
            # Get extension
            import os
            extension = os.path.splitext(doc_name)[1]
            
            # Store for processing
            indexed_docs.append({
                'name': doc_name,
                'bytes': doc_bytes,
                'extension': extension
            })
            
            logger.info(f"    Doc {doc_idx}/{len(documents)}: {doc_name} - Ready")
        
        except Exception as e:
            logger.error(f"    Doc {doc_idx}/{len(documents)}: FAILED - {e}")
    
    logger.info(f"  PHASE 1 complete: {len(indexed_docs)} documents ready")
    logger.info("")
    
    # ========================================================================
    # PHASE 2: PER-FIELD EXTRACTION
    # ========================================================================
    logger.info(f"  PHASE 2: Per-field extraction...")
    logger.info(f"    Total extractions: {len(indexed_docs)} docs × {len(fields)} fields = {len(indexed_docs) * len(fields)}")
    logger.info("")
    
    all_results = []
    
    for doc_idx, doc in enumerate(indexed_docs, 1):
        logger.info(f"    Processing {doc_idx}/{len(indexed_docs)}: {doc['name']}")
        
        extracted_data, success = process_document_per_field_rag(
            doc_bytes=doc['bytes'],
            doc_name=doc['name'],
            extension=doc['extension'],
            provider=provider,
            folder=folder,
            fields=fields,
            ocr=ocr,
            openai_manager=openai_manager,
            search_manager=search_manager,
            cost_tracker=cost_tracker,
            prompt_module=prompt_module
        )
        
        if success:
            all_results.append({
                'document_name': doc['name'],
                'fields': extracted_data
            })
    
    logger.info(f"  PHASE 2 complete: {len(all_results)} documents extracted")
    logger.info("")
    
    # ========================================================================
    # PHASE 3: AGGREGATION
    # ========================================================================
    logger.info(f"  PHASE 3: Aggregating results...")
    
    aggregated = aggregate_field_results(
        results=all_results,
        fields=fields
    )
    
    logger.info(f"  PHASE 3 complete")
    logger.info("")
    
    return aggregated


def aggregate_field_results(results: List[Dict], fields: List[str]) -> Dict:
    """
    Aggregate per-field extraction results
    
    For each field:
    - Collect all values from all documents
    - Choose most frequent value
    - If tie, choose highest confidence
    - Track source document and frequency
    
    Args:
        results: List of document results
        fields: List of field names
    
    Returns:
        Aggregated results
    """
    from collections import Counter
    
    aggregated = {}
    
    for field_name in fields:
        # Collect all values for this field
        values = []
        
        for doc_result in results:
            field_data = doc_result['fields'].get(field_name, {})
            value = field_data.get('value', 'Unknown')
            confidence = field_data.get('confidence', 0.0)
            
            # KEEP ALL VALUES - even low confidence or "Unknown"
            # Human will review based on confidence score
            values.append({
                'value': value,
                'confidence': confidence,
                'source': doc_result['document_name']
            })
        
        if not values:
            # This should never happen, but just in case
            aggregated[field_name] = {
                'value': 'Unknown',
                'confidence': 0.0,
                'source_file': 'None',
                'frequency': 0,
                'total_documents': len(results)
            }
            continue
        
        # Count frequency
        value_counts = Counter([v['value'] for v in values])
        most_common_value, frequency = value_counts.most_common(1)[0]
        
        # If multiple values have same frequency, choose highest confidence
        candidates = [v for v in values if v['value'] == most_common_value]
        best_candidate = max(candidates, key=lambda x: x['confidence'])
        
        aggregated[field_name] = {
            'value': best_candidate['value'],
            'confidence': best_candidate['confidence'],
            'source_file': best_candidate['source'],
            'frequency': frequency,
            'total_documents': len(results)
        }
    
    # Calculate average confidence from ALL fields (including low ones)
    all_confidences = [v['confidence'] for v in aggregated.values()]
    avg_confidence = sum(all_confidences) / len(all_confidences) if all_confidences else 0.0
    
    return {
        'fields': aggregated,
        'average_confidence': avg_confidence,
        'total_documents': len(results)
    }
