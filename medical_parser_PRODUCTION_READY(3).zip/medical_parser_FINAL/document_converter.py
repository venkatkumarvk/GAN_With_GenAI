"""
Document to Image Converter
Converts any document type to images for multimodal processing
Uses ONLY PyMuPDF (fitz) - no other dependencies needed
"""

import fitz  # PyMuPDF
import base64
import logging
from io import BytesIO
from typing import List, Tuple
import os

logger = logging.getLogger(__name__)


class DocumentConverter:
    """
    Converts documents to images for multimodal RAG processing
    
    Supports:
    - PDF (multi-page)
    - Images (PNG, JPG, JPEG, TIFF, BMP, GIF, WEBP)
    - DOCX (convert to PDF first, then images)
    - DOC (convert to PDF first, then images)
    """
    
    def __init__(self, dpi: int = 200):
        """
        Initialize converter
        
        Args:
            dpi: Resolution for PDF to image conversion (default 200, good quality)
                 - 150 = fast, lower quality
                 - 200 = balanced (recommended)
                 - 300 = high quality, slower
        """
        self.dpi = dpi
        self.zoom = dpi / 72  # PDF standard is 72 DPI
        
    def convert_to_images(self, file_bytes: bytes, filename: str) -> List[Tuple[bytes, str]]:
        """
        Convert any document to list of images
        
        Args:
            file_bytes: Document bytes
            filename: Original filename (to determine type)
        
        Returns:
            List of (image_bytes, page_info) tuples
            page_info = "page_1", "page_2", etc. or "image" for single images
        """
        ext = os.path.splitext(filename)[1].lower()
        
        if ext == '.pdf':
            return self._convert_pdf_to_images(file_bytes)
        
        elif ext in ['.png', '.jpg', '.jpeg', '.tiff', '.tif', '.bmp', '.gif', '.webp']:
            return self._handle_image(file_bytes, ext)
        
        elif ext in ['.docx', '.doc']:
            # Convert DOCX/DOC to PDF first, then to images
            return self._convert_office_to_images(file_bytes, ext)
        
        else:
            logger.warning(f"Unsupported file type: {ext}")
            return []
    
    def _convert_pdf_to_images(self, pdf_bytes: bytes) -> List[Tuple[bytes, str]]:
        """
        Convert PDF to list of images (one per page)
        
        Returns:
            List of (image_bytes, "page_N") tuples
        """
        images = []
        
        try:
            # Open PDF from bytes
            doc = fitz.open(stream=pdf_bytes, filetype="pdf")
            
            # Convert each page to image
            for page_num in range(len(doc)):
                page = doc[page_num]
                
                # Render page to image
                mat = fitz.Matrix(self.zoom, self.zoom)
                pix = page.get_pixmap(matrix=mat, alpha=False)
                
                # Convert to PNG bytes
                img_bytes = pix.tobytes("png")
                
                images.append((img_bytes, f"page_{page_num + 1}"))
                
                logger.debug(f"Converted PDF page {page_num + 1} to image")
            
            doc.close()
            
            logger.info(f"Converted PDF to {len(images)} images")
            return images
            
        except Exception as e:
            logger.error(f"Error converting PDF to images: {e}")
            return []
    
    def _handle_image(self, image_bytes: bytes, ext: str) -> List[Tuple[bytes, str]]:
        """
        Handle image files (already in image format)
        
        For multi-page TIFFs, extract each page
        For single images, return as-is
        """
        images = []
        
        try:
            # For TIFF, check if multi-page
            if ext in ['.tiff', '.tif']:
                # PyMuPDF can handle multi-page TIFF
                doc = fitz.open(stream=image_bytes, filetype="tiff")
                
                for page_num in range(len(doc)):
                    page = doc[page_num]
                    pix = page.get_pixmap()
                    img_bytes = pix.tobytes("png")
                    images.append((img_bytes, f"page_{page_num + 1}"))
                
                doc.close()
                logger.info(f"Extracted {len(images)} pages from TIFF")
                
            else:
                # Single image - return as-is
                images.append((image_bytes, "image"))
                logger.debug(f"Loaded single image: {ext}")
            
            return images
            
        except Exception as e:
            logger.error(f"Error handling image: {e}")
            return []
    
    def _convert_office_to_images(self, doc_bytes: bytes, ext: str) -> List[Tuple[bytes, str]]:
        """
        Convert DOCX/DOC to images
        
        Strategy:
        1. DOCX → HTML (using mammoth)
        2. HTML → PDF (using weasyprint or simple rendering)
        3. PDF → Images (using PyMuPDF)
        
        Simpler alternative: Use python-docx to extract text and create simple PDF
        """
        try:
            # Import required libraries
            try:
                from docx import Document
                from reportlab.lib.pagesizes import letter
                from reportlab.pdfgen import canvas
                from reportlab.lib.utils import simpleSplit
                from io import BytesIO
            except ImportError:
                logger.error("Missing libraries for DOCX conversion")
                logger.error("Install: pip install python-docx reportlab")
                return []
            
            # Read DOCX
            docx_stream = BytesIO(doc_bytes)
            doc = Document(docx_stream)
            
            # Extract all text
            full_text = []
            for paragraph in doc.paragraphs:
                if paragraph.text.strip():
                    full_text.append(paragraph.text)
            
            # Also extract from tables
            for table in doc.tables:
                for row in table.rows:
                    row_text = ' | '.join([cell.text for cell in row.cells])
                    if row_text.strip():
                        full_text.append(row_text)
            
            combined_text = '\n'.join(full_text)
            
            if not combined_text.strip():
                logger.warning("DOCX appears to be empty")
                return []
            
            # Create PDF from text
            pdf_buffer = BytesIO()
            c = canvas.Canvas(pdf_buffer, pagesize=letter)
            width, height = letter
            
            # Settings
            margin = 50
            y_position = height - margin
            line_height = 14
            max_width = width - (2 * margin)
            
            # Write text to PDF
            for line in combined_text.split('\n'):
                if not line.strip():
                    y_position -= line_height / 2
                    continue
                
                # Word wrap
                wrapped_lines = simpleSplit(line, 'Helvetica', 10, max_width)
                
                for wrapped_line in wrapped_lines:
                    if y_position < margin:
                        # New page
                        c.showPage()
                        y_position = height - margin
                    
                    c.setFont('Helvetica', 10)
                    c.drawString(margin, y_position, wrapped_line)
                    y_position -= line_height
            
            c.save()
            
            # Get PDF bytes
            pdf_bytes = pdf_buffer.getvalue()
            pdf_buffer.close()
            
            # Convert PDF to images
            logger.info("Converted DOCX to PDF, now converting to images...")
            return self._convert_pdf_to_images(pdf_bytes)
            
        except Exception as e:
            logger.error(f"Error converting DOCX to images: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return []
    
    def images_to_base64(self, images: List[Tuple[bytes, str]]) -> List[Tuple[str, str]]:
        """
        Convert image bytes to base64 for API calls
        
        Args:
            images: List of (image_bytes, page_info) tuples
        
        Returns:
            List of (base64_string, page_info) tuples
        """
        base64_images = []
        
        for img_bytes, page_info in images:
            b64_string = base64.b64encode(img_bytes).decode('utf-8')
            base64_images.append((b64_string, page_info))
        
        return base64_images


def test_converter():
    """Test the converter with sample files"""
    converter = DocumentConverter(dpi=200)
    
    # Test with sample PDF
    print("Document Converter Test")
    print("-" * 40)
    print("OK PyMuPDF imported successfully")
    print("OK Converter initialized (200 DPI)")
    print("")
    print("Supported formats:")
    print("  OK PDF (multi-page)")
    print("  OK Images (PNG, JPG, TIFF, etc.)")
    print("  ⚠ DOCX/DOC (requires LibreOffice)")


if __name__ == "__main__":
    test_converter()
