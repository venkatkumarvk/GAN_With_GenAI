"""
Flexible Key Vault Manager
Supports BOTH Key Vault references AND direct values
"""

from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential
import logging


class KeyVaultManager:
    """
    Flexible Key Vault Manager
    - If vault_url provided → uses Key Vault
    - If vault_url is None/placeholder → uses direct values only
    """
    
    def __init__(self, vault_url):
        """
        Initialize Key Vault Manager
        
        Args:
            vault_url: Azure Key Vault URL or None
                - "https://your-vault.vault.azure.net/" → Key Vault enabled
                - "https://your-keyvault-name.vault.azure.net/" → Direct values (placeholder)
                - None → Direct values
        """
        self.logger = logging.getLogger(__name__)
        self.cache = {}
        self.enabled = False
        self.client = None
        self.vault_url = vault_url
        
        # Check if Key Vault should be enabled
        if vault_url and not vault_url.startswith("https://your-keyvault"):
            # Real vault URL provided
            try:
                self.credential = DefaultAzureCredential()
                self.client = SecretClient(
                    vault_url=vault_url,
                    credential=self.credential
                )
                self.enabled = True
                self.logger.info(f"OK Key Vault ENABLED: {vault_url}")
            except Exception as e:
                self.logger.warning(f"WARNING  Key Vault connection failed: {str(e)}")
                self.logger.warning(f"   Will use direct values from config")
                self.enabled = False
        else:
            # Placeholder URL or None - use direct values
            self.logger.info(f"ℹ️  Key Vault DISABLED - using direct values from config")
            self.enabled = False
    
    def resolve_value(self, value):
        """
        Resolve a configuration value
        
        Args:
            value: Either "@azureKeyVault(SecretName)" or direct value
        
        Returns:
            Resolved value
        """
        if not value or not isinstance(value, str):
            return value
        
        # Check if it's a Key Vault reference
        if value.startswith("@azureKeyVault(") and value.endswith(")"):
            secret_name = value[15:-1]  # Extract secret name
            
            if self.enabled:
                # Fetch from Key Vault
                return self.get_secret(secret_name)
            else:
                # Key Vault disabled - return error
                error_msg = (
                    f"Key Vault reference '{value}' found but Key Vault is disabled. "
                    f"Please either:\n"
                    f"  1. Enable Key Vault by setting a real vault_url, OR\n"
                    f"  2. Replace '{value}' with the actual direct value in config.json"
                )
                self.logger.error(f"FAILED {error_msg}")
                raise ValueError(error_msg)
        
        # Direct value - return as-is
        return value
    
    def get_secret(self, secret_name):
        """Get secret from Key Vault with caching"""
        if not self.enabled:
            raise RuntimeError("Key Vault is not enabled")
        
        # Check cache
        if secret_name in self.cache:
            self.logger.debug(f"   Using cached secret: {secret_name}")
            return self.cache[secret_name]
        
        # Fetch from Key Vault
        try:
            self.logger.info(f"   Fetching secret: {secret_name}")
            secret = self.client.get_secret(secret_name)
            self.cache[secret_name] = secret.value
            self.logger.info(f"   OK Secret fetched")
            return secret.value
        except Exception as e:
            self.logger.error(f"   FAILED Failed to get secret '{secret_name}': {str(e)}")
            raise


def resolve_config_values(config, kv_manager):
    """
    Recursively resolve all @azureKeyVault() references in config
    
    Args:
        config: Dict to resolve (modified in-place)
        kv_manager: KeyVaultManager instance
    
    Returns:
        Resolved config
    """
    if isinstance(config, dict):
        for key, value in list(config.items()):
            if isinstance(value, str):
                config[key] = kv_manager.resolve_value(value)
            elif isinstance(value, dict):
                resolve_config_values(value, kv_manager)
            elif isinstance(value, list):
                for i, item in enumerate(value):
                    if isinstance(item, str):
                        value[i] = kv_manager.resolve_value(item)
                    elif isinstance(item, dict):
                        resolve_config_values(item, kv_manager)
    return config
