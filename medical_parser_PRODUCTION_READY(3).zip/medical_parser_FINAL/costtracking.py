"""
Cost Tracking Module
===================
Tracks and calculates costs for Azure services
"""

import logging
from typing import Dict


class CostTracker:
    """Track costs for document processing"""
    
    def __init__(self, config: dict = None, 
                 ocr_per_page: float = 0.01, 
                 embedding_per_1k: float = 0.0001,
                 gpt4o_input_per_1k: float = 0.0025,
                 gpt4o_output_per_1k: float = 0.01):
        """
        Initialize cost tracker
        
        Args:
            config: Configuration dictionary (if provided, extracts costs from it)
            ocr_per_page: Cost per page for OCR
            embedding_per_1k: Cost per 1K tokens for embeddings
            gpt4o_input_per_1k: Cost per 1K input tokens for GPT-4o
            gpt4o_output_per_1k: Cost per 1K output tokens for GPT-4o
        """
        # If config dict provided, extract cost parameters
        if config and isinstance(config, dict):
            costs = config.get('costs', {})
            self.ocr_per_page = costs.get('ocr_per_page', ocr_per_page)
            self.embedding_per_1k = costs.get('embedding_per_1k_tokens', embedding_per_1k)
            self.gpt4o_input_per_1k = costs.get('gpt4o_input_per_1k_tokens', gpt4o_input_per_1k)
            self.gpt4o_output_per_1k = costs.get('gpt4o_output_per_1k_tokens', gpt4o_output_per_1k)
        else:
            # Use provided parameters
            self.ocr_per_page = ocr_per_page
            self.embedding_per_1k = embedding_per_1k
            self.gpt4o_input_per_1k = gpt4o_input_per_1k
            self.gpt4o_output_per_1k = gpt4o_output_per_1k
        
        self.ocr_pages = 0
        self.embedding_tokens = 0
        self.gpt4o_input_tokens = 0
        self.gpt4o_output_tokens = 0
        
        self.logger = logging.getLogger(__name__)
    
    def add_ocr_pages(self, pages: int):
        """Add OCR page count"""
        self.ocr_pages += pages
    
    def add_ocr(self, pages: int):
        """Add OCR page count (alias for add_ocr_pages)"""
        self.add_ocr_pages(pages)
    
    def add_embedding_tokens(self, tokens: int):
        """Add embedding token count"""
        self.embedding_tokens += tokens
    
    def add_embedding(self, tokens: int):
        """Add embedding token count (alias for add_embedding_tokens)"""
        self.add_embedding_tokens(tokens)
    
    def add_gpt4o_tokens(self, input_tokens: int, output_tokens: int):
        """Add GPT-4o token counts"""
        self.gpt4o_input_tokens += input_tokens
        self.gpt4o_output_tokens += output_tokens
    
    def add_gpt4o(self, input_tokens: int, output_tokens: int):
        """Add GPT-4o token counts (alias for add_gpt4o_tokens)"""
        self.add_gpt4o_tokens(input_tokens, output_tokens)
    
    def add_gpt_tokens(self, input_tokens: int, output_tokens: int):
        """Add GPT token counts (alias for add_gpt4o_tokens)"""
        self.add_gpt4o_tokens(input_tokens, output_tokens)
    
    def get_costs(self) -> Dict[str, float]:
        """Calculate and return all costs"""
        ocr_cost = self.ocr_pages * self.ocr_per_page
        embedding_cost = (self.embedding_tokens / 1000) * self.embedding_per_1k
        gpt4o_input_cost = (self.gpt4o_input_tokens / 1000) * self.gpt4o_input_per_1k
        gpt4o_output_cost = (self.gpt4o_output_tokens / 1000) * self.gpt4o_output_per_1k
        gpt4o_cost = gpt4o_input_cost + gpt4o_output_cost
        total_cost = ocr_cost + embedding_cost + gpt4o_cost
        
        return {
            "ocr_cost": round(ocr_cost, 4),
            "embedding_cost": round(embedding_cost, 4),
            "gpt4o_input_cost": round(gpt4o_input_cost, 4),
            "gpt4o_output_cost": round(gpt4o_output_cost, 4),
            "gpt4o_cost": round(gpt4o_cost, 4),
            "total_estimated": round(total_cost, 4)
        }
    
    def get_summary(self) -> Dict:
        """Get complete cost summary"""
        costs = self.get_costs()
        
        # Return format compatible with main.py expectations
        return {
            "total": costs["total_estimated"],
            "usage": {
                "ocr_pages": self.ocr_pages,
                "embedding_tokens": self.embedding_tokens,
                "gpt_input_tokens": self.gpt4o_input_tokens,
                "gpt_output_tokens": self.gpt4o_output_tokens,
                "gpt4o_input_tokens": self.gpt4o_input_tokens,  # For compatibility
                "gpt4o_output_tokens": self.gpt4o_output_tokens
            },
            "costs": {
                "ocr_cost": costs["ocr_cost"],
                "embedding_cost": costs["embedding_cost"],
                "gpt_input_cost": costs["gpt4o_input_cost"],
                "gpt_output_cost": costs["gpt4o_output_cost"],
                "gpt4o_cost": costs["gpt4o_cost"],
                "total_cost": costs["total_estimated"]
            },
            "breakdown": {
                "ocr": costs["ocr_cost"],
                "embedding": costs["embedding_cost"],
                "gpt4o": costs["gpt4o_cost"]
            }
        }
    
    def log_summary(self):
        """Log cost summary"""
        summary = self.get_summary()
        self.logger.info("=" * 60)
        self.logger.info("COST SUMMARY")
        self.logger.info("=" * 60)
        self.logger.info(f"OCR Pages: {summary['usage']['ocr_pages']}")
        self.logger.info(f"Embedding Tokens: {summary['usage']['embedding_tokens']:,}")
        self.logger.info(f"GPT-4o Input Tokens: {summary['usage']['gpt4o_input_tokens']:,}")
        self.logger.info(f"GPT-4o Output Tokens: {summary['usage']['gpt4o_output_tokens']:,}")
        self.logger.info("-" * 60)
        self.logger.info(f"OCR Cost: ${summary['costs']['ocr_cost']:.4f}")
        self.logger.info(f"Embedding Cost: ${summary['costs']['embedding_cost']:.4f}")
        self.logger.info(f"GPT-4o Cost: ${summary['costs']['gpt4o_cost']:.4f}")
        self.logger.info(f"TOTAL COST: ${summary['costs']['total_cost']:.4f}")
        self.logger.info("=" * 60)
    
    def reset(self):
        """Reset all counters"""
        self.ocr_pages = 0
        self.embedding_tokens = 0
        self.gpt4o_input_tokens = 0
        self.gpt4o_output_tokens = 0
