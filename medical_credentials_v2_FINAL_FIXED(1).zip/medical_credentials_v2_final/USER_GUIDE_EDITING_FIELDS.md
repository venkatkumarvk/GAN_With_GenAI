# User Guide: How to Edit Fields

## 🎯 To Change Fields, Edit Only 2 Files:

1. **config.json** - Define which fields to extract per folder
2. **prompt_config.py** - Define field descriptions (optional)

**That's it! No code changes needed!**

---

## 📝 STEP 1: Edit config.json

### **Add/Remove Fields in folder_configs:**

```json
{
  "folder_configs": {
    "GEN & HR": {
      "description": "General and HR information",
      "fields": [
        "first_name",
        "last_name",
        "email",
        "cell",
        "birth_date",
        "birth_place",
        "birth_city",
        "birth_state_province",
        "birth_country",
        "citizenship",
        "gender",
        "ssn"
      ],
      "min_confidence": 0.70
    },
    
    "ED & TRAIN": {
      "description": "Education and Training",
      "fields": [
        "degree",
        "state_license_number",
        "state_license_state",
        "state_license_expiration",
        "dea_license_number",
        "dea_license_state",
        "dea_license_expiration",
        "cds_license_number",
        "cds_license_state",
        "cds_license_expiration",
        "other_credential_type",
        "other_credential_state",
        "other_credential_expiration",
        "board_cert_name",
        "board_cert_specialty"
      ],
      "min_confidence": 0.70
    }
  }
}
```

### **To Add a New Field:**

1. Add field name to the "fields" list
2. That's it!

```json
"fields": [
  "first_name",
  "last_name",
  "new_field_name"  ← Add here
]
```

### **To Remove a Field:**

1. Delete the field name from the list

```json
"fields": [
  "first_name",
  "last_name"
  // "old_field" ← Removed
]
```

### **To Add a New Folder:**

```json
"folder_configs": {
  "Existing_Folder": { ... },
  
  "New_Folder_Name": {
    "description": "What this folder contains",
    "fields": [
      "field1",
      "field2",
      "field3"
    ],
    "min_confidence": 0.70
  }
}
```

---

## 📝 STEP 2: Edit prompt_config.py (Optional)

**Only edit this if you want custom field descriptions**

### **Add Field Definition:**

```python
FIELD_LIBRARY = {
    # Existing fields...
    
    # Add your custom field
    "custom_field_name": {
        "description": "What this field represents",
        "format": "Expected format (e.g., Text, Date, Number)",
        "examples": ["Example 1", "Example 2"],
        "extraction_hints": "Where to look for this field"
    }
}
```

### **Example - Adding a New Field:**

```python
"npi_number": {
    "description": "National Provider Identifier",
    "format": "10-digit number",
    "examples": ["1234567890", "9876543210"],
    "extraction_hints": "Unique 10-digit identifier, may be labeled as 'NPI'"
}
```

---

## 🎯 COMPLETE EXAMPLE

### **Scenario: Extract Different Fields for Different Folders**

Your folder structure:
```
Provider1/
├── Demographics/     ← Extract personal info
├── Licenses/         ← Extract license numbers
└── Certifications/   ← Extract certifications
```

### **config.json:**

```json
{
  "folder_configs": {
    "Demographics": {
      "description": "Personal information",
      "fields": [
        "first_name",
        "last_name",
        "email",
        "phone",
        "birth_date",
        "ssn"
      ],
      "min_confidence": 0.85
    },
    
    "Licenses": {
      "description": "Medical licenses",
      "fields": [
        "state_license_number",
        "state_license_state",
        "state_license_expiration",
        "dea_license_number",
        "dea_license_expiration"
      ],
      "min_confidence": 0.70
    },
    
    "Certifications": {
      "description": "Board certifications",
      "fields": [
        "board_cert_name",
        "board_cert_specialty",
        "board_cert_date",
        "board_cert_expiration"
      ],
      "min_confidence": 0.75
    }
  },
  
  "default_config": {
    "description": "Default for unknown folders",
    "fields": [
      "document_type",
      "document_date"
    ],
    "min_confidence": 0.50
  },
  
  // ... rest of config
}
```

**That's it! System will automatically:**
- Extract 6 fields from Demographics/
- Extract 5 fields from Licenses/
- Extract 4 fields from Certifications/
- Extract 2 fields from unknown folders

---

## 🔍 HANDLING NESTED SUBFOLDERS

### **Question: What if folder has many subfolders?**

```
Provider1/
└── Licenses/
    ├── State_Licenses/
    │   ├── California/
    │   │   └── doc.pdf
    │   └── New_York/
    │       └── doc.pdf
    └── DEA_Licenses/
        └── doc.pdf
```

### **Answer: System handles automatically!**

**config.json:**
```json
"folder_configs": {
  "Licenses": {
    "fields": [
      "state_license_number",
      "dea_license_number"
    ]
  }
}
```

**Result:** ALL documents under `Licenses/` (including all subfolders at any depth) will extract these 2 fields!

**You don't need separate configs for:**
- `State_Licenses`
- `California`
- `New_York`
- `DEA_Licenses`

**Just one config for the main folder: `Licenses`** ✅

---

## ⚠️ COMMON MISTAKES

### **Mistake 1: Forgetting 'fields' key**
```json
// ❌ WRONG
"Demographics": {
  "description": "Personal info"
  // Missing "fields": [...]
}

// ✅ CORRECT
"Demographics": {
  "description": "Personal info",
  "fields": ["first_name", "last_name"]
}
```

### **Mistake 2: Empty fields list**
```json
// ❌ BAD
"fields": []

// ✅ GOOD
"fields": ["at_least_one_field"]
```

### **Mistake 3: Missing comma**
```json
// ❌ WRONG
"fields": [
  "field1"
  "field2"  ← Missing comma above
]

// ✅ CORRECT
"fields": [
  "field1",
  "field2"
]
```

---

## ✅ VALIDATION

After editing, always validate:

```bash
python config_validator.py
```

**Valid:**
```
✅ CONFIGURATION IS VALID!
```

**Invalid:**
```
❌ 'Demographics' missing 'fields' key
Fix it, then run validator again!
```

---

## 🎯 QUICK REFERENCE

| Task | File to Edit | What to Change |
|------|--------------|----------------|
| Add/remove fields | config.json | Edit "fields" list |
| Add new folder | config.json | Add new entry in "folder_configs" |
| Change field descriptions | prompt_config.py | Edit FIELD_LIBRARY |
| Add extraction hints | prompt_config.py | Edit FIELD_LIBRARY |

---

## 💡 BEST PRACTICES

1. **Start Small:**
   - Begin with 2-3 essential fields
   - Test with a few documents
   - Add more fields gradually

2. **Use Clear Field Names:**
   - `state_license_number` ✅
   - `sln` ❌ (unclear)

3. **Validate After Every Change:**
   ```bash
   python config_validator.py
   ```

4. **Keep default_config:**
   - Always include it
   - Use generic fields like "document_type"

5. **Match Folder Names:**
   - Config: `"Licenses"`
   - Folder: `Provider1/Licenses/`
   - Must match! (case-sensitive)

---

## 🚀 WORKFLOW

```
1. Edit config.json (add/remove fields)
   ↓
2. python config_validator.py (validate)
   ↓
3. Fix any errors
   ↓
4. python config_validator.py (validate again)
   ↓
5. python main.py (run extraction)
   ↓
6. Check results
   ↓
7. Adjust fields if needed (go back to step 1)
```

---

## ✅ SUMMARY

**To change extraction fields:**
1. Edit `config.json` → "fields" list
2. Run `python config_validator.py`
3. Fix errors if any
4. Run `python main.py`

**Optional:**
- Edit `prompt_config.py` → FIELD_LIBRARY (for custom descriptions)

**No code changes needed!** ✅
