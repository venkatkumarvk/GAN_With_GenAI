# Configuration Troubleshooting Guide

## 🔧 Common Config Issues & Solutions

### **Issue 1: KeyError 'processing' or 'skip_unknown_folders'**

**Error:**
```python
KeyError: 'processing'
# OR
KeyError: 'skip_unknown_folders'
```

**Cause:** Missing `processing` section in config.json

**Solution:**
```json
{
  "processing": {
    "max_doc_length_chars": 12000,
    "max_prompt_tokens": 7000,
    "batch_size": 10,
    "enable_chunking": true,
    "enable_logging": true,
    "save_per_provider": true,
    "checkpoint_interval": 50,
    "skip_unknown_folders": true,     ← IMPORTANT!
    "multimodal_threshold": 50
  }
}
```

---

### **Issue 2: KeyError 'fields'**

**Error:**
```python
KeyError: 'fields'
```

**Cause:** Folder config missing 'fields' key

**Solution:** ALL folder configs MUST have 'fields':
```json
{
  "folder_configs": {
    "Licenses": {
      "description": "Medical licenses",
      "fields": [                        ← REQUIRED!
        "state_license_number",
        "dea_license_number"
      ],
      "min_confidence": 0.70
    }
  },
  
  "default_config": {
    "description": "Default",
    "fields": [                          ← REQUIRED!
      "first_name",
      "last_name"
    ],
    "min_confidence": 0.50
  }
}
```

---

### **Issue 3: KeyError 'folder_configs'**

**Error:**
```python
KeyError: 'folder_configs'
```

**Cause:** Missing `folder_configs` section

**Solution:**
```json
{
  "folder_configs": {
    "Licenses": {
      "fields": [...],
      "min_confidence": 0.70
    }
  }
}
```

---

### **Issue 4: KeyError 'default_config'**

**Error:**
```python
KeyError: 'default_config'
```

**Cause:** Missing `default_config` section

**Solution:**
```json
{
  "default_config": {
    "description": "Default configuration",
    "fields": [
      "first_name",
      "last_name",
      "document_type"
    ],
    "min_confidence": 0.50
  }
}
```

---

## ✅ Config Validation Tool

### **Test Your Config:**

```bash
# Run validator
python config_validator.py
```

**Valid Config Output:**
```
============================================================
CONFIG VALIDATOR TEST
============================================================

✅ Configuration is VALID!

Found 6 folder configurations:
  • Licenses: 9 fields
  • Personal: 8 fields
  • Education: 5 fields

Default config: 4 fields
Skip unknown folders: True
============================================================
```

**Invalid Config Output:**
```
============================================================
CONFIG VALIDATION ERRORS
============================================================
❌ Missing section: 'processing'
❌ 'Licenses' missing 'fields' key
❌ 'default_config' missing 'fields' key
============================================================
Total errors: 3
============================================================

❌ Configuration validation FAILED!
Please fix the errors above in config.json
```

---

## 📋 Required Config Structure

### **Minimal Valid Config:**

```json
{
  "azure_blob": {
    "connection_string": "YOUR_CONNECTION_STRING",
    "inputcontainer": "inputcontainer",
    "outputcontainer": "outputcontainer"
  },
  
  "azure_document_intelligence": {
    "endpoint": "YOUR_ENDPOINT",
    "key": "YOUR_KEY"
  },
  
  "azure_openai_gpt": {
    "endpoint": "YOUR_ENDPOINT",
    "api_key": "YOUR_KEY",
    "api_version": "2024-02-01",
    "deployment_name": "gpt-4o"
  },
  
  "azure_openai_embedding": {
    "endpoint": "YOUR_ENDPOINT",
    "api_key": "YOUR_KEY",
    "api_version": "2024-02-01",
    "deployment_name": "text-embedding-3-large",
    "dimension": 3072
  },
  
  "azure_search": {
    "endpoint": "YOUR_ENDPOINT",
    "api_key": "YOUR_KEY",
    "universal_index_name": "documents_universal"
  },
  
  "folder_configs": {
    "Licenses": {
      "fields": ["license_number"],
      "min_confidence": 0.70
    }
  },
  
  "default_config": {
    "fields": ["document_type"],
    "min_confidence": 0.50
  },
  
  "extraction": {
    "na_value": "NA"
  },
  
  "rag": {
    "mode": "auto",
    "top_k": 3
  },
  
  "costs": {},
  
  "processing": {
    "skip_unknown_folders": true
  }
}
```

---

## 🎯 Validation Checklist

Before running main.py:

- [ ] Run `python config_validator.py`
- [ ] All sections present (11 sections)
- [ ] All folder_configs have 'fields' key
- [ ] default_config has 'fields' key
- [ ] processing section has 'skip_unknown_folders'
- [ ] Azure credentials filled in (not placeholders)
- [ ] No JSON syntax errors

---

## 🔍 Debug Mode

### **Enable Detailed Logging:**

```python
# In main.py or add to config:
import logging
logging.basicConfig(level=logging.DEBUG)
```

This will show:
- Which config keys are being accessed
- What values are being used
- Where errors occur

---

## 💡 Best Practices

### **1. Use Config Validator First**
```bash
python config_validator.py
# Only proceed if ✅ Configuration is VALID!
```

### **2. Start with Minimal Config**
- Copy the minimal valid config above
- Add your Azure credentials
- Test with `python config_validator.py`
- Then add more folder_configs

### **3. Keep 'fields' Lists Non-Empty**
```json
// ❌ BAD
"fields": []

// ✅ GOOD
"fields": ["document_type"]
```

### **4. Always Include default_config**
Even if you skip unknown folders, include default_config:
```json
"default_config": {
  "fields": ["document_type", "document_date"],
  "min_confidence": 0.50
}
```

---

## ⚠️ Common Mistakes

### **Mistake 1: Missing Comma**
```json
{
  "field1": "value1"
  "field2": "value2"  ← Missing comma above!
}
```

### **Mistake 2: Trailing Comma**
```json
{
  "field1": "value1",
  "field2": "value2",  ← Trailing comma!
}
```

### **Mistake 3: Missing 'fields' Key**
```json
"Licenses": {
  "description": "Licenses",
  "min_confidence": 0.70
  // ❌ Missing "fields": [...]
}
```

### **Mistake 4: Wrong Data Type**
```json
"fields": "license_number"  ← ❌ Should be a list!
// Correct:
"fields": ["license_number"]  ← ✅ List
```

---

## 🚨 Emergency Fix

If your config is broken and main.py won't start:

```bash
# 1. Backup your config
cp config.json config.json.backup

# 2. Use the template
cp config.json.template config.json
# (Or use minimal valid config above)

# 3. Test
python config_validator.py

# 4. Add your credentials

# 5. Test again
python config_validator.py

# 6. Run
python main.py
```

---

## ✅ Summary

**Most common config errors:**
1. Missing 'fields' key (80% of issues)
2. Missing 'processing' section (10%)
3. Missing 'default_config' section (5%)
4. JSON syntax errors (5%)

**Solution:**
- Always run `python config_validator.py` first!
- It will tell you exactly what's wrong!
- Fix all errors before running main.py!

---

**Remember: The validator is your friend! Use it!** ✅
