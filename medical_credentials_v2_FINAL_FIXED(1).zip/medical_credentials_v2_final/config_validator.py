"""
Configuration Validator - FIXED VERSION
========================================
Validates config.json structure correctly
Handles folder names with special characters like "GEN & HR"
"""

import json
import sys
from typing import Dict, List, Tuple


class ConfigValidator:
    """Validate configuration file structure"""
    
    # These sections MUST exist
    REQUIRED_SECTIONS = [
        'azure_blob',
        'azure_document_intelligence', 
        'azure_openai_gpt',
        'azure_openai_embedding',
        'azure_search',
        'folder_configs',
        'default_config',
        'extraction',
        'rag',
        'costs',
        'processing'
    ]
    
    # Required keys per section
    REQUIRED_KEYS = {
        'azure_blob': ['connection_string', 'inputcontainer', 'outputcontainer'],
        'azure_document_intelligence': ['endpoint', 'key'],
        'azure_openai_gpt': ['endpoint', 'api_key', 'deployment_name'],
        'azure_openai_embedding': ['endpoint', 'api_key', 'deployment_name'],
        'azure_search': ['endpoint', 'api_key'],
        'default_config': ['fields'],  # Must have fields!
        'extraction': ['na_value'],
        'rag': ['mode', 'top_k'],
    }
    
    @staticmethod
    def validate(config: Dict) -> Tuple[bool, List[str]]:
        """
        Validate configuration
        
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []
        
        # Check required top-level sections
        for section in ConfigValidator.REQUIRED_SECTIONS:
            if section not in config:
                errors.append(f"❌ Missing section: '{section}'")
        
        # Check required keys in each section
        for section, required_keys in ConfigValidator.REQUIRED_KEYS.items():
            if section in config:
                for key in required_keys:
                    if key not in config[section]:
                        errors.append(f"❌ '{section}' missing required key: '{key}'")
        
        # Validate folder_configs (any name is OK, just need 'fields')
        if 'folder_configs' in config:
            if not config['folder_configs']:
                errors.append("⚠️  'folder_configs' is empty")
            else:
                for folder_name, folder_config in config['folder_configs'].items():
                    if not isinstance(folder_config, dict):
                        errors.append(f"❌ '{folder_name}' must be a dictionary")
                        continue
                        
                    if 'fields' not in folder_config:
                        errors.append(f"❌ '{folder_name}' missing 'fields' key")
                    elif not isinstance(folder_config['fields'], list):
                        errors.append(f"❌ '{folder_name}.fields' must be a list")
                    elif len(folder_config['fields']) == 0:
                        errors.append(f"⚠️  '{folder_name}.fields' is empty (no fields to extract)")
        
        # Validate default_config has fields
        if 'default_config' in config:
            if 'fields' not in config['default_config']:
                errors.append("❌ 'default_config' missing 'fields' key")
            elif not isinstance(config['default_config']['fields'], list):
                errors.append("❌ 'default_config.fields' must be a list")
            elif len(config['default_config']['fields']) == 0:
                errors.append("⚠️  'default_config.fields' is empty")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def validate_file(config_path: str = "config.json") -> Tuple[bool, Dict, List[str]]:
        """
        Load and validate configuration file
        
        Returns:
            Tuple of (is_valid, config_dict, list_of_errors)
        """
        errors = []
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
        except FileNotFoundError:
            return False, {}, [f"❌ Config file not found: {config_path}"]
        except json.JSONDecodeError as e:
            return False, {}, [f"❌ Invalid JSON: {e}"]
        except Exception as e:
            return False, {}, [f"❌ Error loading config: {e}"]
        
        # Validate structure
        is_valid, validation_errors = ConfigValidator.validate(config)
        errors.extend(validation_errors)
        
        return is_valid, config, errors
    
    @staticmethod
    def print_errors(errors: List[str]):
        """Print validation errors with clear formatting"""
        print("="*70)
        print("❌ CONFIG VALIDATION ERRORS")
        print("="*70)
        for error in errors:
            print(f"  {error}")
        print("="*70)
        print(f"Total errors: {len(errors)}")
        print("="*70)
    
    @staticmethod
    def print_success(config: Dict):
        """Print success message with config summary"""
        print("="*70)
        print("✅ CONFIGURATION IS VALID!")
        print("="*70)
        
        # Show folder configs
        if 'folder_configs' in config:
            print(f"\nFolder Configurations: {len(config['folder_configs'])}")
            for folder_name, folder_config in config['folder_configs'].items():
                num_fields = len(folder_config.get('fields', []))
                print(f"  • {folder_name}: {num_fields} fields")
        
        # Show default config
        if 'default_config' in config:
            num_fields = len(config['default_config'].get('fields', []))
            print(f"\nDefault Config: {num_fields} fields")
        
        # Show processing settings
        if 'processing' in config:
            skip = config['processing'].get('skip_unknown_folders', False)
            threshold = config['processing'].get('multimodal_threshold', 50)
            print(f"\nProcessing Settings:")
            print(f"  • Skip unknown folders: {skip}")
            print(f"  • Multimodal threshold: {threshold} chars")
        
        print("="*70)


def validate_config_file(config_path: str = "config.json") -> Dict:
    """
    Validate and load config file
    Exits if validation fails
    
    Returns:
        Validated config dictionary
    """
    is_valid, config, errors = ConfigValidator.validate_file(config_path)
    
    if not is_valid:
        ConfigValidator.print_errors(errors)
        print("\n💡 FIX: Check CONFIG_TROUBLESHOOTING.md for solutions")
        sys.exit(1)
    
    return config


# Test if run directly
if __name__ == "__main__":
    print("="*70)
    print("CONFIG VALIDATOR")
    print("="*70)
    
    is_valid, config, errors = ConfigValidator.validate_file("config.json")
    
    if is_valid:
        ConfigValidator.print_success(config)
    else:
        ConfigValidator.print_errors(errors)
        print("\n💡 See CONFIG_TROUBLESHOOTING.md for help fixing these errors")
        print("="*70)
        sys.exit(1)
