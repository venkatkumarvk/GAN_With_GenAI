"""
Prompt Configuration - PROMPTS ONLY
====================================
Contains all prompt templates
Users can edit these prompts to customize extraction behavior

NO HELPER CODE - Just prompts!
"""

# Standard extraction prompt template
STANDARD_PROMPT_TEMPLATE = {
    "header": "Extract the configured fields from this medical credentialing document.",
    "reminder": "Return ONLY the JSON object with all configured fields. Use 'NA' for missing values."
}

# Field definitions template
FIELD_DEFINITION_TEMPLATE = """
Field: {field_name}
Description: {description}
Format: {format}
Examples: {examples}
"""

# Extraction instructions
EXTRACTION_INSTRUCTIONS = """
INSTRUCTIONS:
1. Extract ONLY the fields listed above
2. Return a JSON object with field names as keys
3. For each field, include:
   - "value": the extracted value
   - "confidence": confidence score (0.0 to 1.0)
4. Use "NA" for fields not found in the document
5. Ensure all field names match exactly as listed
6. Do not add any fields not listed above
7. Do not include any explanation or commentary
"""

# RAG context template
RAG_CONTEXT_TEMPLATE = """
## SIMILAR DOCUMENTS (for reference):

{rag_examples}

## CURRENT DOCUMENT:
{current_document}
"""

# Multimodal instruction
MULTIMODAL_INSTRUCTION = """
This document is provided as an image. 
Carefully examine all visible text, fields, and values.
"""

# Text-only instruction
TEXT_INSTRUCTION = """
This document is provided as extracted text.
Carefully read and extract the required fields.
"""

# Confidence scoring guidance
CONFIDENCE_GUIDANCE = """
CONFIDENCE SCORING:
- 1.0: Value clearly visible and unambiguous
- 0.8-0.9: Value visible but partially unclear
- 0.6-0.7: Value inferred from context
- 0.4-0.5: Value uncertain or partially missing
- 0.0-0.3: Value not found or highly uncertain

Assign "NA" with confidence 0.0 if field is not present.
"""

# Output format template
OUTPUT_FORMAT_TEMPLATE = """
OUTPUT FORMAT (JSON):
{
  "field_name_1": {
    "value": "extracted_value",
    "confidence": 0.95
  },
  "field_name_2": {
    "value": "NA",
    "confidence": 0.0
  }
}
"""

# Field library - User can add/modify fields here
FIELD_LIBRARY = {
    # Personal Information
    "first_name": {
        "description": "Person's first name",
        "format": "Text",
        "examples": ["John", "Mary", "Robert"],
        "extraction_hints": "Usually found at top of document or in name section"
    },
    "last_name": {
        "description": "Person's last name/surname",
        "format": "Text", 
        "examples": ["Smith", "Johnson", "Williams"],
        "extraction_hints": "Usually found at top of document or in name section"
    },
    "email": {
        "description": "Email address",
        "format": "email@domain.com",
        "examples": ["john.smith@email.com", "doctor@hospital.org"],
        "extraction_hints": "Look for @ symbol"
    },
    "cell": {
        "description": "Cell phone number",
        "format": "Phone number",
        "examples": ["555-123-4567", "(555) 123-4567", "5551234567"],
        "extraction_hints": "May be labeled as 'mobile', 'cell', or 'phone'"
    },
    "birth_date": {
        "description": "Date of birth",
        "format": "MM/DD/YYYY or similar",
        "examples": ["01/15/1980", "1980-01-15"],
        "extraction_hints": "May be labeled as 'DOB' or 'birth date'"
    },
    "ssn": {
        "description": "Social Security Number",
        "format": "XXX-XX-XXXX",
        "examples": ["123-45-6789"],
        "extraction_hints": "9 digits, may have dashes"
    },
    "gender": {
        "description": "Gender",
        "format": "M/F or Male/Female",
        "examples": ["M", "F", "Male", "Female"],
        "extraction_hints": "Single letter or full word"
    },
    
    # License Information
    "state_license_number": {
        "description": "State medical license number",
        "format": "Alphanumeric",
        "examples": ["A12345", "MD123456", "12345"],
        "extraction_hints": "May be labeled as 'State License', 'Medical License'"
    },
    "state_license_state": {
        "description": "State that issued the license",
        "format": "2-letter state code or full name",
        "examples": ["CA", "NY", "California", "New York"],
        "extraction_hints": "Look near state license number"
    },
    "state_license_expiration": {
        "description": "State license expiration date",
        "format": "MM/DD/YYYY",
        "examples": ["12/31/2025", "2025-12-31"],
        "extraction_hints": "May be labeled as 'Exp', 'Expires', 'Expiration Date'"
    },
    "dea_license_number": {
        "description": "DEA (Drug Enforcement Administration) license number",
        "format": "2 letters + 7 digits",
        "examples": ["FB1234567", "AD9876543"],
        "extraction_hints": "Always starts with 2 letters, followed by 7 digits"
    },
    "dea_license_state": {
        "description": "State for DEA license",
        "format": "2-letter state code",
        "examples": ["CA", "TX", "NY"],
        "extraction_hints": "Look near DEA number"
    },
    "dea_license_expiration": {
        "description": "DEA license expiration date",
        "format": "MM/DD/YYYY",
        "examples": ["06/30/2026"],
        "extraction_hints": "DEA licenses typically valid for 3 years"
    },
    
    # Education
    "degree": {
        "description": "Medical degree obtained",
        "format": "Text",
        "examples": ["MD", "DO", "MBBS", "Doctor of Medicine"],
        "extraction_hints": "Common abbreviations: MD, DO, MBBS"
    },
    "medical_school": {
        "description": "Name of medical school attended",
        "format": "Text",
        "examples": ["Harvard Medical School", "Johns Hopkins University"],
        "extraction_hints": "Usually includes 'University', 'School of Medicine', or 'Medical College'"
    },
    "graduation_date": {
        "description": "Medical school graduation date",
        "format": "MM/YYYY or YYYY",
        "examples": ["05/2015", "2015"],
        "extraction_hints": "Year is usually sufficient"
    },
    
    # Additional fields can be added here by users
    # Just copy the format above and add your fields
}

# Users can customize these prompts as needed
# The prompt_builder.py will use these templates
