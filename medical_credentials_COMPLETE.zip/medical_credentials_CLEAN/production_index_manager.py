"""
PRODUCTION INDEX MANAGER - Universal Index with Auto-Cleanup
============================================================

Features:
- Universal index (all providers in one index)
- Auto-delete old data (configurable days)
- Production-grade chunking
- Context length management
- Provider filtering
"""

import json
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SimpleField,
    SearchableField,
    SearchField,
    SearchFieldDataType,
    VectorSearch,
    VectorSearchProfile,
    HnswAlgorithmConfiguration,
)
from azure.core.credentials import AzureKeyCredential


class ProductionIndexManager:
    """
    Production-grade index manager with:
    - Universal index
    - Auto-cleanup
    - Provider filtering
    - Chunking support
    """
    
    def __init__(
        self,
        search_endpoint: str,
        search_api_key: str,
        index_name: str = "documents_universal",
        auto_delete_days: int = 30,
        enable_auto_cleanup: bool = True
    ):
        """
        Initialize index manager
        
        Args:
            search_endpoint: Azure AI Search endpoint
            search_api_key: API key
            index_name: Universal index name
            auto_delete_days: Delete data older than this many days
            enable_auto_cleanup: Enable automatic cleanup
        """
        self.search_endpoint = search_endpoint
        self.search_api_key = search_api_key
        self.index_name = index_name
        self.auto_delete_days = auto_delete_days
        self.enable_auto_cleanup = enable_auto_cleanup
        
        # Initialize clients
        credential = AzureKeyCredential(search_api_key)
        self.index_client = SearchIndexClient(
            endpoint=search_endpoint,
            credential=credential
        )
        self.search_client = SearchClient(
            endpoint=search_endpoint,
            index_name=index_name,
            credential=credential
        )
    
    def create_universal_index(self, embedding_dimension: int = 3072) -> None:
        """
        Create universal index with all necessary fields
        
        Features:
        - Vector search for RAG
        - Provider filtering
        - Timestamp for auto-cleanup
        - Chunk support
        """
        
        # Define fields
        fields = [
            SimpleField(
                name="id",
                type=SearchFieldDataType.String,
                key=True,
                filterable=True
            ),
            SearchableField(
                name="content",
                type=SearchFieldDataType.String,
                searchable=True
            ),
            SearchField(
                name="content_vector",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                searchable=True,
                vector_search_dimensions=embedding_dimension,
                vector_search_profile_name="vector-profile"
            ),
            SimpleField(
                name="provider",
                type=SearchFieldDataType.String,
                filterable=True,
                facetable=True
            ),
            SimpleField(
                name="provider_id",
                type=SearchFieldDataType.String,
                filterable=True
            ),
            SimpleField(
                name="document_name",
                type=SearchFieldDataType.String,
                filterable=True
            ),
            SimpleField(
                name="timestamp",
                type=SearchFieldDataType.DateTimeOffset,
                filterable=True,
                sortable=True
            ),
            SimpleField(
                name="chunk_index",
                type=SearchFieldDataType.Int32,
                filterable=True
            ),
            SimpleField(
                name="total_chunks",
                type=SearchFieldDataType.Int32,
                filterable=True
            ),
            SearchableField(
                name="extracted_fields",
                type=SearchFieldDataType.String,
                searchable=False
            ),
            SimpleField(
                name="page_count",
                type=SearchFieldDataType.Int32,
                filterable=True
            )
        ]
        
        # Configure vector search
        vector_search = VectorSearch(
            profiles=[
                VectorSearchProfile(
                    name="vector-profile",
                    algorithm_configuration_name="hnsw-config"
                )
            ],
            algorithms=[
                HnswAlgorithmConfiguration(name="hnsw-config")
            ]
        )
        
        # Create index
        index = SearchIndex(
            name=self.index_name,
            fields=fields,
            vector_search=vector_search
        )
        
        try:
            self.index_client.create_index(index)
            print(f"✅ Created universal index: {self.index_name}")
        except Exception as e:
            if "already exists" in str(e).lower():
                print(f"✅ Universal index already exists: {self.index_name}")
            else:
                raise
    
    def upload_document(
        self,
        doc_id: str,
        content: str,
        content_vector: List[float],
        provider: str,
        provider_id: str,
        document_name: str,
        chunk_index: int = 0,
        total_chunks: int = 1,
        extracted_fields: Dict = None,
        page_count: int = 1
    ) -> None:
        """
        Upload document to universal index
        
        Args:
            doc_id: Unique document ID
            content: Document text content
            content_vector: Embedding vector
            provider: Provider name
            provider_id: Provider run ID
            document_name: Document filename
            chunk_index: Chunk number (0 for non-chunked)
            total_chunks: Total chunks in document
            extracted_fields: Extracted field data
            page_count: Number of pages
        """
        
        document = {
            "id": doc_id,
            "content": content,
            "content_vector": content_vector,
            "provider": provider,
            "provider_id": provider_id,
            "document_name": document_name,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "chunk_index": chunk_index,
            "total_chunks": total_chunks,
            "extracted_fields": json.dumps(extracted_fields) if extracted_fields else "{}",
            "page_count": page_count
        }
        
        try:
            self.search_client.upload_documents(documents=[document])
        except Exception as e:
            print(f"❌ Error uploading document {doc_id}: {e}")
            raise
    
    def vector_search_with_provider_filter(
        self,
        query_vector: List[float],
        provider: str,
        top_k: int = 5
    ) -> List[Dict]:
        """
        Search with provider filter to prevent cross-provider contamination
        
        Args:
            query_vector: Query embedding vector
            provider: Filter to this provider only
            top_k: Number of results
        
        Returns:
            List of similar documents from same provider
        """
        
        try:
            results = self.search_client.search(
                search_text=None,
                vector_queries=[{
                    "kind": "vector",
                    "vector": query_vector,
                    "fields": "content_vector",
                    "k": top_k
                }],
                filter=f"provider eq '{provider}'",  # CRITICAL: Provider filter
                select=["id", "content", "document_name", "extracted_fields", "chunk_index"],
                top=top_k
            )
            
            return [dict(result) for result in results]
            
        except Exception as e:
            print(f"❌ Vector search error: {e}")
            return []
    
    def cleanup_old_data(self, days: int = None) -> int:
        """
        Delete documents older than specified days
        
        Args:
            days: Delete older than this (uses self.auto_delete_days if None)
        
        Returns:
            Number of documents deleted
        """
        
        if not self.enable_auto_cleanup:
            print("⚠️ Auto-cleanup is disabled")
            return 0
        
        days = days or self.auto_delete_days
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        cutoff_str = cutoff_date.isoformat() + "Z"
        
        print(f"\n🗑️ Cleaning up data older than {days} days (before {cutoff_date.date()})")
        
        try:
            # Search for old documents
            results = self.search_client.search(
                search_text="*",
                filter=f"timestamp lt {cutoff_str}",
                select=["id", "provider", "document_name", "timestamp"],
                top=1000  # Batch delete
            )
            
            old_docs = list(results)
            
            if not old_docs:
                print("✅ No old documents to delete")
                return 0
            
            # Delete in batches
            doc_ids = [{"id": doc["id"]} for doc in old_docs]
            self.search_client.delete_documents(documents=doc_ids)
            
            print(f"✅ Deleted {len(doc_ids)} documents older than {days} days")
            
            # Show summary
            providers = {}
            for doc in old_docs:
                prov = doc.get("provider", "unknown")
                providers[prov] = providers.get(prov, 0) + 1
            
            for prov, count in providers.items():
                print(f"   {prov}: {count} documents")
            
            return len(doc_ids)
            
        except Exception as e:
            print(f"❌ Cleanup error: {e}")
            return 0
    
    def get_index_stats(self) -> Dict[str, Any]:
        """Get statistics about the universal index"""
        
        try:
            # Count total documents
            total_results = self.search_client.search(
                search_text="*",
                include_total_count=True,
                top=0
            )
            total_count = total_results.get_count()
            
            # Count by provider
            provider_results = self.search_client.search(
                search_text="*",
                facets=["provider"],
                top=0
            )
            
            providers = {}
            for facet in provider_results.get_facets().get("provider", []):
                providers[facet["value"]] = facet["count"]
            
            return {
                "index_name": self.index_name,
                "total_documents": total_count,
                "providers": providers,
                "auto_delete_days": self.auto_delete_days,
                "auto_cleanup_enabled": self.enable_auto_cleanup
            }
            
        except Exception as e:
            print(f"❌ Error getting stats: {e}")
            return {}


class ProductionChunker:
    """
    Production-grade text chunking for long documents
    
    Features:
    - Semantic chunking
    - Overlap for context
    - Token-aware splitting
    """
    
    def __init__(
        self,
        chunk_size: int = 1000,
        chunk_overlap: int = 200,
        max_chunks: int = 5
    ):
        """
        Initialize chunker
        
        Args:
            chunk_size: Characters per chunk
            chunk_overlap: Overlap between chunks
            max_chunks: Maximum chunks per document
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.max_chunks = max_chunks
    
    def chunk_text(self, text: str) -> List[Dict[str, Any]]:
        """
        Split text into overlapping chunks
        
        Args:
            text: Input text
        
        Returns:
            List of chunks with metadata
        """
        
        if len(text) <= self.chunk_size:
            return [{
                "text": text,
                "chunk_index": 0,
                "total_chunks": 1,
                "start": 0,
                "end": len(text)
            }]
        
        chunks = []
        start = 0
        chunk_index = 0
        
        while start < len(text) and chunk_index < self.max_chunks:
            # Calculate end
            end = start + self.chunk_size
            
            # If not last chunk, try to break at sentence/word boundary
            if end < len(text):
                # Look for sentence end
                sentence_end = text.rfind(". ", start, end)
                if sentence_end > start:
                    end = sentence_end + 1
                else:
                    # Look for word boundary
                    space = text.rfind(" ", start, end)
                    if space > start:
                        end = space
            
            chunk_text = text[start:end].strip()
            
            if chunk_text:
                chunks.append({
                    "text": chunk_text,
                    "chunk_index": chunk_index,
                    "total_chunks": 0,  # Will update later
                    "start": start,
                    "end": end
                })
                chunk_index += 1
            
            # Move start with overlap
            start = end - self.chunk_overlap if end < len(text) else end
        
        # Update total chunks
        total = len(chunks)
        for chunk in chunks:
            chunk["total_chunks"] = total
        
        return chunks
    
    def should_chunk(self, text: str) -> bool:
        """Check if text needs chunking"""
        return len(text) > self.chunk_size
    
    def handle_document(self, text: str) -> str:
        """
        Handle document text for processing
        
        For medical credentials, we want full context, so we:
        1. Truncate if too long (keeps first part which usually has key info)
        2. Return the text (no chunking for embeddings - need full context)
        
        Args:
            text: Input document text
        
        Returns:
            Processed text ready for embedding/indexing
        """
        if not text:
            return ""
        
        # Clean text
        text = text.strip()
        
        # For very long documents, take first portion
        # Medical credentials usually have key info at the top
        max_length = self.chunk_size * self.max_chunks
        if len(text) > max_length:
            # Take first part and try to end at sentence boundary
            truncated = text[:max_length]
            last_period = truncated.rfind('. ')
            if last_period > max_length * 0.8:  # If we find a period in last 20%
                text = truncated[:last_period + 1]
            else:
                text = truncated
        
        return text


# Test code
if __name__ == "__main__":
    print("="*70)
    print("PRODUCTION INDEX MANAGER - TEST")
    print("="*70)
    
    # Test chunker
    chunker = ProductionChunker(chunk_size=100, chunk_overlap=20)
    
    test_text = "This is a test. " * 50  # Long text
    chunks = chunker.chunk_text(test_text)
    
    print(f"\nTest text length: {len(test_text)}")
    print(f"Number of chunks: {len(chunks)}")
    
    for chunk in chunks:
        print(f"\nChunk {chunk['chunk_index']}/{chunk['total_chunks']-1}")
        print(f"  Length: {len(chunk['text'])} chars")
        print(f"  Start: {chunk['start']}, End: {chunk['end']}")
        print(f"  Text: {chunk['text'][:50]}...")
    
    print("\n✅ Chunker working correctly!")
