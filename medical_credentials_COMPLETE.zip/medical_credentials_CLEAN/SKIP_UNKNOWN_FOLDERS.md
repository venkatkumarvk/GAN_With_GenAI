# SKIP UNKNOWN FOLDERS - Configuration Guide

## ✅ FEATURE: Skip Folders Not in Config

You can now control what happens with folders NOT defined in your config!

---

## 🎯 TWO OPTIONS:

### **Option 1: SKIP Unknown Folders** (Recommended)
```json
{
  "processing": {
    "skip_unknown_folders": true  ← Only process configured folders!
  }
}
```

**What happens:**
- ✅ Only folders in `folder_configs` are processed
- ⚠️  Unknown folders are SKIPPED with warning message
- ✅ Faster processing (no wasted time on unconfigured folders)

### **Option 2: Process with Default Fields**
```json
{
  "processing": {
    "skip_unknown_folders": false  ← Process all folders
  }
}
```

**What happens:**
- ✅ All folders are processed
- ✅ Unknown folders use `default_config` fields
- ✅ Less configuration needed

---

## 📊 EXAMPLE:

### **Your Config:**
```json
{
  "folder_configs": {
    "GEN & HR": {
      "fields": ["first_name", "last_name", "email", ...]
    },
    "ED & TRAIN": {
      "fields": ["degree", "state_license_number", ...]
    }
  },
  
  "default_config": {
    "fields": ["first_name", "last_name", "document_type"]
  },
  
  "processing": {
    "skip_unknown_folders": true  ← SKIP unknown folders
  }
}
```

### **Your Folder Structure:**
```
Provider1/
├── 1. GEN & HR/        ← In config → PROCESSED ✅
├── 2. ED & TRAIN/      ← In config → PROCESSED ✅
├── 3. REFERENCES/      ← NOT in config → SKIPPED ⚠️
└── 4. OTHER DOCS/      ← NOT in config → SKIPPED ⚠️
```

### **Processing Output:**
```
Processing Provider 1/1: Provider1
  Found 4 folders

  Processing Folder 1/4: 1. GEN & HR
    Folder type: GEN & HR
    Extracting 12 fields
    [1/2] doc1.pdf
      ✓ Successfully extracted
    ✅ Saved: 3 files

  Processing Folder 2/4: 2. ED & TRAIN
    Folder type: ED & TRAIN
    Extracting 15 fields
    [1/1] doc2.pdf
      ✓ Successfully extracted
    ✅ Saved: 3 files

  Processing Folder 3/4: 3. REFERENCES
    ⚠️  SKIPPING folder '3. REFERENCES' - not in folder_configs
       To process this folder, add it to config.json folder_configs

  Processing Folder 4/4: 4. OTHER DOCS
    ⚠️  SKIPPING folder '4. OTHER DOCS' - not in folder_configs
       To process this folder, add it to config.json folder_configs

EXTRACTION COMPLETE
```

**Result:**
- ✅ 2 folders processed (GEN & HR, ED & TRAIN)
- ⚠️  2 folders skipped (REFERENCES, OTHER DOCS)

---

## 📊 OUTPUT FILES:

### **With skip_unknown_folders: true**
```
outputcontainer/
└── highconfidence/
    └── Provider1/
        ├── processedjsonresult/
        │   ├── Provider1_GEN & HR_timestamp.json      ← Only configured
        │   └── Provider1_ED & TRAIN_timestamp.json    ← folders saved
        │
        ├── processedcsvresult/
        │   ├── Provider1_GEN & HR_timestamp.csv
        │   └── Provider1_ED & TRAIN_timestamp.csv
        │
        └── estimationcost/
            ├── Provider1_GEN & HR_timestamp_cost.json
            └── Provider1_ED & TRAIN_timestamp_cost.json
```

**No files for REFERENCES or OTHER DOCS!** ✅

---

## 🎯 WHEN TO USE EACH:

### **Use skip_unknown_folders: true when:**
- ✅ You only want specific folders processed
- ✅ Other folders contain irrelevant documents
- ✅ You want faster processing
- ✅ You want clean, focused output
- ✅ **Recommended for most use cases!**

### **Use skip_unknown_folders: false when:**
- ✅ You want to process ALL folders
- ✅ Unknown folders might have useful data
- ✅ You're exploring what data exists
- ✅ You're okay with default field extraction

---

## 📋 CONFIGURATION EXAMPLES:

### **Example 1: Only Process 2 Specific Folders**
```json
{
  "folder_configs": {
    "GEN & HR": { "fields": [...] },
    "ED & TRAIN": { "fields": [...] }
  },
  "processing": {
    "skip_unknown_folders": true  ← Skip everything else
  }
}
```

### **Example 2: Process Everything, Use Defaults for Unknown**
```json
{
  "folder_configs": {
    "GEN & HR": { "fields": [...] },
    "ED & TRAIN": { "fields": [...] }
  },
  "default_config": {
    "fields": ["first_name", "last_name", "document_type"]
  },
  "processing": {
    "skip_unknown_folders": false  ← Process all folders
  }
}
```

### **Example 3: Add More Folders Later**
```json
{
  "folder_configs": {
    "GEN & HR": { "fields": [...] },
    "ED & TRAIN": { "fields": [...] },
    "REFERENCES": { "fields": ["reference_name", "reference_phone"] }
  },
  "processing": {
    "skip_unknown_folders": true
  }
}
```

**Now REFERENCES folder will be processed!** ✅

---

## ✅ BENEFITS:

| Feature | Benefit |
|---------|---------|
| **Selective processing** | ✅ Only process what you need |
| **Faster execution** | ✅ Skip irrelevant folders |
| **Clean output** | ✅ No unwanted files |
| **Cost savings** | ✅ Less API calls |
| **Clear warnings** | ✅ Know what's skipped |
| **Easy to add folders** | ✅ Just edit config |

---

## 🎯 RECOMMENDED SETUP:

```json
{
  "folder_configs": {
    "GEN & HR": {
      "description": "Personal information",
      "fields": [
        "first_name",
        "last_name",
        "email",
        "cell",
        "birth_date",
        "citizenship",
        "gender",
        "ssn"
      ],
      "min_confidence": 0.70
    },
    
    "ED & TRAIN": {
      "description": "Education and licenses",
      "fields": [
        "degree",
        "state_license_number",
        "dea_license_number",
        "board_cert_name"
      ],
      "min_confidence": 0.70
    }
  },
  
  "default_config": {
    "description": "Default for unknown folders",
    "fields": [
      "first_name",
      "last_name",
      "document_type"
    ],
    "min_confidence": 0.50
  },
  
  "processing": {
    "skip_unknown_folders": true  ← RECOMMENDED!
  }
}
```

**This ensures only GEN & HR and ED & TRAIN are processed!** ✅

---

## ✅ SUMMARY:

**Current Setting:** `skip_unknown_folders: true`

**What This Means:**
- Only folders defined in `folder_configs` are processed
- Unknown folders are skipped with warning
- Clean, focused output
- Faster processing
- Lower costs

**To Process a New Folder:**
Just add it to `folder_configs` in config.json!

---

**PERFECT FOR YOUR USE CASE!** ✅
