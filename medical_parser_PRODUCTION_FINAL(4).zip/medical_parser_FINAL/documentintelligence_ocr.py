"""
Azure Document Intelligence OCR Module
Version: 1.0.0b4

Handles document OCR extraction using Azure Document Intelligence
Supports ALL document types with DIRECT client calls (no AnalyzeDocumentRequest needed)
"""

import logging
from typing import Tuple, Dict
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential


class DocumentIntelligenceOCR:
    """
    Document Intelligence OCR Manager for text extraction
    
    Uses Azure Document Intelligence API version 1.0.0b4
    """
    
    def __init__(self, config: dict):
        """
        Initialize Document Intelligence client
        
        Args:
            config: Configuration dict with endpoint, key, api_version
        """
        self.logger = logging.getLogger(__name__)
        
        self.endpoint = config.get('endpoint')
        self.key = config.get('key')
        self.api_version = config.get('api_version', '2024-07-31-preview')
        
        if not self.endpoint or not self.key:
            raise ValueError("Document Intelligence endpoint and key are required")
        
        # Initialize client with v1.0.0b4 API
        self.client = DocumentIntelligenceClient(
            endpoint=self.endpoint,
            credential=AzureKeyCredential(self.key),
            api_version=self.api_version
        )
        
        self.logger.info(f"Document Intelligence initialized: {self.endpoint}")
    
    def extract_text(self, doc_bytes: bytes, extension: str) -> Tuple[str, int, bool]:
        """
        Extract text from document with base64 conversion for OCR
        
        Strategy:
        1. Text-based documents (DOCX, TXT, HTML) → Direct extraction (faster, no OCR cost)
        2. Image/PDF documents → Convert to base64 → Document Intelligence OCR
        
        Supported formats:
        - PDF: All versions (scanned and digital)
        - Images: JPG, JPEG, PNG, TIFF, TIF, BMP, GIF, WEBP, HEIC, HEIF
        - Office: DOCX, DOC, XLSX, XLS, PPTX, PPT
        - Text: TXT, CSV, TSV, RTF
        - Web: HTML, HTM, XML
        - Other: ODT, ODS, ODP
        
        Args:
            doc_bytes: Document bytes
            extension: File extension (e.g., '.pdf', '.jpg', '.docx')
        
        Returns:
            Tuple of (text_content, page_count, success)
        """
        try:
            # Normalize extension
            ext = extension.lower().strip('.')
            
            # Define which files need OCR vs direct text extraction
            # Direct text extraction (no OCR needed - faster, no cost)
            text_only_extensions = ['txt', 'csv', 'tsv', 'rtf']
            
            # DOC/DOCX should be converted to images for OCR (more accurate)
            # Direct extraction with parsing (no OCR - faster)
            parsed_extensions = ['html', 'htm', 'xml']
            
            # Everything else goes through OCR (PDF, images, scanned docs, DOC/DOCX, etc.)
            ocr_extensions = [
                'pdf',  # PDFs (all types)
                'jpg', 'jpeg', 'png', 'tiff', 'tif', 'bmp', 'gif', 'webp',  # Images
                'heic', 'heif',  # Modern image formats
                'docx', 'doc',  # Office Word (convert to images for accurate OCR)
                'xlsx', 'xls', 'pptx', 'ppt',  # Office (better with OCR)
                'odt', 'ods', 'odp'  # OpenOffice
            ]
            
            # Route to appropriate extraction method
            if ext in text_only_extensions:
                self.logger.info(f"Direct text extraction for {ext.upper()} (no OCR)")
                text, pages = self._extract_text_direct(doc_bytes, ext)
                return text, pages, True
            
            elif ext in parsed_extensions:
                self.logger.info(f"Parsed text extraction for {ext.upper()} (no OCR)")
                text, pages = self._extract_text_direct(doc_bytes, ext)
                return text, pages, True
            
            else:
                # Use OCR for everything else (PDF, images, Office files)
                self.logger.info(f"OCR extraction for {ext.upper()} via Document Intelligence")
                
                # Extract using Document Intelligence (with bytes)
                result = self._extract_with_base64(doc_bytes, ext)
                
                if result and 'content' in result:
                    text = result['content']
                    pages = result.get('pages', 1)
                    self.logger.info(f"OCR successful: {len(text)} chars, {pages} pages")
                    return text, pages, True
                else:
                    self.logger.warning("OCR returned no content")
                    return "", 0, False
                
        except Exception as e:
            self.logger.error(f"Text extraction failed: {e}")
            return "", 0, False
    
    def _extract_text_direct(self, doc_bytes: bytes, extension: str) -> Tuple[str, int]:
        """
        Extract text directly from text-based documents (no OCR)
        
        Args:
            doc_bytes: Document bytes
            extension: File extension without dot
        
        Returns:
            Tuple of (text_content, estimated_page_count)
        """
        try:
            if extension == 'docx':
                # Extract from DOCX using python-docx
                try:
                    from docx import Document
                    from io import BytesIO
                    
                    doc = Document(BytesIO(doc_bytes))
                    
                    # Extract all text from paragraphs
                    text_parts = []
                    for paragraph in doc.paragraphs:
                        if paragraph.text.strip():
                            text_parts.append(paragraph.text)
                    
                    # Extract text from tables
                    for table in doc.tables:
                        for row in table.rows:
                            for cell in row.cells:
                                if cell.text.strip():
                                    text_parts.append(cell.text)
                    
                    text = '\n'.join(text_parts)
                    
                    # Estimate pages (roughly 3000 chars per page)
                    pages = max(1, len(text) // 3000)
                    
                    self.logger.info(f"Extracted {len(text)} chars from DOCX ({pages} estimated pages)")
                    return text, pages
                    
                except ImportError:
                    self.logger.warning("python-docx not installed, trying plain text extraction")
                    # Fallback to basic text extraction
                    text = doc_bytes.decode('utf-8', errors='ignore')
                    pages = max(1, len(text) // 3000)
                    return text, pages
            
            elif extension == 'doc':
                # Old Word format - try textract or fallback
                try:
                    import textract
                    text = textract.process(BytesIO(doc_bytes)).decode('utf-8')
                    pages = max(1, len(text) // 3000)
                    return text, pages
                except ImportError:
                    self.logger.warning("textract not installed for DOC files")
                    # Fallback
                    text = doc_bytes.decode('utf-8', errors='ignore')
                    pages = max(1, len(text) // 3000)
                    return text, pages
            
            elif extension in ['txt', 'csv']:
                # Plain text files
                text = doc_bytes.decode('utf-8', errors='ignore')
                pages = max(1, len(text) // 3000)
                self.logger.info(f"Extracted {len(text)} chars from {extension.upper()}")
                return text, pages
            
            elif extension in ['html', 'htm', 'xml']:
                # HTML/XML files
                from html.parser import HTMLParser
                
                class TextExtractor(HTMLParser):
                    def __init__(self):
                        super().__init__()
                        self.text = []
                    
                    def handle_data(self, data):
                        self.text.append(data.strip())
                
                try:
                    html_text = doc_bytes.decode('utf-8', errors='ignore')
                    extractor = TextExtractor()
                    extractor.feed(html_text)
                    text = ' '.join(extractor.text)
                    pages = max(1, len(text) // 3000)
                    return text, pages
                except:
                    # Fallback to raw text
                    text = doc_bytes.decode('utf-8', errors='ignore')
                    pages = max(1, len(text) // 3000)
                    return text, pages
            
            else:
                # Unknown format - try UTF-8 decode
                text = doc_bytes.decode('utf-8', errors='ignore')
                pages = max(1, len(text) // 3000)
                return text, pages
                
        except Exception as e:
            self.logger.error(f"Direct text extraction failed: {e}")
            # Last resort - try to decode as text
            try:
                text = doc_bytes.decode('utf-8', errors='ignore')
                pages = max(1, len(text) // 3000)
                return text, pages
            except:
                return "", 0
    
    def _extract_with_base64(self, doc_bytes: bytes, extension: str) -> Dict:
        """
        Extract text using Document Intelligence - DIRECT client call
        No AnalyzeDocumentRequest needed!
        
        Args:
            doc_bytes: Document bytes
            extension: File extension (for content-type detection)
        
        Returns:
            Dict with 'content', 'pages', and metadata
        """
        try:
            # Determine content type from extension
            content_type = self._get_content_type(f"document.{extension}")
            
            self.logger.info(f"Analyzing document with Document Intelligence")
            self.logger.info(f"Content type: {content_type}")
            
            # Call Document Intelligence - DIRECT method (no AnalyzeDocumentRequest!)
            # Just pass the bytes directly to begin_analyze_document
            poller = self.client.begin_analyze_document(
                model_id="prebuilt-read",
                analyze_request=doc_bytes,  # Pass bytes directly!
                content_type=content_type
            )
            
            self.logger.info(f"Waiting for OCR result...")
            
            # Wait for result
            result = poller.result()
            
            # Extract text content
            extracted_text = result.content if result.content else ""
            
            # Get page count
            page_count = len(result.pages) if result.pages else 0
            
            self.logger.info(f"OCR successful: {len(extracted_text)} chars, {page_count} pages")
            
            # Return structured result
            return {
                'content': extracted_text,
                'pages': page_count,
                'content_length': len(extracted_text),
                'model_id': 'prebuilt-read',
                'api_version': self.api_version
            }
            
        except Exception as e:
            self.logger.error(f"OCR extraction failed: {e}")
            self.logger.exception("Full traceback:")
            return {}
    
    def extract_text_from_document(
        self, 
        doc_bytes: bytes, 
        doc_name: str
    ) -> Dict:
        """
        Extract text from document using OCR - DIRECT client call
        No AnalyzeDocumentRequest needed!
        
        Args:
            doc_bytes: Binary document content
            doc_name: Document filename (for extension detection)
            
        Returns:
            Dict with 'content', 'pages', and metadata
        """
        try:
            self.logger.info(f"Starting OCR for document: {doc_name}")
            
            # Determine content type from file extension
            content_type = self._get_content_type(doc_name)
            self.logger.info(f"Content type: {content_type}")
            
            # Call Document Intelligence - DIRECT method
            # Pass bytes directly (no AnalyzeDocumentRequest wrapper!)
            self.logger.info(f"Calling Document Intelligence API...")
            
            poller = self.client.begin_analyze_document(
                model_id="prebuilt-read",
                analyze_request=doc_bytes,  # Pass bytes directly!
                content_type=content_type
            )
            
            self.logger.info(f"Waiting for OCR result...")
            
            # Wait for result
            result = poller.result()
            
            # Extract text content
            extracted_text = result.content if result.content else ""
            
            # Get page count
            page_count = len(result.pages) if result.pages else 0
            
            self.logger.info(
                f"OCR complete: {doc_name} - {page_count} pages, "
                f"{len(extracted_text)} chars"
            )
            
            # Return as dict (consistent with _extract_with_base64)
            return {
                'content': extracted_text,
                'pages': page_count,
                'content_length': len(extracted_text),
                'model_id': 'prebuilt-read',
                'api_version': self.api_version
            }
            
        except Exception as e:
            self.logger.error(f"OCR failed for {doc_name}: {str(e)}")
            self.logger.exception("Full error traceback:")
            return {}
    
    def _get_content_type(self, filename: str) -> str:
        """
        Determine content type from file extension
        Supports ALL document types for Document Intelligence
        
        Args:
            filename: Document filename
            
        Returns:
            Content type string (MIME type)
        """
        extension = filename.lower().split('.')[-1]
        
        content_types = {
            # PDF
            'pdf': 'application/pdf',
            
            # Images - Common formats
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'tiff': 'image/tiff',
            'tif': 'image/tiff',
            'bmp': 'image/bmp',
            'gif': 'image/gif',
            'webp': 'image/webp',
            
            # Images - Modern formats
            'heic': 'image/heic',
            'heif': 'image/heif',
            
            # Microsoft Office
            'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'doc': 'application/msword',
            'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'xls': 'application/vnd.ms-excel',
            'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'ppt': 'application/vnd.ms-powerpoint',
            
            # OpenOffice/LibreOffice
            'odt': 'application/vnd.oasis.opendocument.text',
            'ods': 'application/vnd.oasis.opendocument.spreadsheet',
            'odp': 'application/vnd.oasis.opendocument.presentation',
            
            # Text formats
            'txt': 'text/plain',
            'csv': 'text/csv',
            'tsv': 'text/tab-separated-values',
            'rtf': 'application/rtf',
            
            # Web formats
            'html': 'text/html',
            'htm': 'text/html',
            'xml': 'application/xml'
        }
        
        content_type = content_types.get(extension, 'application/octet-stream')
        
        if content_type == 'application/octet-stream':
            self.logger.warning(
                f"Unknown file extension: {extension}, "
                f"using application/octet-stream"
            )
        
        return content_type
    
    def extract_text_with_layout(
        self, 
        doc_bytes: bytes, 
        doc_name: str
    ) -> Tuple[str, int, Dict, list]:
        """
        Extract text with layout information (advanced)
        
        Args:
            doc_bytes: Binary document content
            doc_name: Document filename
            
        Returns:
            Tuple of (text, page_count, metadata, layout_info)
        """
        try:
            self.logger.info(f"Starting OCR with layout for: {doc_name}")
            
            content_type = self._get_content_type(doc_name)
            analyze_request = AnalyzeDocumentRequest(bytes_source=doc_bytes)
            
            # Use prebuilt-layout for structured extraction
            poller = self.client.begin_analyze_document(
                model_id="prebuilt-layout",
                analyze_request=analyze_request,
                content_type=content_type
            )
            
            result: AnalyzeResult = poller.result()
            
            extracted_text = result.content if result.content else ""
            page_count = len(result.pages) if result.pages else 0
            
            # Extract layout information
            layout_info = []
            if result.paragraphs:
                for para in result.paragraphs:
                    layout_info.append({
                        'content': para.content,
                        'role': para.role if hasattr(para, 'role') else None,
                        'bounding_regions': [
                            {
                                'page_number': region.page_number,
                                'polygon': region.polygon
                            }
                            for region in para.bounding_regions
                        ] if para.bounding_regions else []
                    })
            
            metadata = {
                'page_count': page_count,
                'has_content': bool(extracted_text),
                'content_length': len(extracted_text),
                'paragraph_count': len(layout_info),
                'model_id': 'prebuilt-layout',
                'api_version': self.api_version
            }
            
            self.logger.info(
                f"OCR with layout complete: {doc_name} - "
                f"{page_count} pages, {len(layout_info)} paragraphs"
            )
            
            return extracted_text, page_count, metadata, layout_info
            
        except Exception as e:
            self.logger.error(f"OCR with layout failed for {doc_name}: {str(e)}")
            raise
    
    def test_connection(self) -> bool:
        """
        Test Document Intelligence connection
        
        Returns:
            True if connection successful
        """
        try:
            # Simple test - just verify client is initialized
            if self.client and self.endpoint:
                self.logger.info("Document Intelligence connection test passed")
                return True
            return False
        except Exception as e:
            self.logger.error(f"Connection test failed: {str(e)}")
            return False


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_ocr_manager(config: dict) -> DocumentIntelligenceOCR:
    """
    Factory function to create OCR manager
    
    Args:
        config: Configuration dict
        
    Returns:
        DocumentIntelligenceOCR instance
    """
    return DocumentIntelligenceOCR(config)


def extract_text_simple(
    doc_bytes: bytes,
    doc_name: str,
    config: dict
) -> str:
    """
    Simple text extraction (convenience function)
    
    Args:
        doc_bytes: Document binary
        doc_name: Document filename
        config: OCR configuration
        
    Returns:
        Extracted text string
    """
    ocr = DocumentIntelligenceOCR(config)
    text, _, _ = ocr.extract_text_from_document(doc_bytes, doc_name)
    return text


# =============================================================================
# VALIDATION
# =============================================================================

if __name__ == "__main__":
    print("="*80)
    print("Document Intelligence OCR Module")
    print("Version: 1.0.0b4")
    print("="*80)
    
    # Example configuration
    example_config = {
        'endpoint': 'https://your-resource.cognitiveservices.azure.com/',
        'key': 'your-key-here',
        'api_version': '2024-07-31-preview'
    }
    
    print("\nExample usage:")
    print("```python")
    print("from documentintelligence_ocr import DocumentIntelligenceOCR")
    print("")
    print("# Initialize")
    print("ocr = DocumentIntelligenceOCR(config)")
    print("")
    print("# Extract text")
    print("text, pages, metadata = ocr.extract_text_from_document(")
    print("    doc_bytes=document_bytes,")
    print("    doc_name='sample.pdf'")
    print(")")
    print("```")
    print("\n" + "="*80)
    print("OK Module ready for import")
    print("="*80)
