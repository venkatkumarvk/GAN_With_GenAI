SIMPLIFIED MEDICAL PARSER - 10 FIELDS ONLY
===========================================

CONFIGURATION:
--------------
- ONLY cred doctype (bus and claim removed)
- ONLY 10 fields from GEN & HR folder
- Simplified for testing

FIELDS (10 total):
------------------
1. first_name
2. last_name
3. email
4. cell
5. birth_date
6. birth_place
7. birth_city
8. birth_state_province
9. birth_country
10. citizenship

FOLDER:
-------
Only processes: "GEN & HR" folder

INSTALLATION:
-------------
pip install -r requirements.txt

CONFIGURATION:
--------------
1. Update config.json with your Azure Key Vault URL
2. Add secrets to Azure Key Vault

USAGE:
------
python main.py --doctype cred --apitype general --archive true

NOTE:
-----
This is a simplified version for testing.
Only GEN & HR folder with 10 fields will be processed.
