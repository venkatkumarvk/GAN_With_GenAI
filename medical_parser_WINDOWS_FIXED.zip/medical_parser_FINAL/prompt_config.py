"""
SIMPLIFIED FIELD LIBRARY - 10 FIELDS ONLY
==========================================
For GEN & HR folder in Medical Credentials
"""

# =============================================================================
# FIELD LIBRARY - 10 FIELDS ONLY
# =============================================================================

FIELD_LIBRARY = {
    "first_name": {
        "description": "First/Given name of the individual",
        "examples": ["John", "Mary", "Robert"],
        "format": "Capitalized text",
        "extraction_hints": [
            "Look for 'First Name' or 'Given Name' labels",
            "Check top of document",
            "May be in 'Full Name' section"
        ],
        "confidence_factors": [
            "Clear text with proper spacing",
            "Consistent formatting"
        ]
    },
    
    "last_name": {
        "description": "Last/Family name of the individual",
        "examples": ["Smith", "Johnson", "Williams"],
        "format": "Capitalized text, may include suffixes (Jr., MD)",
        "extraction_hints": [
            "Look for 'Last Name' or 'Surname' labels",
            "May include professional suffixes (MD, DO)"
        ],
        "confidence_factors": [
            "Clear text with proper spacing",
            "Matches expected surname pattern"
        ]
    },
    
    "email": {
        "description": "Email address for contact",
        "examples": ["john.doe@hospital.com", "mary@clinic.org"],
        "format": "Standard email format: username@domain.com",
        "extraction_hints": [
            "Look for 'Email' or 'E-mail' labels",
            "Must contain @ symbol"
        ],
        "confidence_factors": [
            "Contains @ symbol",
            "Has valid domain structure"
        ]
    },
    
    "cell": {
        "description": "Cell/Mobile phone number",
        "examples": ["(555) 123-4567", "555-123-4567"],
        "format": "10 digits, may include formatting",
        "extraction_hints": [
            "Look for 'Cell' or 'Mobile' labels",
            "Extract 10-digit number"
        ],
        "confidence_factors": [
            "Contains 10 digits",
            "Has standard phone formatting"
        ]
    },
    
    "birth_date": {
        "description": "Date of birth",
        "examples": ["01/15/1985", "1985-01-15", "January 15, 1985"],
        "format": "MM/DD/YYYY",
        "extraction_hints": [
            "Look for 'DOB' or 'Date of Birth' labels",
            "Convert to MM/DD/YYYY format"
        ],
        "confidence_factors": [
            "Valid date format",
            "Reasonable age (25-80 years)"
        ]
    },
    
    "birth_place": {
        "description": "Complete birth place",
        "examples": ["New York, NY, USA", "London, UK"],
        "format": "City, State, Country",
        "extraction_hints": [
            "Look for 'Place of Birth' or 'Birth Place' labels",
            "Include all location details available"
        ],
        "confidence_factors": [
            "Complete location information",
            "Standard place name format"
        ]
    },
    
    "birth_city": {
        "description": "City of birth",
        "examples": ["New York", "Los Angeles", "Chicago"],
        "format": "City name only",
        "extraction_hints": [
            "Look for 'Birth City' label",
            "Extract city portion from birth place"
        ],
        "confidence_factors": [
            "Valid city name",
            "Consistent with birth_place"
        ]
    },
    
    "birth_state_province": {
        "description": "State or Province of birth",
        "examples": ["California", "CA", "New York", "NY"],
        "format": "Full name or 2-letter abbreviation",
        "extraction_hints": [
            "Look for 'Birth State' label",
            "May be full name or abbreviation"
        ],
        "confidence_factors": [
            "Valid state/province",
            "Consistent with birth_place"
        ]
    },
    
    "birth_country": {
        "description": "Country of birth",
        "examples": ["USA", "United States", "Canada"],
        "format": "Full name or abbreviation",
        "extraction_hints": [
            "Look for 'Birth Country' label",
            "May be full name or abbreviation (USA, US)"
        ],
        "confidence_factors": [
            "Valid country name",
            "Standard country format"
        ]
    },
    
    "citizenship": {
        "description": "Citizenship/Nationality status",
        "examples": ["US Citizen", "USA", "Canadian"],
        "format": "Country name or citizenship status",
        "extraction_hints": [
            "Look for 'Citizenship' or 'Nationality' labels",
            "May indicate status like 'US Citizen'"
        ],
        "confidence_factors": [
            "Valid citizenship status",
            "Standard format"
        ]
    }
}


# =============================================================================
# SYSTEM PROMPT
# =============================================================================

SYSTEM_PROMPT_CONFIG = {
    "role": "You are an expert medical credentialing specialist extracting information from GEN & HR documents.",
    
    "extraction_rules": [
        "Extract EXACTLY what you see - do not guess",
        "If field not found, use 'NA' with confidence 0.50",
        "Convert dates to MM/DD/YYYY format",
        "Return 'NA' for ANY field with confidence < 0.50"
    ],
    
    "confidence_guide": {
        "0.95-1.00": "Exact match, clear, properly labeled",
        "0.85-0.94": "Strong match, minor formatting differences",
        "0.70-0.84": "Likely match, some interpretation needed",
        "0.50-0.69": "Possible match, moderate uncertainty",
        "below 0.50": "Use 'NA'"
    },
    
    "output_format": """
MANDATORY JSON FORMAT:

{
  "first_name": {
    "value": "John",
    "confidence": 0.95
  },
  "last_name": {
    "value": "Smith",
    "confidence": 0.92
  }
}

REQUIREMENTS:
1. EVERY field MUST have "value" and "confidence"
2. Confidence must be 0.00-1.00
3. If not found: {"value": "NA", "confidence": 0.50}
4. Return ONLY valid JSON, no markdown
""",
    
    "restrictions": """
STRICT REQUIREMENTS:
1. Return ONLY valid JSON - no extra text
2. EVERY field MUST have 'value' and 'confidence'
3. If you cannot find a field, return {"value": "NA", "confidence": 0.50}
"""
}


# =============================================================================
# DOCUMENT TYPE HINTS
# =============================================================================

DOCUMENT_TYPE_HINTS = {
    "medical_credentials": {
        "title": "MEDICAL CREDENTIALING - GEN & HR FOLDER",
        "special_considerations": [
            "Personal information section",
            "Contact details",
            "Birth information",
            "Citizenship status"
        ]
    }
}


# =============================================================================
# RAG PROMPT TEMPLATES
# =============================================================================

RAG_PROMPT_TEMPLATE = {
    "intro": "You have {num_docs} similar documents. Learn from their patterns.",
    "example_header": "SIMILAR DOCUMENTS:",
    "transition": "Now extract from the CURRENT document.",
    "instructions": [
        "Follow the same extraction patterns",
        "Return 'NA' for any field not found",
        "Maintain consistent date formatting: MM/DD/YYYY"
    ],
    "reminder": "Return ONLY JSON. Use 'NA' for missing values."
}

STANDARD_PROMPT_TEMPLATE = {
    "header": "Extract the fields from this GEN & HR document:",
    "reminder": "Return ONLY JSON. Use 'NA' for missing values."
}


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_field_count():
    """Get current number of fields"""
    return len(FIELD_LIBRARY)

def get_field_names():
    """Get list of all field names"""
    return list(FIELD_LIBRARY.keys())


if __name__ == "__main__":
    print("="*80)
    print("SIMPLIFIED FIELD LIBRARY - 10 FIELDS")
    print("="*80)
    print(f"\nTotal fields: {get_field_count()}")
    print(f"Fields: {', '.join(get_field_names())}")
    print("\n✓ Field library ready!")
