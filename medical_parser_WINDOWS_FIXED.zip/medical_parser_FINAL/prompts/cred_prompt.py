"""
Medical Credentials Prompt - GEN & HR folder
Uses prompt_config.py for field definitions
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from prompt_config import (
    FIELD_LIBRARY,
    SYSTEM_PROMPT_CONFIG,
    DOCUMENT_TYPE_HINTS,
    RAG_PROMPT_TEMPLATE,
    STANDARD_PROMPT_TEMPLATE
)

__all__ = [
    'FIELD_LIBRARY',
    'SYSTEM_PROMPT_CONFIG',
    'DOCUMENT_TYPE_HINTS',
    'RAG_PROMPT_TEMPLATE',
    'STANDARD_PROMPT_TEMPLATE'
]
