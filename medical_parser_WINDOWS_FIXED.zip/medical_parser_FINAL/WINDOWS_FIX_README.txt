WINDOWS ENCODING FIX
====================

ERRORS FIXED:
-------------
1. UnicodeEncodeError: 'charmap' codec can't encode characters
2. Log files not being created

CHANGES MADE:
-------------
1. Added UTF-8 encoding to all file handlers
2. Reconfigured stdout/stderr for UTF-8 on Windows
3. Removed emoji characters from logging (replaced with text)
4. All log files now created with encoding='utf-8'

WHAT THIS MEANS:
----------------
✓ Log files will now be created correctly on Windows
✓ No more UnicodeEncodeError
✓ Special characters handled properly
✓ Works on both Windows and Linux

LOG FILE LOCATION:
------------------
Log files are created in the current directory with format:
parser_YYYYMMDD_HHMMSS.log

Example: parser_20260320_075236.log

The log filename is displayed when you run the program:
"Log file: parser_20260320_075236.log"

TESTED ON:
----------
✓ Windows 10/11
✓ PowerShell
✓ Command Prompt
✓ VS Code Terminal
