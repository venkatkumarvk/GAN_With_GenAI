FLEXIBLE KEY VAULT SUPPORT - MIXED MODE
========================================

✅ THREE MODES SUPPORTED:

1. ALL KEY VAULT:
   - vault_url: Real Azure Key Vault URL
   - All values: @azureKeyVault(SecretName)
   
2. ALL DIRECT VALUES:
   - vault_url: Placeholder (https://your-keyvault-name.vault.azure.net/)
   - All values: Direct strings
   
3. MIXED (RECOMMENDED):
   - vault_url: Real Azure Key Vault URL
   - Sensitive values: @azureKeyVault(SecretName)
   - Non-sensitive values: Direct strings

EXAMPLES:
---------

Example 1 - Mixed Mode (Recommended):
{
  "azure_keyvault": {
    "vault_url": "https://prod-vault.vault.azure.net/"
  },
  "azure_blob": {
    "connection_string": "@azureKeyVault(BlobConnection)"
  },
  "azure_document_intelligence": {
    "endpoint": "https://my-docintel.cognitiveservices.azure.com/",
    "key": "@azureKeyVault(DocIntKey)"
  },
  "doctypes": {
    "cred": {
      "azure_openai": {
        "general": {
          "endpoint": "https://my-openai.openai.azure.com/",
          "api_key": "@azureKeyVault(OpenAIKey)"
        }
      }
    }
  }
}

Result:
- connection_string → Fetched from Key Vault ✓
- docintel.endpoint → Used directly ✓
- docintel.key → Fetched from Key Vault ✓
- openai.endpoint → Used directly ✓
- openai.api_key → Fetched from Key Vault ✓

BENEFITS:
---------
✓ Sensitive data (keys, secrets) in Key Vault = Secure
✓ Non-sensitive data (endpoints, names) direct = Simple
✓ Mix both in same config = Flexible
✓ No code changes needed = Automatic

RECOMMENDATION:
---------------
Put in Key Vault:
- Connection strings
- API keys
- Secret keys
- Any sensitive data

Put directly:
- Endpoints/URLs
- Deployment names
- Model names
- Container names
- Configuration values (thresholds, batch sizes, etc.)

For full examples, see the included config.json!
