# Medical Document Parser - Production

Azure RAG-based credential extraction system for healthcare provider documents.

## Folder Structure

```
medical_document_parser/
|-- main.py                          # Entry point (CLI)
|-- requirements.txt                 # Python dependencies
|
|-- config/
|   |-- config.json                  # Azure credentials, doctype configs, RAG mode
|
|-- services/                        # Azure service wrappers (no business logic)
|   |-- azure_clients.py             # BlobManager, OpenAIManager, SearchManager
|   |-- keyvault_manager.py          # Azure Key Vault secret resolution
|   |-- ocr.py                       # Document Intelligence OCR
|   |-- cost_tracker.py              # Token and page cost tracking
|   |-- document_converter.py        # PDF/DOCX to image conversion (for multimodal)
|   |-- archive_manager.py           # Post-processing archival to blob
|
|-- extraction/                      # RAG extraction pipelines
|   |-- text_rag.py                  # Text-only RAG (OCR + text GPT)
|   |-- multimodal_rag.py            # Text + Vision RAG (OCR + image + GPT Vision)
|   |-- semantic_chunker.py          # Zero-data-loss document chunking
|
|-- prompts/                         # LLM prompt configuration + builder
|   |-- cred_prompt.py               # Field library for medical credentials
|   |-- prompt_builder.py            # Dynamic prompt construction
```

## Usage

```bash
python main.py --apitype general --doctype cred --archive false
```

## RAG Mode (config.json)

```json
"rag": {
    "mode": "text",
    "top_k": 3,
    "similarity_threshold": 0.7
}
```

- text = OCR + text-only GPT extraction
- multimodal = OCR + document image + GPT Vision extraction

## Adding a New Document Type

Only 2 changes needed - no code modifications:

1. Create new prompt file in prompts/ (copy cred_prompt.py as template)
2. Add doctype entry in config.json with folder_configs and fields

Then run with --doctype your_new_type
