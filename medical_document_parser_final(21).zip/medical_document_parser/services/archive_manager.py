"""
Archive Manager - Blob-to-Blob Document Archiving

After processing ALL providers, creates a SINGLE zip file containing
all providers organized by confidence routing:

  archivecontainer/
    archive_cred_20250324_103000.zip
      |-- processedprovider/
      |     |-- highconfidence/
      |     |     |-- SMITH-JOHN/
      |     |     |     |-- 1. GEN & HR/file1.pdf
      |     |-- lowconfidence/
      |           |-- DOE-JANE/
      |                 |-- 1. GEN & HR/license.pdf
      |-- unprocessedprovider/
            |-- BROWN-MIKE/
                  |-- 1. GEN & HR/incomplete.pdf

After archiving, the original blobs are deleted from input container.
"""

import io
import zipfile
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class ArchiveManager:
    """
    Archive all processed providers into a single zip file.
    
    Usage:
        archiver = ArchiveManager(blob_manager, config, "cred")
        
        # After each provider is processed:
        archiver.add_provider(provider, documents, "highconfidence")
        archiver.add_provider(provider2, documents2, "lowconfidence")
        
        # After ALL providers are done:
        archiver.finalize()  # Creates zip, uploads, cleans input
    """
    
    def __init__(self, blob_manager, config: dict, doctype: str):
        self.blob_manager = blob_manager
        self.config = config
        self.doctype = doctype
        
        self.input_container = config['azure_blob']['inputcontainer']
        self.archive_container = config['azure_blob'].get(
            'archivecontainer',
            config.get('archive', {}).get('container', 'archivecontainer')
        )
        
        # Accumulate providers until finalize()
        self._providers = []  # List of (provider, documents, routing)
    
    def add_provider(
        self, provider: str, documents: list, confidence_routing: str
    ):
        """
        Queue a provider for archiving.
        
        Args:
            provider: Provider name
            documents: List of blob objects that were processed
            confidence_routing: 
                "highconfidence" -> processedprovider/highconfidence/
                "lowconfidence"  -> processedprovider/lowconfidence/
                "unprocessed"    -> unprocessedprovider/
        """
        self._providers.append((provider, documents, confidence_routing))
        logger.info(
            f"   Archive: Queued {provider} "
            f"({len(documents)} docs, {confidence_routing})"
        )
    
    def finalize(self) -> bool:
        """
        Create single zip with all providers and upload to archive container.
        
        Structure inside zip:
          processedprovider/PROVIDER_NAME/folder/file.pdf
          unprocessedprovider/PROVIDER_NAME/folder/file.pdf
        
        After upload, deletes original blobs from input container.
        
        Returns:
            True if archive succeeded
        """
        if not self._providers:
            logger.info("   Archive: No providers to archive")
            return False
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        zip_filename = f"archive_{self.doctype}_{timestamp}.zip"
        
        total_docs = sum(len(docs) for _, docs, _ in self._providers)
        logger.info(
            f"   Archive: Creating {zip_filename} "
            f"({len(self._providers)} providers, {total_docs} documents)"
        )
        
        try:
            # Step 1: Build zip in memory
            zip_buffer = io.BytesIO()
            docs_added = 0
            all_blob_names = []  # Track for cleanup
            
            with zipfile.ZipFile(
                zip_buffer, 'w', zipfile.ZIP_DEFLATED
            ) as zipf:
                for provider, documents, routing in self._providers:
                    # Map routing to folder path inside zip
                    if routing == "highconfidence":
                        archive_folder = "processedprovider/highconfidence"
                    elif routing == "lowconfidence":
                        archive_folder = "processedprovider/lowconfidence"
                    else:
                        archive_folder = "unprocessedprovider"
                    
                    for doc_blob in documents:
                        blob_name = doc_blob.name
                        all_blob_names.append(blob_name)
                        
                        # Download blob
                        doc_bytes = self.blob_manager.download_blob(
                            self.input_container, blob_name
                        )
                        
                        if doc_bytes:
                            # Path inside zip: 
                            # processedprovider/SMITH-JOHN/1. GEN & HR/file.pdf
                            relative_path = blob_name  # Already has provider/folder/file
                            zip_path = f"{archive_folder}/{relative_path}"
                            zipf.writestr(zip_path, doc_bytes)
                            docs_added += 1
                        else:
                            logger.warning(
                                f"     Could not download {blob_name}"
                            )
            
            logger.info(
                f"   Archive: Added {docs_added}/{total_docs} documents to zip"
            )
            
            # Step 2: Upload zip to archive container
            zip_buffer.seek(0)
            
            success = self.blob_manager.upload_blob(
                self.archive_container,
                zip_filename,
                zip_buffer.getvalue(),
                content_type='application/zip'
            )
            
            if not success:
                logger.error(
                    f"   Archive: Failed to upload {zip_filename}"
                )
                return False
            
            logger.info(
                f"   Archive: Uploaded {zip_filename} to {self.archive_container}"
            )
            
            # Step 3: Delete originals from input container
            deleted = 0
            for blob_name in all_blob_names:
                try:
                    blob_client = (
                        self.blob_manager.blob_service_client
                        .get_blob_client(self.input_container, blob_name)
                    )
                    blob_client.delete_blob()
                    deleted += 1
                except Exception as e:
                    logger.warning(
                        f"     Could not delete {blob_name}: {e}"
                    )
            
            logger.info(
                f"   Archive: Cleaned up {deleted}/{len(all_blob_names)} "
                f"blobs from input container"
            )
            
            self._providers.clear()
            return True
            
        except Exception as e:
            logger.error(f"   Archive: Failed: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False
