"""
SEMANTIC CHUNKER V2 - ZERO DATA LOSS
======================================

Production chunking for medical document processing.

KEY IMPROVEMENTS over v1:
1. NO max_chunks limit  ->  every character is preserved
2. Section-aware splitting  ->  respects medical document structure
3. Adaptive chunk sizing  ->  small docs stay whole, large docs split smart
4. Coverage validation  ->  verifies 100% text is captured
5. Sentence-boundary splitting  ->  never cuts mid-sentence
6. Smart overlap  ->  overlaps at paragraph/section boundaries, not arbitrary chars

DATA LOSS POINTS FIXED:
- Old: max_chunks=10  ->  30,000+ char docs got TRUNCATED
- Old: text[:3000] truncation  ->  only first page sent to GPT
- Old: max_chunks_for_extraction=2  ->  only first 2 chunks extracted
- New: ALL chunks created, ALL indexed, RAG retrieves BEST chunks per field
"""

import re
import logging
from typing import List, Dict, Tuple, Optional

logger = logging.getLogger(__name__)


# =============================================================================
# MEDICAL DOCUMENT SECTION PATTERNS
# =============================================================================

# These patterns detect section boundaries in medical/credential documents
SECTION_PATTERNS = [
    # Numbered sections: "1.", "1)", "Section 1", "SECTION 1"
    r'(?:^|\n)(?:Section\s+\d+|SECTION\s+\d+|\d+\.\s+[A-Z])',
    
    # Header-style lines: ALL CAPS lines, lines ending with ":"
    r'(?:^|\n)[A-Z][A-Z\s]{10,}(?:\n|:)',
    
    # Common medical document headers
    r'(?:^|\n)(?:EDUCATION|TRAINING|LICENSE|CERTIFICATION|EMPLOYMENT|'
    r'EXPERIENCE|PERSONAL|CONTACT|REFERENCES|BOARD|MALPRACTICE|'
    r'PRIVILEGES|AFFILIATIONS|PUBLICATIONS|DEA|NPI|INSURANCE|'
    r'WORK HISTORY|PROFESSIONAL|DISCLOSURE|ATTESTATION)',
    
    # Form field labels (common in credential apps)
    r'(?:^|\n)(?:First Name|Last Name|Date of Birth|SSN|NPI|DEA|'
    r'Medical School|Residency|Fellowship|Board Certification)',
    
    # Page breaks / form boundaries
    r'(?:Page\s+\d+\s+of\s+\d+|={5,}|-{5,}|\*{5,})',
]

COMPILED_SECTION_PATTERNS = [re.compile(p, re.MULTILINE | re.IGNORECASE) 
                              for p in SECTION_PATTERNS]


class SemanticChunkerV2:
    """
    Zero-data-loss semantic chunker for medical documents.
    
    Strategy:
    1. Try section-based splitting first (respects document structure)
    2. Fall back to paragraph-based splitting
    3. Last resort: sentence-based splitting with overlap
    4. NEVER drops any text - no max_chunks limit
    """
    
    def __init__(
        self,
        target_chunk_size: int = 3000,
        min_chunk_size: int = 500,
        max_chunk_size: int = 6000,
        overlap_size: int = 300,
        adaptive: bool = True
    ):
        """
        Initialize chunker.
        
        Args:
            target_chunk_size: Ideal characters per chunk (3000 ≈ ~750 tokens)
            min_chunk_size: Minimum chunk size (avoid tiny fragments)
            max_chunk_size: Maximum chunk size (avoid token overflow)
            overlap_size: Characters to overlap between chunks
            adaptive: Auto-adjust chunk size based on document length
        """
        self.target_chunk_size = target_chunk_size
        self.min_chunk_size = min_chunk_size
        self.max_chunk_size = max_chunk_size
        self.overlap_size = overlap_size
        self.adaptive = adaptive
    
    def should_chunk(self, text: str) -> bool:
        """Check if text needs chunking"""
        return len(text) > self.target_chunk_size
    
    def chunk_document(self, text: str, doc_id: str = "") -> List[Dict]:
        """
        Chunk document with ZERO data loss.
        
        Returns ALL chunks - no max_chunks limit.
        Every character in the original text appears in at least one chunk.
        
        Args:
            text: Full document text
            doc_id: Document identifier for tracking
            
        Returns:
            List of chunk dicts with metadata
        """
        if not text or not text.strip():
            return []
        
        text_length = len(text)
        
        # ====================================================================
        # TIER 1: Small documents  ->  no chunking (single chunk)
        # ====================================================================
        if text_length <= self.target_chunk_size:
            logger.info(f"Small doc ({text_length} chars)  ->  single chunk, no split needed")
            return [self._make_chunk(text, doc_id, 0, 1, 0, text_length)]
        
        # ====================================================================
        # TIER 2: Medium documents  ->  try section-based splitting
        # ====================================================================
        if text_length <= self.max_chunk_size * 3:
            # Try section-based split first
            sections = self._split_by_sections(text)
            if sections and len(sections) > 1:
                chunks = self._sections_to_chunks(sections, doc_id)
                if self._validate_coverage(text, chunks):
                    logger.info(f"Medium doc ({text_length} chars)  ->  {len(chunks)} section-based chunks")
                    return chunks
        
        # ====================================================================
        # TIER 3: Large documents  ->  adaptive paragraph+sentence splitting
        # ====================================================================
        # Adapt chunk size based on document length
        effective_chunk_size = self._get_adaptive_size(text_length)
        
        chunks = self._split_with_overlap(text, doc_id, effective_chunk_size)
        
        if self._validate_coverage(text, chunks):
            logger.info(f"Large doc ({text_length} chars)  ->  {len(chunks)} chunks "
                       f"(adaptive size: {effective_chunk_size})")
        else:
            # Safety fallback - should never hit this, but just in case
            logger.warning(f"Coverage validation failed, using raw split")
            chunks = self._raw_split_fallback(text, doc_id, effective_chunk_size)
        
        return chunks
    
    def _get_adaptive_size(self, text_length: int) -> int:
        """
        Adaptively set chunk size based on document length.
        
        Goal: Balance between too-many-chunks (cost) and too-large-chunks (token overflow).
        
        Args:
            text_length: Total document length in characters
            
        Returns:
            Optimal chunk size for this document
        """
        if not self.adaptive:
            return self.target_chunk_size
        
        if text_length <= 8000:
            # Small-medium: larger chunks, fewer API calls
            return min(4000, text_length)
        elif text_length <= 20000:
            # Medium: balanced
            return 3000
        elif text_length <= 50000:
            # Large: standard chunks
            return 3000
        else:
            # Very large (50K+): slightly larger chunks to control count
            return 4000
    
    def _split_by_sections(self, text: str) -> Optional[List[Dict]]:
        """
        Split text by detected section boundaries.
        
        Medical documents often have clear sections:
        EDUCATION, TRAINING, LICENSES, EMPLOYMENT, etc.
        
        Returns:
            List of {'text': str, 'section_name': str, 'start': int, 'end': int}
            or None if no clear sections detected
        """
        # Find all section boundary positions
        boundaries = set()
        boundary_names = {}
        
        for pattern in COMPILED_SECTION_PATTERNS:
            for match in pattern.finditer(text):
                pos = match.start()
                # Snap to line start
                line_start = text.rfind('\n', 0, pos)
                line_start = line_start + 1 if line_start >= 0 else 0
                boundaries.add(line_start)
                
                # Extract section name (first 50 chars of the match)
                name = text[line_start:line_start + 50].strip().split('\n')[0].strip()
                boundary_names[line_start] = name
        
        if len(boundaries) < 2:
            return None  # Not enough sections to split
        
        # Sort boundaries and create sections
        sorted_boundaries = sorted(boundaries)
        sections = []
        
        for i, start in enumerate(sorted_boundaries):
            end = sorted_boundaries[i + 1] if i + 1 < len(sorted_boundaries) else len(text)
            section_text = text[start:end].strip()
            
            if section_text:  # Skip empty sections
                sections.append({
                    'text': section_text,
                    'section_name': boundary_names.get(start, f'section_{i}'),
                    'start': start,
                    'end': end
                })
        
        # Handle text before first section
        if sorted_boundaries[0] > 0:
            preamble = text[:sorted_boundaries[0]].strip()
            if preamble:
                sections.insert(0, {
                    'text': preamble,
                    'section_name': 'header',
                    'start': 0,
                    'end': sorted_boundaries[0]
                })
        
        return sections if len(sections) >= 2 else None
    
    def _sections_to_chunks(self, sections: List[Dict], doc_id: str) -> List[Dict]:
        """
        Convert sections to chunks, merging small sections and splitting large ones.
        
        Rules:
        - Sections smaller than min_chunk_size get merged with neighbors
        - Sections larger than max_chunk_size get sub-split by paragraphs
        - No data is ever dropped
        """
        chunks = []
        buffer_text = ""
        buffer_start = 0
        
        for section in sections:
            section_text = section['text']
            
            if len(buffer_text) + len(section_text) <= self.target_chunk_size:
                # Merge small section into buffer
                if buffer_text:
                    buffer_text += "\n\n" + section_text
                else:
                    buffer_text = section_text
                    buffer_start = section['start']
            else:
                # Flush buffer if it has content
                if buffer_text:
                    if len(buffer_text) > self.max_chunk_size:
                        # Buffer too large - sub-split it
                        sub_chunks = self._split_with_overlap(
                            buffer_text, doc_id, self.target_chunk_size
                        )
                        chunks.extend(sub_chunks)
                    else:
                        chunks.append(self._make_chunk(
                            buffer_text, doc_id, len(chunks), -1,
                            buffer_start, buffer_start + len(buffer_text)
                        ))
                
                # Start new buffer with current section
                if len(section_text) > self.max_chunk_size:
                    # Section itself is too large - sub-split
                    sub_chunks = self._split_with_overlap(
                        section_text, doc_id, self.target_chunk_size
                    )
                    chunks.extend(sub_chunks)
                    buffer_text = ""
                    buffer_start = section['end']
                else:
                    buffer_text = section_text
                    buffer_start = section['start']
        
        # Flush remaining buffer
        if buffer_text:
            if len(buffer_text) > self.max_chunk_size:
                sub_chunks = self._split_with_overlap(
                    buffer_text, doc_id, self.target_chunk_size
                )
                chunks.extend(sub_chunks)
            else:
                chunks.append(self._make_chunk(
                    buffer_text, doc_id, len(chunks), -1,
                    buffer_start, buffer_start + len(buffer_text)
                ))
        
        # Fix indices
        total = len(chunks)
        for i, chunk in enumerate(chunks):
            chunk['chunk_index'] = i
            chunk['total_chunks'] = total
            chunk['chunk_id'] = f"{doc_id}_chunk_{i}"
        
        return chunks
    
    def _split_with_overlap(self, text: str, doc_id: str, 
                            chunk_size: int) -> List[Dict]:
        """
        Split text into overlapping chunks at sentence boundaries.
        
        ZERO DATA LOSS guaranteed:
        - No max_chunks limit
        - Every sentence appears in at least one chunk
        - Overlap ensures context at boundaries
        
        Args:
            text: Text to split
            doc_id: Document identifier
            chunk_size: Target chunk size
            
        Returns:
            List of chunk dicts
        """
        # Split into paragraphs first, then sentences within paragraphs
        paragraphs = self._split_paragraphs(text)
        
        # Flatten to sentence-level units while preserving paragraph structure
        units = []
        for para in paragraphs:
            sentences = self._split_sentences(para)
            for sent in sentences:
                if sent.strip():
                    units.append(sent.strip())
            # Add paragraph break marker
            units.append("")  # Empty string = paragraph break
        
        # Remove trailing empty
        while units and units[-1] == "":
            units.pop()
        
        chunks = []
        current_units = []
        current_size = 0
        char_position = 0
        chunk_start = 0
        
        for unit in units:
            unit_size = len(unit) + 1  # +1 for joining space/newline
            
            if unit == "":
                # Paragraph break - add newline
                if current_units:
                    current_units.append("\n")
                    current_size += 1
                continue
            
            # Check if adding this unit would exceed chunk size
            if current_size + unit_size > chunk_size and current_units:
                # Save current chunk
                chunk_text = self._join_units(current_units)
                chunk_end = chunk_start + len(chunk_text)
                
                chunks.append(self._make_chunk(
                    chunk_text, doc_id, len(chunks), -1,
                    chunk_start, chunk_end
                ))
                
                # Create overlap: take last N characters worth of units
                overlap_units = self._get_overlap_units(
                    current_units, self.overlap_size
                )
                
                # Start new chunk with overlap
                current_units = overlap_units + [unit]
                current_size = sum(len(u) + 1 for u in current_units)
                chunk_start = chunk_end - sum(len(u) + 1 for u in overlap_units)
            else:
                current_units.append(unit)
                current_size += unit_size
        
        # CRITICAL: Don't forget the last chunk!
        if current_units:
            chunk_text = self._join_units(current_units)
            chunks.append(self._make_chunk(
                chunk_text, doc_id, len(chunks), -1,
                chunk_start, chunk_start + len(chunk_text)
            ))
        
        # Fix total_chunks
        total = len(chunks)
        for i, chunk in enumerate(chunks):
            chunk['chunk_index'] = i
            chunk['total_chunks'] = total
            chunk['chunk_id'] = f"{doc_id}_chunk_{i}"
        
        return chunks
    
    def _split_paragraphs(self, text: str) -> List[str]:
        """Split text into paragraphs (double newline or multiple newlines)"""
        # Split on 2+ newlines
        paragraphs = re.split(r'\n{2,}', text)
        return [p.strip() for p in paragraphs if p.strip()]
    
    def _split_sentences(self, text: str) -> List[str]:
        """
        Split text into sentences with medical-document-aware rules.
        
        Handles:
        - Standard sentence endings (. ! ?)
        - Abbreviations (Dr., Mr., St., etc.) - avoids false splits
        - Medical abbreviations (M.D., D.O., Ph.D.)
        - Numbered lists (1. 2. 3.)
        - Dates (Jan. Feb. etc.)
        """
        # Protect common abbreviations from being split points
        protected = text
        abbreviations = [
            'Dr.', 'Mr.', 'Mrs.', 'Ms.', 'Jr.', 'Sr.', 'St.', 'Ave.',
            'M.D.', 'D.O.', 'Ph.D.', 'D.D.S.', 'D.M.D.', 'R.N.', 'L.P.N.',
            'N.P.', 'P.A.', 'D.P.M.', 'O.D.', 'D.C.', 'Pharm.D.',
            'Inc.', 'Ltd.', 'Corp.', 'vs.', 'etc.', 'i.e.', 'e.g.',
            'Jan.', 'Feb.', 'Mar.', 'Apr.', 'Jun.', 'Jul.', 'Aug.',
            'Sep.', 'Oct.', 'Nov.', 'Dec.',
            'No.', 'Ste.', 'Dept.', 'Div.', 'Vol.',
        ]
        
        for abbr in abbreviations:
            # Replace period with placeholder
            protected = protected.replace(abbr, abbr.replace('.', '{{DOT}}'))
        
        # Split on sentence-ending punctuation followed by space + uppercase
        # or followed by newline
        sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z\d])|(?<=[.!?])\s*\n', protected)
        
        # Restore periods
        sentences = [s.replace('{{DOT}}', '.').strip() for s in sentences]
        
        return [s for s in sentences if s]
    
    def _get_overlap_units(self, units: List[str], target_size: int) -> List[str]:
        """
        Get the last N characters worth of units for overlap.
        
        Always takes complete sentences - never cuts mid-sentence.
        """
        if not units:
            return []
        
        # Walk backwards collecting units until we hit target_size
        overlap = []
        total_size = 0
        
        for unit in reversed(units):
            if unit == "\n":
                continue
            unit_size = len(unit) + 1
            if total_size + unit_size > target_size and overlap:
                break
            overlap.insert(0, unit)
            total_size += unit_size
        
        return overlap
    
    def _join_units(self, units: List[str]) -> str:
        """Join text units, handling paragraph breaks"""
        result = []
        for unit in units:
            if unit == "\n":
                if result and result[-1] != "\n\n":
                    result.append("\n\n")
            elif unit.strip():
                result.append(unit)
        
        return " ".join(result).replace("  ", " ").strip()
    
    def _make_chunk(self, text: str, doc_id: str, index: int,
                    total: int, start_char: int, end_char: int) -> Dict:
        """Create a chunk dictionary with metadata"""
        return {
            'chunk_id': f"{doc_id}_chunk_{index}",
            'text': text.strip(),
            'chunk_index': index,
            'total_chunks': total,
            'start_char': start_char,
            'end_char': end_char,
            'char_count': len(text.strip()),
            'estimated_tokens': len(text.strip()) // 4  # Rough: 4 chars ≈ 1 token
        }
    
    def _validate_coverage(self, original_text: str, chunks: List[Dict]) -> bool:
        """
        Validate that chunks cover 100% of the original text.
        
        Checks that every sentence from the original appears in at least one chunk.
        This is the GUARANTEE of zero data loss.
        
        Args:
            original_text: The full original text
            chunks: The generated chunks
            
        Returns:
            True if 100% coverage, False if any data was lost
        """
        if not chunks:
            return False
        
        # Extract key phrases from original (every 200-char window)
        # This is a spot-check, not exhaustive, but catches most data loss
        original_clean = original_text.strip()
        chunk_combined = " ".join(c['text'] for c in chunks)
        
        # Check that key segments from original appear in chunks
        check_points = range(0, len(original_clean), 200)
        missing = 0
        
        for pos in check_points:
            # Take a 50-char sample at this position
            sample = original_clean[pos:pos + 50].strip()
            if len(sample) < 10:
                continue
            
            # Normalize whitespace for comparison
            sample_normalized = re.sub(r'\s+', ' ', sample)
            combined_normalized = re.sub(r'\s+', ' ', chunk_combined)
            
            if sample_normalized not in combined_normalized:
                missing += 1
                logger.warning(f"Coverage gap at position {pos}: '{sample[:30]}...'")
        
        total_checks = len(list(check_points))
        if total_checks == 0:
            return True
        
        coverage_pct = (total_checks - missing) / total_checks * 100
        
        if coverage_pct < 95:
            logger.error(f"Coverage only {coverage_pct:.1f}% - data loss detected!")
            return False
        
        if coverage_pct < 100:
            logger.warning(f"Coverage {coverage_pct:.1f}% - minor gaps (likely whitespace)")
        
        return True
    
    def _raw_split_fallback(self, text: str, doc_id: str,
                            chunk_size: int) -> List[Dict]:
        """
        Emergency fallback: simple character-based split at word boundaries.
        
        Used only if all other methods fail coverage validation.
        Guarantees zero data loss by including ALL text.
        """
        chunks = []
        pos = 0
        
        while pos < len(text):
            end = min(pos + chunk_size, len(text))
            
            # Don't cut mid-word
            if end < len(text):
                # Find last space before end
                last_space = text.rfind(' ', pos, end)
                if last_space > pos:
                    end = last_space
            
            chunk_text = text[pos:end].strip()
            if chunk_text:
                chunks.append(self._make_chunk(
                    chunk_text, doc_id, len(chunks), -1, pos, end
                ))
            
            # Move forward, but overlap
            pos = end - self.overlap_size if end < len(text) else end
        
        # Fix totals
        total = len(chunks)
        for i, chunk in enumerate(chunks):
            chunk['chunk_index'] = i
            chunk['total_chunks'] = total
            chunk['chunk_id'] = f"{doc_id}_chunk_{i}"
        
        return chunks
    
    def get_chunk_summary(self, chunks: List[Dict]) -> Dict:
        """Get summary statistics for chunks"""
        if not chunks:
            return {
                'total_chunks': 0,
                'avg_chunk_size': 0,
                'total_text_length': 0,
                'min_chunk_size': 0,
                'max_chunk_size': 0,
                'estimated_total_tokens': 0
            }
        
        chunk_sizes = [c.get('char_count', len(c['text'])) for c in chunks]
        return {
            'total_chunks': len(chunks),
            'avg_chunk_size': sum(chunk_sizes) // len(chunks),
            'total_text_length': sum(chunk_sizes),
            'min_chunk_size': min(chunk_sizes),
            'max_chunk_size': max(chunk_sizes),
            'estimated_total_tokens': sum(chunk_sizes) // 4
        }


# =============================================================================
# BACKWARD-COMPATIBLE WRAPPER
# =============================================================================

class SemanticChunker(SemanticChunkerV2):
    """
    Backward-compatible wrapper for SemanticChunkerV2.
    
    Maintains the same API as the original SemanticChunker
    but uses the improved zero-data-loss logic internally.
    """
    
    def __init__(self, chunk_size: int = 3000, overlap: int = 300, 
                 max_chunks: int = None):
        """
        Initialize with v1-compatible parameters.
        
        NOTE: max_chunks is IGNORED in v2 (zero data loss guarantee).
        It's kept in the signature for backward compatibility only.
        """
        if max_chunks is not None:
            logger.info(f"NOTE: max_chunks={max_chunks} is ignored in v2 "
                       f"(zero data loss guarantee)")
        
        super().__init__(
            target_chunk_size=chunk_size,
            overlap_size=overlap,
            adaptive=True
        )
    
    def should_chunk(self, text: str) -> bool:
        """Check if text needs chunking (v1 compatible)"""
        return len(text) > self.target_chunk_size
    
    def chunk_text(self, text: str, document_id: str = "") -> List[Dict]:
        """
        Chunk text (v1 compatible method name).
        Internally calls the v2 chunk_document method.
        """
        return self.chunk_document(text, document_id)


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def process_for_chunking(text: str, config: dict, 
                         document_id: str = "") -> Tuple[bool, List[Dict], str]:
    """
    Process document text for chunking (backward compatible).
    
    Args:
        text: Document text
        config: RAG configuration
        document_id: Document identifier
    
    Returns:
        Tuple of (needs_chunking, chunks_or_none, strategy)
    """
    if not config.get('enable_priority_chunking', True):
        return False, None, 'no_chunking_disabled'
    
    chunk_size = config.get('chunk_size', 3000)
    overlap = config.get('chunk_overlap', 300)
    
    # NOTE: max_chunks from config is intentionally ignored
    # Zero data loss means we create as many chunks as needed
    
    chunker = SemanticChunkerV2(
        target_chunk_size=chunk_size,
        overlap_size=overlap,
        adaptive=True
    )
    
    if not chunker.should_chunk(text):
        return False, None, 'no_chunking_small'
    
    chunks = chunker.chunk_document(text, document_id)
    
    strategy = 'section_based' if len(chunks) > 1 else 'single_chunk'
    
    return True, chunks, strategy


def chunk_for_rag(text: str, doc_id: str = "",
                  chunk_size: int = 3000, overlap: int = 300) -> List[Dict]:
    """
    Simple chunking function for RAG pipelines.
    
    Args:
        text: Document text to chunk
        doc_id: Document identifier
        chunk_size: Target chunk size in characters
        overlap: Overlap size in characters
        
    Returns:
        List of chunk dicts (always at least 1, covers 100% of text)
    """
    chunker = SemanticChunkerV2(
        target_chunk_size=chunk_size,
        overlap_size=overlap
    )
    return chunker.chunk_document(text, doc_id)
