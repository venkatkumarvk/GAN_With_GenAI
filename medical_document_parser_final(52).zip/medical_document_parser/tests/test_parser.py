"""
Test Suite - Medical Document Parser
=====================================
DYNAMIC: Auto-discovers doctypes and prompt files from config.
No need to edit this file when adding new doctypes.

Run:
  cd medical_document_parser
  python tests/test_parser.py

  Or: python -m tests.test_parser
"""

import sys
import os
import json
import importlib

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))


# =============================================================================
# HELPERS
# =============================================================================

def load_config():
    config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'config.json')
    with open(config_path) as f:
        return json.load(f)


def discover_prompt_modules():
    """Auto-discover all prompt modules in prompts/ folder."""
    prompts_dir = os.path.join(os.path.dirname(__file__), '..', 'prompts')
    modules = {}
    for fname in os.listdir(prompts_dir):
        if fname.endswith('_prompt.py') and fname != '__init__.py':
            module_name = fname.replace('.py', '')
            doctype = module_name.replace('_prompt', '')
            try:
                mod = importlib.import_module(f'prompts.{module_name}')
                modules[doctype] = mod
            except Exception as e:
                print(f"  WARNING: Could not load prompts.{module_name}: {e}")
    return modules


# =============================================================================
# TEST 1: CONFIGURATION
# =============================================================================

def test_config_loads():
    """Config loads and has all required top-level keys."""
    config = load_config()
    required_keys = ['extraction', 'rag', 'doctypes', 'log', 'sql_logging',
                     'azure_blob', 'costs', 'processing']
    for key in required_keys:
        assert key in config, f"Missing required key: '{key}'"
    print("  PASS: config.json has all required keys")


def test_config_no_logging_conflict():
    """Config should NOT have 'logging' key (only 'log' and 'sql_logging')."""
    config = load_config()
    assert 'logging' not in config, \
        "Found 'logging' key in config -- use 'log' for file logging and 'sql_logging' for SQL logging"
    assert 'log' in config, "Missing 'log' key for file logging"
    assert 'sql_logging' in config, "Missing 'sql_logging' key for SQL logging"
    print("  PASS: no 'logging' conflict ('log' + 'sql_logging' only)")


def test_config_log_section():
    """Log section has prefix, directory, level."""
    config = load_config()
    log = config['log']
    assert 'prefix' in log, "log missing 'prefix'"
    assert 'directory' in log, "log missing 'directory'"
    assert 'level' in log, "log missing 'level'"
    assert log['level'] in ['DEBUG', 'INFO', 'WARNING', 'ERROR'], f"Invalid log level: {log['level']}"
    print(f"  PASS: log section valid (prefix={log['prefix']}, level={log['level']})")


def test_config_sql_logging_section():
    """SQL logging section has enabled and table_name."""
    config = load_config()
    sql = config['sql_logging']
    assert 'enabled' in sql, "sql_logging missing 'enabled'"
    assert 'table_name' in sql, "sql_logging missing 'table_name'"
    assert isinstance(sql['enabled'], bool), "sql_logging.enabled should be boolean"
    print(f"  PASS: sql_logging valid (enabled={sql['enabled']}, table={sql['table_name']})")


def test_config_extraction():
    """Extraction config has required settings."""
    config = load_config()
    ext = config['extraction']
    assert 'confidence_threshold' in ext, "Missing confidence_threshold"
    assert 'parallel_workers' in ext, "Missing parallel_workers"
    assert 0 < ext['confidence_threshold'] <= 1.0, f"Invalid threshold: {ext['confidence_threshold']}"
    assert ext['parallel_workers'] >= 1, f"Invalid parallel_workers: {ext['parallel_workers']}"
    print(f"  PASS: extraction config (threshold={ext['confidence_threshold']}, workers={ext['parallel_workers']})")


def test_config_doctypes_have_fields():
    """Each doctype in config has folder_configs with fields."""
    config = load_config()
    for doctype, dt_config in config['doctypes'].items():
        assert 'folder_configs' in dt_config, f"doctype '{doctype}' missing folder_configs"
        for folder, folder_cfg in dt_config['folder_configs'].items():
            assert 'fields' in folder_cfg, f"doctype '{doctype}' folder '{folder}' missing fields"
            assert len(folder_cfg['fields']) > 0, f"doctype '{doctype}' folder '{folder}' has empty fields"
    print(f"  PASS: all {len(config['doctypes'])} doctypes have folder_configs with fields")


def test_config_costs():
    """Cost config has all pricing fields."""
    config = load_config()
    costs = config['costs']
    required = ['gpt_input_per_1k_tokens', 'gpt_output_per_1k_tokens',
                'embedding_per_1k_tokens', 'ocr_per_page']
    for key in required:
        assert key in costs, f"Missing cost: {key}"
        assert isinstance(costs[key], (int, float)), f"Cost {key} should be numeric"
    print("  PASS: all cost pricing fields present")


# =============================================================================
# TEST 2: DYNAMIC FIELD LIBRARY VALIDATION (auto-discovers all prompt modules)
# =============================================================================

def test_all_prompt_modules():
    """Auto-discover and validate ALL prompt modules."""
    modules = discover_prompt_modules()
    assert len(modules) > 0, "No prompt modules found in prompts/"
    
    for doctype, mod in modules.items():
        assert hasattr(mod, 'FIELD_LIBRARY'), f"{doctype}_prompt.py missing FIELD_LIBRARY"
        assert hasattr(mod, 'SYSTEM_PROMPT_CONFIG'), f"{doctype}_prompt.py missing SYSTEM_PROMPT_CONFIG"
        print(f"  PASS: {doctype}_prompt.py has FIELD_LIBRARY + SYSTEM_PROMPT_CONFIG")


def test_field_library_structure_all():
    """All fields in all prompt modules have correct structure."""
    modules = discover_prompt_modules()
    
    for doctype, mod in modules.items():
        library = mod.FIELD_LIBRARY
        single_count = 0
        multi_count = 0
        
        for field_name, field_info in library.items():
            assert 'cardinality' in field_info, f"[{doctype}] {field_name}: missing cardinality"
            assert 'description' in field_info, f"[{doctype}] {field_name}: missing description"
            assert 'extraction_hints' in field_info, f"[{doctype}] {field_name}: missing extraction_hints"
            assert len(field_info['extraction_hints']) > 0, f"[{doctype}] {field_name}: empty extraction_hints"
            
            if field_info['cardinality'] == 'single':
                single_count += 1
            elif field_info['cardinality'] == 'multi':
                multi_count += 1
                assert 'item_fields' in field_info, f"[{doctype}] {field_name}: multi missing item_fields"
                assert 'examples' in field_info, f"[{doctype}] {field_name}: multi missing examples"
                assert 'format' in field_info, f"[{doctype}] {field_name}: multi missing format"
                assert 'confidence_factors' in field_info, f"[{doctype}] {field_name}: multi missing confidence_factors"
                assert isinstance(field_info['examples'], list), f"[{doctype}] {field_name}: examples not list"
                if field_info['examples']:
                    assert isinstance(field_info['examples'][0], dict), f"[{doctype}] {field_name}: multi examples should be list of dicts"
        
        print(f"  PASS: [{doctype}] {single_count} single + {multi_count} multi = {len(library)} fields validated")


def test_multi_value_normalize_hints_all():
    """All multi-value fields in all prompt modules have NORMALIZE + DEDUPLICATE hints."""
    modules = discover_prompt_modules()
    
    for doctype, mod in modules.items():
        library = mod.FIELD_LIBRARY
        multi_fields = [f for f, v in library.items() if v['cardinality'] == 'multi']
        
        for field_name in multi_fields:
            hints = ' '.join(library[field_name].get('extraction_hints', []))
            assert 'NORMALIZE' in hints, f"[{doctype}] {field_name}: missing NORMALIZE hint"
            assert 'DEDUPLICATE' in hints, f"[{doctype}] {field_name}: missing DEDUPLICATE hint"
        
        print(f"  PASS: [{doctype}] all {len(multi_fields)} multi-value fields have NORMALIZE + DEDUPLICATE")


def test_no_na_unknown_in_rules_all():
    """No NA/Unknown/Not found in extraction rules for any prompt module."""
    modules = discover_prompt_modules()
    
    for doctype, mod in modules.items():
        rules = mod.SYSTEM_PROMPT_CONFIG.get('extraction_rules', [])
        rules_text = ' '.join(rules)
        assert "'NA'" not in rules_text, f"[{doctype}] Found 'NA' in extraction_rules"
        assert "'Unknown'" not in rules_text, f"[{doctype}] Found 'Unknown' in extraction_rules"
        assert "'Not found'" not in rules_text, f"[{doctype}] Found 'Not found' in extraction_rules"
        print(f"  PASS: [{doctype}] no NA/Unknown/Not found in rules")


def test_config_fields_exist_in_library():
    """Every field listed in config.json exists in the corresponding FIELD_LIBRARY."""
    config = load_config()
    modules = discover_prompt_modules()
    
    for doctype, dt_config in config['doctypes'].items():
        if doctype not in modules:
            print(f"  SKIP: [{doctype}] no prompt module found")
            continue
        
        library = modules[doctype].FIELD_LIBRARY
        
        for folder, folder_cfg in dt_config['folder_configs'].items():
            for field in folder_cfg['fields']:
                assert field in library, \
                    f"[{doctype}] field '{field}' in config folder '{folder}' not found in FIELD_LIBRARY"
        
        print(f"  PASS: [{doctype}] all config fields exist in FIELD_LIBRARY")


# =============================================================================
# TEST 3: SINGLE-VALUE AGGREGATION
# =============================================================================

def test_single_value_frequency_wins():
    """Most frequent value wins in aggregation."""
    from main import calculate_best_values
    modules = discover_prompt_modules()
    mod = list(modules.values())[0]
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {'first_name': {'value': 'John', 'confidence': 0.95}}},
        {'document_name': 'doc2.pdf', 'fields': {'first_name': {'value': 'John', 'confidence': 0.90}}},
        {'document_name': 'doc3.pdf', 'fields': {'first_name': {'value': 'Jonathan', 'confidence': 0.70}}},
    ]
    
    result = calculate_best_values(documents, ['first_name'], 'Data', prompt_module=mod)
    assert result['first_name']['value'] == 'John'
    assert result['first_name']['frequency'] == 2
    print("  PASS: most frequent value wins")


def test_single_value_confidence_tiebreak():
    """Equal frequency → higher confidence wins."""
    from main import _aggregate_single_field
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {'email': {'value': 'john@a.com', 'confidence': 0.70}}},
        {'document_name': 'doc2.pdf', 'fields': {'email': {'value': 'john@b.com', 'confidence': 0.95}}},
    ]
    
    result = _aggregate_single_field('email', documents, 'Data')
    # Both have frequency 1, higher confidence should win
    assert result['value'] in ['john@a.com', 'john@b.com'], "Should pick one of the values"
    print(f"  PASS: equal frequency tiebreak works (picked '{result['value']}')")


def test_single_value_empty_skipped():
    """Empty values should not win over real values."""
    from main import calculate_best_values
    modules = discover_prompt_modules()
    mod = list(modules.values())[0]
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {'email': {'value': '', 'confidence': 0.0}}},
        {'document_name': 'doc2.pdf', 'fields': {'email': {'value': '', 'confidence': 0.0}}},
        {'document_name': 'doc3.pdf', 'fields': {'email': {'value': 'john@test.com', 'confidence': 0.85}}},
    ]
    
    result = calculate_best_values(documents, ['email'], 'Data', prompt_module=mod)
    assert result['email']['value'] == 'john@test.com'
    print("  PASS: empty values don't win over real values")


def test_single_value_all_empty():
    """All empty → returns empty with 0 confidence."""
    from main import calculate_best_values
    modules = discover_prompt_modules()
    mod = list(modules.values())[0]
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {'ssn': {'value': '', 'confidence': 0.0}}},
        {'document_name': 'doc2.pdf', 'fields': {'ssn': {'value': '', 'confidence': 0.0}}},
    ]
    
    result = calculate_best_values(documents, ['ssn'], 'Data', prompt_module=mod)
    assert result['ssn']['value'] == ''
    print("  PASS: all empty → returns empty")


# =============================================================================
# TEST 4: MULTI-VALUE AGGREGATION & DEDUPLICATION
# =============================================================================

def test_multi_dedup_same_license_diff_docs():
    """Same license from different docs = 1 entry."""
    from main import _aggregate_multi_field
    modules = discover_prompt_modules()
    mod = list(modules.values())[0]
    field_info = mod.FIELD_LIBRARY.get('state_licenses', {})
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {'state_licenses': [
            {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.96},
             'license_state': {'value': 'KY', 'confidence': 0.96},
             'license_issue_date': {'value': '', 'confidence': 0.0},
             'license_expiration_date': {'value': '12/31/2025', 'confidence': 0.90},
             'license_status': {'value': 'Active', 'confidence': 0.85}}
        ]}},
        {'document_name': 'doc2.pdf', 'fields': {'state_licenses': [
            {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.94},
             'license_state': {'value': 'KY', 'confidence': 0.98},
             'license_issue_date': {'value': '01/15/2020', 'confidence': 0.80},
             'license_expiration_date': {'value': '', 'confidence': 0.0},
             'license_status': {'value': '', 'confidence': 0.0}}
        ]}},
    ]
    
    result = _aggregate_multi_field('state_licenses', documents, 'Data', field_info)
    assert len(result) == 1, f"Expected 1 deduplicated, got {len(result)}"
    assert result[0]['license_number']['frequency'] == 2
    print("  PASS: same license from 2 docs = 1 entry (frequency 2)")


def test_multi_dedup_different_licenses():
    """Different license numbers = separate entries."""
    from main import _aggregate_multi_field
    modules = discover_prompt_modules()
    mod = list(modules.values())[0]
    field_info = mod.FIELD_LIBRARY.get('state_licenses', {})
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {'state_licenses': [
            {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.96},
             'license_state': {'value': 'KY', 'confidence': 0.96}},
            {'id': 2, 'license_number': {'value': 'MD-12345', 'confidence': 0.90},
             'license_state': {'value': 'NY', 'confidence': 0.88}}
        ]}},
    ]
    
    result = _aggregate_multi_field('state_licenses', documents, 'Data', field_info)
    assert len(result) == 2, f"Expected 2 licenses, got {len(result)}"
    print("  PASS: 2 different licenses = 2 entries")


def test_multi_dedup_case_insensitive():
    """Dedup should be case-insensitive (KY vs ky = same)."""
    from main import _aggregate_multi_field
    modules = discover_prompt_modules()
    mod = list(modules.values())[0]
    field_info = mod.FIELD_LIBRARY.get('state_licenses', {})
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {'state_licenses': [
            {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.96},
             'license_state': {'value': 'KY', 'confidence': 0.96}}
        ]}},
        {'document_name': 'doc2.pdf', 'fields': {'state_licenses': [
            {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.90},
             'license_state': {'value': 'ky', 'confidence': 0.88}}
        ]}},
    ]
    
    result = _aggregate_multi_field('state_licenses', documents, 'Data', field_info)
    assert len(result) == 1, f"Expected 1 (case-insensitive dedup), got {len(result)}"
    print("  PASS: case-insensitive dedup (KY == ky)")


def test_multi_empty_returns_empty_array():
    """No multi-value data → empty []."""
    from main import _aggregate_multi_field
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {'dea_licenses': []}},
        {'document_name': 'doc2.pdf', 'fields': {'dea_licenses': []}},
    ]
    
    result = _aggregate_multi_field('dea_licenses', documents, 'Data', {})
    assert result == [], f"Expected [], got {result}"
    print("  PASS: empty multi-value = []")


def test_multi_keeps_highest_confidence():
    """When deduping, keep the version with highest confidence."""
    from main import _aggregate_multi_field
    modules = discover_prompt_modules()
    mod = list(modules.values())[0]
    field_info = mod.FIELD_LIBRARY.get('state_licenses', {})
    
    documents = [
        {'document_name': 'doc1.pdf', 'fields': {'state_licenses': [
            {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.70},
             'license_state': {'value': 'KY', 'confidence': 0.70}}
        ]}},
        {'document_name': 'doc2.pdf', 'fields': {'state_licenses': [
            {'id': 1, 'license_number': {'value': '56359', 'confidence': 0.98},
             'license_state': {'value': 'KY', 'confidence': 0.98}}
        ]}},
    ]
    
    result = _aggregate_multi_field('state_licenses', documents, 'Data', field_info)
    assert len(result) == 1
    assert result[0]['license_number']['confidence'] == 0.98, "Should keep highest confidence version"
    print("  PASS: dedup keeps highest confidence version")


# =============================================================================
# TEST 5: CONFIDENCE ROUTING
# =============================================================================

def test_routing_high_confidence():
    """All high → highconfidence."""
    confidences = _calc_confidences({
        'first_name': {'value': 'John', 'confidence': 0.95},
        'last_name': {'value': 'Smith', 'confidence': 0.90},
    })
    assert min(confidences) >= 0.70
    print("  PASS: all high → highconfidence")


def test_routing_low_confidence():
    """One low → lowconfidence."""
    confidences = _calc_confidences({
        'first_name': {'value': 'John', 'confidence': 0.95},
        'email': {'value': 'maybe@test.com', 'confidence': 0.15},
    })
    assert min(confidences) < 0.70
    print("  PASS: one low (0.15) → lowconfidence")


def test_routing_skips_empty_multi():
    """Empty [] multi-value not counted."""
    confidences = _calc_confidences({
        'first_name': {'value': 'John', 'confidence': 0.95},
        'state_licenses': [],
        'dea_licenses': [],
    })
    assert len(confidences) == 1, f"Expected 1, got {len(confidences)}"
    assert confidences[0] == 0.95
    print("  PASS: empty [] skipped in routing")


def test_routing_empty_string_confidence_skipped():
    """confidence: '' (empty string) should be skipped."""
    confidences = _calc_confidences({
        'first_name': {'value': 'John', 'confidence': 0.95},
        'state_licenses': [
            {'id': 1, 'license_number': {'value': '', 'confidence': ''}}
        ],
    })
    assert len(confidences) == 1
    assert confidences[0] == 0.95
    print("  PASS: confidence '' skipped")


def test_routing_zero_confidence_counted():
    """confidence: 0.0 is real and should be counted."""
    confidences = _calc_confidences({
        'first_name': {'value': 'John', 'confidence': 0.95},
        'email': {'value': '', 'confidence': 0.0},
    })
    assert 0.0 in confidences
    assert min(confidences) == 0.0
    print("  PASS: confidence 0.0 counted (real value)")


def _calc_confidences(extracted_data):
    """Helper: replicate confidence routing logic from save_results."""
    confidences = []
    for field_data in extracted_data.values():
        if isinstance(field_data, dict) and 'confidence' in field_data:
            conf = field_data.get('confidence', 0)
            if isinstance(conf, (int, float)):
                confidences.append(conf)
        elif isinstance(field_data, list):
            for item in field_data:
                if isinstance(item, dict):
                    item_confs = []
                    for key, val in item.items():
                        if key == 'id':
                            continue
                        if isinstance(val, dict) and 'confidence' in val:
                            conf = val.get('confidence')
                            if isinstance(conf, (int, float)):
                                item_confs.append(conf)
                    if item_confs:
                        confidences.append(sum(item_confs) / len(item_confs))
    return confidences


# =============================================================================
# TEST 6: PROMPT BUILDER
# =============================================================================

def test_prompt_single_field():
    """Prompt builds for single-value field."""
    from extraction.text_rag import _build_field_prompt
    modules = discover_prompt_modules()
    mod = list(modules.values())[0]
    library = mod.FIELD_LIBRARY
    
    # Pick first single field
    single_field = next(f for f, v in library.items() if v['cardinality'] == 'single')
    
    prompt = _build_field_prompt(
        field_name=single_field,
        field_info=library[single_field],
        similar_docs=[{'content': 'Test content', 'score': 0.95}],
        fallback_text='',
        system_config=mod.SYSTEM_PROMPT_CONFIG
    )
    
    assert single_field in prompt
    assert 'FIELD DEFINITION' in prompt
    assert 'confidence' in prompt
    print(f"  PASS: prompt builds for single field '{single_field}'")


def test_prompt_multi_field():
    """Prompt builds for multi-value field with sub-field descriptions."""
    from extraction.text_rag import _build_field_prompt
    modules = discover_prompt_modules()
    mod = list(modules.values())[0]
    library = mod.FIELD_LIBRARY
    
    # Pick first multi field
    multi_field = next(f for f, v in library.items() if v['cardinality'] == 'multi')
    
    prompt = _build_field_prompt(
        field_name=multi_field,
        field_info=library[multi_field],
        similar_docs=[{'content': 'Test content', 'score': 0.90}],
        fallback_text='',
        system_config=mod.SYSTEM_PROMPT_CONFIG
    )
    
    assert multi_field in prompt
    assert 'Do NOT return empty array' in prompt
    assert 'Sub-field descriptions' in prompt
    print(f"  PASS: prompt builds for multi field '{multi_field}'")


def test_prompt_has_confidence_guidance():
    """Multi-value prompt includes confidence scoring guidance."""
    from extraction.text_rag import _build_field_prompt
    modules = discover_prompt_modules()
    mod = list(modules.values())[0]
    library = mod.FIELD_LIBRARY
    
    multi_field = next(f for f, v in library.items() if v['cardinality'] == 'multi')
    
    prompt = _build_field_prompt(
        field_name=multi_field,
        field_info=library[multi_field],
        similar_docs=[{'content': 'Test', 'score': 0.90}],
        fallback_text='',
        system_config=mod.SYSTEM_PROMPT_CONFIG
    )
    
    assert 'Confidence scoring guidance' in prompt or 'confidence' in prompt.lower()
    print(f"  PASS: prompt includes confidence guidance")


# =============================================================================
# TEST 7: JSON OUTPUT STRUCTURE
# =============================================================================

def test_json_uses_data_key():
    """Output uses 'data' not 'fields'."""
    json_output = {
        'provider_name': 'TEST',
        'data': {'first_name': {'value': 'John'}},
    }
    assert 'data' in json_output
    assert 'fields' not in json_output
    print("  PASS: JSON uses 'data' key")


def test_json_empty_values_are_empty_string():
    """Empty values should be '' not NA/Unknown."""
    values = ['', '', '']
    for v in values:
        assert v != 'NA'
        assert v != 'Unknown'
        assert v != 'Not found'
    print("  PASS: empty values use '' not NA/Unknown")


# =============================================================================
# TEST 8: SERVICES
# =============================================================================

def test_sql_logger_disabled():
    """SQL Logger disabled state."""
    from services.sql_logger import SQLLogger
    sl = SQLLogger({'sql_logging': {'enabled': False}})
    assert sl.enabled == False
    assert sl.insert_begin('TEST', 'cred', 'general') is None
    print("  PASS: SQL Logger disabled works")


def test_sql_logger_no_config():
    """SQL Logger with empty config."""
    from services.sql_logger import SQLLogger
    sl = SQLLogger({})
    assert sl.enabled == False
    print("  PASS: SQL Logger empty config works")


def test_cost_tracker():
    """Cost tracker accumulates tokens."""
    from services.cost_tracker import CostTracker
    config = {
        'costs': {
            'gpt_input_per_1k_tokens': 0.01,
            'gpt_output_per_1k_tokens': 0.03,
            'embedding_per_1k_tokens': 0.0001,
            'ocr_per_page': 0.01
        }
    }
    tracker = CostTracker(config)
    tracker.set_provider('TEST')
    tracker.add_gpt_tokens(1000, 500)
    tracker.add_embedding(200)
    tracker.add_ocr(5)
    
    summary = tracker.get_summary()
    assert summary['usage']['gpt_input_tokens'] == 1000
    assert summary['usage']['gpt_output_tokens'] == 500
    assert summary['usage']['embedding_tokens'] == 200
    assert summary['usage']['ocr_pages'] == 5
    print("  PASS: cost tracker accumulates correctly")


def test_cost_tracker_multi_provider():
    """Cost tracker tracks per-provider."""
    from services.cost_tracker import CostTracker
    config = {
        'costs': {
            'gpt_input_per_1k_tokens': 0.01,
            'gpt_output_per_1k_tokens': 0.03,
            'embedding_per_1k_tokens': 0.0001,
            'ocr_per_page': 0.01
        }
    }
    tracker = CostTracker(config)
    
    tracker.set_provider('PROVIDER-A')
    tracker.add_gpt_tokens(500, 200)
    
    tracker.set_provider('PROVIDER-B')
    tracker.add_gpt_tokens(300, 100)
    
    summary = tracker.get_summary()
    assert summary['usage']['gpt_input_tokens'] == 800
    assert 'PROVIDER-A' in summary.get('providers', {})
    print("  PASS: cost tracker per-provider tracking")


# =============================================================================
# TEST 9: SEMANTIC CHUNKER
# =============================================================================

def test_semantic_chunker():
    """Chunker splits text into chunks."""
    from extraction.semantic_chunker import SemanticChunker
    
    text = "This is a test paragraph. " * 500
    chunker = SemanticChunker()
    chunks = chunker.chunk_document(text)
    
    assert len(chunks) > 0, "Should produce at least 1 chunk"
    assert all('text' in c for c in chunks), "Each chunk should have 'text' key"
    print(f"  PASS: chunker produces {len(chunks)} chunks from long text")


def test_semantic_chunker_short_text():
    """Short text should produce 1 chunk."""
    from extraction.semantic_chunker import SemanticChunker
    
    text = "Short text here."
    chunker = SemanticChunker()
    chunks = chunker.chunk_document(text)
    
    assert len(chunks) >= 1, f"Short text should be at least 1 chunk, got {len(chunks)}"
    assert all('text' in c for c in chunks), "Each chunk should have 'text' key"
    print(f"  PASS: short text = {len(chunks)} chunk(s)")


# =============================================================================
# RUN ALL TESTS
# =============================================================================
if __name__ == '__main__':
    print("\n" + "=" * 65)
    print("  MEDICAL DOCUMENT PARSER - TEST SUITE (DYNAMIC)")
    print("  Auto-discovers all doctypes and prompt modules")
    print("=" * 65 + "\n")
    
    tests = [
        # Config
        ("Config: Loads", test_config_loads),
        ("Config: No Logging Conflict", test_config_no_logging_conflict),
        ("Config: Log Section", test_config_log_section),
        ("Config: SQL Logging Section", test_config_sql_logging_section),
        ("Config: Extraction Settings", test_config_extraction),
        ("Config: Doctypes Have Fields", test_config_doctypes_have_fields),
        ("Config: Costs", test_config_costs),
        
        # Field Library (dynamic)
        ("Fields: All Prompt Modules Exist", test_all_prompt_modules),
        ("Fields: Structure Valid (all doctypes)", test_field_library_structure_all),
        ("Fields: Normalize Hints (all doctypes)", test_multi_value_normalize_hints_all),
        ("Fields: No NA/Unknown (all doctypes)", test_no_na_unknown_in_rules_all),
        ("Fields: Config Fields Match Library", test_config_fields_exist_in_library),
        
        # Single-Value Aggregation
        ("Agg Single: Frequency Wins", test_single_value_frequency_wins),
        ("Agg Single: Confidence Tiebreak", test_single_value_confidence_tiebreak),
        ("Agg Single: Empty Skipped", test_single_value_empty_skipped),
        ("Agg Single: All Empty", test_single_value_all_empty),
        
        # Multi-Value Dedup
        ("Agg Multi: Dedup Same License", test_multi_dedup_same_license_diff_docs),
        ("Agg Multi: Different Licenses", test_multi_dedup_different_licenses),
        ("Agg Multi: Case Insensitive", test_multi_dedup_case_insensitive),
        ("Agg Multi: Empty = []", test_multi_empty_returns_empty_array),
        ("Agg Multi: Keeps Highest Conf", test_multi_keeps_highest_confidence),
        
        # Confidence Routing
        ("Routing: High Confidence", test_routing_high_confidence),
        ("Routing: Low Confidence", test_routing_low_confidence),
        ("Routing: Skips Empty Multi", test_routing_skips_empty_multi),
        ("Routing: Skips '' Confidence", test_routing_empty_string_confidence_skipped),
        ("Routing: 0.0 Counted", test_routing_zero_confidence_counted),
        
        # Prompt Builder
        ("Prompt: Single Field", test_prompt_single_field),
        ("Prompt: Multi Field", test_prompt_multi_field),
        ("Prompt: Confidence Guidance", test_prompt_has_confidence_guidance),
        
        # JSON Output
        ("JSON: Uses 'data' Key", test_json_uses_data_key),
        ("JSON: Empty = '' Not NA", test_json_empty_values_are_empty_string),
        
        # Services
        ("Service: SQL Logger Disabled", test_sql_logger_disabled),
        ("Service: SQL Logger No Config", test_sql_logger_no_config),
        ("Service: Cost Tracker", test_cost_tracker),
        ("Service: Cost Tracker Multi-Provider", test_cost_tracker_multi_provider),
        
        # Chunker
        ("Chunker: Long Text", test_semantic_chunker),
        ("Chunker: Short Text", test_semantic_chunker_short_text),
    ]
    
    passed = 0
    failed = 0
    skipped = 0
    errors = []
    
    for name, test_fn in tests:
        try:
            test_fn()
            passed += 1
        except AssertionError as e:
            failed += 1
            errors.append((name, str(e)))
            print(f"  FAIL: {name}: {e}")
        except Exception as e:
            failed += 1
            errors.append((name, str(e)))
            print(f"  ERROR: {name}: {e}")
    
    print(f"\n{'=' * 65}")
    print(f"  RESULTS: {passed} passed, {failed} failed out of {len(tests)} tests")
    if errors:
        print(f"\n  Failed:")
        for name, err in errors:
            print(f"    ✗ {name}: {err}")
    else:
        print(f"\n  ALL TESTS PASSED")
    print(f"{'=' * 65}\n")
    
    sys.exit(1 if failed > 0 else 0)
