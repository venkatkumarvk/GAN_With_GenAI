# How to Change Extraction Mode

## 🎯 Three Extraction Modes Available

| Mode | When to Use | Cost | Speed |
|------|-------------|------|-------|
| **"auto"** | Mixed documents (text + images) | Medium | Medium |
| **"text"** | All text-based PDFs | Lowest | Fastest |
| **"multimodal"** | All images/scanned documents | Highest | Slowest |

---

## ⚙️ How to Change Mode

### **Edit config.json:**

```json
{
  "rag": {
    "mode": "auto"  ← Change this value
  }
}
```

### **Options:**

```json
"mode": "auto"        ← System decides per document (RECOMMENDED)
"mode": "text"        ← Force text extraction for ALL documents
"mode": "multimodal"  ← Force vision extraction for ALL documents
```

---

## 📊 Mode Details

### **1. AUTO MODE (Recommended)**

```json
"rag": {
  "mode": "auto"
},
"processing": {
  "multimodal_threshold": 50
}
```

**How it works:**
- System checks text length after OCR
- If text < 50 chars → Use vision (multimodal)
- If text >= 50 chars → Use text extraction

**Example:**
```
doc1.pdf → OCR extracts 2500 chars → TEXT mode ✅
doc2.jpg → OCR extracts 15 chars → MULTIMODAL mode ✅
doc3.png → OCR extracts 22 chars → MULTIMODAL mode ✅
```

**When to use:**
- Mixed document types (PDFs + images)
- Want best accuracy per document
- Let system decide automatically

---

### **2. TEXT MODE**

```json
"rag": {
  "mode": "text"
}
```

**Forces text extraction for ALL documents**

**Example:**
```
doc1.pdf → TEXT mode (even if image)
doc2.jpg → TEXT mode (uses OCR text)
doc3.png → TEXT mode (uses OCR text)
```

**When to use:**
- All documents are text-based PDFs
- OCR quality is good
- Want cheapest cost
- Want fastest processing

**Cost:** $0.015 per document average

---

### **3. MULTIMODAL MODE**

```json
"rag": {
  "mode": "multimodal"
}
```

**Forces vision extraction for ALL documents**

**Example:**
```
doc1.pdf → MULTIMODAL mode (uses vision)
doc2.jpg → MULTIMODAL mode (uses vision)
doc3.png → MULTIMODAL mode (uses vision)
```

**When to use:**
- All documents are images/scans
- Poor OCR quality
- Need visual understanding
- Documents have tables/charts

**Cost:** $0.018 per document average

---

## 🎛️ AUTO Mode Threshold

### **Adjust multimodal_threshold:**

```json
"processing": {
  "multimodal_threshold": 50  ← Change this number
}
```

**What it means:**
- Documents with text < threshold → Use VISION
- Documents with text >= threshold → Use TEXT

**Examples:**

```json
// Very aggressive (prefer text)
"multimodal_threshold": 20
→ Only use vision if OCR extracts < 20 chars

// Balanced (default)
"multimodal_threshold": 50
→ Use vision if OCR extracts < 50 chars

// Conservative (prefer vision)
"multimodal_threshold": 100
→ Use vision if OCR extracts < 100 chars
```

---

## 💰 Cost Comparison

### **1000 Documents Example:**

**AUTO Mode (50/50 mix):**
```
500 text docs   × $0.015 = $7.50
500 vision docs × $0.018 = $9.00
Total: $16.50
```

**TEXT Mode (all text):**
```
1000 docs × $0.015 = $15.00
Total: $15.00 (cheapest!)
```

**MULTIMODAL Mode (all vision):**
```
1000 docs × $0.018 = $18.00
Total: $18.00 (most expensive)
```

---

## 📋 Quick Configuration Examples

### **Example 1: All Text PDFs**

```json
{
  "rag": {
    "mode": "text",
    "top_k": 3
  }
}
```

**Use case:** Clean text-based PDF documents

---

### **Example 2: All Scanned Images**

```json
{
  "rag": {
    "mode": "multimodal",
    "top_k": 3
  }
}
```

**Use case:** Scanned documents, license cards, certificates

---

### **Example 3: Mixed Documents (Recommended)**

```json
{
  "rag": {
    "mode": "auto",
    "top_k": 3
  },
  "processing": {
    "multimodal_threshold": 50
  }
}
```

**Use case:** Mix of PDFs and images, let system decide

---

## 🔍 How to Check Which Mode Was Used

### **In Logs:**

```
[1/100] state_license.pdf
  Mode: TEXT (text length: 2547 chars)
✓ Successfully extracted

[2/100] dea_card.jpg
  Mode: MULTIMODAL (text length: 15 chars)
✓ Successfully extracted
```

### **In JSON Output:**

```json
{
  "results": [
    {
      "document_name": "license.pdf",
      "extraction_mode": "text",
      "extracted_fields": {...}
    },
    {
      "document_name": "card.jpg",
      "extraction_mode": "multimodal",
      "extracted_fields": {...}
    }
  ]
}
```

### **In Cost Summary:**

```json
{
  "total_documents": 100,
  "text_mode_count": 65,
  "multimodal_mode_count": 35,
  "costs": {
    "total_estimated": 1.62
  }
}
```

---

## ⚡ Quick Decision Guide

```
Do you have ONLY text PDFs?
  └─ YES → Use "text" mode
  └─ NO → Continue

Do you have ONLY images/scans?
  └─ YES → Use "multimodal" mode
  └─ NO → Continue

Do you have a mix?
  └─ YES → Use "auto" mode (recommended)
```

---

## 🎯 Recommended Settings

### **For Most Users:**

```json
{
  "rag": {
    "mode": "auto"
  },
  "processing": {
    "multimodal_threshold": 50
  }
}
```

**Why:** 
- Handles any document type
- Automatically chooses best mode
- Balanced cost and accuracy
- No manual sorting needed

---

## ✅ Summary

| Setting | Location | Values | Default |
|---------|----------|--------|---------|
| **Mode** | rag.mode | "auto", "text", "multimodal" | "auto" |
| **Threshold** | processing.multimodal_threshold | 20-100 | 50 |

**To change:** Edit config.json → Change these values → Run main.py

**That's it!** No code changes needed! ✅
