"""
Prompt Configuration
====================
All prompt templates and field definitions
Users can edit this file to customize extraction

STRUCTURE:
- FIELD_LIBRARY: Field definitions with examples and hints
- SYSTEM_PROMPT_CONFIG: System-level prompts
- DOCUMENT_TYPE_HINTS: Document type detection hints  
- RAG_PROMPT_TEMPLATE: RAG example formatting
- STANDARD_PROMPT_TEMPLATE: Main extraction prompt
"""

# ============================================================================
# FIELD LIBRARY - Define all extractable fields here
# ============================================================================

FIELD_LIBRARY = {
    # Personal Information
    "first_name": {
        "description": "First/Given name of the individual",
        "examples": ["John", "Mary", "Robert", "Jennifer", "Michael"],
        "format": "Capitalized text, may include middle initial",
        "extraction_hints": [
            "May be split across multiple lines",
            "Check for 'First Name' and 'Given Name' labels",
            "Look for 'Full Name' or 'Name of Holder' sections",
            "Sometimes appears as 'Nom' or 'Name of Holder'",
            "Can be in format: First Middle Last OR Given Names Surname"
        ],
        "confidence_factors": [
            "Clear text with proper spacing",
            "Consistent formatting across document",
            "Matches expected name pattern",
            "Found near expected location (top of document)"
        ]
    },
    
    "last_name": {
        "description": "Last name/surname/family name",
        "examples": ["Smith", "Johnson", "Williams", "Brown", "Davis"],
        "format": "Capitalized text",
        "extraction_hints": [
            "Usually appears after first name",
            "May be labeled as 'Last Name', 'Surname', 'Family Name'",
            "In some formats appears before first name",
            "Check 'Full Name' field"
        ]
    },
    
    "email": {
        "description": "Email address",
        "examples": ["john.smith@email.com", "doctor@hospital.org"],
        "format": "email@domain.com",
        "extraction_hints": [
            "Look for @ symbol",
            "May be in contact section",
            "Check for labels like 'Email', 'E-mail', 'Electronic Mail'"
        ]
    },
    
    "cell": {
        "description": "Cell phone/mobile number",
        "examples": ["555-123-4567", "(555) 123-4567", "5551234567"],
        "format": "10-digit phone number with optional formatting",
        "extraction_hints": [
            "May be labeled as 'Cell', 'Mobile', 'Phone'",
            "Look for 10-digit numbers",
            "May include country code"
        ]
    },
    
    "birth_date": {
        "description": "Date of birth",
        "examples": ["01/15/1980", "1980-01-15", "January 15, 1980"],
        "format": "MM/DD/YYYY or similar date format",
        "extraction_hints": [
            "May be labeled as 'DOB', 'Date of Birth', 'Birth Date'",
            "Check personal information section",
            "Format varies: MM/DD/YYYY, DD/MM/YYYY, YYYY-MM-DD"
        ]
    },
    
    "birth_place": {
        "description": "Place of birth (city/state/country)",
        "examples": ["New York, NY", "Los Angeles, California", "Chicago, IL, USA"],
        "format": "City, State/Province, Country",
        "extraction_hints": [
            "May be labeled as 'Place of Birth', 'Birth Place', 'POB'",
            "Can include just city, or city+state, or full address"
        ]
    },
    
    "birth_city": {
        "description": "City of birth",
        "examples": ["New York", "Los Angeles", "Chicago"],
        "format": "City name",
        "extraction_hints": [
            "Part of birth place information",
            "First component of 'City, State' format"
        ]
    },
    
    "birth_state_province": {
        "description": "State or province of birth",
        "examples": ["California", "NY", "Texas", "Ontario"],
        "format": "State/Province name or abbreviation",
        "extraction_hints": [
            "Second component of 'City, State' format",
            "May be 2-letter abbreviation or full name"
        ]
    },
    
    "birth_country": {
        "description": "Country of birth",
        "examples": ["USA", "United States", "Canada", "United Kingdom"],
        "format": "Country name or code",
        "extraction_hints": [
            "May be abbreviated (USA, UK, etc.)",
            "Look at end of birth place field"
        ]
    },
    
    "citizenship": {
        "description": "Citizenship/nationality",
        "examples": ["US Citizen", "USA", "American", "Dual Citizen"],
        "format": "Country or citizenship status",
        "extraction_hints": [
            "May be labeled as 'Citizenship', 'Nationality'",
            "Can include 'Dual Citizen' or multiple countries"
        ]
    },
    
    "gender": {
        "description": "Gender",
        "examples": ["M", "F", "Male", "Female"],
        "format": "M/F or Male/Female",
        "extraction_hints": [
            "Usually single letter or full word",
            "May be labeled as 'Gender', 'Sex'"
        ]
    },
    
    "ssn": {
        "description": "Social Security Number",
        "examples": ["123-45-6789", "###-##-6789"],
        "format": "XXX-XX-XXXX (9 digits)",
        "extraction_hints": [
            "9 digits, may have dashes",
            "May be partially masked (###-##-1234)",
            "Labeled as 'SSN', 'Social Security Number', 'Social Security No.'"
        ]
    },
    
    # License Information
    "degree": {
        "description": "Medical degree obtained",
        "examples": ["MD", "DO", "MBBS", "Doctor of Medicine"],
        "format": "Abbreviation or full degree name",
        "extraction_hints": [
            "Common: MD, DO, MBBS, DPM, DDS",
            "May be in education section",
            "Check credentials after name"
        ]
    },
    
    "state_license_number": {
        "description": "State medical license number",
        "examples": ["A12345", "MD123456", "12345"],
        "format": "Alphanumeric",
        "extraction_hints": [
            "May be labeled as 'State License', 'Medical License', 'License Number'",
            "Format varies by state",
            "Usually accompanied by state name"
        ]
    },
    
    "state_license_state": {
        "description": "State that issued the medical license",
        "examples": ["CA", "NY", "Texas", "California"],
        "format": "2-letter code or full state name",
        "extraction_hints": [
            "Located near state license number",
            "May say 'State:', 'Issued by:', 'Jurisdiction:'"
        ]
    },
    
    "state_license_expiration": {
        "description": "State license expiration date",
        "examples": ["12/31/2025", "2025-12-31", "Dec 31, 2025"],
        "format": "Date in various formats",
        "extraction_hints": [
            "Labeled as 'Expiration', 'Expires', 'Valid Until', 'Exp Date'",
            "Usually near license number",
            "Check if license is 'Active' or 'Expired'"
        ]
    },
    
    "dea_license_number": {
        "description": "DEA (Drug Enforcement Administration) license",
        "examples": ["FB1234567", "AD9876543"],
        "format": "2 letters + 7 digits",
        "extraction_hints": [
            "Always starts with 2 letters, followed by 7 digits",
            "Total 9 characters",
            "Labeled as 'DEA', 'DEA Number', 'DEA License'"
        ]
    },
    
    "dea_license_state": {
        "description": "State for DEA license",
        "examples": ["CA", "TX", "NY"],
        "format": "2-letter state code",
        "extraction_hints": [
            "Near DEA number",
            "May match state license state"
        ]
    },
    
    "dea_license_expiration": {
        "description": "DEA license expiration date",
        "examples": ["06/30/2026", "2026-06-30"],
        "format": "Date",
        "extraction_hints": [
            "DEA licenses typically valid for 3 years",
            "Labeled similar to state license expiration"
        ]
    },
    
    "cds_license_number": {
        "description": "CDS (Controlled Dangerous Substances) license",
        "examples": ["CDS123456", "12345"],
        "format": "Alphanumeric",
        "extraction_hints": [
            "State-specific controlled substance license",
            "May be labeled as 'CDS', 'Controlled Substances'"
        ]
    },
    
    "cds_license_state": {
        "description": "State for CDS license",
        "examples": ["CA", "MD", "NY"],
        "format": "2-letter state code"
    },
    
    "cds_license_expiration": {
        "description": "CDS license expiration date",
        "examples": ["12/31/2025"],
        "format": "Date"
    },
    
    # Board Certifications
    "board_cert_name": {
        "description": "Name of board certification",
        "examples": ["American Board of Internal Medicine", "ABIM"],
        "format": "Board name or abbreviation",
        "extraction_hints": [
            "Usually includes 'Board'",
            "Common: ABIM, ABFM, ABEM, etc."
        ]
    },
    
    "board_cert_specialty": {
        "description": "Medical specialty for board certification",
        "examples": ["Internal Medicine", "Family Medicine", "Emergency Medicine"],
        "format": "Specialty name",
        "extraction_hints": [
            "Describes medical specialty area",
            "May be combined with board name"
        ]
    },
    
    "board_cert_date": {
        "description": "Date board certification was obtained",
        "examples": ["01/2020", "2020"],
        "format": "Date",
        "extraction_hints": [
            "Initial certification date",
            "May be labeled as 'Certified Date', 'Issue Date'"
        ]
    },
    
    "board_cert_expiration": {
        "description": "Board certification expiration date",
        "examples": ["12/31/2030"],
        "format": "Date",
        "extraction_hints": [
            "Board certifications typically 10 years",
            "May require recertification"
        ]
    },
    
    # Other Credentials
    "other_credential_type": {
        "description": "Type of other credential/license",
        "examples": ["NPI", "Medical Staff", "Hospital Privileges"],
        "format": "Credential name"
    },
    
    "other_credential_state": {
        "description": "State for other credential",
        "examples": ["CA", "NY"],
        "format": "2-letter state code"
    },
    
    "other_credential_expiration": {
        "description": "Expiration date for other credential",
        "examples": ["12/31/2025"],
        "format": "Date"
    },
    
    # Users can add more fields here following the same format
}


# ============================================================================
# SYSTEM PROMPT CONFIGURATION
# ============================================================================

SYSTEM_PROMPT_CONFIG = {
    "role": "medical credentialing data extractor",
    "expertise": "Extract accurate information from medical licensing and credentialing documents",
    "constraints": [
        "Return ONLY valid JSON",
        "Use exact field names provided",
        "Include confidence scores",
        "Use 'NA' for missing values"
    ]
}


# ============================================================================
# DOCUMENT TYPE HINTS
# ============================================================================

DOCUMENT_TYPE_HINTS = {
    "license": ["license number", "state license", "DEA", "expiration"],
    "personal": ["name", "date of birth", "SSN", "address", "phone"],
    "education": ["degree", "medical school", "graduation", "residency"],
    "certification": ["board", "certified", "specialty", "ABIM", "ABFM"]
}


# ============================================================================
# RAG PROMPT TEMPLATE
# ============================================================================

RAG_PROMPT_TEMPLATE = """
## REFERENCE EXAMPLES (from similar documents):

{rag_examples}

## CURRENT DOCUMENT:

{current_document}
"""


# ============================================================================
# STANDARD PROMPT TEMPLATE
# ============================================================================

STANDARD_PROMPT_TEMPLATE = {
    "header": "Extract the configured fields from this medical credentialing document.",
    "reminder": "Return ONLY the JSON object with all configured fields. Use 'NA' for missing values.",
    "output_format": """
OUTPUT FORMAT:
{
  "field_name": {
    "value": "extracted value or NA",
    "confidence": 0.95
  }
}
"""
}
