"""
MEDICAL DOCUMENT PARSER - PRODUCTION WITH RAG
Includes complete RAG-based extraction workflow from POC
"""

import os
import sys
import json
import logging
import argparse
from datetime import datetime
from typing import Dict, List, Any

# Fix encoding for Windows
if sys.platform == 'win32':
    if sys.stdout.encoding != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')
    if sys.stderr.encoding != 'utf-8':
        sys.stderr.reconfigure(encoding='utf-8')

# Create logs directory
logs_dir = 'logs'
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)
    print(f"Created logs directory: {logs_dir}/")

# Setup logging
log_filename = os.path.join(logs_dir, f'parser_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_filename, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


def print_section(title: str, char: str = "="):
    """Print a formatted section header"""
    logger.info("")
    logger.info(char * 80)
    logger.info(title)
    logger.info(char * 80)


def load_configuration(config_path: str = "config.json") -> Dict:
    """Load and validate configuration file"""
    print_section("STEP 1: LOADING CONFIGURATION")
    
    try:
        logger.info(f"Looking for config file: {config_path}")
        
        if not os.path.exists(config_path):
            logger.error(f"Config file not found: {config_path}")
            raise FileNotFoundError(f"Config file not found: {config_path}")
        
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        logger.info(f"Config file loaded successfully")
        logger.info(f"Found {len(config['doctypes'])} doctypes: {', '.join(config['doctypes'].keys())}")
        
        return config
        
    except Exception as e:
        logger.error(f"Configuration loading failed: {str(e)}")
        raise


def validate_doctype_config(config: Dict, doctype: str) -> Dict:
    """Validate doctype-specific configuration"""
    print_section(f"STEP 2: VALIDATING DOCTYPE '{doctype}' CONFIG")
    
    try:
        logger.info(f"Checking doctype: {doctype}")
        
        if doctype not in config['doctypes']:
            raise ValueError(f"Doctype '{doctype}' not configured")
        
        doctype_config = config['doctypes'][doctype]
        folders = list(doctype_config['folder_configs'].keys())
        logger.info(f"Doctype '{doctype}' found with folders: {', '.join(folders)}")
        
        return doctype_config
        
    except Exception as e:
        logger.error(f"Doctype validation failed: {str(e)}")
        raise


def load_prompt_module(prompt_module_path: str):
    """Load prompt module dynamically"""
    print_section("STEP 3: LOADING PROMPT MODULE")
    
    try:
        logger.info(f"Loading prompt module: {prompt_module_path}")
        
        module_parts = prompt_module_path.split('.')
        module_name = module_parts[-1]
        
        module = __import__(prompt_module_path, fromlist=[module_name])
        
        field_count = len(module.FIELD_LIBRARY)
        logger.info(f"Prompt module loaded - {field_count} fields available")
        
        return module
        
    except Exception as e:
        logger.error(f"Prompt module loading failed: {str(e)}")
        raise


def initialize_azure_services(config: Dict, doctype_config: Dict):
    """Initialize Azure service connections"""
    print_section("STEP 4: INITIALIZING AZURE SERVICES")
    
    services = {}
    
    try:
        from keyvault_manager import KeyVaultManager, resolve_config_values
        from helper import BlobManager, OpenAIManager, SearchManager
        from documentintelligence_ocr import DocumentIntelligenceOCR
        from costtracking import CostTracker
        
        # Key Vault
        logger.info("Initializing Key Vault Manager...")
        vault_url = config.get('azure_keyvault', {}).get('vault_url')
        kv_manager = KeyVaultManager(vault_url)
        services['keyvault'] = kv_manager
        
        logger.info("Resolving configuration values...")
        resolve_config_values(config, kv_manager)
        resolve_config_values(doctype_config, kv_manager)
        logger.info("Configuration values resolved")
        
        # Blob Storage
        logger.info("Initializing Blob Storage...")
        blob_manager = BlobManager(config['azure_blob']['connection_string'])
        services['blob'] = blob_manager
        logger.info("Blob Storage initialized")
        
        # Document Intelligence (OCR)
        logger.info("Initializing Document Intelligence...")
        doc_intel_config = config['azure_document_intelligence']
        ocr_manager = DocumentIntelligenceOCR({
            'endpoint': doc_intel_config['endpoint'],
            'key': doc_intel_config['key'],
            'api_version': doc_intel_config.get('api_version', '2024-07-31-preview')
        })
        services['ocr'] = ocr_manager
        logger.info("Document Intelligence initialized")
        
        # OpenAI Manager (for extraction + embeddings)
        logger.info("Initializing OpenAI Manager...")
        openai_config = doctype_config['azure_openai']['general']
        embedding_config = doctype_config['azure_openai_embedding']
        
        # Get batch config if available
        batch_config = doctype_config['azure_openai'].get('batch')
        
        openai_manager = OpenAIManager(
            openai_config=openai_config,
            embedding_config=embedding_config,
            batch_config=batch_config  # Optional - for Batch API
        )
        services['openai'] = openai_manager
        
        if batch_config:
            logger.info(f"OpenAI Manager initialized - General: {openai_config['model_name']}, Batch: {batch_config['model_name']}")
        else:
            logger.info(f"OpenAI Manager initialized - Model: {openai_config['model_name']} (Batch API: disabled)")
        
        # AI Search Manager (for RAG)
        logger.info("Initializing AI Search...")
        search_config = doctype_config['azure_ai_search']
        search_manager = SearchManager(
            endpoint=search_config['endpoint'],
            api_key=search_config['key'],  # Fixed: api_key parameter
            index_name=search_config['index_name']
        )
        services['search'] = search_manager
        logger.info(f"AI Search initialized - Index: {search_config['index_name']}")
        
        # Cost Tracker
        cost_tracker = CostTracker(config.get('costs', {}))
        services['cost_tracker'] = cost_tracker
        logger.info("Cost Tracker initialized")
        
        logger.info("All Azure services initialized successfully!")
        
        return services
        
    except Exception as e:
        logger.error(f"Azure services initialization failed: {str(e)}")
        raise


def discover_providers(blob_manager, input_container: str):
    """Discover all providers"""
    print_section("STEP 5: DISCOVERING PROVIDERS")
    
    try:
        logger.info(f"Scanning container: {input_container}")
        
        folder_structure = blob_manager.get_folder_structure(input_container)
        providers = list(folder_structure.keys())
        
        logger.info(f"Found {len(providers)} providers")
        
        if len(providers) == 0:
            logger.warning("No providers found")
            return [], {}
        
        for i, provider in enumerate(providers[:5], 1):
            folders = folder_structure[provider]
            logger.info(f"   {i}. {provider} ({len(folders)} folders)")
        
        if len(providers) > 5:
            logger.info(f"   ... and {len(providers) - 5} more providers")
        
        return providers, folder_structure
        
    except Exception as e:
        logger.error(f"Provider discovery failed: {str(e)}")
        raise


def process_document_with_rag(doc_blob, provider: str, folder: str, fields: List[str],
                              services: Dict, config: Dict) -> Dict:
    """
    Process a single document using RAG-based extraction
    
    This follows the POC workflow:
    1. Download document
    2. OCR extraction
    3. Adaptive chunking (if needed)
    4. Generate embedding
    5. Index document
    6. RAG search for similar documents
    7. Build prompt with RAG examples
    8. GPT extraction
    """
    doc_name = doc_blob.name.split('/')[-1]
    
    try:
        # Import RAG module
        from text_rag import process_text_rag
        
        # Get document extension
        _, ext = os.path.splitext(doc_name)
        
        # Download document
        logger.info(f"      Step 1: Downloading {doc_name}...")
        doc_bytes = services['blob'].download_blob(
            config['azure_blob']['inputcontainer'],
            doc_blob.name
        )
        
        if not doc_bytes:
            logger.error(f"      Failed to download {doc_name}")
            return None
        
        logger.info(f"      Downloaded {len(doc_bytes)} bytes")
        
        # Prepare document info
        doc_info = {
            'name': doc_name,
            'filename': doc_name,
            'extension': ext,
            'blob_name': doc_blob.name,
            'provider': provider,
            'folder': folder
        }
        
        # Prepare folder config
        folder_config = {
            'fields': fields,
            'description': 'Medical credentials extraction'
        }
        
        # Process with TEXT RAG
        extracted_data, success = process_text_rag(
            doc_bytes=doc_bytes,
            doc_info=doc_info,
            provider=provider,
            folder=folder,
            folder_config=folder_config,
            ocr=services['ocr'],
            openai_manager=services['openai'],
            search_manager=services['search'],
            cost_tracker=services['cost_tracker'],
            config=config,
            logger=logger
        )
        
        if not success:
            logger.error(f"      RAG extraction failed for {doc_name}")
            return None
        
        return extracted_data
        
    except Exception as e:
        logger.error(f"      Document processing failed: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return None


def save_results(provider: str, extracted_data: Dict, output_container: str, blob_manager, doctype: str):
    """Save extraction results to output container"""
    try:
        import csv
        from io import StringIO
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Calculate overall confidence
        confidences = [field_data.get('confidence', 0) for field_data in extracted_data.values() 
                      if isinstance(field_data, dict)]
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0
        
        # Determine folder based on confidence
        confidence_threshold = 0.70
        if avg_confidence >= confidence_threshold:
            output_folder = "highconfidence"
        else:
            output_folder = "lowconfidence"
        
        # JSON output
        json_path = f"{output_folder}/{provider}/ProcessedJSONResult/{provider}_{timestamp}.json"
        json_content = json.dumps(extracted_data, indent=2)
        blob_manager.upload_blob(output_container, json_path, json_content)
        logger.info(f"      Saved JSON: {json_path}")
        
        # CSV output
        csv_buffer = StringIO()
        csv_writer = csv.writer(csv_buffer)
        csv_writer.writerow(['Field', 'Value', 'Confidence'])
        
        for field_name, field_data in extracted_data.items():
            if isinstance(field_data, dict):
                value = field_data.get('value', '')
                confidence = field_data.get('confidence', 0)
                csv_writer.writerow([field_name, value, confidence])
        
        csv_path = f"{output_folder}/{provider}/ProcessedCSVResult/{provider}_{timestamp}.csv"
        csv_content = csv_buffer.getvalue()
        blob_manager.upload_blob(output_container, csv_path, csv_content)
        logger.info(f"      Saved CSV: {csv_path}")
        
        logger.info(f"      Average confidence: {avg_confidence:.2f} -> {output_folder}")
        
        return avg_confidence
        
    except Exception as e:
        logger.error(f"      Failed to save results: {str(e)}")
        raise


def process_single_provider(provider: str, folder_structure: Dict, blob_manager, 
                            config: Dict, services: Dict, doctype: str, 
                            doctype_config: Dict, prompt_module):
    """Process a single provider's documents with RAG"""
    try:
        if provider not in folder_structure:
            logger.warning(f"   Provider not found")
            return
        
        provider_folders = folder_structure[provider]
        folder_configs = doctype_config['folder_configs']
        
        # Get folder names
        provider_folder_names = list(provider_folders.keys()) if isinstance(provider_folders, dict) else provider_folders
        
        # Find matching folder
        matching_folder = None
        for folder_name in folder_configs.keys():
            if folder_name in provider_folder_names:
                matching_folder = folder_name
                break
        
        if not matching_folder:
            logger.warning(f"   No matching folder found")
            logger.warning(f"   Expected: {list(folder_configs.keys())}")
            logger.warning(f"   Found: {provider_folder_names}")
            return
        
        logger.info(f"   Processing folder: {matching_folder}")
        
        # Get documents
        folder_path = f"{provider}/{matching_folder}"
        documents = blob_manager.list_blobs_in_folder(
            config['azure_blob']['inputcontainer'],
            folder_path
        )
        
        logger.info(f"   Found {len(documents)} documents (including all subfolders)")
        
        if len(documents) == 0:
            logger.warning(f"   No documents to process")
            return
        
        # Get fields
        fields = folder_configs[matching_folder]['fields']
        logger.info(f"   Extracting {len(fields)} fields using RAG approach")
        
        # Aggregate results from all documents
        all_extracted_data = {}
        
        # Process each document with RAG
        for doc_idx, doc_blob in enumerate(documents, 1):
            # Extract subfolder path from blob name
            # e.g., "Provider/1. GEN & HR/Subfolder/doc.pdf" -> "1. GEN & HR/Subfolder/doc.pdf"
            relative_path = doc_blob.name.replace(f"{provider}/", "")
            
            logger.info(f"   Document {doc_idx}/{len(documents)}: {relative_path}")
            
            extracted_data = process_document_with_rag(
                doc_blob,
                provider,
                matching_folder,
                fields,
                services,
                config
            )
            
            if not extracted_data:
                continue
            
            # Merge with previous results (keep higher confidence)
            for field_name, field_data in extracted_data.items():
                if field_name not in all_extracted_data:
                    all_extracted_data[field_name] = field_data
                else:
                    # Keep higher confidence value
                    existing_conf = all_extracted_data[field_name].get('confidence', 0)
                    new_conf = field_data.get('confidence', 0)
                    if new_conf > existing_conf:
                        all_extracted_data[field_name] = field_data
            
            logger.info(f"      Document processed successfully with RAG")
        
        # Save aggregated results
        if all_extracted_data:
            logger.info(f"   Saving aggregated results from {len(documents)} documents...")
            avg_confidence = save_results(
                provider,
                all_extracted_data,
                config['azure_blob']['outputcontainer'],
                blob_manager,
                doctype
            )
            logger.info(f"   Provider processing complete - Confidence: {avg_confidence:.2f}")
        else:
            logger.warning(f"   No data extracted from any document")
        
    except Exception as e:
        logger.error(f"   Provider failed: {str(e)}")
        logger.exception("   Traceback:")


def process_providers(providers: List[str], folder_structure: Dict, config: Dict, 
                     services: Dict, doctype: str, doctype_config: Dict, prompt_module):
    """Process all providers in batches"""
    print_section("STEP 6: PROCESSING PROVIDERS WITH RAG")
    
    try:
        batch_size = config['processing'].get('batch_size', 10)
        total_providers = len(providers)
        total_batches = (total_providers + batch_size - 1) // batch_size
        
        logger.info(f"Processing configuration:")
        logger.info(f"   Total providers: {total_providers}")
        logger.info(f"   Batch size: {batch_size}")
        logger.info(f"   RAG mode: {config['rag']['mode']}")
        logger.info(f"   Total batches: {total_batches}")
        
        if total_providers == 0:
            logger.warning("No providers to process")
            return
        
        # Process in batches
        for batch_num in range(total_batches):
            start_idx = batch_num * batch_size
            end_idx = min(start_idx + batch_size, total_providers)
            batch_providers = providers[start_idx:end_idx]
            
            logger.info("")
            logger.info("=" * 80)
            logger.info(f"BATCH {batch_num + 1}/{total_batches} (Providers {start_idx + 1}-{end_idx})")
            logger.info("=" * 80)
            
            for provider_idx, provider in enumerate(batch_providers, 1):
                global_idx = start_idx + provider_idx
                logger.info("")
                logger.info(f"Provider {global_idx}/{total_providers}: {provider}")
                logger.info("-" * 80)
                
                process_single_provider(
                    provider,
                    folder_structure,
                    services['blob'], 
                    config, 
                    services, 
                    doctype,
                    doctype_config,
                    prompt_module
                )
        
        logger.info("")
        logger.info("Batch processing complete")
        
        # Show cost summary
        cost_summary = services['cost_tracker'].get_summary()
        logger.info("")
        logger.info("COST SUMMARY:")
        logger.info(f"   Total cost: ${cost_summary['total']:.2f}")
        logger.info(f"   OCR: ${cost_summary.get('ocr', 0):.2f}")
        logger.info(f"   GPT: ${cost_summary.get('gpt', 0):.2f}")
        logger.info(f"   Embeddings: ${cost_summary.get('embeddings', 0):.2f}")
        
    except Exception as e:
        logger.error(f"Processing failed: {str(e)}")
        raise


def main():
    """Main application entry point"""
    
    try:
        parser = argparse.ArgumentParser(description='Medical Document Parser with RAG')
        parser.add_argument('--doctype', required=True, help='Document type (cred)')
        parser.add_argument('--apitype', required=True, help='API type (general, batch)')
        parser.add_argument('--archive', default='false', help='Enable archiving')
        
        args = parser.parse_args()
        
        print_section("MEDICAL DOCUMENT PARSER - RAG-BASED PRODUCTION SYSTEM", "=")
        logger.info(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Log file: {log_filename}")
        logger.info(f"Doctype: {args.doctype} | API: {args.apitype} | Archive: {args.archive}")
        
        config = load_configuration()
        doctype_config = validate_doctype_config(config, args.doctype)
        prompt_module = load_prompt_module(doctype_config['prompt_module'])
        services = initialize_azure_services(config, doctype_config)
        providers, folder_structure = discover_providers(services['blob'], config['azure_blob']['inputcontainer'])
        process_providers(providers, folder_structure, config, services, args.doctype, doctype_config, prompt_module)
        
        print_section("PROCESSING COMPLETE", "=")
        logger.info(f"End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Log saved: {log_filename}")
        logger.info(f"Check output container for results!")
        
    except KeyboardInterrupt:
        logger.warning("Process interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error("FATAL ERROR")
        logger.error(f"   {str(e)}")
        logger.exception("Traceback:")
        sys.exit(1)


if __name__ == "__main__":
    main()
