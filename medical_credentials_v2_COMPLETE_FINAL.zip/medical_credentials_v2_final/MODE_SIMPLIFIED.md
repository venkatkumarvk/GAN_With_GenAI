# Mode Selection - Simplified

## 🎯 Two Modes Only

| Mode | When to Use | Cost |
|------|-------------|------|
| **"text"** | Text-based PDFs, DOCs | Cheaper |
| **"multimodal"** | Images, scanned documents | More expensive |

**NO AUTO MODE!** You choose the mode manually in config.json ✅

---

## ⚙️ How to Set Mode

### **Edit config.json:**

```json
{
  "rag": {
    "mode": "text"  ← Change to "text" or "multimodal"
  }
}
```

---

## 📊 Mode Details

### **1. TEXT MODE**

```json
"rag": {
  "mode": "text"
}
```

**Uses:** OCR text only (no vision)

**Best for:**
- ✅ Text-based PDFs
- ✅ Word documents (DOC, DOCX)
- ✅ Text files
- ✅ Good quality scans with clear text

**Cost:** ~$0.015 per document

**Example:**
```
All documents processed as TEXT
├── license.pdf   → TEXT extraction
├── cert.docx     → TEXT extraction
├── scan.jpg      → TEXT extraction (OCR text only)
└── card.png      → TEXT extraction (OCR text only)
```

---

### **2. MULTIMODAL MODE**

```json
"rag": {
  "mode": "multimodal"
}
```

**Uses:** Vision (GPT-4o with images)

**Best for:**
- ✅ Images (JPG, PNG, etc.)
- ✅ Scanned documents
- ✅ Poor quality text
- ✅ Documents with tables/charts
- ✅ License cards, certificates

**Cost:** ~$0.018 per document

**Example:**
```
All documents processed as MULTIMODAL
├── license.pdf   → Vision extraction
├── cert.docx     → Vision extraction
├── scan.jpg      → Vision extraction
└── card.png      → Vision extraction
```

---

## 💡 Which Mode to Choose?

### **Use TEXT if:**
- All documents are clean PDFs or Word docs
- OCR quality is good
- Want lowest cost
- Processing speed is important

### **Use MULTIMODAL if:**
- Documents are mostly images/scans
- OCR quality is poor
- Documents have complex layouts
- Need to see actual document structure

---

## 🎯 Recommendation

**For medical credentials (your use case):**

```json
"rag": {
  "mode": "multimodal"  ← RECOMMENDED
}
```

**Why?**
- Medical licenses are often scanned cards/images
- Better accuracy for forms and structured documents
- Handles poor quality scans
- Reads from actual visual layout

**Cost difference is minimal:** $0.003 per document

---

## 📋 Example Configs

### **All Text Processing:**
```json
{
  "rag": {
    "mode": "text",
    "top_k": 3
  }
}
```

### **All Vision Processing (Recommended):**
```json
{
  "rag": {
    "mode": "multimodal",
    "top_k": 3
  }
}
```

---

## 🔍 How to Check Which Mode Was Used

### **In Logs:**
```
[1/100] state_license.pdf
  Mode: TEXT
✓ Successfully extracted

[2/100] dea_card.jpg
  Mode: MULTIMODAL
✓ Successfully extracted
```

### **In JSON Output:**
```json
{
  "results": [
    {
      "document_name": "license.pdf",
      "extraction_mode": "text"
    },
    {
      "document_name": "card.jpg",
      "extraction_mode": "multimodal"
    }
  ]
}
```

---

## ⚡ Quick Decision

```
Do you have mostly TEXT PDFs/Word docs?
  └─ YES → Use "text" mode
  └─ NO → Continue

Do you have mostly IMAGES/SCANS?
  └─ YES → Use "multimodal" mode
  └─ NO → Continue

Mixed documents?
  └─ Use "multimodal" mode (safer choice)
```

---

## ✅ Summary

**Setting:** Edit config.json → rag.mode → Choose "text" or "multimodal"

**Options:**
- `"text"` = Cheaper, faster, text only
- `"multimodal"` = Better for images/scans, slightly more expensive

**No auto detection!** You control the mode ✅

**Recommended for medical credentials:** `"multimodal"`
