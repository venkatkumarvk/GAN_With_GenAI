# Output Folder Structure

## 📁 Complete Folder Organization

```
outputcontainer/
│
├── highconfidence/
│   ├── Provider1_GEN & HR/
│   │   ├── processedcsvresult/
│   │   │   ├── Provider1_GEN & HR_20260305_120000.csv
│   │   │   └── Provider1_GEN & HR_20260305_120100.csv
│   │   │
│   │   ├── processedjsonresult/
│   │   │   ├── Provider1_GEN & HR_20260305_120000.json
│   │   │   └── Provider1_GEN & HR_20260305_120100.json
│   │   │
│   │   └── processedestimationcost/
│   │       ├── Provider1_GEN & HR_20260305_120000_cost.json
│   │       └── Provider1_GEN & HR_20260305_120100_cost.json
│   │
│   ├── Provider1_ED & TRAIN/
│   │   ├── processedcsvresult/
│   │   ├── processedjsonresult/
│   │   └── processedestimationcost/
│   │
│   ├── Provider2_Licenses/
│   │   ├── processedcsvresult/
│   │   ├── processedjsonresult/
│   │   └── processedestimationcost/
│   │
│   └── Provider3_Certifications/
│       ├── processedcsvresult/
│       ├── processedjsonresult/
│       └── processedestimationcost/
│
└── lowconfidence/
    ├── Provider1_Unknown_Folder/
    │   ├── processedcsvresult/
    │   ├── processedjsonresult/
    │   └── processedestimationcost/
    │
    └── Provider2_Old_Documents/
        ├── processedcsvresult/
        ├── processedjsonresult/
        └── processedestimationcost/
```

---

## 🎯 Folder Logic

### **High vs Low Confidence:**

| Confidence | Criteria | Folder |
|------------|----------|--------|
| **High** | Min confidence ≥ threshold | `highconfidence/` |
| **Low** | Min confidence < threshold | `lowconfidence/` |

**Threshold:** Defined in config.json per folder (default: 0.70)

---

## 📄 File Types

### **1. CSV Files** (`processedcsvresult/`)

**Format:**
```csv
Provider,Folder,Field,Value,Confidence,Status
Provider1,GEN & HR,first_name,John,0.98,high
Provider1,GEN & HR,last_name,Smith,0.96,high
Provider1,GEN & HR,email,john@email.com,0.92,high
Provider1,GEN & HR,cell,555-1234,0.85,high
Provider1,GEN & HR,birth_date,01/15/1980,0.88,high
Provider1,GEN & HR,ssn,NA,0.00,low
```

**Contains:**
- ✅ All fields for the folder
- ✅ Best values (most common across documents)
- ✅ Confidence scores
- ✅ Status (high/medium/low)

**Use Case:** Quick view of extracted data with quality indicators

---

### **2. JSON Files** (`processedjsonresult/`)

**Format:**
```json
{
  "provider": "Provider1",
  "folder": "GEN & HR",
  "folder_type": "Personal identification information",
  "timestamp": "20260305_120000",
  "total_documents": 10,
  "min_confidence": 0.85,
  "category": "highconfidence",
  "confidence_summary": {
    "high": 10,
    "medium": 1,
    "low": 1
  },
  "best_values": {
    "first_name": {
      "value": "John",
      "confidence": 0.98,
      "status": "high"
    },
    "last_name": {
      "value": "Smith",
      "confidence": 0.96,
      "status": "high"
    },
    "ssn": {
      "value": "NA",
      "confidence": 0.00,
      "status": "low"
    }
  },
  "results": [
    {
      "document_name": "doc1.pdf",
      "extracted_fields": {
        "first_name": {"value": "John", "confidence": 0.98},
        "last_name": {"value": "Smith", "confidence": 0.96}
      }
    }
  ]
}
```

**Contains:**
- ✅ All documents processed
- ✅ Individual extraction results
- ✅ Best values summary
- ✅ Confidence breakdown
- ✅ Complete metadata

**Use Case:** Complete extraction details, re-processing, auditing

---

### **3. Cost Estimation Files** (`processedestimationcost/`)

**Format:**
```json
{
  "provider": "Provider1",
  "folder": "GEN & HR",
  "timestamp": "20260305_120000",
  "total_documents": 10,
  "total_fields": 12,
  "confidence_breakdown": {
    "high": 10,
    "medium": 1,
    "low": 1
  },
  "estimated_costs": {
    "ocr_cost_usd": 0.1000,
    "extraction_cost_usd": 0.2000,
    "total_cost_usd": 0.3000,
    "cost_per_document": 0.0300
  }
}
```

**Contains:**
- ✅ Total documents processed
- ✅ Number of fields extracted
- ✅ Confidence breakdown
- ✅ Cost breakdown (OCR + Extraction)
- ✅ Per-document cost

**Use Case:** Budget tracking, cost analysis, billing

---

## 🗂️ File Naming Convention

### **Pattern:**
```
{Provider}_{Folder}_{Timestamp}.{extension}
{Provider}_{Folder}_{Timestamp}_cost.json  (for cost files)
```

### **Examples:**
```
Provider1_GEN & HR_20260305_120000.csv
Provider1_GEN & HR_20260305_120000.json
Provider1_GEN & HR_20260305_120000_cost.json

Provider1_ED & TRAIN_20260305_120100.csv
Provider1_ED & TRAIN_20260305_120100.json
Provider1_ED & TRAIN_20260305_120100_cost.json
```

**Timestamp Format:** `YYYYMMDD_HHMMSS`

---

## 📊 Example: Processing 2 Providers

### **Input Structure:**
```
inputcontainer/
├── Provider1/
│   ├── 1. GEN & HR/
│   │   ├── doc1.pdf
│   │   └── doc2.pdf
│   └── 2. ED & TRAIN/
│       └── doc3.pdf
│
└── Provider2/
    └── Licenses/
        └── doc4.pdf
```

### **Output Structure:**
```
outputcontainer/
├── highconfidence/
│   ├── Provider1_GEN & HR/
│   │   ├── processedcsvresult/
│   │   │   └── Provider1_GEN & HR_20260305_120000.csv
│   │   ├── processedjsonresult/
│   │   │   └── Provider1_GEN & HR_20260305_120000.json
│   │   └── processedestimationcost/
│   │       └── Provider1_GEN & HR_20260305_120000_cost.json
│   │
│   ├── Provider1_ED & TRAIN/
│   │   ├── processedcsvresult/
│   │   │   └── Provider1_ED & TRAIN_20260305_120100.csv
│   │   ├── processedjsonresult/
│   │   │   └── Provider1_ED & TRAIN_20260305_120100.json
│   │   └── processedestimationcost/
│   │       └── Provider1_ED & TRAIN_20260305_120100_cost.json
│   │
│   └── Provider2_Licenses/
│       ├── processedcsvresult/
│       │   └── Provider2_Licenses_20260305_120200.csv
│       ├── processedjsonresult/
│       │   └── Provider2_Licenses_20260305_120200.json
│       └── processedestimationcost/
│           └── Provider2_Licenses_20260305_120200_cost.json
│
└── lowconfidence/
    (empty if all extractions are high confidence)
```

---

## 🎯 Quick Access

### **To find CSV for Provider1, GEN & HR folder:**
```
outputcontainer/
  → highconfidence/
    → Provider1_GEN & HR/
      → processedcsvresult/
        → Provider1_GEN & HR_20260305_120000.csv
```

### **To find Cost for Provider1, ED & TRAIN folder:**
```
outputcontainer/
  → highconfidence/
    → Provider1_ED & TRAIN/
      → processedestimationcost/
        → Provider1_ED & TRAIN_20260305_120100_cost.json
```

### **To find JSON for low confidence Provider2:**
```
outputcontainer/
  → lowconfidence/
    → Provider2_Unknown/
      → processedjsonresult/
        → Provider2_Unknown_20260305_120300.json
```

---

## 🔍 Folder Purpose Summary

| Folder | Contents | Purpose |
|--------|----------|---------|
| **processedcsvresult/** | Field-by-field CSV | Quick data view, Excel import |
| **processedjsonresult/** | Complete JSON | Full details, re-processing |
| **processedestimationcost/** | Cost breakdown | Budget tracking, billing |

---

## ✅ Benefits of This Structure

1. **✅ Organized by Confidence:** Easy to prioritize review (check lowconfidence first)
2. **✅ Organized by Provider/Folder:** Easy to find specific results
3. **✅ Separated by Type:** CSV for data, JSON for details, Cost for billing
4. **✅ Timestamped:** Track processing history
5. **✅ Scalable:** Works for 1 provider or 1000 providers

---

## 📋 Config Settings

To change confidence threshold:

```json
{
  "folder_configs": {
    "GEN & HR": {
      "fields": [...],
      "min_confidence": 0.70  ← Adjust this (0.0-1.0)
    }
  }
}
```

**Examples:**
- `0.90` = Very strict (only best extractions in highconfidence)
- `0.70` = Balanced (recommended)
- `0.50` = Lenient (more in highconfidence)

---

## ✅ Summary

```
outputcontainer/
├── highconfidence/{Provider}_{Folder}/
│   ├── processedcsvresult/        ← CSV with confidence
│   ├── processedjsonresult/       ← Full JSON details
│   └── processedestimationcost/   ← Cost breakdown
│
└── lowconfidence/{Provider}_{Folder}/
    ├── processedcsvresult/        ← CSV with confidence
    ├── processedjsonresult/       ← Full JSON details
    └── processedestimationcost/   ← Cost breakdown
```

**Every Provider + Folder combination gets its own organized subfolder!** ✅
