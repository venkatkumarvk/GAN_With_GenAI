# Debug: Embedding & Output Issues

## 🐛 Problem: Embedding Not Working, No Output Created

### **Symptoms:**
- ❌ No files in outputcontainer
- ❌ Embedding generation fails
- ❌ Azure AI Search empty (0 bytes)
- ❌ Process completes but no results

---

## 🔍 Step-by-Step Debugging

### **Step 1: Check Azure OpenAI Credentials**

```bash
# Test OpenAI connection
python -c "
import json
from openai import AzureOpenAI

with open('config.json') as f:
    config = json.load(f)

try:
    client = AzureOpenAI(
        azure_endpoint=config['azure_openai_embedding']['endpoint'],
        api_key=config['azure_openai_embedding']['api_key'],
        api_version=config['azure_openai_embedding']['api_version']
    )
    
    # Try to generate embedding
    response = client.embeddings.create(
        input='test',
        model=config['azure_openai_embedding']['deployment_name']
    )
    
    print('✅ OpenAI Connected!')
    print(f'   Embedding dimensions: {len(response.data[0].embedding)}')
except Exception as e:
    print(f'❌ OpenAI Connection Failed: {e}')
"
```

**Expected Output:**
```
✅ OpenAI Connected!
   Embedding dimensions: 3072
```

**If Failed:**
- Check `azure_openai_embedding.endpoint` in config.json
- Check `azure_openai_embedding.api_key` in config.json
- Check `azure_openai_embedding.deployment_name` in config.json
- Verify deployment exists in Azure portal

---

### **Step 2: Check Azure Search Credentials**

```bash
# Test Search connection
python -c "
import json
from azure.search.documents.indexes import SearchIndexClient
from azure.core.credentials import AzureKeyCredential

with open('config.json') as f:
    config = json.load(f)

try:
    client = SearchIndexClient(
        config['azure_search']['endpoint'],
        AzureKeyCredential(config['azure_search']['api_key'])
    )
    
    indexes = list(client.list_indexes())
    print(f'✅ Search Connected!')
    print(f'   Found {len(indexes)} indexes')
    for idx in indexes:
        print(f'   - {idx.name}')
except Exception as e:
    print(f'❌ Search Connection Failed: {e}')
"
```

**Expected Output:**
```
✅ Search Connected!
   Found 1 indexes
   - documents_universal
```

**If Failed:**
- Check `azure_search.endpoint` in config.json
- Check `azure_search.api_key` in config.json

---

### **Step 3: Check Blob Storage**

```bash
# Test Blob connection
python -c "
import json
from azure.storage.blob import BlobServiceClient

with open('config.json') as f:
    config = json.load(f)

try:
    client = BlobServiceClient.from_connection_string(
        config['azure_blob']['connection_string']
    )
    
    # List containers
    containers = list(client.list_containers())
    print('✅ Blob Storage Connected!')
    print(f'   Found {len(containers)} containers')
    for container in containers:
        print(f'   - {container.name}')
except Exception as e:
    print(f'❌ Blob Connection Failed: {e}')
"
```

**Expected Output:**
```
✅ Blob Storage Connected!
   Found 2 containers
   - inputcontainer
   - outputcontainer
```

---

### **Step 4: Enable Debug Logging**

**Edit logging_config.py:**
```python
def setup_logging(log_dir: str = "logs"):
    # ... existing code ...
    
    # Change this line:
    logging.basicConfig(
        level=logging.DEBUG,  ← Change INFO to DEBUG
        # ... rest of config
    )
```

**Or add to main.py at the top:**
```python
import logging
logging.getLogger().setLevel(logging.DEBUG)
```

---

### **Step 5: Check Logs for Errors**

**Run with logging:**
```bash
python main.py 2>&1 | tee debug.log
```

**Look for:**
```
✓ Generating embedding...
✓ Embedding generated: 3072 dimensions
✓ Uploading to index: Provider1_GEN_and_HR_doc1.pdf
✓ Uploaded to Azure AI Search
```

**If you see:**
```
❌ Embedding generation failed
```

**Then:** OpenAI credentials issue

**If you see:**
```
❌ Failed to upload to index
```

**Then:** Azure Search issue

---

### **Step 6: Test Single Document**

**Create test script:**
```python
# test_single_doc.py
import json
from helper import BlobManager, OpenAIManager
from documentintelligence_ocr import DocumentIntelligenceOCR
from production_index_manager import ProductionIndexManager

with open('config.json') as f:
    config = json.load(f)

# Initialize
blob_manager = BlobManager(config['azure_blob']['connection_string'])
ocr_manager = DocumentIntelligenceOCR(
    config['azure_document_intelligence']['endpoint'],
    config['azure_document_intelligence']['key']
)
openai_manager = OpenAIManager(
    config['azure_openai_embedding']['endpoint'],
    config['azure_openai_embedding']['api_key'],
    config['azure_openai_embedding']['api_version'],
    config['azure_openai_gpt']['deployment_name'],
    config['azure_openai_embedding']['deployment_name']
)
index_manager = ProductionIndexManager(
    config['azure_search']['endpoint'],
    config['azure_search']['api_key']
)

# Test document
print("1. Testing OCR...")
doc_bytes = blob_manager.download_blob("inputcontainer", "Provider1/1. GEN & HR/test.pdf")
text, is_supported, file_type = ocr_manager.extract_text(doc_bytes, "test.pdf")
print(f"   OCR extracted: {len(text)} chars")

print("2. Testing Embedding...")
embedding = openai_manager.get_embedding(text[:2000])
print(f"   Embedding generated: {len(embedding)} dimensions")

print("3. Testing Index Upload...")
index_manager.create_index_if_not_exists()
index_manager.upload_document(
    doc_id="test_doc",
    content=text[:1000],
    content_vector=embedding,
    provider="TestProvider",
    provider_id="test123",
    document_name="test.pdf"
)
print("   ✅ Document uploaded!")

print("\n✅ All tests passed!")
```

**Run:**
```bash
python test_single_doc.py
```

---

## 🎯 Common Issues & Solutions

### **Issue 1: Embedding Fails**

**Error:**
```
❌ Embedding generation failed
```

**Causes:**
- Wrong OpenAI endpoint
- Wrong API key
- Wrong deployment name
- Deployment not deployed

**Fix:**
```json
{
  "azure_openai_embedding": {
    "endpoint": "https://YOUR_NAME.openai.azure.com/",  ← Check this
    "api_key": "YOUR_KEY",  ← Check this
    "deployment_name": "text-embedding-3-large"  ← Check deployment exists
  }
}
```

---

### **Issue 2: No Output Files**

**Cause:** Save function might be failing

**Check logs for:**
```
✅ Saved JSON: ...
✅ Saved CSV: ...
✅ Saved Cost Estimation: ...
```

**If missing:**
- Check Blob Storage connection
- Check outputcontainer exists
- Check permissions

---

### **Issue 3: Azure Search Empty**

**Cause:** Documents not uploading

**Check logs for:**
```
✓ Uploading to index: ...
✓ Uploaded to Azure AI Search
```

**If missing:**
- Check Search credentials
- Check index created
- Check upload not throwing errors

**Manual check in Azure Portal:**
```
1. Open Azure Portal
2. Go to AI Search service
3. Click "Indexes"
4. Click "documents_universal"
5. Check "Document Count"
```

---

### **Issue 4: Process Completes But No Results**

**Possible causes:**
1. Documents being skipped (unsupported files)
2. Folder not matching config
3. Embedding failing silently
4. Upload failing silently

**Enable debug logging and check:**
```
⏭️  Skipping ... : unsupported
⏭️  Skipping ... : embedding failed
❌ Failed to upload to index
```

---

## ✅ Verification Checklist

Before running main.py:

- [ ] Test OpenAI connection (embedding)
- [ ] Test Azure Search connection
- [ ] Test Blob Storage connection
- [ ] Enable debug logging
- [ ] Check input files are supported types
- [ ] Check folder names match config
- [ ] Run test_single_doc.py first
- [ ] Check Azure portal after run

---

## 🆘 Still Not Working?

**Collect this info:**

1. **Error messages from logs**
2. **Results of connection tests**
3. **Config.json (remove sensitive keys)**
4. **File types being processed**
5. **Folder structure**

**Run full debug:**
```bash
# Enable all debug output
export AZURE_LOG_LEVEL=debug
python main.py > full_debug.log 2>&1

# Check the log
cat full_debug.log | grep -E "ERROR|Failed|❌"
```
