"""
Configuration Validator
=======================
Validates config.json structure and provides helpful error messages
"""

import json
import sys
from typing import Dict, List, Tuple


class ConfigValidator:
    """Validate configuration file structure"""
    
    REQUIRED_SECTIONS = {
        'azure_blob': ['connection_string', 'inputcontainer', 'outputcontainer'],
        'azure_document_intelligence': ['endpoint', 'key'],
        'azure_openai_gpt': ['endpoint', 'api_key', 'api_version', 'deployment_name'],
        'azure_openai_embedding': ['endpoint', 'api_key', 'api_version', 'deployment_name', 'dimension'],
        'azure_search': ['endpoint', 'api_key', 'universal_index_name'],
        'folder_configs': [],  # At least one folder config required
        'default_config': ['fields'],  # Must have fields
        'extraction': ['na_value'],
        'rag': ['mode', 'top_k'],
        'costs': [],
        'processing': []  # Optional keys handled with defaults
    }
    
    @staticmethod
    def validate(config: Dict) -> Tuple[bool, List[str]]:
        """
        Validate configuration
        
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []
        
        # Check top-level sections
        for section, required_keys in ConfigValidator.REQUIRED_SECTIONS.items():
            if section not in config:
                errors.append(f"❌ Missing section: '{section}'")
                continue
            
            # Check required keys in section
            for key in required_keys:
                if key not in config[section]:
                    errors.append(f"❌ Missing key: '{section}.{key}'")
        
        # Validate folder_configs
        if 'folder_configs' in config:
            if not config['folder_configs']:
                errors.append("❌ 'folder_configs' is empty - need at least one folder")
            else:
                for folder_name, folder_config in config['folder_configs'].items():
                    if 'fields' not in folder_config:
                        errors.append(f"❌ '{folder_name}' missing 'fields' key")
                    elif not isinstance(folder_config['fields'], list):
                        errors.append(f"❌ '{folder_name}.fields' must be a list")
                    elif len(folder_config['fields']) == 0:
                        errors.append(f"⚠️  '{folder_name}.fields' is empty")
        
        # Validate default_config
        if 'default_config' in config:
            if 'fields' not in config['default_config']:
                errors.append("❌ 'default_config' missing 'fields' key")
            elif not isinstance(config['default_config']['fields'], list):
                errors.append("❌ 'default_config.fields' must be a list")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def validate_file(config_path: str = "config.json") -> Tuple[bool, Dict, List[str]]:
        """
        Load and validate configuration file
        
        Returns:
            Tuple of (is_valid, config_dict, list_of_errors)
        """
        errors = []
        
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            return False, {}, [f"❌ Config file not found: {config_path}"]
        except json.JSONDecodeError as e:
            return False, {}, [f"❌ Invalid JSON in config file: {e}"]
        except Exception as e:
            return False, {}, [f"❌ Error loading config: {e}"]
        
        # Validate structure
        is_valid, validation_errors = ConfigValidator.validate(config)
        errors.extend(validation_errors)
        
        return is_valid, config, errors
    
    @staticmethod
    def print_errors(errors: List[str]):
        """Print validation errors"""
        print("="*60)
        print("CONFIG VALIDATION ERRORS")
        print("="*60)
        for error in errors:
            print(error)
        print("="*60)
        print(f"Total errors: {len(errors)}")
        print("="*60)


def validate_config_file(config_path: str = "config.json") -> Dict:
    """
    Validate and load config file
    Exits if validation fails
    
    Returns:
        Validated config dictionary
    """
    is_valid, config, errors = ConfigValidator.validate_file(config_path)
    
    if not is_valid:
        ConfigValidator.print_errors(errors)
        print("\n❌ Configuration validation FAILED!")
        print("Please fix the errors above in config.json")
        sys.exit(1)
    
    return config


# Test if run directly
if __name__ == "__main__":
    print("="*60)
    print("CONFIG VALIDATOR TEST")
    print("="*60)
    
    is_valid, config, errors = ConfigValidator.validate_file("config.json")
    
    if is_valid:
        print("\n✅ Configuration is VALID!")
        print(f"\nFound {len(config['folder_configs'])} folder configurations:")
        for folder_name, folder_config in config['folder_configs'].items():
            num_fields = len(folder_config.get('fields', []))
            print(f"  • {folder_name}: {num_fields} fields")
        
        print(f"\nDefault config: {len(config['default_config'].get('fields', []))} fields")
        
        skip = config.get('processing', {}).get('skip_unknown_folders', False)
        print(f"\nSkip unknown folders: {skip}")
        
    else:
        ConfigValidator.print_errors(errors)
        print("\n❌ Configuration validation FAILED!")
    
    print("="*60)
