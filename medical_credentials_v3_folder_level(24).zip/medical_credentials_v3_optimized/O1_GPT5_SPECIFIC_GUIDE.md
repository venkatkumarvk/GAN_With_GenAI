# O1 / GPT-5 MODEL SPECIFIC GUIDE

## 🎯 **CRITICAL: O1 MODELS ARE DIFFERENT!**

If you're using **o1, o1-preview, o1-mini, or GPT-5**, they have **DIFFERENT API parameters** than GPT-4!

---

## ❌ **WHAT DOESN'T WORK WITH O1**

### **1. Temperature Parameter**
```python
# GPT-4/4.5:
temperature=0.0  ✅ Works

# o1/GPT-5:
temperature=0.0  ❌ ERROR! Not supported
```

**o1 models use fixed reasoning - no temperature control!**

### **2. max_tokens Parameter**
```python
# GPT-4/4.5:
max_tokens=4000  ✅ Works

# o1/GPT-5:
max_tokens=4000  ❌ ERROR! Use max_completion_tokens instead
```

### **3. System Messages (Some Models)**
```python
# GPT-4/4.5:
{"role": "system", "content": "..."}  ✅ Works

# o1/GPT-5 (some versions):
{"role": "developer", "content": "..."}  ✅ Use this instead
```

---

## ✅ **WHAT THE FIX DOES**

### **Auto-Detection:**

```python
# System detects o1 models by name
deployment_name = "o1-preview"  # or "o1", "o1-mini", "gpt-5", "gpt5"

if "o1" in deployment_name or "gpt-5" in deployment_name:
    # Use o1 parameters
    params = {
        "max_completion_tokens": 4000,  # NOT max_tokens!
        # NO temperature parameter!
        "messages": [
            {"role": "developer", ...}  # NOT system!
        ]
    }
else:
    # Use GPT-4 parameters
    params = {
        "max_tokens": 4000,
        "temperature": 0.0,
        "messages": [
            {"role": "system", ...}
        ]
    }
```

**System automatically adjusts!** ✅

---

## 🔧 **YOUR CONFIGURATION**

### **For o1/GPT-5:**

```json
{
  "azure_openai_gpt": {
    "endpoint": "https://your-resource.openai.azure.com/",
    "api_key": "your-key",
    "deployment_name": "o1-preview",  ← or "o1", "o1-mini", "gpt-5"
    "api_version": "2024-02-01"  ← May need newer version
  }
}
```

**System will automatically:**
1. ✅ Detect it's an o1 model
2. ✅ Use `max_completion_tokens` instead of `max_tokens`
3. ✅ Remove `temperature` parameter
4. ✅ Use `developer` role instead of `system`

**No manual configuration needed!** ✅

---

## 📊 **PARAMETER COMPARISON**

### **GPT-4/4.5 API Call:**
```python
response = client.chat.completions.create(
    model="gpt-4o-2",
    messages=[
        {"role": "system", "content": "Format instructions..."},
        {"role": "user", "content": "Extract from..."}
    ],
    temperature=0.0,
    max_tokens=4000
)
```

### **o1/GPT-5 API Call:**
```python
response = client.chat.completions.create(
    model="o1-preview",
    messages=[
        {"role": "developer", "content": "Format instructions..."},
        {"role": "user", "content": "Extract from..."}
    ],
    # NO temperature!
    max_completion_tokens=4000  # NOT max_tokens!
)
```

---

## 💡 **HOW AUTO-DETECTION WORKS**

### **Detection Logic:**

```python
deployment_lower = deployment_name.lower()

is_o1_model = any(x in deployment_lower for x in [
    'o1',       # Catches: o1, o1-preview, o1-mini
    'gpt-5',    # Catches: gpt-5, gpt-5-prod
    'gpt5'      # Catches: gpt5, gpt5-deployment
])

if is_o1_model:
    # Use o1 parameters
else:
    # Use GPT-4 parameters
```

**Deployment Names Detected:**
- ✅ `o1`
- ✅ `o1-preview`
- ✅ `o1-mini`
- ✅ `o1-prod`
- ✅ `gpt-5`
- ✅ `gpt-5-production`
- ✅ `gpt5`
- ✅ `my-gpt5-deployment`

---

## 🔍 **LOGS SHOW WHICH MODE**

### **When using o1/GPT-5:**
```
INFO - Using o1/GPT-5 model parameters (no temperature, max_completion_tokens)
INFO - ✓ Step 8 Complete: Used TEXT RAG
```

### **When using GPT-4/4.5:**
```
INFO - Using GPT-4/4.5 model parameters (temperature=0.0)
INFO - ✓ Step 8 Complete: Used TEXT RAG
```

**Check logs to confirm correct parameters!** ✅

---

## 🎯 **TESTING O1/GPT-5**

### **Test Your Deployment:**

**1. Update config.json:**
```json
{
  "deployment_name": "o1-preview"  ← Your o1 deployment
}
```

**2. Run:**
```bash
python main.py
```

**3. Check logs:**
```bash
grep "Using o1/GPT-5 model parameters" logs/extraction_*.log
```

**Should see:**
```
Using o1/GPT-5 model parameters (no temperature, max_completion_tokens)
```

**4. Check for errors:**
```bash
grep "ERROR" logs/extraction_*.log
```

**Should NOT see:**
```
temperature is not supported
max_tokens is not supported
```

**If you see these errors → System didn't detect o1 model!**

---

## ⚠️ **TROUBLESHOOTING**

### **Problem: Still Getting Parameter Errors**

**Error:**
```
BadRequestError: temperature is not supported
```

**Solution 1: Check Deployment Name**
```
Your deployment: "openai-o1"  ← Contains "o1"
Should detect: ✅ YES

Your deployment: "my-prod-deployment"  ← Doesn't contain "o1" or "gpt-5"
Should detect: ❌ NO
```

**Fix:** Rename deployment or add manual detection.

**Solution 2: Update API Version**
```json
{
  "api_version": "2024-02-01"  ← Try newer
  // OR
  "api_version": "2024-08-01-preview"
}
```

---

### **Problem: System Message Error**

**Error:**
```
role 'system' is not supported for o1 models
```

**Solution:** System should use "developer" role automatically.

**Check logs:**
```bash
grep "role" logs/extraction_*.log
```

**Should use:**
```
{"role": "developer", ...}  ← Correct for o1
```

**Not:**
```
{"role": "system", ...}  ← Wrong for o1
```

---

## 💰 **O1 COST CONSIDERATIONS**

### **o1 Models are MORE EXPENSIVE:**

**GPT-4o:**
```
Input:  $2.50 per 1M tokens
Output: $10.00 per 1M tokens
```

**o1-preview:**
```
Input:  $15.00 per 1M tokens (6x more!)
Output: $60.00 per 1M tokens (6x more!)
```

**o1-mini:**
```
Input:  $3.00 per 1M tokens
Output: $12.00 per 1M tokens
```

**Example: 1000 Documents**
```
GPT-4o:      ~$8.75
o1-mini:     ~$10.50 (1.2x)
o1-preview:  ~$52.50 (6x!)
```

**Budget accordingly!**

---

## 📋 **O1 MODEL DIFFERENCES SUMMARY**

| Parameter | GPT-4/4.5 | o1/GPT-5 |
|-----------|-----------|----------|
| **temperature** | ✅ 0.0 | ❌ Not supported |
| **max_tokens** | ✅ Yes | ❌ Use max_completion_tokens |
| **max_completion_tokens** | ❌ Not used | ✅ Use this! |
| **system role** | ✅ Yes | ⚠️ Use "developer" |
| **developer role** | ❌ Not used | ✅ Use this! |
| **Reasoning** | Standard | Advanced (slower) |
| **Cost** | Lower | Higher (3-6x) |

---

## ✅ **COMPLETE EXAMPLE**

### **config.json:**
```json
{
  "azure_openai_gpt": {
    "endpoint": "https://my-openai.openai.azure.com/",
    "api_key": "abc123...",
    "deployment_name": "o1-preview",
    "api_version": "2024-02-01"
  }
}
```

### **System automatically uses:**
```python
response = client.chat.completions.create(
    model="o1-preview",
    messages=[
        {"role": "developer", "content": "Format instructions..."},
        {"role": "user", "content": "Extract fields..."}
    ],
    max_completion_tokens=4000
    # NO temperature!
)
```

### **Logs show:**
```
INFO - Using o1/GPT-5 model parameters (no temperature, max_completion_tokens)
INFO - ✓ Step 8 Complete: Used TEXT RAG
INFO - GPT-4o tokens: input=1234, output=567
INFO - Sample field format - first_name: dict = {'value': 'John', 'confidence': 0.95}
```

**Works perfectly!** ✅

---

## 🚀 **SWITCHING BETWEEN MODELS**

### **Easy Model Switch:**

**GPT-4o:**
```json
{
  "deployment_name": "gpt-4o-2"
}
```
→ Uses: temperature, max_tokens, system role

**o1:**
```json
{
  "deployment_name": "o1-preview"
}
```
→ Uses: max_completion_tokens, developer role, no temperature

**Just change deployment_name!** System adapts automatically! ✅

---

## 🎉 **SUMMARY**

**Your Issue:**
> "Currently using GPT-5, temperature parameter not here and also not max_token, it's max_completion_tokens"

**Fix Applied:**
1. ✅ Auto-detects o1/GPT-5 models
2. ✅ Uses `max_completion_tokens` for o1
3. ✅ Removes `temperature` for o1
4. ✅ Uses `developer` role instead of `system`
5. ✅ Logs which parameters being used

**Works With:**
- ✅ GPT-4o (temperature, max_tokens, system)
- ✅ GPT-4.5 (temperature, max_tokens, system)
- ✅ o1-preview (max_completion_tokens, developer, no temp)
- ✅ o1-mini (max_completion_tokens, developer, no temp)
- ✅ o1 (max_completion_tokens, developer, no temp)
- ✅ GPT-5 (max_completion_tokens, developer, no temp)

**Configuration:**
```json
{
  "deployment_name": "your-o1-or-gpt5-deployment"
}
```

**System automatically adjusts parameters!** ✅

**No more parameter errors!** 🎉
