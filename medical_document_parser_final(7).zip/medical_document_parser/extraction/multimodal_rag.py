"""
Multimodal RAG Extraction Module
==================================

Text + Vision extraction pipeline:
  OCR -> Semantic Chunking -> Embedding -> AI Search Index ->
  Per-field RAG Search -> Convert page to image ->
  GPT Vision (text + image) Extraction

Config: rag.mode = "multimodal"

Same as text_rag.py EXCEPT at the GPT extraction step:
  - text_rag: sends only text chunks to GPT
  - multimodal_rag: sends text chunks AND the document page image to GPT Vision

RAG search is ALWAYS text-based (AI Search indexes text, not images).
The image is added at the GPT call for visual context (handwriting,
checkboxes, stamps, signatures, table layouts).

Adding new document types:
  1. Create new prompt file in prompts/ (copy cred_prompt.py as template)
  2. Add doctype entry in config.json with folder_configs and fields
  3. Done - this module adapts automatically via prompt_module parameter
"""

import logging
import hashlib
import base64
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)


def process_document_multimodal_rag(
    doc_bytes: bytes,
    doc_name: str,
    extension: str,
    provider: str,
    folder: str,
    fields: List[str],
    ocr,
    openai_manager,
    search_manager,
    cost_tracker,
    prompt_module,
    api_type: str = "general"
) -> Tuple[Dict, bool]:
    """
    Extract fields using multimodal RAG (text + vision).
    
    Note: Batch API is NOT supported for multimodal mode because
    Azure Batch API does not support image inputs. If api_type="batch"
    is passed, it will fall back to general API with a warning.
    
    Args:
        doc_bytes: Document bytes
        doc_name: Document name
        extension: File extension
        provider: Provider name
        folder: Folder name
        fields: List of field names to extract
        ocr: OCR service
        openai_manager: OpenAI service
        search_manager: AI Search service
        cost_tracker: Cost tracker
        prompt_module: Prompt module with FIELD_LIBRARY
    
    Returns:
        (extracted_data, success)
    """
    logger.info(f"    Document: {doc_name} - Multimodal RAG extraction (text + vision)")
    
    # Batch API does not support image inputs - warn and use general
    if api_type == 'batch':
        logger.warning(
            "      Batch API does not support image inputs. "
            "Falling back to general API for multimodal extraction."
        )
        api_type = 'general'
    
    # ========================================================================
    # STEP 1: OCR (text extraction for RAG search - same as text mode)
    # ========================================================================
    text, pages, success = ocr.extract_text(doc_bytes, extension)
    
    if not success or len(text) < 100:
        logger.warning(f"      FAILED: Insufficient text from OCR")
        return {}, False
    
    cost_tracker.add_ocr(pages)
    logger.info(f"      Step 1: OCR complete ({len(text)} chars, {pages} pages)")
    
    # ========================================================================
    # STEP 2: CONVERT DOCUMENT TO IMAGES (for vision)
    # ========================================================================
    page_images = _convert_to_images(doc_bytes, doc_name, extension)
    
    if not page_images:
        logger.warning(f"      Could not convert to images, falling back to text-only")
        # Fall back to text-only extraction
        from extraction.text_rag import process_document_text_rag
        return process_document_text_rag(
            doc_bytes, doc_name, extension, provider, folder,
            fields, ocr, openai_manager, search_manager,
            cost_tracker, prompt_module
        )
    
    logger.info(f"      Step 2: Converted to {len(page_images)} page image(s)")
    
    # Use first page image for per-field extraction
    # (most credential documents have key info on page 1)
    primary_image_b64 = page_images[0]['base64']
    primary_image_format = page_images[0]['format']
    
    # ========================================================================
    # STEP 3: SEMANTIC CHUNKING + INDEXING (same as text mode)
    # ========================================================================
    from extraction.semantic_chunker import SemanticChunkerV2
    
    chunker = SemanticChunkerV2(
        target_chunk_size=3000,
        min_chunk_size=500,
        max_chunk_size=6000,
        overlap_size=300,
        adaptive=True
    )
    
    chunks = chunker.chunk_document(text, doc_name)
    summary = chunker.get_chunk_summary(chunks)
    logger.info(f"      Step 3a: {summary['total_chunks']} chunks "
               f"({summary['total_text_length']} chars)")
    
    content_hash = hashlib.md5(text.encode('utf-8')).hexdigest()
    
    uploaded_chunks = 0
    for chunk in chunks:
        try:
            chunk_embedding, tokens = openai_manager.generate_embedding(chunk['text'])
            cost_tracker.add_embedding(tokens)
            
            chunk_doc_id = f"{content_hash}_{chunk['chunk_index']}"
            
            success = search_manager.upload_document(
                doc_id=chunk_doc_id,
                content=chunk['text'],
                vector=chunk_embedding,
                provider=provider,
                folder=folder,
                document_name=doc_name,
                chunk_index=chunk['chunk_index'],
                total_chunks=chunk['total_chunks']
            )
            
            if success:
                uploaded_chunks += 1
        except Exception as e:
            logger.warning(f"      Failed to upload chunk {chunk['chunk_index']}: {e}")
            continue
    
    if uploaded_chunks == 0:
        logger.warning(f"      FAILED: Could not upload any chunks")
        return {}, False
    
    logger.info(f"      Step 3b: Indexed {uploaded_chunks}/{len(chunks)} chunks")
    
    # ========================================================================
    # STEP 4: EXTRACT EACH FIELD WITH RAG SEARCH + VISION
    # ========================================================================
    logger.info(f"      Step 4: Extracting {len(fields)} fields (text + vision)...")
    
    FIELD_LIBRARY = getattr(prompt_module, 'FIELD_LIBRARY', {})
    SYSTEM_PROMPT_CONFIG = getattr(prompt_module, 'SYSTEM_PROMPT_CONFIG', {})
    
    extracted_data = {}
    
    for field_idx, field_name in enumerate(fields, 1):
        try:
            field_info = FIELD_LIBRARY.get(field_name, {})
            field_desc = field_info.get('description', field_name)
            
            logger.info(f"        Field {field_idx}/{len(fields)}: {field_name}")
            
            # --- 4A: Field-specific RAG search (text-based, same as text mode) ---
            field_query_parts = [
                field_name.replace('_', ' '),
                field_desc
            ]
            hints = field_info.get('extraction_hints', [])
            if hints:
                field_query_parts.append(' '.join(hints[:2]))
            
            field_query_text = ' '.join(field_query_parts)
            field_embedding, query_tokens = openai_manager.generate_embedding(
                field_query_text
            )
            cost_tracker.add_embedding(query_tokens)
            
            similar_docs = search_manager.search_similar(
                vector=field_embedding,
                provider=provider,
                folder=folder,
                top_k=3
            )
            
            logger.info(f"          RAG: {len(similar_docs)} chunks found")
            
            # --- 4B: Build prompt with RAG context ---
            prompt = _build_multimodal_prompt(
                field_name=field_name,
                field_info=field_info,
                similar_docs=similar_docs,
                fallback_text=chunks[0]['text'] if chunks else "",
                system_config=SYSTEM_PROMPT_CONFIG
            )
            
            # --- 4C: GPT Vision extraction (text + image) ---
            # THIS IS THE KEY DIFFERENCE FROM TEXT RAG:
            # We send both text context AND the document image
            result, tokens = openai_manager.extract_fields(
                prompt=prompt,
                temperature=0.1,
                use_vision=True,
                image_base64=primary_image_b64,
                image_format=primary_image_format
            )
            
            cost_tracker.add_gpt_tokens(
                input_tokens=tokens['input_tokens'],
                output_tokens=tokens['output_tokens']
            )
            
            if field_name in result:
                extracted_data[field_name] = result[field_name]
                value = result[field_name].get('value', 'Unknown')
                conf = result[field_name].get('confidence', 0.0)
                logger.info(f"          Result: {value} (conf: {conf:.2f})")
            else:
                extracted_data[field_name] = {
                    'value': 'Unknown', 'confidence': 0.0
                }
                logger.info(f"          WARNING: Field not in response")
        
        except Exception as e:
            logger.error(f"          ERROR: {e}")
            extracted_data[field_name] = {
                'value': 'Unknown', 'confidence': 0.0
            }
    
    logger.info(
        f"      Step 4 complete: {len(extracted_data)}/{len(fields)} fields"
    )
    
    return extracted_data, True


def _convert_to_images(
    doc_bytes: bytes, doc_name: str, extension: str
) -> List[Dict]:
    """
    Convert document to base64-encoded page images.
    
    Returns:
        List of {'base64': str, 'format': str, 'page': int}
        Empty list if conversion fails
    """
    try:
        ext = extension.lower().strip('.')
        
        # Already an image - encode directly
        image_extensions = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp']
        if ext in image_extensions:
            b64 = base64.b64encode(doc_bytes).decode('utf-8')
            fmt = ext.replace('jpg', 'jpeg')
            return [{'base64': b64, 'format': fmt, 'page': 1}]
        
        # PDF or Office - convert pages to images
        if ext in ['pdf', 'docx', 'doc', 'tiff', 'tif']:
            from services.document_converter import DocumentConverter
            converter = DocumentConverter(dpi=200)
            images = converter.convert_to_images(doc_bytes, doc_name)
            
            if not images:
                return []
            
            result = []
            for img_bytes, page_info in images:
                b64 = base64.b64encode(img_bytes).decode('utf-8')
                page_num = int(page_info.replace('page_', '').replace('image', '1'))
                result.append({
                    'base64': b64,
                    'format': 'png',
                    'page': page_num
                })
            
            return result
        
        return []
        
    except Exception as e:
        logger.error(f"Document to image conversion failed: {e}")
        return []


def _build_multimodal_prompt(
    field_name: str,
    field_info: dict,
    similar_docs: list,
    fallback_text: str,
    system_config: dict
) -> str:
    """
    Build extraction prompt for multimodal mode.
    
    Same as text mode prompt but adds instruction to use the attached image
    for visual verification (handwriting, checkboxes, stamps, layouts).
    """
    field_desc = field_info.get('description', field_name)
    
    parts = []
    
    # System role
    parts.append(system_config.get('role', 'You are a data extraction assistant.'))
    parts.append("")
    
    # Task (multimodal-specific instruction)
    parts.append(f"TASK: Extract the '{field_name}' field from the document.")
    parts.append("You have both the OCR text AND the original document image.")
    parts.append("Use the image to verify handwritten text, checkboxes, stamps,")
    parts.append("signatures, and any visual elements that OCR may have missed.")
    parts.append("")
    
    # Field definition
    parts.append("FIELD DEFINITION:")
    parts.append(f"  Name: {field_name}")
    parts.append(f"  Description: {field_desc}")
    parts.append(f"  Type: {field_info.get('type', 'string')}")
    
    if 'format' in field_info:
        parts.append(f"  Format: {field_info['format']}")
    if 'examples' in field_info:
        parts.append(f"  Valid examples: {', '.join(field_info['examples'])}")
    if 'validation' in field_info:
        parts.append(f"  Validation: {field_info['validation']}")
    parts.append("")
    
    # Document context from RAG (text-based)
    parts.append("OCR TEXT (from relevant sections):")
    parts.append("-" * 40)
    
    if similar_docs:
        total_chars = 0
        max_chars = 6000  # Slightly smaller than text mode (image takes tokens too)
        
        for idx, doc in enumerate(similar_docs, 1):
            doc_content = doc.get('content', '')
            doc_score = doc.get('score', 0)
            
            if total_chars + len(doc_content) > max_chars:
                remaining = max_chars - total_chars
                if remaining > 200:
                    parts.append(f"\n[Section {idx} (relevance: {doc_score:.2f})]:")
                    parts.append(doc_content[:remaining])
                break
            
            parts.append(f"\n[Section {idx} (relevance: {doc_score:.2f})]:")
            parts.append(doc_content)
            total_chars += len(doc_content)
    else:
        parts.append(fallback_text[:3000] if fallback_text else "")
    
    parts.append("-" * 40)
    parts.append("")
    
    # Vision instruction
    parts.append("IMPORTANT: Also examine the attached document IMAGE carefully.")
    parts.append("The image may contain information not captured by OCR, such as")
    parts.append("handwritten entries, checked boxes, stamps, or visual layouts.")
    parts.append("")
    
    # Output format
    parts.append("OUTPUT FORMAT (JSON only, no markdown):")
    parts.append('{')
    parts.append(f'  "{field_name}": {{')
    parts.append('    "value": "extracted_value",')
    parts.append('    "confidence": 0.00-1.00')
    parts.append('  }')
    parts.append('}')
    parts.append("")
    
    # Rules
    rules = system_config.get('rules', [])
    if rules:
        parts.append("RULES:")
        for rule in rules[:3]:
            parts.append(f"  - {rule}")
    
    return "\n".join(parts)
