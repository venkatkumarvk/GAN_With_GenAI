# CONFIDENCE SCORE DEBUG GUIDE

## ❓ **WHY IS CONFIDENCE 0.5 (DEFAULT)?**

If you're seeing confidence = 0.5 for all fields, it means **GPT-4o is not returning the proper JSON format**.

---

## 🔍 **HOW TO DEBUG**

### **Step 1: Check Logs**

Look for these warning messages in logs:

```
⚠️ Warning: Field 'first_name' returned as string (not dict), GPT-4o didn't follow format!
```

This means GPT-4o returned:
```json
{
  "first_name": "John"  ← String (WRONG!)
}
```

Instead of:
```json
{
  "first_name": {
    "value": "John",
    "confidence": 0.95  ← Dict with confidence (CORRECT!)
  }
}
```

### **Step 2: Check Sample Field Log**

Look for this log entry:
```
Sample field format - first_name: str = John
```

If it says **`str`** → GPT-4o returned string (wrong format)
If it says **`dict`** → GPT-4o returned dict (correct format)

---

## 🎯 **ROOT CAUSES**

### **Cause 1: Prompt Not Clear Enough**

**Problem:** GPT-4o ignores output format instructions

**Solution:** The prompt in `prompt_config.py` is already very clear:
```python
"output_format": """
Return a JSON object with ALL configured fields. For each field provide:
{
  "field_name": {
    "value": "extracted value or 'NA'",
    "confidence": 0.XX
  }
}
"""
```

### **Cause 2: GPT-4o Temperature Too High**

**Problem:** Higher temperature = less structured output

**Current Setting:**
```python
# In helper.py extract_fields()
temperature=0.0  ← Already at minimum!
```

### **Cause 3: Context Too Long**

**Problem:** Very long prompts → GPT-4o skips format instructions

**Solution:** Already implemented:
- Priority chunking (max 1000 chars)
- RAG examples limited (top 3)
- Document truncation

---

## ✅ **EXPECTED BEHAVIOR**

### **Correct GPT-4o Response:**
```json
{
  "first_name": {
    "value": "John",
    "confidence": 0.95
  },
  "last_name": {
    "value": "Doe",
    "confidence": 0.92
  },
  "email": {
    "value": "john@example.com",
    "confidence": 0.88
  },
  "cell": {
    "value": "555-1234",
    "confidence": 0.75
  }
}
```

### **Log Output:**
```
Sample field format - first_name: dict = {'value': 'John', 'confidence': 0.95}
```

### **CSV Output:**
```csv
first_name,first_name_confidence,...
John,0.95,...
```

---

## ⚠️ **INCORRECT BEHAVIOR (0.5 Default)**

### **Wrong GPT-4o Response:**
```json
{
  "first_name": "John",
  "last_name": "Doe",
  "email": "john@example.com",
  "cell": "555-1234"
}
```

### **Log Output:**
```
⚠️ Warning: Field 'first_name' returned as string (not dict), GPT-4o didn't follow format!
Sample field format - first_name: str = John
```

### **CSV Output:**
```csv
first_name,first_name_confidence,...
John,0.5,...  ← Default 0.5!
```

---

## 🔧 **TROUBLESHOOTING STEPS**

### **1. Check Your Logs**
```bash
# Look for warnings
grep "Warning:" logs/extraction_*.log

# Check sample field format
grep "Sample field format" logs/extraction_*.log
```

**If you see warnings** → GPT-4o is not following format

### **2. Check Prompt Config**
```bash
# Verify output format is correct
grep -A 10 "output_format" prompt_config.py
```

**Should see:**
```python
"output_format": """
Return a JSON object with ALL configured fields. For each field provide:
{
  "field_name": {
    "value": "extracted value or 'NA'",
    "confidence": 0.XX
  }
}
"""
```

### **3. Test with Simple Document**

Try with a very simple, clean document:
- Single page PDF
- Clear text (no OCR errors)
- Only 2-3 fields configured

If this works → Issue is document complexity
If this fails → Issue is prompt/model

### **4. Check Azure OpenAI Deployment**

Make sure you're using GPT-4o (not GPT-3.5):
```json
// config.json
{
  "azure_openai_gpt": {
    "deployment_name": "gpt-4o"  ← Must be GPT-4o!
  }
}
```

---

## 💡 **TEMPORARY WORKAROUND**

If GPT-4o consistently returns strings, you can use heuristic confidence:

**Edit main.py calculate_best_values():**
```python
else:
    # field_data is a string - estimate confidence
    value = field_data if field_data else 'NA'
    
    # Heuristic confidence based on value quality
    if value == 'NA':
        confidence = 0.5
    elif len(value) > 2 and value.strip():
        confidence = 0.85  # Reasonable default
    else:
        confidence = 0.6  # Short values less confident
```

**⚠️ Note:** This is NOT ideal - GPT-4o should return proper format!

---

## 🎯 **BEST SOLUTION**

### **Reinforce Prompt Instructions:**

Add to `prompt_config.py`:
```python
"output_format": """
CRITICAL: You MUST return a JSON object in this EXACT format:
{
  "field_name": {
    "value": "extracted value",
    "confidence": 0.XX
  }
}

DO NOT return simplified format like:
{
  "field_name": "value"  ← WRONG!
}

EVERY field must have both 'value' and 'confidence' keys.
""",
```

---

## 📊 **WHAT LOGS SHOW**

### **Good Extraction (Confidence Working):**
```
INFO - Used TEXT RAG for CV_2025.pdf
INFO - Sample field format - first_name: dict = {'value': 'John', 'confidence': 0.95}
INFO - Sample field format - last_name: dict = {'value': 'Doe', 'confidence': 0.92}
```

### **Bad Extraction (Default 0.5):**
```
INFO - Used TEXT RAG for CV_2025.pdf
INFO - Sample field format - first_name: str = John
⚠️ Warning: Field 'first_name' returned as string (not dict), GPT-4o didn't follow format!
⚠️ Warning: Field 'last_name' returned as string (not dict), GPT-4o didn't follow format!
```

---

## ✅ **CHECKLIST**

To get proper confidence scores:

- [ ] Verify GPT-4o deployment (not GPT-3.5)
- [ ] Check temperature = 0.0
- [ ] Review prompt output_format in prompt_config.py
- [ ] Check logs for "Sample field format"
- [ ] Look for warnings about string format
- [ ] Test with simple, clean document
- [ ] Verify Azure OpenAI API version is current

---

## 🎉 **SUMMARY**

**Problem:** Confidence = 0.5 (default value)

**Root Cause:** GPT-4o returning strings instead of dicts

**Detection:** Check logs for:
```
Sample field format - first_name: str = John  ← BAD!
Sample field format - first_name: dict = {'value': 'John', 'confidence': 0.95}  ← GOOD!
```

**Solution:**
1. Verify prompt format is clear
2. Check GPT-4o deployment
3. Review logs for warnings
4. Test with simple documents

**The system is already set up correctly - if GPT-4o follows the prompt format, you'll get proper confidence scores!**
