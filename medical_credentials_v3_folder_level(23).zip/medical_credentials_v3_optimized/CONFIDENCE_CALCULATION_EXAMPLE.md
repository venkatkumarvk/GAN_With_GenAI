# CONFIDENCE CALCULATION - HOW IT WORKS

## ✅ **CORRECT: Only Winning Value's Confidences**

The system calculates confidence using **ONLY the confidences of the winning value**, not all values!

---

## 📊 **EXAMPLE 1: Different Values**

### **Input:**
```
Document 1: first_name = "John" (confidence: 0.95)
Document 2: first_name = "John" (confidence: 0.92)
Document 3: first_name = "Jon"  (confidence: 0.75)  ← Different!
Document 4: first_name = "John" (confidence: 0.88)
```

### **Step 1: Group by Value**
```
"John": [0.95, 0.92, 0.88]  ← 3 occurrences
"Jon":  [0.75]              ← 1 occurrence
```

### **Step 2: Winner = Highest Frequency**
```
"John" wins (3 occurrences vs 1)
```

### **Step 3: Calculate Confidence**
```
✅ CORRECT: Use only "John" confidences
confidence = (0.95 + 0.92 + 0.88) / 3 = 0.917

❌ WRONG: Would use ALL values
confidence = (0.95 + 0.92 + 0.88 + 0.75) / 4 = 0.875
```

### **Final Result:**
```json
{
  "first_name": {
    "value": "John",
    "confidence": 0.92  ← Rounded from 0.917
  }
}
```

**The 0.75 from "Jon" is NOT included!** ✅

---

## 📊 **EXAMPLE 2: Same Value, Different Confidences**

### **Input:**
```
Document 1: email = "john@example.com" (confidence: 0.95)
Document 2: email = "john@example.com" (confidence: 0.92)
Document 3: email = "john@example.com" (confidence: 0.88)
Document 4: email = "john@example.com" (confidence: 0.85)
```

### **Step 1: Group by Value**
```
"john@example.com": [0.95, 0.92, 0.88, 0.85]  ← 4 occurrences
```

### **Step 2: Winner**
```
"john@example.com" (only value)
```

### **Step 3: Calculate Confidence**
```
confidence = (0.95 + 0.92 + 0.88 + 0.85) / 4 = 0.90
```

### **Final Result:**
```json
{
  "email": {
    "value": "john@example.com",
    "confidence": 0.90
  }
}
```

**Average reflects quality across all documents!** ✅

---

## 📊 **EXAMPLE 3: Tie-Breaking with Confidence**

### **Input:**
```
Document 1: cell = "555-1234" (confidence: 0.95)
Document 2: cell = "555-1234" (confidence: 0.90)
Document 3: cell = "555-5678" (confidence: 0.85)
Document 4: cell = "555-5678" (confidence: 0.82)
```

### **Step 1: Group by Value**
```
"555-1234": [0.95, 0.90]  ← 2 occurrences, avg: 0.925
"555-5678": [0.85, 0.82]  ← 2 occurrences, avg: 0.835
```

### **Step 2: Tied Frequency - Use Confidence**
```
Both have 2 occurrences
"555-1234" avg: 0.925 ← WINNER!
"555-5678" avg: 0.835
```

### **Step 3: Calculate Final Confidence**
```
Use only winner's confidences:
confidence = (0.95 + 0.90) / 2 = 0.925
```

### **Final Result:**
```json
{
  "cell": {
    "value": "555-1234",
    "confidence": 0.93  ← Rounded from 0.925
  }
}
```

**Only "555-1234" confidences used, not "555-5678"!** ✅

---

## 📊 **EXAMPLE 4: Single Occurrence**

### **Input:**
```
Document 1: birth_date = "01/15/1990" (confidence: 0.88)
Document 2: birth_date = "NA" (confidence: 0.50)
Document 3: birth_date = "NA" (confidence: 0.50)
Document 4: birth_date = "NA" (confidence: 0.50)
```

### **Step 1: Group by Value (exclude NA)**
```
"01/15/1990": [0.88]  ← 1 occurrence
(NA values ignored)
```

### **Step 2: Winner**
```
"01/15/1990" (only non-NA value)
```

### **Step 3: Calculate Confidence**
```
Only one value:
confidence = 0.88 / 1 = 0.88
```

### **Final Result:**
```json
{
  "birth_date": {
    "value": "01/15/1990",
    "confidence": 0.88
  }
}
```

**Single confidence used directly!** ✅

---

## 🎯 **WHY THIS IS CORRECT**

### **Scenario A: OCR Error**
```
3 docs: "Smith" (0.95, 0.92, 0.88) ← Correct value
1 doc: "Smyth" (0.75) ← OCR error

Winner: "Smith"
Confidence: (0.95 + 0.92 + 0.88) / 3 = 0.92

✅ High confidence because majority is reliable!
❌ Would be 0.875 if we included "Smyth" 0.75
```

### **Scenario B: Consistent Value**
```
4 docs: "John" (0.95, 0.92, 0.88, 0.85)

Winner: "John"
Confidence: (0.95 + 0.92 + 0.88 + 0.85) / 4 = 0.90

✅ Reflects average quality across all extractions
```

### **Scenario C: Low Quality Document**
```
1 doc: "John" (0.45) ← Barely readable
3 docs: "Jon" (0.95, 0.92, 0.88) ← Clear OCR

Winner: "Jon" (higher frequency)
Confidence: (0.95 + 0.92 + 0.88) / 3 = 0.92

✅ High confidence because winner is reliable!
❌ Would be 0.80 if we included "John" 0.45
```

---

## 💡 **COMPLETE ALGORITHM**

```python
def calculate_confidence(field):
    # Step 1: Collect all (value, confidence) pairs
    occurrences = []
    for doc in documents:
        value = doc[field]['value']
        confidence = doc[field]['confidence']
        if value != 'NA':
            occurrences.append((value, confidence))
    
    # Step 2: Group by value
    value_groups = {}
    for value, confidence in occurrences:
        if value not in value_groups:
            value_groups[value] = []
        value_groups[value].append(confidence)
    
    # Step 3: Find winner (highest frequency, then highest confidence)
    max_freq = max(len(confs) for confs in value_groups.values())
    top_values = [(v, c) for v, c in value_groups.items() if len(c) == max_freq]
    
    if len(top_values) > 1:
        # Tie - choose highest avg confidence
        winner_value, winner_confs = max(top_values, key=lambda x: sum(x[1])/len(x[1]))
    else:
        winner_value, winner_confs = top_values[0]
    
    # Step 4: Calculate confidence using ONLY winner's confidences
    final_confidence = sum(winner_confs) / len(winner_confs)
    
    return {
        'value': winner_value,
        'confidence': round(final_confidence, 2)
    }
```

---

## ✅ **KEY POINTS**

### **1. Winner Determined First**
```
Use frequency (most common value)
If tied, use highest average confidence
```

### **2. Confidence Calculated Second**
```
Take average of ONLY the winner's confidences
Do NOT include loser values' confidences
```

### **3. Why This Makes Sense**
```
Winner's confidence = reliability of winning value
Including losers would dilute the confidence
Each value judged independently
```

---

## 📊 **COMPARISON**

### **Method 1: Only Winner's Confidences (CORRECT - CURRENT)**
```
Input:
  3x "John" (0.95, 0.92, 0.88)
  1x "Jon" (0.75)

Result:
  value: "John"
  confidence: 0.92  ← Only "John" confidences

✅ Shows reliability of "John" extractions
```

### **Method 2: All Confidences (WRONG)**
```
Input:
  3x "John" (0.95, 0.92, 0.88)
  1x "Jon" (0.75)

Result:
  value: "John"
  confidence: 0.875  ← Includes "Jon" confidence!

❌ Misleading - "Jon" confidence shouldn't affect "John"
```

---

## 🎉 **SUMMARY**

**How Confidence is Calculated:**

1. ✅ Group values with their confidences
2. ✅ Select winner (frequency + tie-breaker)
3. ✅ Calculate average using ONLY winner's confidences
4. ✅ Ignore all other values' confidences

**Example:**
```
3x "John" (0.95, 0.92, 0.88) ← WINNER
1x "Jon" (0.75) ← IGNORED

Final: "John" with confidence 0.92
```

**Why This is Correct:**
- ✅ Confidence reflects reliability of the winning value
- ✅ Losing values don't affect winner's score
- ✅ Each value judged independently
- ✅ Clear, logical calculation

**The system is already doing this correctly!** ✅
