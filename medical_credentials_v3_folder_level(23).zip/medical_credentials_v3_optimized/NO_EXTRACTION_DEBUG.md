# NO EXTRACTION - DEBUG GUIDE

## ❌ **CRITICAL ISSUE: NO FIELD DATA IN CSV**

If your CSV shows empty columns and GPT-4o cost = $0.00, **extraction is not happening!**

---

## 🔍 **SYMPTOMS**

1. **CSV has no field data** - Only provider_name, provider_id columns filled
2. **GPT-4o cost = $0.00** - Should be > $0 if extraction ran
3. **Column shows ########** - provider_id column too narrow (not critical)

---

## 🎯 **ROOT CAUSES**

### **Cause 1: Documents Not Downloading**
```
Step 1 fails: Could not download document
```

**Check:**
- Azure Blob Storage connection string correct?
- Input container name correct?
- Documents actually uploaded to Azure?

### **Cause 2: OCR Failing**
```
Step 2 fails: OCR failed
```

**Check:**
- Azure Document Intelligence credentials correct?
- File format supported? (PDF, images only)
- File not corrupted?

### **Cause 3: Insufficient Text**
```
Step 3 fails: Text length < minimum (default 50 chars)
```

**Check:**
- Document actually has text? (not blank page)
- OCR extracted text? (check logs)
- min_text_length setting too high?

### **Cause 4: Azure OpenAI Not Configured**
```
Step 8 fails: Cannot call GPT-4o
```

**Check:**
- Azure OpenAI credentials correct?
- Deployment name correct? (must be 'gpt-4o')
- API key valid?
- Endpoint URL correct?

---

## 📋 **NEW DIAGNOSTIC LOGGING**

### **System now logs each step:**

```
✓ Step 1 Complete: Downloaded 45231 bytes
✓ Step 2 Complete: Extracted 1523 characters from 1 pages
✓ Step 3 Complete: Text length sufficient (1523 chars)
✓ Step 4 Complete: needs_chunking=False, chunks=0
✓ Step 5 Complete: Indexed document
✓ Step 6 Complete: RAG search found 3 similar docs
✓ Step 7 Complete: Prompt built (2341 chars)
✓ Step 8 Complete: Used TEXT RAG for document.pdf
GPT-4o tokens: input=1234, output=567
Sample field format - first_name: dict = {'value': 'John', 'confidence': 0.95}
```

### **If extraction fails, you'll see:**

```
❌ FAILED Step 3: Insufficient text (23 < 50 chars) for document.pdf
```

**This tells you EXACTLY where it failed!**

---

## 🔧 **DEBUGGING STEPS**

### **Step 1: Check Logs**

```bash
# Look for failed steps
grep "FAILED Step" logs/extraction_*.log

# Check which step failed
grep "Step [0-9]" logs/extraction_*.log | tail -20
```

### **Step 2: Check Config**

**config.json must have ALL these:**
```json
{
  "azure_blob": {
    "connection_string": "DefaultEndpointsProtocol=https;...",
    "inputcontainer": "inputcontainer",
    "outputcontainer": "outputcontainer"
  },
  "azure_document_intelligence": {
    "endpoint": "https://your-resource.cognitiveservices.azure.com/",
    "api_key": "your-key-here"
  },
  "azure_openai_gpt": {
    "endpoint": "https://your-openai.openai.azure.com/",
    "api_key": "your-key-here",
    "deployment_name": "gpt-4o",
    "api_version": "2024-02-01"
  },
  "azure_openai_embedding": {
    "endpoint": "https://your-openai.openai.azure.com/",
    "api_key": "your-key-here",
    "deployment_name": "text-embedding-ada-002",
    "api_version": "2024-02-01"
  },
  "extraction": {
    "min_text_length": 50
  }
}
```

### **Step 3: Test Each Service**

**Test Blob Storage:**
```python
from azure.storage.blob import BlobServiceClient
conn_str = "your_connection_string"
blob_service = BlobServiceClient.from_connection_string(conn_str)
containers = blob_service.list_containers()
print([c.name for c in containers])
# Should show: ['inputcontainer', 'outputcontainer']
```

**Test Document Intelligence:**
```python
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential

client = DocumentIntelligenceClient(
    endpoint="your_endpoint",
    credential=AzureKeyCredential("your_key")
)
# Should not raise error
```

**Test Azure OpenAI:**
```python
from openai import AzureOpenAI

client = AzureOpenAI(
    api_key="your_key",
    api_version="2024-02-01",
    azure_endpoint="your_endpoint"
)

response = client.chat.completions.create(
    model="gpt-4o",  # deployment name
    messages=[{"role": "user", "content": "Hi"}]
)
print(response.choices[0].message.content)
# Should return response
```

### **Step 4: Check Minimum Text Length**

**If documents have little text, lower the threshold:**
```json
{
  "extraction": {
    "min_text_length": 10  ← Lower from 50
  }
}
```

---

## 💡 **COMMON ISSUES**

### **Issue 1: Wrong Deployment Name**

**Config says:**
```json
"deployment_name": "gpt-35-turbo"  ← WRONG!
```

**Should be:**
```json
"deployment_name": "gpt-4o"  ← CORRECT!
```

### **Issue 2: Wrong API Version**

**Config says:**
```json
"api_version": "2023-05-15"  ← OLD!
```

**Should be:**
```json
"api_version": "2024-02-01"  ← CURRENT!
```

### **Issue 3: Missing Credentials**

**Config has:**
```json
"api_key": ""  ← EMPTY!
```

**Should have:**
```json
"api_key": "abc123def456..."  ← ACTUAL KEY!
```

### **Issue 4: Wrong Endpoint**

**Config has:**
```json
"endpoint": "https://api.openai.com/"  ← OpenAI (not Azure!)
```

**Should have:**
```json
"endpoint": "https://your-resource.openai.azure.com/"  ← Azure OpenAI!
```

---

## 🎯 **EXACT STEPS TO FIX**

### **1. Run System with New Logging**

```bash
python main.py
```

### **2. Check Logs Immediately**

```bash
tail -f logs/extraction_*.log
```

**Look for:**
```
✓ Step 1 Complete: Downloaded...
✓ Step 2 Complete: Extracted...
✓ Step 3 Complete: Text length sufficient...
✓ Step 4 Complete: needs_chunking...
✓ Step 5 Complete: Indexed...
✓ Step 6 Complete: RAG search...
✓ Step 7 Complete: Prompt built...
✓ Step 8 Complete: Used TEXT RAG...
GPT-4o tokens: input=1234, output=567  ← MUST SEE THIS!
```

### **3. If You See "FAILED Step X"**

**Failed Step 1:** Check Azure Blob Storage
- Connection string
- Container names
- Documents uploaded

**Failed Step 2:** Check Document Intelligence
- Endpoint correct
- API key valid
- File format supported

**Failed Step 3:** Check text length
- Lower min_text_length in config.json
- Verify OCR extracted text

**Failed Step 8:** Check Azure OpenAI
- Endpoint correct
- API key valid
- Deployment name = 'gpt-4o'

---

## 📊 **EXPECTED LOG OUTPUT**

### **Successful Extraction:**
```
INFO - Processing: ANAND-NICHOLS/GEN & HR/CV_2025.pdf
INFO - Step 1: Downloading document...
INFO - ✓ Step 1 Complete: Downloaded 45231 bytes
INFO - Step 2: Running OCR...
INFO - ✓ Step 2 Complete: Extracted 1523 characters from 1 pages
INFO - ✓ Step 3 Complete: Text length sufficient (1523 chars)
INFO - Step 4: Chunking document...
INFO - ✓ Step 4 Complete: needs_chunking=False, chunks=0
INFO - ✓ Step 5 Complete: Indexed document
INFO - ✓ Step 6 Complete: RAG search found 3 similar docs
INFO - Step 7: Building extraction prompt...
INFO - ✓ Step 7 Complete: Prompt built (2341 chars)
INFO - Step 8: Calling GPT-4o for extraction...
INFO - ✓ Step 8 Complete: Used TEXT RAG for CV_2025.pdf
INFO - GPT-4o tokens: input=1234, output=567
INFO - Sample field format - first_name: dict = {'value': 'John', 'confidence': 0.95}
```

**Result:** Fields extracted, CSV has data, GPT-4o cost > $0 ✅

---

### **Failed Extraction:**
```
INFO - Processing: ANAND-NICHOLS/GEN & HR/blank.pdf
INFO - Step 1: Downloading document...
INFO - ✓ Step 1 Complete: Downloaded 1234 bytes
INFO - Step 2: Running OCR...
INFO - ✓ Step 2 Complete: Extracted 15 characters from 1 pages
WARNING - ❌ FAILED Step 3: Insufficient text (15 < 50 chars) for blank.pdf
```

**Result:** No extraction, CSV empty, GPT-4o cost = $0 ❌

---

## ✅ **CHECKLIST**

- [ ] Azure Blob Storage connection string correct
- [ ] Input container has documents
- [ ] Azure Document Intelligence credentials correct
- [ ] Azure OpenAI GPT credentials correct
- [ ] Deployment name is 'gpt-4o' (not gpt-35-turbo)
- [ ] Azure OpenAI Embedding credentials correct
- [ ] min_text_length not too high (try 10 if documents small)
- [ ] Check logs for "Step X Complete" messages
- [ ] Check logs for "GPT-4o tokens:" message
- [ ] Check logs for "Sample field format" message

---

## 🎉 **SUMMARY**

**Problem:** No field data, GPT-4o cost = $0

**Root Cause:** Extraction not running (fails at some step)

**Solution:**
1. Check logs for "FAILED Step X"
2. Fix the service that failed
3. Verify credentials in config.json
4. Run again and check logs

**New logging shows EXACTLY where it fails!** ✅
