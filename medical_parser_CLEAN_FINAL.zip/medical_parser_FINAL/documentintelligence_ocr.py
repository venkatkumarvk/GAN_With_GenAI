"""
Azure Document Intelligence OCR Module
Version: 1.0.0b4

Handles document OCR extraction using Azure Document Intelligence
Supports: PDF, images (JPG, PNG, TIFF, BMP, GIF, WEBP)
"""

import logging
from typing import Tuple, Dict
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeDocumentRequest, AnalyzeResult
from azure.core.credentials import AzureKeyCredential


class DocumentIntelligenceOCR:
    """
    Document Intelligence OCR Manager for text extraction
    
    Uses Azure Document Intelligence API version 1.0.0b4
    """
    
    def __init__(self, config: dict):
        """
        Initialize Document Intelligence client
        
        Args:
            config: Configuration dict with endpoint, key, api_version
        """
        self.logger = logging.getLogger(__name__)
        
        self.endpoint = config.get('endpoint')
        self.key = config.get('key')
        self.api_version = config.get('api_version', '2024-07-31-preview')
        
        if not self.endpoint or not self.key:
            raise ValueError("Document Intelligence endpoint and key are required")
        
        # Initialize client with v1.0.0b4 API
        self.client = DocumentIntelligenceClient(
            endpoint=self.endpoint,
            credential=AzureKeyCredential(self.key),
            api_version=self.api_version
        )
        
        self.logger.info(f"Document Intelligence initialized: {self.endpoint}")
    
    def extract_text(self, doc_bytes: bytes, extension: str) -> Tuple[str, int, bool]:
        """
        Extract text from document (POC-compatible interface)
        
        Args:
            doc_bytes: Document bytes
            extension: File extension (e.g., '.pdf', '.jpg')
        
        Returns:
            Tuple of (text_content, page_count, success)
        """
        try:
            result = self.extract_text_from_document(doc_bytes, extension)
            
            if result and 'content' in result:
                text = result['content']
                pages = result.get('pages', 1)
                return text, pages, True
            else:
                return "", 0, False
                
        except Exception as e:
            self.logger.error(f"Text extraction failed: {e}")
            return "", 0, False
    
    def extract_text_from_document(
        self, 
        doc_bytes: bytes, 
        doc_name: str
    ) -> Tuple[str, int, Dict]:
        """
        Extract text from document using OCR
        
        Args:
            doc_bytes: Binary document content
            doc_name: Document filename (for extension detection)
            
        Returns:
            Tuple of (extracted_text, page_count, metadata)
        """
        try:
            self.logger.info(f"Starting OCR for document: {doc_name}")
            
            # Determine content type from file extension
            content_type = self._get_content_type(doc_name)
            
            # Create analyze request
            analyze_request = AnalyzeDocumentRequest(bytes_source=doc_bytes)
            
            # Call Document Intelligence - prebuilt-read model for OCR
            poller = self.client.begin_analyze_document(
                model_id="prebuilt-read",
                analyze_request=analyze_request,
                content_type=content_type
            )
            
            # Wait for result
            result: AnalyzeResult = poller.result()
            
            # Extract text content
            extracted_text = result.content if result.content else ""
            
            # Get page count
            page_count = len(result.pages) if result.pages else 0
            
            # Build metadata
            metadata = {
                'page_count': page_count,
                'has_content': bool(extracted_text),
                'content_length': len(extracted_text),
                'model_id': 'prebuilt-read',
                'api_version': self.api_version
            }
            
            self.logger.info(
                f"OCR complete: {doc_name} - {page_count} pages, "
                f"{len(extracted_text)} chars"
            )
            
            return extracted_text, page_count, metadata
            
        except Exception as e:
            self.logger.error(f"OCR failed for {doc_name}: {str(e)}")
            raise
    
    def _get_content_type(self, filename: str) -> str:
        """
        Determine content type from file extension
        
        Args:
            filename: Document filename
            
        Returns:
            Content type string
        """
        extension = filename.lower().split('.')[-1]
        
        content_types = {
            'pdf': 'application/pdf',
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'tiff': 'image/tiff',
            'tif': 'image/tiff',
            'bmp': 'image/bmp',
            'gif': 'image/gif',
            'webp': 'image/webp'
        }
        
        content_type = content_types.get(extension, 'application/octet-stream')
        
        if content_type == 'application/octet-stream':
            self.logger.warning(
                f"Unknown file extension: {extension}, "
                f"using application/octet-stream"
            )
        
        return content_type
    
    def extract_text_with_layout(
        self, 
        doc_bytes: bytes, 
        doc_name: str
    ) -> Tuple[str, int, Dict, list]:
        """
        Extract text with layout information (advanced)
        
        Args:
            doc_bytes: Binary document content
            doc_name: Document filename
            
        Returns:
            Tuple of (text, page_count, metadata, layout_info)
        """
        try:
            self.logger.info(f"Starting OCR with layout for: {doc_name}")
            
            content_type = self._get_content_type(doc_name)
            analyze_request = AnalyzeDocumentRequest(bytes_source=doc_bytes)
            
            # Use prebuilt-layout for structured extraction
            poller = self.client.begin_analyze_document(
                model_id="prebuilt-layout",
                analyze_request=analyze_request,
                content_type=content_type
            )
            
            result: AnalyzeResult = poller.result()
            
            extracted_text = result.content if result.content else ""
            page_count = len(result.pages) if result.pages else 0
            
            # Extract layout information
            layout_info = []
            if result.paragraphs:
                for para in result.paragraphs:
                    layout_info.append({
                        'content': para.content,
                        'role': para.role if hasattr(para, 'role') else None,
                        'bounding_regions': [
                            {
                                'page_number': region.page_number,
                                'polygon': region.polygon
                            }
                            for region in para.bounding_regions
                        ] if para.bounding_regions else []
                    })
            
            metadata = {
                'page_count': page_count,
                'has_content': bool(extracted_text),
                'content_length': len(extracted_text),
                'paragraph_count': len(layout_info),
                'model_id': 'prebuilt-layout',
                'api_version': self.api_version
            }
            
            self.logger.info(
                f"OCR with layout complete: {doc_name} - "
                f"{page_count} pages, {len(layout_info)} paragraphs"
            )
            
            return extracted_text, page_count, metadata, layout_info
            
        except Exception as e:
            self.logger.error(f"OCR with layout failed for {doc_name}: {str(e)}")
            raise
    
    def test_connection(self) -> bool:
        """
        Test Document Intelligence connection
        
        Returns:
            True if connection successful
        """
        try:
            # Simple test - just verify client is initialized
            if self.client and self.endpoint:
                self.logger.info("Document Intelligence connection test passed")
                return True
            return False
        except Exception as e:
            self.logger.error(f"Connection test failed: {str(e)}")
            return False


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_ocr_manager(config: dict) -> DocumentIntelligenceOCR:
    """
    Factory function to create OCR manager
    
    Args:
        config: Configuration dict
        
    Returns:
        DocumentIntelligenceOCR instance
    """
    return DocumentIntelligenceOCR(config)


def extract_text_simple(
    doc_bytes: bytes,
    doc_name: str,
    config: dict
) -> str:
    """
    Simple text extraction (convenience function)
    
    Args:
        doc_bytes: Document binary
        doc_name: Document filename
        config: OCR configuration
        
    Returns:
        Extracted text string
    """
    ocr = DocumentIntelligenceOCR(config)
    text, _, _ = ocr.extract_text_from_document(doc_bytes, doc_name)
    return text


# =============================================================================
# VALIDATION
# =============================================================================

if __name__ == "__main__":
    print("="*80)
    print("Document Intelligence OCR Module")
    print("Version: 1.0.0b4")
    print("="*80)
    
    # Example configuration
    example_config = {
        'endpoint': 'https://your-resource.cognitiveservices.azure.com/',
        'key': 'your-key-here',
        'api_version': '2024-07-31-preview'
    }
    
    print("\nExample usage:")
    print("```python")
    print("from documentintelligence_ocr import DocumentIntelligenceOCR")
    print("")
    print("# Initialize")
    print("ocr = DocumentIntelligenceOCR(config)")
    print("")
    print("# Extract text")
    print("text, pages, metadata = ocr.extract_text_from_document(")
    print("    doc_bytes=document_bytes,")
    print("    doc_name='sample.pdf'")
    print(")")
    print("```")
    print("\n" + "="*80)
    print("✓ Module ready for import")
    print("="*80)
