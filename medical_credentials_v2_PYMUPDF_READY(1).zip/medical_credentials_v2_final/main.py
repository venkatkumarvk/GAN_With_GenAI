"""
Medical Credentials Extraction - V2 FINAL (Updated)
===================================================
Uses new documentintelligence_ocr.py module
Handles ALL file types gracefully (no errors for unsupported files)
"""

import json
import logging
from datetime import datetime
from typing import Dict, List
import pandas as pd
from collections import Counter
import base64
from io import BytesIO
from PIL import Image

from logging_config import setup_logging
from helper import BlobManager, OpenAIManager
from documentintelligence_ocr import DocumentIntelligenceOCR  # NEW!
from production_index_manager import ProductionIndexManager, ProductionChunker
from prompt_builder import ExtractionPromptBuilder
from unified_rag import unified_rag_extraction
from costtracking import CostTracker
from config_validator import validate_config_file  # NEW!


def load_config(config_path: str = "config.json") -> Dict:
    """Load and validate configuration from JSON file"""
    # Use validator to load and check config
    config = validate_config_file(config_path)
    return config


def detect_folder_type(folder_name: str, config: Dict) -> str:
    """
    Detect folder type from folder name
    Handles formats like: "1. GEN & HR", "2. ED & TRAIN", etc.
    """
    # Remove common prefixes (numbers, dots, spaces)
    import re
    clean_folder = re.sub(r'^\d+\.\s*', '', folder_name).strip()
    folder_lower = clean_folder.lower()
    
    # Try exact match first (case-insensitive)
    for folder_type in config['folder_configs'].keys():
        if folder_type.lower() == folder_lower:
            return folder_type
    
    # Try partial match
    for folder_type in config['folder_configs'].keys():
        if folder_type.lower() in folder_lower:
            return folder_type
    
    # Fallback patterns
    if 'license' in folder_lower or 'lic' in folder_lower:
        if 'Licenses' in config['folder_configs']:
            return 'Licenses'
    elif 'personal' in folder_lower or 'identity' in folder_lower or 'gen' in folder_lower or 'hr' in folder_lower:
        # Check for GEN & HR pattern
        for folder_type in config['folder_configs'].keys():
            if 'gen' in folder_type.lower() and 'hr' in folder_type.lower():
                return folder_type
        if 'Personal' in config['folder_configs']:
            return 'Personal'
    elif 'education' in folder_lower or 'school' in folder_lower or 'train' in folder_lower or 'ed' in folder_lower:
        # Check for ED & TRAIN pattern
        for folder_type in config['folder_configs'].keys():
            if ('ed' in folder_type.lower() or 'education' in folder_type.lower()) and 'train' in folder_type.lower():
                return folder_type
        if 'Education' in config['folder_configs']:
            return 'Education'
    elif 'cert' in folder_lower or 'board' in folder_lower:
        if 'Certifications' in config['folder_configs']:
            return 'Certifications'
    elif 'work' in folder_lower or 'employ' in folder_lower or 'history' in folder_lower:
        if 'Work_History' in config['folder_configs']:
            return 'Work_History'
    elif 'insurance' in folder_lower or 'malpractice' in folder_lower:
        if 'Insurance' in config['folder_configs']:
            return 'Insurance'
    
    if config['processing'].get('skip_unknown_folders', False):
        return None
    else:
        return 'default'


def get_folder_config(folder_type: str, config: Dict) -> Dict:
    """Get configuration for specific folder type"""
    if folder_type in config['folder_configs']:
        return config['folder_configs'][folder_type]
    else:
        return config['default_config']


def convert_to_base64(file_bytes: bytes, file_type: str) -> str:
    """
    Convert file bytes to base64 string for multimodal processing
    Uses PyMuPDF (fitz) for PDF to image conversion
    
    Args:
        file_bytes: Raw file bytes
        file_type: File type (pdf, image, document, text)
    
    Returns:
        Base64 encoded string or None if failed
    """
    try:
        if file_type == 'image':
            # For images, convert to PNG format
            img = Image.open(BytesIO(file_bytes))
            buffered = BytesIO()
            img.convert('RGB').save(buffered, format="PNG")
            return base64.b64encode(buffered.getvalue()).decode('utf-8')
        
        elif file_type == 'pdf':
            # For PDFs, use PyMuPDF (fitz) to render first page as image
            try:
                import fitz  # PyMuPDF
                
                # Open PDF from bytes
                pdf_document = fitz.open(stream=file_bytes, filetype="pdf")
                
                # Get first page
                if len(pdf_document) > 0:
                    page = pdf_document[0]
                    
                    # Render page to image (pixmap)
                    # Use higher resolution for better quality (matrix for 2x zoom)
                    mat = fitz.Matrix(2, 2)
                    pix = page.get_pixmap(matrix=mat)
                    
                    # Convert pixmap to PNG bytes
                    img_bytes = pix.tobytes("png")
                    
                    # Convert to base64
                    pdf_document.close()
                    return base64.b64encode(img_bytes).decode('utf-8')
                else:
                    logging.warning("PDF has no pages")
                    return None
                    
            except ImportError:
                # fitz not installed, use raw PDF bytes as fallback
                logging.warning("PyMuPDF (fitz) not installed, using raw PDF bytes")
                return base64.b64encode(file_bytes).decode('utf-8')
            except Exception as e:
                logging.error(f"Error rendering PDF with fitz: {e}")
                # Fallback to raw bytes
                return base64.b64encode(file_bytes).decode('utf-8')
        
        elif file_type == 'document':
            # For DOC/DOCX, use raw bytes
            return base64.b64encode(file_bytes).decode('utf-8')
        
        else:
            # For any other type, use raw bytes
            return base64.b64encode(file_bytes).decode('utf-8')
            
    except Exception as e:
        logging.error(f"Error converting to base64 ({file_type}): {e}")
        return None


def save_provider_results(
    blob_manager: BlobManager,
    output_container: str,
    provider: str,
    folder: str,
    results: List[Dict],
    folder_config: Dict,
    config: Dict,
    logger: logging.Logger
):
    """Save results for a provider+folder immediately"""
    if not results:
        logger.warning(f"No results to save for {provider}/{folder}")
        return
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    all_confidences = []
    for result in results:
        for field_data in result['extracted_fields'].values():
            if isinstance(field_data, dict) and 'confidence' in field_data:
                all_confidences.append(field_data['confidence'])
    
    min_confidence = min(all_confidences) if all_confidences else 0.0
    threshold = folder_config.get('min_confidence', config['extraction']['confidence_threshold'])
    category = "highconfidence" if min_confidence >= threshold else "lowconfidence"
    
    output_data = {
        "provider": provider,
        "folder": folder,
        "folder_type": folder_config.get('description', 'Unknown'),
        "timestamp": timestamp,
        "total_documents": len(results),
        "min_confidence": round(min_confidence, 2),
        "category": category,
        "results": results
    }
    
    json_path = f"processedjsonresult/{provider}_{folder}_{timestamp}.json"
    blob_manager.upload_blob(
        output_container,
        json_path,
        json.dumps(output_data, indent=2),
        content_type="application/json"
    )
    logger.info(f"✅ Saved JSON: {json_path}")
    
    # Safe access to fields
    fields = folder_config.get('fields', [])
    if not fields:
        logger.warning(f"⚠️  No fields configured for {folder}, using empty field list")
        
    field_values = {field: [] for field in fields}
    field_confidences = {field: [] for field in fields}
    
    # Collect values and confidences
    for result in results:
        for field in fields:
            if field in result['extracted_fields']:
                field_data = result['extracted_fields'][field]
                if isinstance(field_data, dict):
                    value = field_data.get('value', config['extraction']['na_value'])
                    confidence = field_data.get('confidence', 0.0)
                else:
                    value = field_data
                    confidence = 0.0
                field_values[field].append(value)
                field_confidences[field].append(confidence)
    
    # Calculate best values with confidence tracking
    best_values = {}
    confidence_summary = {"high": 0, "medium": 0, "low": 0}
    
    for field, values in field_values.items():
        if values:
            freq = Counter([v for v in values if v != config['extraction']['na_value']])
            if freq:
                best_value = freq.most_common(1)[0][0]
                # Get average confidence for this value
                value_confidences = [field_confidences[field][i] for i, v in enumerate(values) if v == best_value]
                avg_confidence = sum(value_confidences) / len(value_confidences) if value_confidences else 0.0
            else:
                best_value = config['extraction']['na_value']
                avg_confidence = 0.0
        else:
            best_value = config['extraction']['na_value']
            avg_confidence = 0.0
        
        # Categorize confidence
        if avg_confidence >= 0.70:
            conf_status = "high"
            confidence_summary["high"] += 1
        elif avg_confidence >= 0.40:
            conf_status = "medium"
            confidence_summary["medium"] += 1
        else:
            conf_status = "low"
            confidence_summary["low"] += 1
        
        best_values[field] = {
            "value": best_value,
            "confidence": round(avg_confidence, 2),
            "status": conf_status
        }
    
    # Update output_data with confidence summary
    output_data["confidence_summary"] = confidence_summary
    output_data["best_values"] = best_values
    
    # Define folder structure based on confidence
    base_folder = f"{category}/{provider}_{folder}"
    
    # 1. Save JSON in processedjsonresult folder
    json_path = f"{base_folder}/processedjsonresult/{provider}_{folder}_{timestamp}.json"
    blob_manager.upload_blob(
        output_container,
        json_path,
        json.dumps(output_data, indent=2),
        content_type="application/json"
    )
    logger.info(f"✅ Saved JSON: {json_path}")
    
    # 2. Save detailed CSV in processedcsvresult folder
    csv_rows = []
    for field, field_info in best_values.items():
        csv_rows.append({
            "Provider": provider,
            "Folder": folder,
            "Field": field,
            "Value": field_info["value"],
            "Confidence": field_info["confidence"],
            "Status": field_info["status"]
        })
    
    csv_path = f"{base_folder}/processedcsvresult/{provider}_{folder}_{timestamp}.csv"
    df = pd.DataFrame(csv_rows)
    csv_content = df.to_csv(index=False)
    blob_manager.upload_blob(
        output_container,
        csv_path,
        csv_content,
        content_type="text/csv"
    )
    logger.info(f"✅ Saved CSV: {csv_path}")
    
    # 3. Calculate and save cost estimation
    total_fields = len(best_values)
    ocr_cost = len(results) * 0.01  # $0.01 per page estimate
    extraction_cost = len(results) * 0.02  # $0.02 per extraction estimate
    total_cost = ocr_cost + extraction_cost
    
    cost_data = {
        "provider": provider,
        "folder": folder,
        "timestamp": timestamp,
        "total_documents": len(results),
        "total_fields": total_fields,
        "confidence_breakdown": confidence_summary,
        "estimated_costs": {
            "ocr_cost_usd": round(ocr_cost, 4),
            "extraction_cost_usd": round(extraction_cost, 4),
            "total_cost_usd": round(total_cost, 4),
            "cost_per_document": round(total_cost / len(results), 4) if results else 0
        }
    }
    
    cost_path = f"{base_folder}/processedestimationcost/{provider}_{folder}_{timestamp}_cost.json"
    blob_manager.upload_blob(
        output_container,
        cost_path,
        json.dumps(cost_data, indent=2),
        content_type="application/json"
    )
    logger.info(f"✅ Saved Cost Estimation: {cost_path}")
    
    return json_path, csv_path, cost_path


def process_document(
    document_blob: str,
    provider: str,
    folder: str,
    folder_config: Dict,
    blob_manager: BlobManager,
    ocr_manager: DocumentIntelligenceOCR,  # NEW type!
    openai_manager: OpenAIManager,
    index_manager: ProductionIndexManager,
    chunker: ProductionChunker,
    prompt_builder: ExtractionPromptBuilder,
    cost_tracker: CostTracker,
    config: Dict,
    logger: logging.Logger
) -> Dict:
    """Process a single document"""
    try:
        input_container = config['azure_blob']['inputcontainer']
        doc_bytes = blob_manager.download_blob(input_container, document_blob)
        if not doc_bytes:
            logger.warning(f"⏭️  Skipping {document_blob}: download failed")
            return None
        
        document_name = document_blob.split('/')[-1]
        
        # NEW: Check file support
        if not ocr_manager.is_supported(document_name):
            file_type = ocr_manager.get_file_type(document_name)
            logger.warning(f"⏭️  Skipping {document_name}: unsupported file type ({file_type})")
            return None
        
        # NEW: Extract text with file type detection
        document_text, is_supported, file_type = ocr_manager.extract_text(doc_bytes, document_name)
        
        if not is_supported:
            logger.warning(f"⏭️  Skipping {document_name}: extraction failed")
            return None
        
        cost_tracker.add_ocr_pages(1)
        
        # Determine mode
        multimodal_threshold = config['processing'].get('multimodal_threshold', 50)
        text_length = len(document_text.strip())
        # Get mode from config (no auto detection)
        mode = config['rag']['mode']  # "text" or "multimodal"
        logger.info(f"  Mode: {mode.upper()} (text: {text_length} chars, type: {file_type})")
        
        if mode == "multimodal":
            # Use vision for multimodal
            image_base64 = convert_to_base64(doc_bytes, file_type)
            if not image_base64:
                logger.warning(f"⏭️  Skipping {document_blob}: base64 conversion failed")
                return None
            document_text_for_index = f"[{file_type.upper()}] {document_name}"
        else:
            # Use text for text mode
            image_base64 = None
            document_text_for_index = document_text
        
        # Process text for indexing
        processed_text = chunker.handle_document(document_text_for_index)
        logger.debug(f"  Processed text length: {len(processed_text)} chars")
        
        # Generate embedding
        logger.info(f"  Generating embedding...")
        embedding = openai_manager.get_embedding(processed_text[:2000])
        if not embedding:
            logger.error(f"❌ Embedding generation failed for {document_blob}")
            return None
        logger.info(f"  ✓ Embedding generated: {len(embedding)} dimensions")
        cost_tracker.add_embedding_tokens(len(processed_text.split()))
        
        # Upload to Azure AI Search
        doc_id = f"{provider}_{folder}_{document_name}".replace(" ", "_").replace("&", "and")
        logger.info(f"  Uploading to index: {doc_id}")
        
        try:
            index_manager.upload_document(
                doc_id=doc_id,
                content=processed_text,
                content_vector=embedding,
                provider=provider,
                provider_id=f"{provider}_{folder}_{datetime.now().strftime('%Y%m%d')}",
                document_name=document_name
            )
            logger.info(f"  ✓ Uploaded to Azure AI Search")
        except Exception as e:
            logger.error(f"❌ Failed to upload to index: {e}")
            # Continue anyway - don't fail the extraction
        
        extraction_prompt = prompt_builder.build_extraction_prompt()
        
        extracted_data = unified_rag_extraction(
            openai_manager=openai_manager,
            search_manager=index_manager,
            index_name=config['azure_search']['universal_index_name'],
            provider=provider,
            document_text=document_text if mode == "text" else None,
            document_image_base64=image_base64 if mode == "multimodal" else None,
            prompt=extraction_prompt,
            top_k=config['rag']['top_k'],
            mode=mode
        )
        
        cost_tracker.add_gpt4o_tokens(
            input_tokens=int(len(extraction_prompt.split()) * 1.3),
            output_tokens=500
        )
        
        if extracted_data:
            logger.info(f"✓ Successfully extracted from {document_blob}")
            return {
                "document_name": document_name,
                "file_type": file_type,
                "extraction_mode": mode,
                "extracted_fields": extracted_data
            }
        else:
            logger.warning(f"✗ Extraction failed for {document_blob}")
            return None
            
    except Exception as e:
        logger.error(f"✗ Error processing {document_blob}: {e}", exc_info=True)
        return None


def main():
    """Main execution function"""
    
    logger = setup_logging()
    logger.info("="*80)
    logger.info("MEDICAL CREDENTIALS EXTRACTION - V2 FINAL")
    logger.info("All File Types Supported + Unsupported File Handling")
    logger.info("="*80)
    
    config = load_config()
    
    logger.info(f"Folder configurations: {len(config['folder_configs'])} types")
    for folder_type, folder_config in config['folder_configs'].items():
        num_fields = len(folder_config.get('fields', []))
        logger.info(f"  • {folder_type}: {num_fields} fields")
    
    skip_unknown = config['processing'].get('skip_unknown_folders', False)
    logger.info(f"Skip unknown folders: {skip_unknown}")
    logger.info(f"Multimodal threshold: {config['processing'].get('multimodal_threshold', 50)} chars")
    
    blob_manager = BlobManager(config['azure_blob']['connection_string'])
    
    # NEW: Use DocumentIntelligenceOCR
    ocr_manager = DocumentIntelligenceOCR(
        config['azure_document_intelligence']['endpoint'],
        config['azure_document_intelligence']['key']
    )
    logger.info("✅ OCR Manager initialized with multi-format support")
    
    openai_manager = OpenAIManager(
        config['azure_openai_gpt']['endpoint'],
        config['azure_openai_gpt']['api_key'],
        config['azure_openai_gpt']['api_version'],
        config['azure_openai_gpt']['deployment_name'],
        config['azure_openai_embedding']['deployment_name']
    )
    
    index_manager = ProductionIndexManager(
        search_endpoint=config['azure_search']['endpoint'],
        search_api_key=config['azure_search']['api_key'],
        index_name=config['azure_search']['universal_index_name'],
        auto_delete_days=config['azure_search']['auto_delete_days'],
        enable_auto_cleanup=config['azure_search']['enable_auto_cleanup']
    )
    
    index_manager.create_universal_index(
        embedding_dimension=config['azure_openai_embedding']['dimension']
    )
    
    if config['azure_search']['enable_auto_cleanup']:
        logger.info("Running auto-cleanup...")
        deleted_count = index_manager.cleanup_old_data(
            days=config['azure_search']['auto_delete_days']
        )
        logger.info(f"Auto-cleanup complete: {deleted_count} documents deleted")
    
    cost_tracker = CostTracker(
        ocr_per_page=config['costs']['ocr_per_page'],
        embedding_per_1k=config['costs']['embedding_per_1k_tokens'],
        gpt4o_input_per_1k=config['costs']['gpt4o_input_per_1k_tokens'],
        gpt4o_output_per_1k=config['costs']['gpt4o_output_per_1k_tokens']
    )
    
    chunker = ProductionChunker(
        max_doc_length_chars=config['processing']['max_doc_length_chars'],
        max_prompt_tokens=config['processing']['max_prompt_tokens'],
        chunk_size=config['rag']['chunk_size'],
        chunk_overlap=config['rag']['chunk_overlap']
    )
    
    input_container = config['azure_blob']['inputcontainer']
    output_container = config['azure_blob']['outputcontainer']
    all_blobs = blob_manager.list_blobs(input_container)
    
    provider_folders = {}
    for blob in all_blobs:
        parts = blob.split('/')
        if len(parts) >= 3:
            provider = parts[0]
            folder = parts[1]
            
            if provider not in provider_folders:
                provider_folders[provider] = {}
            if folder not in provider_folders[provider]:
                provider_folders[provider][folder] = []
            
            provider_folders[provider][folder].append(blob)
    
    logger.info(f"Found {len(provider_folders)} providers")
    
    total_providers = len(provider_folders)
    total_folders_processed = 0
    total_folders_skipped = 0
    total_documents_processed = 0
    total_documents_skipped = 0
    text_mode_count = 0
    multimodal_mode_count = 0
    
    for provider_idx, (provider, folders) in enumerate(sorted(provider_folders.items()), 1):
        logger.info("="*80)
        logger.info(f"PROVIDER {provider_idx}/{total_providers}: {provider}")
        logger.info(f"Folders: {len(folders)}")
        logger.info("="*80)
        
        for folder_idx, (folder, documents) in enumerate(sorted(folders.items()), 1):
            logger.info("-"*80)
            logger.info(f"Folder {folder_idx}/{len(folders)}: {provider}/{folder}")
            logger.info(f"Documents: {len(documents)}")
            logger.info("-"*80)
            
            folder_type = detect_folder_type(folder, config)
            
            if folder_type is None:
                logger.info(f"⏭️  SKIPPING {folder} - No configuration found")
                logger.info(f"   To process this folder, add '{folder}' to config.json folder_configs")
                total_folders_skipped += 1
                total_documents_skipped += len(documents)
                continue
            
            folder_config = get_folder_config(folder_type, config)
            
            # Ensure folder_config has 'fields' key
            if 'fields' not in folder_config:
                logger.error(f"❌ ERROR: folder_config for '{folder_type}' missing 'fields' key!")
                logger.error(f"   folder_config: {folder_config}")
                logger.error(f"   Please check config.json - all folder configs must have 'fields' list")
                total_folders_skipped += 1
                total_documents_skipped += len(documents)
                continue
            
            logger.info(f"✅ Processing as: {folder_type}")
            logger.info(f"Fields to extract: {len(folder_config['fields'])}")
            
            prompt_builder = ExtractionPromptBuilder(
                fields=folder_config['fields'],
                mode=config['rag']['mode']
            )
            
            folder_results = []
            checkpoint_interval = config['processing']['checkpoint_interval']
            
            for doc_idx, document_blob in enumerate(documents, 1):
                logger.info(f"[{doc_idx}/{len(documents)}] {document_blob.split('/')[-1]}")
                
                result = process_document(
                    document_blob=document_blob,
                    provider=provider,
                    folder=folder,
                    folder_config=folder_config,
                    blob_manager=blob_manager,
                    ocr_manager=ocr_manager,
                    openai_manager=openai_manager,
                    index_manager=index_manager,
                    chunker=chunker,
                    prompt_builder=prompt_builder,
                    cost_tracker=cost_tracker,
                    config=config,
                    logger=logger
                )
                
                if result:
                    folder_results.append(result)
                    total_documents_processed += 1
                    
                    if result.get('extraction_mode') == 'text':
                        text_mode_count += 1
                    elif result.get('extraction_mode') == 'multimodal':
                        multimodal_mode_count += 1
                else:
                    total_documents_skipped += 1
                
                if checkpoint_interval > 0 and (doc_idx % checkpoint_interval == 0):
                    if folder_results:
                        logger.info(f"💾 Checkpoint at {doc_idx} documents...")
                        save_provider_results(
                            blob_manager=blob_manager,
                            output_container=output_container,
                            provider=provider,
                            folder=folder,
                            results=folder_results,
                            folder_config=folder_config,
                            config=config,
                            logger=logger
                        )
            
            if folder_results:
                logger.info(f"💾 Saving final results for {provider}/{folder}...")
                json_path, csv_path = save_provider_results(
                    blob_manager=blob_manager,
                    output_container=output_container,
                    provider=provider,
                    folder=folder,
                    results=folder_results,
                    folder_config=folder_config,
                    config=config,
                    logger=logger
                )
                logger.info(f"✅ SAVED: {provider}/{folder}")
                logger.info(f"   Documents: {len(folder_results)}")
                total_folders_processed += 1
            else:
                logger.warning(f"⚠️  No results for {provider}/{folder}")
    
    # Log OCR statistics
    logger.info("="*80)
    ocr_manager.log_statistics()
    
    # Save cost summary
    logger.info("Saving cost summary...")
    cost_summary = cost_tracker.get_summary()
    cost_summary['total_providers'] = total_providers
    cost_summary['total_folders_processed'] = total_folders_processed
    cost_summary['total_folders_skipped'] = total_folders_skipped
    cost_summary['total_documents_processed'] = total_documents_processed
    cost_summary['total_documents_skipped'] = total_documents_skipped
    cost_summary['text_mode_count'] = text_mode_count
    cost_summary['multimodal_mode_count'] = multimodal_mode_count
    cost_summary['ocr_statistics'] = ocr_manager.get_statistics()
    
    cost_path = f"estimatecost/summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    blob_manager.upload_blob(
        output_container,
        cost_path,
        json.dumps(cost_summary, indent=2),
        content_type="application/json"
    )
    
    logger.info("="*80)
    logger.info("EXTRACTION COMPLETE - V2 FINAL")
    logger.info("="*80)
    logger.info(f"Providers: {total_providers}")
    logger.info(f"Folders processed: {total_folders_processed}")
    logger.info(f"Folders skipped: {total_folders_skipped}")
    logger.info(f"Documents processed: {total_documents_processed}")
    logger.info(f"Documents skipped: {total_documents_skipped}")
    logger.info(f"  Text mode: {text_mode_count}")
    logger.info(f"  Multimodal mode: {multimodal_mode_count}")
    cost_tracker.log_summary()
    logger.info("="*80)
    logger.info("✅ All supported files processed!")
    logger.info("✅ Unsupported files skipped (no errors)!")
    logger.info("="*80)


if __name__ == "__main__":
    main()
