# CONFIDENCE THRESHOLD - AUTOMATIC CONFIGURATION

## ✅ **YES! IT'S AUTOMATIC!**

When you change the confidence threshold in `config.json`, it **automatically** affects the entire system.

---

## 🔧 **HOW TO CHANGE**

### **In config.json:**
```json
{
  "extraction": {
    "confidence_threshold": 0.70  ← Change this value (0.00 to 1.00)
  }
}
```

### **That's it!** No code changes needed! ✅

---

## 📊 **HOW IT WORKS**

### **Step 1: System Reads Config**
```python
# main.py automatically loads config
config = load_config()
threshold = config['extraction']['confidence_threshold']  # 0.70
```

### **Step 2: Processes Documents**
```python
# Extracts fields from each document
# GPT-4o returns confidence scores
document_1 = {
    'fields': {
        'first_name': {'value': 'John', 'confidence': 0.95},
        'last_name': {'value': 'Doe', 'confidence': 0.75},
        'email': {'value': 'john@example.com', 'confidence': 0.60}
    }
}
```

### **Step 3: Calculates Best Values**
```python
# Combines all documents for the folder
# Finds most common values
# Calculates average confidence per field

best_values = {
    'first_name': {'value': 'John', 'confidence': 0.95},
    'last_name': {'value': 'Doe', 'confidence': 0.75},
    'email': {'value': 'john@example.com', 'confidence': 0.60}
}

# Finds minimum confidence across all fields
min_confidence = 0.60  # Lowest confidence field
```

### **Step 4: Applies Threshold (AUTOMATIC)**
```python
# Uses YOUR threshold from config.json
threshold = config['extraction']['confidence_threshold']  # 0.70

# Categorizes based on threshold
if min_confidence >= threshold:
    category = 'highconfidence'
else:
    category = 'lowconfidence'

# Result: min_confidence (0.60) < threshold (0.70)
# Category: 'lowconfidence' ✅
```

### **Step 5: Saves to Correct Folder**
```
outputcontainer/
├── highconfidence/
│   └── (empty - confidence too low)
│
└── lowconfidence/
    └── Provider1_Folder_timestamp.csv  ✅ Saved here!
```

---

## 💡 **EXAMPLES**

### **Example 1: Threshold 0.50 (Default)**

**Config:**
```json
{
  "extraction": {
    "confidence_threshold": 0.50
  }
}
```

**Results:**
```
Document fields:
  first_name: 0.95 ✅
  last_name: 0.75 ✅
  email: 0.55 ✅
  
Min confidence: 0.55
Threshold: 0.50
Result: 0.55 >= 0.50 → highconfidence/ ✅
```

---

### **Example 2: Threshold 0.70 (Stricter)**

**Config:**
```json
{
  "extraction": {
    "confidence_threshold": 0.70
  }
}
```

**Results:**
```
Document fields:
  first_name: 0.95 ✅
  last_name: 0.75 ✅
  email: 0.55 ❌
  
Min confidence: 0.55
Threshold: 0.70
Result: 0.55 < 0.70 → lowconfidence/ ✅
```

---

### **Example 3: Threshold 0.90 (Very Strict)**

**Config:**
```json
{
  "extraction": {
    "confidence_threshold": 0.90
  }
}
```

**Results:**
```
Document fields:
  first_name: 0.95 ✅
  last_name: 0.75 ❌
  email: 0.85 ❌
  
Min confidence: 0.75
Threshold: 0.90
Result: 0.75 < 0.90 → lowconfidence/ ✅
```

---

## 🎯 **CHOOSING THE RIGHT THRESHOLD**

### **0.50 - Balanced (Default)**
```
Use when:
  ✅ You want most results in highconfidence
  ✅ Some uncertainty is acceptable
  ✅ Manual review available for edge cases
  
Output:
  ~70-80% → highconfidence
  ~20-30% → lowconfidence
```

### **0.70 - Stricter**
```
Use when:
  ✅ Higher accuracy required
  ✅ You'll manually review lowconfidence files
  ✅ Critical fields must be accurate
  
Output:
  ~40-60% → highconfidence
  ~40-60% → lowconfidence
```

### **0.90 - Very Strict**
```
Use when:
  ✅ Only extremely confident results accepted
  ✅ All low confidence needs manual review
  ✅ Critical compliance/legal requirements
  
Output:
  ~10-20% → highconfidence
  ~80-90% → lowconfidence
```

---

## 📋 **COMPLETE WORKFLOW**

### **Configuration:**
```json
{
  "extraction": {
    "confidence_threshold": 0.70
  }
}
```

### **Processing:**
```
1. Process 10 documents in folder
   ↓
2. Extract fields with GPT-4o
   - Each field gets confidence score
   ↓
3. Calculate best values
   - Find most common value per field
   - Calculate average confidence per field
   ↓
4. Find minimum confidence
   - first_name: 0.95
   - last_name: 0.82
   - email: 0.68  ← Minimum
   ↓
5. Apply threshold (0.70)
   - min_confidence (0.68) < threshold (0.70)
   - Category: lowconfidence
   ↓
6. Save to lowconfidence/
   - Provider1_Folder_timestamp.csv
   - Provider1_Folder_timestamp.json
```

---

## 🔄 **CHANGING THRESHOLD**

### **Before Change:**
```json
{
  "extraction": {
    "confidence_threshold": 0.50
  }
}
```

**Run:**
```bash
python main.py
```

**Result:**
```
highconfidence/Provider1_Folder_20260305.csv  ✅
```

---

### **After Change:**
```json
{
  "extraction": {
    "confidence_threshold": 0.70  ← Changed!
  }
}
```

**Run:**
```bash
python main.py
```

**Result:**
```
lowconfidence/Provider1_Folder_20260305.csv  ✅ Moved to lowconfidence!
```

**No code changes needed!** ✅

---

## ✅ **VERIFICATION**

### **Test Different Thresholds:**

**Test 1: Threshold 0.50**
```bash
# Edit config.json
{
  "extraction": {
    "confidence_threshold": 0.50
  }
}

# Run
python main.py

# Check results
ls highconfidence/  # Should have more files
ls lowconfidence/   # Should have fewer files
```

**Test 2: Threshold 0.80**
```bash
# Edit config.json
{
  "extraction": {
    "confidence_threshold": 0.80
  }
}

# Run
python main.py

# Check results
ls highconfidence/  # Should have fewer files
ls lowconfidence/   # Should have more files
```

---

## 📊 **CONFIDENCE DISTRIBUTION**

### **Typical Confidence Scores:**

```
Excellent quality PDFs:
  - Clear text: 0.90-0.99
  - Structured data: 0.85-0.95
  
Good quality scans:
  - Clean images: 0.75-0.90
  - Some blur: 0.65-0.80
  
Poor quality scans:
  - Blurry images: 0.50-0.70
  - Handwritten: 0.40-0.65
  
Very poor quality:
  - Heavy blur: 0.30-0.50
  - Damaged docs: 0.20-0.40
```

### **Recommended Thresholds:**

```
Document Type          | Recommended Threshold
-----------------------|---------------------
Digital PDFs           | 0.70 - 0.80
Good scans             | 0.60 - 0.70
Mixed quality          | 0.50 - 0.60  (default)
Handwritten forms      | 0.40 - 0.50
Poor quality scans     | 0.30 - 0.40
```

---

## 💡 **BEST PRACTICES**

### **1. Start with Default (0.50)**
```json
{
  "extraction": {
    "confidence_threshold": 0.50
  }
}
```
Run system, check results, adjust as needed.

### **2. Review Distribution**
```bash
# Count files in each category
ls highconfidence/ | wc -l
ls lowconfidence/ | wc -l
```

### **3. Adjust Based on Accuracy**
- Too many in lowconfidence? → Lower threshold
- Too many errors in highconfidence? → Raise threshold

### **4. Document Your Choice**
Add comment in config.json:
```json
{
  "extraction": {
    "confidence_threshold": 0.70,  // Stricter for legal compliance
    "_note": "Using 0.70 for higher accuracy on critical fields"
  }
}
```

---

## ✅ **SUMMARY**

**Question:** "If I change config.json 70% threshold, it automatically changes, correct?"

**Answer:** ✅ **YES! 100% AUTOMATIC!**

**How it works:**
1. ✅ Change `confidence_threshold` in config.json
2. ✅ System automatically reads it
3. ✅ Applies to all folder processing
4. ✅ Categorizes results correctly
5. ✅ Saves to right folder (highconfidence/lowconfidence)

**No code changes needed!**
**No restart needed!**
**Just edit config.json and run!**

🎉 **Fully configurable and automatic!**
