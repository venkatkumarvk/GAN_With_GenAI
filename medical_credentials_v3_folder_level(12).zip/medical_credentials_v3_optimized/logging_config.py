"""
Logging Configuration
====================
Sets up logging for the application
"""

import logging
import os
from datetime import datetime


def setup_logging(config: dict):
    """
    Configure logging for the application
    
    Args:
        config: Configuration dictionary from config.json
    """
    # Extract log settings from config
    log_folder = config.get('logging', {}).get('log_folder', 'logs')
    log_level_str = config.get('logging', {}).get('log_level', 'INFO')
    
    # Convert log level string to logging constant
    log_level = getattr(logging, log_level_str.upper(), logging.INFO)
    
    # Create logs directory if it doesn't exist
    os.makedirs(log_folder, exist_ok=True)
    
    # Generate log filename with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(log_folder, f"extraction_{timestamp}.log")
    
    # Configure logging format
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"
    
    # Configure root logger
    logging.basicConfig(
        level=log_level,
        format=log_format,
        datefmt=date_format,
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()  # Also print to console
        ]
    )
    
    # Get logger
    logger = logging.getLogger(__name__)
    logger.info("=" * 80)
    logger.info("LOGGING INITIALIZED")
    logger.info(f"Log file: {log_file}")
    logger.info("=" * 80)
    
    return logger
