# CSV OUTPUT FORMAT

## ✅ **ENHANCED CSV FORMAT!**

Your CSV now includes:
- ✅ Provider name and ID
- ✅ Folder name
- ✅ Extraction timestamp
- ✅ Total documents processed
- ✅ **For each field:** Value, Confidence, Source Document

---

## 📊 **CSV STRUCTURE**

### **Headers:**
```csv
provider_name,provider_id,folder_name,extraction_datetime,total_documents_processed,first_name,first_name_confidence,first_name_source_document,last_name,last_name_confidence,last_name_source_document,...
```

### **Format:**
```
Column 1: provider_name
Column 2: provider_id
Column 3: folder_name
Column 4: extraction_datetime (YYYY-MM-DD HH:MM:SS)
Column 5: total_documents_processed

Then for each field (repeating pattern):
  Column N:   field_value
  Column N+1: field_confidence (0.00 to 1.00)
  Column N+2: field_source_document (filename)
```

---

## 💡 **COMPLETE EXAMPLE**

### **Scenario:**
```
Provider: ANAND-NICHOLS
Folder: GEN & HR
Documents processed: 5
Fields configured: first_name, last_name, email, cell
```

### **CSV Output:**
```csv
provider_name,provider_id,folder_name,extraction_datetime,total_documents_processed,first_name,first_name_confidence,first_name_source_document,last_name,last_name_confidence,last_name_source_document,email,email_confidence,email_source_document,cell,cell_confidence,cell_source_document
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,5,Anand,0.95,CV_2025.pdf,Nichols,0.92,Resume.pdf,anand@example.com,0.88,Contact_Info.pdf,555-1234,0.75,Phone_List.pdf
```

---

## 📋 **COLUMN BREAKDOWN**

### **Metadata Columns (Fixed):**
| Column | Description | Example |
|--------|-------------|---------|
| `provider_name` | Provider name | ANAND-NICHOLS |
| `provider_id` | Provider ID (same as name) | ANAND-NICHOLS |
| `folder_name` | Folder being processed | GEN & HR |
| `extraction_datetime` | When extraction ran | 2026-03-06 12:34:56 |
| `total_documents_processed` | Number of docs in folder | 5 |

### **Field Columns (Dynamic - Repeats for Each Field):**
| Column Pattern | Description | Example |
|----------------|-------------|---------|
| `{field}` | Extracted value | Anand |
| `{field}_confidence` | Confidence score (0-1) | 0.95 |
| `{field}_source_document` | Which document had this value | CV_2025.pdf |

---

## 🎯 **REAL EXAMPLE**

### **Input Configuration:**
```json
{
  "folder_configs": {
    "GEN & HR": {
      "fields": [
        "first_name",
        "last_name",
        "email",
        "cell",
        "birth_date"
      ]
    }
  }
}
```

### **Documents Processed:**
```
1. CV_2025.pdf
2. Resume.pdf
3. Contact_Info.pdf
4. Application_Form.pdf
5. Personal_Details.pdf
```

### **CSV Output:**
```csv
provider_name,provider_id,folder_name,extraction_datetime,total_documents_processed,first_name,first_name_confidence,first_name_source_document,last_name,last_name_confidence,last_name_source_document,email,email_confidence,email_source_document,cell,cell_confidence,cell_source_document,birth_date,birth_date_confidence,birth_date_source_document
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,5,Anand,0.95,CV_2025.pdf,Nichols,0.92,Resume.pdf,anand@example.com,0.88,Contact_Info.pdf,555-123-4567,0.75,Application_Form.pdf,1985-06-15,0.82,Personal_Details.pdf
```

---

## 📊 **OPENED IN EXCEL**

### **Columns View:**
```
A: provider_name           | ANAND-NICHOLS
B: provider_id             | ANAND-NICHOLS
C: folder_name             | GEN & HR
D: extraction_datetime     | 2026-03-06 12:34:56
E: total_documents_processed | 5
F: first_name              | Anand
G: first_name_confidence   | 0.95
H: first_name_source_document | CV_2025.pdf
I: last_name               | Nichols
J: last_name_confidence    | 0.92
K: last_name_source_document | Resume.pdf
L: email                   | anand@example.com
M: email_confidence        | 0.88
N: email_source_document   | Contact_Info.pdf
O: cell                    | 555-123-4567
P: cell_confidence         | 0.75
Q: cell_source_document    | Application_Form.pdf
R: birth_date              | 1985-06-15
S: birth_date_confidence   | 0.82
T: birth_date_source_document | Personal_Details.pdf
```

---

## 💡 **USE CASES**

### **1. Quality Review**
```
Check confidence scores:
  - email_confidence: 0.88 (good)
  - cell_confidence: 0.75 (review this)
  
Check source:
  - cell_source_document: Application_Form.pdf
  → Go verify in Application_Form.pdf
```

### **2. Data Validation**
```
Filter by confidence:
  - Confidence >= 0.90: Auto-accept
  - Confidence < 0.90: Manual review
```

### **3. Audit Trail**
```
For each field, know:
  - What value was extracted
  - How confident the system was
  - Which document it came from
```

### **4. Error Investigation**
```
If first_name is wrong:
  - Check: first_name_source_document
  - Open: CV_2025.pdf
  - Verify: What went wrong
```

---

## 🔧 **MULTIPLE PROVIDERS EXAMPLE**

### **Processing 3 Providers:**

**Provider 1 CSV:**
```csv
provider_name,provider_id,folder_name,extraction_datetime,total_documents_processed,first_name,first_name_confidence,first_name_source_document,...
Provider1,Provider1,GEN & HR,2026-03-06 12:00:00,10,John,0.95,doc1.pdf,...
```

**Provider 2 CSV:**
```csv
provider_name,provider_id,folder_name,extraction_datetime,total_documents_processed,first_name,first_name_confidence,first_name_source_document,...
Provider2,Provider2,GEN & HR,2026-03-06 12:05:00,8,Jane,0.92,doc5.pdf,...
```

**Provider 3 CSV:**
```csv
provider_name,provider_id,folder_name,extraction_datetime,total_documents_processed,first_name,first_name_confidence,first_name_source_document,...
Provider3,Provider3,GEN & HR,2026-03-06 12:10:00,12,Mike,0.88,doc8.pdf,...
```

**Each CSV shows:**
- Which provider
- Which folder
- When processed
- How many documents
- All extracted fields with confidence and source

---

## 📋 **COMPLETE FIELD EXAMPLE**

### **Config with 10 Fields:**
```json
{
  "folder_configs": {
    "Licenses": {
      "fields": [
        "state_license_number",
        "state_license_expiration",
        "state_license_state",
        "dea_license_number",
        "dea_license_expiration",
        "cds_license_number",
        "npi_number",
        "medicare_number",
        "medicaid_number",
        "board_cert_name"
      ]
    }
  }
}
```

### **CSV Headers (33 columns total):**
```csv
provider_name,
provider_id,
folder_name,
extraction_datetime,
total_documents_processed,
state_license_number,
state_license_number_confidence,
state_license_number_source_document,
state_license_expiration,
state_license_expiration_confidence,
state_license_expiration_source_document,
state_license_state,
state_license_state_confidence,
state_license_state_source_document,
dea_license_number,
dea_license_number_confidence,
dea_license_number_source_document,
dea_license_expiration,
dea_license_expiration_confidence,
dea_license_expiration_source_document,
cds_license_number,
cds_license_number_confidence,
cds_license_number_source_document,
npi_number,
npi_number_confidence,
npi_number_source_document,
medicare_number,
medicare_number_confidence,
medicare_number_source_document,
medicaid_number,
medicaid_number_confidence,
medicaid_number_source_document,
board_cert_name,
board_cert_name_confidence,
board_cert_name_source_document
```

**Formula:** 5 metadata columns + (3 × number of fields)

---

## 🎯 **FILE NAMING**

### **Pattern:**
```
{category}/{provider}_{folder}_{timestamp}.csv
```

### **Examples:**
```
highconfidence/ANAND-NICHOLS_GEN_HR_20260306_123456.csv
highconfidence/ANAND-NICHOLS_ED_TRAIN_20260306_123500.csv
lowconfidence/Provider2_Licenses_20260306_123600.csv
```

---

## 📊 **CONFIDENCE CATEGORIES**

### **highconfidence/ Folder:**
```
All field confidences >= threshold (default 0.50)

Example:
  first_name_confidence: 0.95
  last_name_confidence: 0.82
  email_confidence: 0.76
  Minimum: 0.76 >= 0.50 ✅
  → Saved to: highconfidence/
```

### **lowconfidence/ Folder:**
```
At least one field confidence < threshold

Example:
  first_name_confidence: 0.95
  last_name_confidence: 0.82
  email_confidence: 0.45  ← Below threshold!
  Minimum: 0.45 < 0.50 ❌
  → Saved to: lowconfidence/
```

---

## ✅ **BENEFITS**

### **1. Complete Audit Trail**
```
For every extracted value, you know:
  - What was extracted
  - How confident the system was
  - Which document it came from
```

### **2. Easy Review**
```
Sort by confidence:
  - Review low confidence fields first
  - Auto-accept high confidence fields
```

### **3. Source Traceability**
```
If value is wrong:
  - Check source_document column
  - Open that specific file
  - Verify extraction
```

### **4. Quality Metrics**
```
Calculate average confidence per field:
  - Which fields are reliable?
  - Which fields need improvement?
```

### **5. Excel-Friendly**
```
Open in Excel:
  - Filter by confidence
  - Sort by provider
  - Pivot by field
  - Easy analysis
```

---

## ✅ **SUMMARY**

**CSV Format:**
```
Metadata (5 columns):
  - provider_name
  - provider_id
  - folder_name
  - extraction_datetime
  - total_documents_processed

For Each Field (3 columns):
  - {field}_value
  - {field}_confidence
  - {field}_source_document
```

**Example:**
```csv
provider_name,provider_id,folder_name,extraction_datetime,total_documents_processed,first_name,first_name_confidence,first_name_source_document,last_name,last_name_confidence,last_name_source_document
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,5,Anand,0.95,CV_2025.pdf,Nichols,0.92,Resume.pdf
```

**Perfect for:**
- ✅ Quality review
- ✅ Data validation
- ✅ Audit trails
- ✅ Error investigation
- ✅ Excel analysis

🎉 **Production-ready CSV format!**
