# UNIVERSAL INDEX - HANDLING DUPLICATES & RE-UPLOADS

## 🎯 **THE CHALLENGE**

### **Scenario 1: Same Filename, Different Providers**
```
Provider1/Licenses/application.pdf  (Different content)
Provider2/Licenses/application.pdf  (Different content)
```

**Solution:** ✅ **Provider name is part of document ID**
```python
doc_id = hash("Provider1_Licenses_application.pdf_[content_hash]")
doc_id = hash("Provider2_Licenses_application.pdf_[content_hash]")
```
**Result:** Different IDs, no collision! ✅

---

### **Scenario 2: Same File Re-Uploaded (Updated Content)**
```
Day 1: Provider1/Licenses/doc1.pdf (Version 1)
Day 7: Provider1/Licenses/doc1.pdf (Version 2 - Updated!)
```

**Problem:** Without content hash, same ID → overwrites old version ❌

**Solution:** ✅ **Content hash included in document ID**
```python
# Day 1
content_hash_v1 = hash(text_content_v1)  # "abc123..."
doc_id = hash("Provider1_Licenses_doc1.pdf_abc123_chunk0")

# Day 7
content_hash_v2 = hash(text_content_v2)  # "xyz789..." (different!)
doc_id = hash("Provider1_Licenses_doc1.pdf_xyz789_chunk0")
```
**Result:** Different IDs! Both versions stored! ✅

---

## 🔧 **HOW IT WORKS**

### **Document ID Generation:**

```python
def generate_document_id(provider, folder, filename, chunk_index=0, content_hash=None):
    """
    Generate unique document ID
    
    Components:
    1. provider: "Provider1"
    2. folder: "Licenses"
    3. filename: "doc1.pdf"
    4. content_hash: First 16 chars of MD5(text_content)
    5. chunk_index: 0, 1, 2, ...
    
    Result: hash("Provider1_Licenses_doc1.pdf_abc123..._chunk0")
    """
    if content_hash:
        combined = f"{provider}_{folder}_{filename}_{content_hash[:16]}_chunk{chunk_index}"
    else:
        combined = f"{provider}_{folder}_{filename}_chunk{chunk_index}"
    
    return hashlib.md5(combined.encode()).hexdigest()
```

### **Content Hash Generation:**

```python
# After OCR extraction
text = ocr.extract_text(document_bytes)

# Generate content hash (MD5 of text content)
content_hash = hashlib.md5(text.encode('utf-8', errors='ignore')).hexdigest()
# Result: "a1b2c3d4e5f6g7h8..." (32 chars, use first 16)
```

---

## 📊 **COMPLETE WORKFLOW**

```
1. Document uploaded: Provider1/Licenses/doc1.pdf
   ↓
2. OCR extraction → text content
   ↓
3. Generate content hash
   content_hash = MD5(text) = "a1b2c3d4e5f6g7h8..."
   ↓
4. Generate document ID
   doc_id = hash("Provider1_Licenses_doc1.pdf_a1b2c3d4e5f6_chunk0")
   Result: "9f8e7d6c5b4a3210..."
   ↓
5. Upload to universal index
   {
     "id": "9f8e7d6c5b4a3210...",
     "provider": "Provider1",
     "folder": "Licenses",
     "document_name": "doc1.pdf",
     "content": "...",
     "content_vector": [...]
   }
```

---

## 🎯 **BENEFITS**

### **1. No Collisions Across Providers**
```
Provider1/Licenses/doc1.pdf → ID: "abc123..."
Provider2/Licenses/doc1.pdf → ID: "def456..."
Provider3/Licenses/doc1.pdf → ID: "ghi789..."
```
✅ All stored separately!

### **2. Handles Re-Uploads**
```
Version 1 (Jan 1): doc1.pdf → ID: "aaa111..." (content hash: xxx)
Version 2 (Feb 1): doc1.pdf → ID: "bbb222..." (content hash: yyy)
Version 3 (Mar 1): doc1.pdf → ID: "ccc333..." (content hash: zzz)
```
✅ All versions stored! (Auto-cleanup removes old ones based on timestamp)

### **3. Content-Based Deduplication**
```
Upload 1: doc1.pdf (same content)
Upload 2: doc1.pdf (exact same content, uploaded again)
```
**Same content hash → Same ID → Overwrites (updates timestamp)**
✅ No duplicate storage for identical content!

---

## 🗄️ **INDEX STRUCTURE**

```json
{
  "index_name": "documents_universal",
  "documents": [
    {
      "id": "9f8e7d6c5b4a3210...",
      "provider": "Provider1",
      "folder": "Licenses",
      "document_name": "doc1.pdf",
      "chunk_index": 0,
      "total_chunks": 1,
      "upload_timestamp": "2026-03-06T12:00:00Z",
      "content": "extracted text...",
      "content_vector": [0.123, 0.456, ...]
    },
    {
      "id": "1a2b3c4d5e6f7g8h...",
      "provider": "Provider2",
      "folder": "Licenses",
      "document_name": "doc1.pdf",
      "chunk_index": 0,
      "total_chunks": 1,
      "upload_timestamp": "2026-03-06T12:00:00Z",
      "content": "different text...",
      "content_vector": [0.789, 0.012, ...]
    }
  ]
}
```

---

## 🔍 **RAG SEARCH WITH FILTERING**

### **Query:** Find similar documents for Provider1/Licenses

```python
# Generate query vector
query_vector = openai.generate_embedding(current_document_text)

# Search with filtering
results = search_manager.search_similar(
    vector=query_vector,
    provider="Provider1",  ← Filter by provider
    folder="Licenses",     ← Filter by folder
    top_k=3
)
```

**Result:** Only returns documents from Provider1/Licenses ✅

**Why this matters:**
- Provider1's documents don't contaminate Provider2's RAG examples
- Each folder gets relevant examples from the same context
- No cross-provider hallucination

---

## 🧹 **AUTO-CLEANUP**

### **Configuration:**
```json
{
  "azure_search": {
    "enable_auto_cleanup": true,
    "auto_delete_days": 30
  }
}
```

### **How it works:**
```
Day 1: Upload doc1.pdf → ID: "aaa111..." (timestamp: 2026-01-01)
Day 7: Upload doc1.pdf → ID: "bbb222..." (timestamp: 2026-01-07, different content)
Day 14: Upload doc1.pdf → ID: "ccc333..." (timestamp: 2026-01-14, different content)

Day 31: Auto-cleanup runs
  → Deletes documents with timestamp < (today - 30 days)
  → Deletes ID "aaa111..." (uploaded Day 1) ✅
  → Keeps ID "bbb222..." and "ccc333..." ✅
```

**Result:** Only recent versions kept, old versions auto-removed!

---

## 💡 **EXAMPLE SCENARIOS**

### **Scenario 1: Multiple Providers, Same Filename**

**Input:**
```
Provider1/Licenses/state_license.pdf (License #12345)
Provider2/Licenses/state_license.pdf (License #67890)
Provider3/Licenses/state_license.pdf (License #11111)
```

**Index Storage:**
```
ID: "aaa111..." | Provider: Provider1 | Content: "License #12345"
ID: "bbb222..." | Provider: Provider2 | Content: "License #67890"
ID: "ccc333..." | Provider: Provider3 | Content: "License #11111"
```

**RAG Search for Provider2/Licenses:**
```
Query: Provider2, Folder: Licenses
Results:
  - ID: "bbb222..." (Provider2's document) ✅
  - (No Provider1 or Provider3 documents) ✅
```

---

### **Scenario 2: Document Updated (Re-Upload)**

**Timeline:**
```
Jan 1: Provider1/Licenses/doc1.pdf (expires 2025)
  → Content hash: "aaa111..."
  → ID: "xyz_aaa111_chunk0"
  → Stored ✅

Feb 1: Provider1/Licenses/doc1.pdf (expires 2026, renewed!)
  → Content hash: "bbb222..." (different!)
  → ID: "xyz_bbb222_chunk0"
  → Stored ✅

Mar 1: Auto-cleanup (30 days)
  → Old version from Jan 1 deleted ✅
  → New version from Feb 1 kept ✅
```

---

### **Scenario 3: Identical Re-Upload (Same Content)**

```
Day 1: Provider1/Licenses/doc1.pdf
  → Content: "License #12345"
  → Content hash: "aaa111..."
  → ID: "xyz_aaa111_chunk0"
  → Stored ✅

Day 5: Provider1/Licenses/doc1.pdf (exact same file uploaded again)
  → Content: "License #12345" (identical!)
  → Content hash: "aaa111..." (same!)
  → ID: "xyz_aaa111_chunk0" (same ID!)
  → Overwrites → Updates timestamp ✅
```

**Result:** No duplicate storage, just timestamp refresh!

---

## ✅ **SUMMARY**

### **Universal Index Handles:**
1. ✅ **Different providers, same filename** → Provider in ID
2. ✅ **Re-uploads with updated content** → Content hash in ID
3. ✅ **Identical re-uploads** → Same ID, timestamp refresh
4. ✅ **Provider isolation** → RAG filtering prevents cross-contamination
5. ✅ **Auto-cleanup** → Old versions removed automatically

### **Key Components:**
- **Document ID** = hash(provider + folder + filename + content_hash + chunk)
- **Content Hash** = MD5(extracted_text)
- **RAG Filtering** = provider + folder filters
- **Auto-Cleanup** = timestamp-based deletion

**Production-ready and collision-proof!** 🎉
