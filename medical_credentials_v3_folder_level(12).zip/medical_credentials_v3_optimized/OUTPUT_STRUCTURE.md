# OUTPUT STRUCTURE - PROVIDER-BASED ORGANIZATION

## ✅ **NEW STRUCTURE - ORGANIZED BY PROVIDER!**

All outputs are now organized by provider with subfolders for each data type.

---

## 📁 **FOLDER STRUCTURE**

```
outputcontainer/
├── highconfidence/
│   ├── ANAND-NICHOLS/
│   │   ├── ProcessedJSONResult/
│   │   │   ├── ANAND-NICHOLS_GEN_HR_20260306_123456.json
│   │   │   └── ANAND-NICHOLS_ED_TRAIN_20260306_123500.json
│   │   ├── ProcessedCSVResult/
│   │   │   ├── ANAND-NICHOLS_GEN_HR_20260306_123456.csv
│   │   │   └── ANAND-NICHOLS_ED_TRAIN_20260306_123500.csv
│   │   └── ProcessedEstimateCostTracking/
│   │       ├── ANAND-NICHOLS_GEN_HR_20260306_123456.json
│   │       └── ANAND-NICHOLS_ED_TRAIN_20260306_123500.json
│   │
│   └── Provider2/
│       ├── ProcessedJSONResult/
│       ├── ProcessedCSVResult/
│       └── ProcessedEstimateCostTracking/
│
└── lowconfidence/
    ├── Provider3/
    │   ├── ProcessedJSONResult/
    │   ├── ProcessedCSVResult/
    │   └── ProcessedEstimateCostTracking/
    │
    └── Provider4/
        ├── ProcessedJSONResult/
        ├── ProcessedCSVResult/
        └── ProcessedEstimateCostTracking/
```

---

## 🎯 **HIERARCHY**

### **Level 1: Confidence Category**
```
highconfidence/  - All fields meet confidence threshold
lowconfidence/   - At least one field below threshold
```

### **Level 2: Provider Name**
```
highconfidence/
  ├── ANAND-NICHOLS/
  ├── Provider2/
  └── Provider3/
```

### **Level 3: Data Type Folders**
```
ANAND-NICHOLS/
  ├── ProcessedJSONResult/        - Complete extraction data
  ├── ProcessedCSVResult/         - CSV with all documents
  └── ProcessedEstimateCostTracking/ - Cost tracking
```

### **Level 4: Files**
```
ProcessedCSVResult/
  └── ANAND-NICHOLS_GEN_HR_20260306_123456.csv
```

**Filename Pattern:** `{provider}_{folder}_{timestamp}.{ext}`

---

## 📊 **CSV FORMAT (CORRECTED)**

### **One Row Per Document!**

```csv
provider_name,provider_id,folder_name,extraction_datetime,document_name,first_name,first_name_confidence,first_name_source_document,last_name,last_name_confidence,last_name_source_document
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,CV_2025.pdf,Anand,0.95,CV_2025.pdf,Nichols,0.92,CV_2025.pdf
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,Resume.pdf,Anand,0.93,Resume.pdf,Nichols,0.90,Resume.pdf
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,Application.pdf,Anand,0.88,Application.pdf,Smith,0.45,Application.pdf
```

**Key Change:** One row per document, not one row per folder!

---

## 💡 **COMPLETE EXAMPLE**

### **Processing:**
```
Provider: ANAND-NICHOLS
Folder: GEN & HR
Documents: 5 files (CV, Resume, Application, Contact, Personal)
Confidence: Average 0.85 (high)
```

### **Output Files Created:**

**1. JSON Result:**
```
highconfidence/ANAND-NICHOLS/ProcessedJSONResult/ANAND-NICHOLS_GEN_HR_20260306_123456.json
```

**2. CSV Result:**
```
highconfidence/ANAND-NICHOLS/ProcessedCSVResult/ANAND-NICHOLS_GEN_HR_20260306_123456.csv
```

**3. Cost Tracking:**
```
highconfidence/ANAND-NICHOLS/ProcessedEstimateCostTracking/ANAND-NICHOLS_GEN_HR_20260306_123456.json
```

---

## 📋 **CSV CONTENT EXAMPLE**

### **5 Documents Processed:**

```csv
provider_name,provider_id,folder_name,extraction_datetime,document_name,first_name,first_name_confidence,first_name_source_document,last_name,last_name_confidence,last_name_source_document,email,email_confidence,email_source_document
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,CV_2025.pdf,Anand,0.95,CV_2025.pdf,Nichols,0.92,CV_2025.pdf,anand@example.com,0.88,CV_2025.pdf
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,Resume.pdf,Anand,0.93,Resume.pdf,Nichols,0.90,Resume.pdf,anand.n@email.com,0.75,Resume.pdf
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,Application_Form.pdf,Anand,0.88,Application_Form.pdf,Nichols,0.85,Application_Form.pdf,contact@work.com,0.70,Application_Form.pdf
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,Contact_Info.pdf,Anand,0.90,Contact_Info.pdf,Nichols,0.88,Contact_Info.pdf,anand@example.com,0.92,Contact_Info.pdf
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,Personal_Details.pdf,Anand,0.87,Personal_Details.pdf,Nichols,0.83,Personal_Details.pdf,NA,0.0,NA
```

**Each row = One document with its extracted fields!**

---

## 🎯 **MULTIPLE PROVIDERS EXAMPLE**

### **Scenario:**
```
3 Providers processed:
  - ANAND-NICHOLS (GEN & HR, ED & TRAIN) - High confidence
  - Provider2 (Licenses) - Low confidence
  - Provider3 (Certifications) - High confidence
```

### **Output Structure:**
```
outputcontainer/
├── highconfidence/
│   ├── ANAND-NICHOLS/
│   │   ├── ProcessedJSONResult/
│   │   │   ├── ANAND-NICHOLS_GEN_HR_20260306_123456.json
│   │   │   └── ANAND-NICHOLS_ED_TRAIN_20260306_123500.json
│   │   ├── ProcessedCSVResult/
│   │   │   ├── ANAND-NICHOLS_GEN_HR_20260306_123456.csv
│   │   │   └── ANAND-NICHOLS_ED_TRAIN_20260306_123500.csv
│   │   └── ProcessedEstimateCostTracking/
│   │       ├── ANAND-NICHOLS_GEN_HR_20260306_123456.json
│   │       └── ANAND-NICHOLS_ED_TRAIN_20260306_123500.json
│   │
│   └── Provider3/
│       ├── ProcessedJSONResult/
│       │   └── Provider3_Certifications_20260306_123600.json
│       ├── ProcessedCSVResult/
│       │   └── Provider3_Certifications_20260306_123600.csv
│       └── ProcessedEstimateCostTracking/
│           └── Provider3_Certifications_20260306_123600.json
│
└── lowconfidence/
    └── Provider2/
        ├── ProcessedJSONResult/
        │   └── Provider2_Licenses_20260306_123530.json
        ├── ProcessedCSVResult/
        │   └── Provider2_Licenses_20260306_123530.csv
        └── ProcessedEstimateCostTracking/
            └── Provider2_Licenses_20260306_123530.json
```

---

## 🔍 **NAVIGATION EXAMPLE**

### **Finding Specific Provider:**

**Step 1: Check Confidence**
```
Is data high quality?
  → Yes: highconfidence/
  → No:  lowconfidence/
```

**Step 2: Find Provider**
```
highconfidence/ANAND-NICHOLS/
```

**Step 3: Choose Data Type**
```
Need CSV?
  → highconfidence/ANAND-NICHOLS/ProcessedCSVResult/

Need JSON?
  → highconfidence/ANAND-NICHOLS/ProcessedJSONResult/

Need Cost?
  → highconfidence/ANAND-NICHOLS/ProcessedEstimateCostTracking/
```

**Step 4: Open File**
```
highconfidence/ANAND-NICHOLS/ProcessedCSVResult/ANAND-NICHOLS_GEN_HR_20260306_123456.csv
```

---

## 📊 **FILE CONTENTS**

### **1. ProcessedJSONResult (Complete Data)**
```json
{
  "provider": "ANAND-NICHOLS",
  "folder": "GEN & HR",
  "timestamp": "20260306_123456",
  "documents_processed": 5,
  "documents": [
    {
      "document_name": "CV_2025.pdf",
      "fields": {
        "first_name": {"value": "Anand", "confidence": 0.95},
        "last_name": {"value": "Nichols", "confidence": 0.92}
      }
    }
  ],
  "best_values": {
    "first_name": {"value": "Anand", "confidence": 0.91},
    "last_name": {"value": "Nichols", "confidence": 0.88}
  },
  "category": "highconfidence"
}
```

### **2. ProcessedCSVResult (Table Format)**
```csv
provider_name,provider_id,folder_name,extraction_datetime,document_name,first_name,first_name_confidence,first_name_source_document,...
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,CV_2025.pdf,Anand,0.95,CV_2025.pdf,...
ANAND-NICHOLS,ANAND-NICHOLS,GEN & HR,2026-03-06 12:34:56,Resume.pdf,Anand,0.93,Resume.pdf,...
```

### **3. ProcessedEstimateCostTracking (Cost Info)**
```json
{
  "total": 0.05,
  "breakdown": {
    "ocr": 0.01,
    "embedding": 0.004,
    "gpt4o": 0.036
  },
  "detailed": {
    "usage": {
      "ocr_pages": 1,
      "embedding_tokens": 4000,
      "gpt4o_input_tokens": 1200,
      "gpt4o_output_tokens": 800
    }
  }
}
```

---

## ✅ **BENEFITS**

### **1. Provider Organization**
```
All files for one provider in one place
  → highconfidence/ANAND-NICHOLS/
Easy to find, easy to manage
```

### **2. Data Type Separation**
```
Want CSV? → ProcessedCSVResult/
Want JSON? → ProcessedJSONResult/
Want Cost? → ProcessedEstimateCostTracking/
Clear organization
```

### **3. No Duplicates**
```
One save per folder
  → No double-saving
  → No duplicate files
```

### **4. Quality Segregation**
```
High confidence data separate from low confidence
Easy quality control
```

### **5. Scalability**
```
100 providers? No problem!
Each gets own folder
Clean structure maintained
```

---

## 🎯 **COMPARISON**

### **Old Structure (Flat):**
```
processedjsonresult/
  ├── Provider1_Folder1_timestamp.json
  ├── Provider1_Folder2_timestamp.json
  ├── Provider2_Folder1_timestamp.json
  └── (100 more files...)

highconfidence/
  ├── Provider1_Folder1_timestamp.csv
  ├── Provider1_Folder2_timestamp.csv
  └── (100 more files...)

estimatecost/
  └── summary_timestamp.json
```
❌ Hard to find specific provider
❌ Mixed quality levels
❌ No cost per provider

---

### **New Structure (Organized):**
```
highconfidence/
  ├── Provider1/
  │   ├── ProcessedJSONResult/
  │   ├── ProcessedCSVResult/
  │   └── ProcessedEstimateCostTracking/
  └── Provider2/
      ├── ProcessedJSONResult/
      ├── ProcessedCSVResult/
      └── ProcessedEstimateCostTracking/

lowconfidence/
  └── Provider3/
      ├── ProcessedJSONResult/
      ├── ProcessedCSVResult/
      └── ProcessedEstimateCostTracking/
```
✅ Easy to find providers
✅ Quality segregated
✅ Cost per provider/folder

---

## ✅ **SUMMARY**

**New Structure:**
```
{confidence}/
  {provider}/
    ProcessedJSONResult/{provider}_{folder}_{timestamp}.json
    ProcessedCSVResult/{provider}_{folder}_{timestamp}.csv
    ProcessedEstimateCostTracking/{provider}_{folder}_{timestamp}.json
```

**CSV Format:**
- One row per document (not per folder)
- All documents for that folder in one CSV
- Complete metadata and field data

**Benefits:**
- ✅ Organized by provider
- ✅ Separated by data type
- ✅ Quality segregation
- ✅ No duplicates
- ✅ Easy navigation
- ✅ Scalable structure

🎉 **Production-ready organization!**
