"""
Document Intelligence OCR Module
Azure Document Intelligence SDK v1.0.0b4
Clean, production-ready implementation
"""

from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential
import io
from typing import Dict, Tuple


class DocumentIntelligenceOCR:
    """Azure Document Intelligence OCR handler (v1.0.0b4)"""
    
    def __init__(self, endpoint: str, key: str):
        """
        Initialize Document Intelligence client
        
        Args:
            endpoint: Azure Document Intelligence endpoint
            key: Azure Document Intelligence key
        """
        self.client = DocumentIntelligenceClient(
            endpoint=endpoint,
            credential=AzureKeyCredential(key)
        )
    
    def extract_text(self, document_bytes: bytes, file_extension: str) -> Tuple[str, int, bool]:
        """
        Extract text from document using Document Intelligence
        
        Args:
            document_bytes: Document file bytes
            file_extension: File extension (.pdf, .jpg, etc.)
        
        Returns:
            Tuple of (extracted_text, page_count, success)
        """
        try:
            # Prepare document stream
            document_stream = io.BytesIO(document_bytes)
            
            # Call Document Intelligence API (prebuilt-read model)
            poller = self.client.begin_analyze_document(
                model_id="prebuilt-read",
                analyze_request=document_stream,
                content_type=self._get_content_type(file_extension)
            )
            
            # Wait for result
            result = poller.result()
            
            # Extract text from all pages
            extracted_text = ""
            if hasattr(result, 'content') and result.content:
                extracted_text = result.content
            
            # Count pages
            page_count = len(result.pages) if hasattr(result, 'pages') else 1
            
            return extracted_text.strip(), page_count, True
            
        except Exception as e:
            print(f"OCR Error: {str(e)}")
            return "", 0, False
    
    def _get_content_type(self, file_extension: str) -> str:
        """Get content type for Document Intelligence API"""
        content_types = {
            '.pdf': 'application/pdf',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.tiff': 'image/tiff',
            '.tif': 'image/tiff',
            '.bmp': 'image/bmp',
            '.gif': 'image/gif',
            '.webp': 'image/webp',
            '.doc': 'application/msword',
            '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        }
        return content_types.get(file_extension.lower(), 'application/octet-stream')
