"""
TEST IMPORTS - Verify all modules import correctly
Run this to check for import errors before running main.py
"""

print("Testing imports...")
print("-" * 70)

try:
    print("1. Testing helper.py imports...")
    from helper import BlobManager, OpenAIManager, SearchManager, generate_document_id
    print("   ✓ helper.py imports successful")
except ImportError as e:
    print(f"   ✗ ERROR in helper.py: {e}")

try:
    print("2. Testing documentintelligence_ocr.py imports...")
    from documentintelligence_ocr import DocumentIntelligenceOCR
    print("   ✓ documentintelligence_ocr.py imports successful")
except ImportError as e:
    print(f"   ✗ ERROR in documentintelligence_ocr.py: {e}")

try:
    print("3. Testing semantic_chunker.py imports...")
    from semantic_chunker import process_for_chunking
    print("   ✓ semantic_chunker.py imports successful")
except ImportError as e:
    print(f"   ✗ ERROR in semantic_chunker.py: {e}")

try:
    print("4. Testing costtracking.py imports...")
    from costtracking import CostTracker
    print("   ✓ costtracking.py imports successful")
except ImportError as e:
    print(f"   ✗ ERROR in costtracking.py: {e}")

try:
    print("5. Testing logging_config.py imports...")
    from logging_config import setup_logging
    print("   ✓ logging_config.py imports successful")
except ImportError as e:
    print(f"   ✗ ERROR in logging_config.py: {e}")

try:
    print("6. Testing prompt_builder.py imports...")
    from prompt_builder import build_extraction_prompt
    print("   ✓ prompt_builder.py imports successful")
    print("   ✓ build_extraction_prompt function found!")
except ImportError as e:
    print(f"   ✗ ERROR in prompt_builder.py: {e}")

try:
    print("7. Testing prompt_config.py imports...")
    from prompt_config import FIELD_LIBRARY
    print("   ✓ prompt_config.py imports successful")
    print(f"   ✓ Found {len(FIELD_LIBRARY)} fields in FIELD_LIBRARY")
except ImportError as e:
    print(f"   ✗ ERROR in prompt_config.py: {e}")

print("-" * 70)
print("✓ All imports successful!")
print("\nYou can now run: python main.py")
