# RAG MODE CONFIGURATION - SIMPLE GUIDE

## 🎯 **ONE GLOBAL RAG MODE SETTING**

### **In config.json:**

```json
{
  "rag": {
    "mode": "text"  ← Change this to "text" or "multimodal"
  }
}
```

**That's it!** One setting for the entire system.

---

## 🔧 **RAG MODE OPTIONS**

### **Option 1: Text Mode (Fast)**
```json
{
  "rag": {
    "mode": "text"
  }
}
```

**When to use:**
- ✅ Digital PDFs
- ✅ Word documents
- ✅ Clear text documents
- ✅ Speed is important

**Characteristics:**
- Speed: 5-8 seconds per document
- Accuracy: 92-95%
- Cost: ~$0.05 per document

---

### **Option 2: Multimodal Mode (Accurate)**
```json
{
  "rag": {
    "mode": "multimodal"
  }
}
```

**When to use:**
- ✅ Scanned documents
- ✅ Handwritten forms
- ✅ Images (JPG, PNG, TIFF)
- ✅ Poor quality scans
- ✅ Accuracy is critical

**Characteristics:**
- Speed: 8-12 seconds per document
- Accuracy: 93-96%
- Cost: ~$0.08 per document
- Uses GPT-4o Vision API

**Note:** Multimodal only works on image files. PDF/DOC files will automatically use text mode even if you set multimodal.

---

## 📊 **HOW IT WORKS**

### **Text Mode:**
```
Document → OCR → Text Extraction → GPT-4o → Results
```

### **Multimodal Mode:**
```
Image File → OCR → Text Extraction + Image → GPT-4o Vision → Results
PDF/DOC → OCR → Text Extraction → GPT-4o Text → Results
```

**Smart behavior:**
- If `mode = "multimodal"` AND file is image (.jpg, .png, etc.)
  → Uses GPT-4o Vision ✅
  
- If `mode = "multimodal"` AND file is PDF/DOC
  → Falls back to text mode ✅
  
- If `mode = "text"`
  → Always uses text mode ✅

---

## 🎯 **TYPICAL USAGE**

### **Most Common: Text Mode**
```json
{
  "rag": {
    "mode": "text"
  }
}
```
**Why:**
- Faster processing
- Lower cost
- Works well for most documents
- 92-95% accuracy is good enough

---

### **When You Need Better Accuracy: Multimodal**
```json
{
  "rag": {
    "mode": "multimodal"
  }
}
```
**Why:**
- Scanned handwritten forms
- Poor quality documents
- Complex layouts
- Need 93-96% accuracy

---

## 💡 **SWITCHING MODES**

### **Example: Testing Both Modes**

**1. Run with Text Mode:**
```json
{
  "rag": {
    "mode": "text"
  }
}
```
```bash
python main.py
```
Result: Fast, 92-95% accuracy

**2. Run with Multimodal Mode:**
```json
{
  "rag": {
    "mode": "multimodal"
  }
}
```
```bash
python main.py
```
Result: Slower, 93-96% accuracy

**3. Compare Results:**
- Check accuracy in output files
- Compare processing time in logs
- Compare costs in estimatecost/

---

## 📝 **COMPLETE CONFIG EXAMPLE**

```json
{
  "azure_blob": {
    "connection_string": "...",
    "inputcontainer": "inputcontainer",
    "outputcontainer": "outputcontainer"
  },
  
  "folder_configs": {
    "GEN & HR": {
      "description": "Personal info",
      "fields": ["first_name", "last_name", ...]
    },
    "ED & TRAIN": {
      "description": "Licenses",
      "fields": ["state_license_number", ...]
    }
  },
  
  "extraction": {
    "confidence_threshold": 0.50
  },
  
  "rag": {
    "mode": "text",  ← CHANGE THIS: "text" or "multimodal"
    "top_k": 3,
    "chunk_size": 1000,
    "chunk_overlap": 200,
    "max_chunks_per_doc": 5,
    "enable_priority_chunking": true
  }
}
```

---

## ✅ **SUMMARY**

**Configuration:**
- ✅ One global setting: `"rag": {"mode": "text"}` or `"mode": "multimodal"`
- ✅ Change anytime in config.json
- ✅ No per-folder configuration needed

**Behavior:**
- Text mode: Always uses text extraction
- Multimodal mode: Uses Vision for images, text for PDFs

**Simple and flexible!** 🎉
