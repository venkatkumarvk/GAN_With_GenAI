"""
Semantic Chunker - Priority chunking BEFORE indexing
Optimized for production medical document processing
"""

import re
from typing import List, Dict, Tuple


class SemanticChunker:
    """Semantic text chunking with sentence-level boundaries"""
    
    def __init__(self, chunk_size: int = 1000, overlap: int = 200, max_chunks: int = 5):
        """
        Initialize chunker
        
        Args:
            chunk_size: Target characters per chunk
            overlap: Characters to overlap between chunks
            max_chunks: Maximum chunks per document
        """
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.max_chunks = max_chunks
    
    def should_chunk(self, text: str) -> bool:
        """Check if text needs chunking"""
        return len(text) > self.chunk_size
    
    def chunk_text(self, text: str, document_id: str = "") -> List[Dict[str, any]]:
        """
        Chunk text into semantic segments with overlap
        
        Args:
            text: Input text to chunk
            document_id: Document identifier for tracking
        
        Returns:
            List of chunk dictionaries with metadata
        """
        # Handle short documents - no chunking needed
        if len(text) <= self.chunk_size:
            return [{
                'chunk_id': f"{document_id}_chunk_0",
                'text': text,
                'chunk_index': 0,
                'total_chunks': 1,
                'start_char': 0,
                'end_char': len(text)
            }]
        
        # Split into sentences for semantic boundaries
        sentences = self._split_sentences(text)
        
        chunks = []
        current_chunk = ""
        current_size = 0
        chunk_start = 0
        chunk_index = 0
        
        for sentence in sentences:
            sentence_len = len(sentence)
            
            # If adding sentence exceeds chunk size, save current chunk
            if current_size + sentence_len > self.chunk_size and current_chunk:
                chunk_end = chunk_start + current_size
                chunks.append({
                    'chunk_id': f"{document_id}_chunk_{chunk_index}",
                    'text': current_chunk.strip(),
                    'chunk_index': chunk_index,
                    'total_chunks': -1,  # Will update later
                    'start_char': chunk_start,
                    'end_char': chunk_end
                })
                chunk_index += 1
                
                # Stop if max chunks reached
                if chunk_index >= self.max_chunks:
                    break
                
                # Create overlap and start new chunk
                overlap_text = self._get_overlap(current_chunk)
                overlap_len = len(overlap_text)
                chunk_start = chunk_end - overlap_len
                
                current_chunk = overlap_text + " " + sentence
                current_size = len(current_chunk)
            else:
                # Add sentence to current chunk
                if current_chunk:
                    current_chunk += " " + sentence
                else:
                    current_chunk = sentence
                current_size += sentence_len + (1 if current_chunk != sentence else 0)
        
        # Add final chunk if exists and under max limit
        if current_chunk and chunk_index < self.max_chunks:
            chunks.append({
                'chunk_id': f"{document_id}_chunk_{chunk_index}",
                'text': current_chunk.strip(),
                'chunk_index': chunk_index,
                'total_chunks': -1,
                'start_char': chunk_start,
                'end_char': chunk_start + len(current_chunk)
            })
        
        # Update total_chunks count
        total = len(chunks)
        for chunk in chunks:
            chunk['total_chunks'] = total
        
        return chunks
    
    def _split_sentences(self, text: str) -> List[str]:
        """Split text into sentences using regex"""
        # Pattern: sentence ending punctuation followed by space/newline
        pattern = r'(?<=[.!?])\s+'
        sentences = re.split(pattern, text)
        return [s.strip() for s in sentences if s.strip()]
    
    def _get_overlap(self, text: str) -> str:
        """Get last N characters for overlap"""
        if len(text) <= self.overlap:
            return text
        
        # Try to get overlap at word boundary
        overlap_text = text[-self.overlap:]
        
        # Find first space to avoid cutting mid-word
        first_space = overlap_text.find(' ')
        if first_space > 0:
            return overlap_text[first_space+1:]
        
        return overlap_text
    
    def get_chunk_summary(self, chunks: List[Dict]) -> Dict[str, any]:
        """Get summary statistics for chunks"""
        if not chunks:
            return {
                'total_chunks': 0,
                'avg_chunk_size': 0,
                'total_text_length': 0,
                'min_chunk_size': 0,
                'max_chunk_size': 0
            }
        
        chunk_sizes = [len(c['text']) for c in chunks]
        return {
            'total_chunks': len(chunks),
            'avg_chunk_size': sum(chunk_sizes) // len(chunks),
            'total_text_length': sum(chunk_sizes),
            'min_chunk_size': min(chunk_sizes),
            'max_chunk_size': max(chunk_sizes)
        }


def process_for_chunking(text: str, config: dict, document_id: str = "") -> Tuple[bool, List[Dict], str]:
    """
    Process document text for chunking
    
    Args:
        text: Document text
        config: RAG configuration from config.json
        document_id: Document identifier
    
    Returns:
        Tuple of (needs_chunking, chunks_or_none, strategy)
    """
    # Check if chunking is enabled
    if not config.get('enable_priority_chunking', True):
        return False, None, 'no_chunking_disabled'
    
    # Initialize chunker with config
    chunker = SemanticChunker(
        chunk_size=config.get('chunk_size', 1000),
        overlap=config.get('chunk_overlap', 200),
        max_chunks=config.get('max_chunks_per_doc', 5)
    )
    
    # Check if chunking needed
    if not chunker.should_chunk(text):
        return False, None, 'no_chunking_small'
    
    # Perform chunking
    chunks = chunker.chunk_text(text, document_id)
    return True, chunks, 'semantic_chunking'
