# FOLDER-LEVEL EXTRACTION - HOW IT WORKS

## 📊 **YOUR WORKFLOW**

### **Step 1: System Scans Blob Storage**
```
inputcontainer/
├── Provider1/
│   ├── GEN & HR/         ← Found!
│   ├── ED & TRAIN/       ← Found!
│   └── Photos/           ← Not configured (uses default)
│
├── Provider2/
│   ├── GEN & HR/         ← Found!
│   ├── Licenses/         ← Found!
│   └── Archive/          ← Not configured (uses default)
│
└── Provider3/
    └── ED & TRAIN/       ← Found!
```

### **Step 2: Match to Configuration**
From your `config.json`:
```json
{
  "folder_configs": {
    "GEN & HR": {
      "description": "Personal identification",
      "fields": ["first_name", "last_name", "email", "cell", ...]
    },
    "ED & TRAIN": {
      "description": "Medical licenses and registrations",
      "fields": ["degree", "state_license_number", "dea_license_number", ...]
    }
  }
}
```

### **Step 3: Process Each Folder**
```
Provider1 / GEN & HR:
  ✓ Extract: first_name, last_name, email, cell, birth_date, ...
  
Provider1 / ED & TRAIN:
  ✓ Extract: degree, state_license_number, dea_license_number, ...
  
Provider2 / GEN & HR:
  ✓ Extract: first_name, last_name, email, cell, birth_date, ...
  (Same fields as Provider1/GEN & HR)
  
Provider2 / Licenses:
  ✓ Extract: state_license_number, dea_license_number, ...
```

---

## ⚙️ **CONFIGURATION EXPLAINED**

### **Folder-Based (Your Approach)**
```json
{
  "folder_configs": {
    "GEN & HR": {
      "description": "Personal info",
      "fields": ["first_name", "last_name", "email"]
    }
  }
}
```

**What happens:**
- System finds "GEN & HR" in ALL providers
- Extracts same fields from all "GEN & HR" folders
- **No need to specify providers!**

---

## 🎯 **KEY FEATURES**

### **1. Global Confidence Threshold**
```json
{
  "extraction": {
    "confidence_threshold": 0.50  ← One threshold for everything
  }
}
```
- ✅ No per-folder confidence needed
- ✅ Simpler configuration
- ✅ Fields with confidence < 0.50 become "NA"

### **2. Auto RAG Mode Selection**
```
Document Extension          RAG Mode
─────────────────────────   ──────────
.jpg, .jpeg, .png, etc.  →  Multimodal (GPT-4o Vision)
.pdf, .doc, .docx        →  Text
```
- ✅ Automatic selection based on file type
- ✅ No manual configuration needed
- ✅ Images → Better accuracy with Vision

### **3. Priority Chunking**
```json
{
  "rag": {
    "chunk_size": 1000,
    "chunk_overlap": 200,
    "max_chunks_per_doc": 5,
    "enable_priority_chunking": true
  }
}
```
- ✅ Handles large documents automatically
- ✅ Semantic splitting (sentence boundaries)
- ✅ No context errors

---

## 📁 **COMPLETE WORKFLOW**

```
1. START
   ↓
2. Load config.json
   ↓
3. Initialize Azure managers
   ↓
4. Create universal index (if needed)
   ↓
5. Auto-cleanup (delete old docs)
   ↓
6. Scan blob storage
   → Get all providers: [Provider1, Provider2, Provider3]
   → Get all folders per provider
   ↓
7. FOR EACH PROVIDER:
   ↓
   8. FOR EACH FOLDER in provider:
      ↓
      9. Match folder name to folder_configs
         - "GEN & HR" → Use GEN & HR config
         - "ED & TRAIN" → Use ED & TRAIN config
         - "Unknown" → Use default_config
      ↓
      10. Get folder configuration
          - Fields to extract
          - Description
      ↓
      11. List all documents in folder
      ↓
      12. FOR EACH DOCUMENT:
          ↓
          13. Download from Blob
          ↓
          14. OCR extraction (Document Intelligence v1.0.0b4)
          ↓
          15. Check text length (skip if < 10 chars)
          ↓
          16. PRIORITY CHUNKING
              - If text > 1000 chars → Chunk it
              - Split at sentences
              - Create overlapping chunks
              - Max 5 chunks
          ↓
          17. Generate embeddings
          ↓
          18. Upload to index
              - Provider tag: "Provider1"
              - Folder tag: "GEN & HR"
              - Content: text/chunks
          ↓
          19. RAG search
              - Filter by: provider="Provider1" AND folder="GEN & HR"
              - Get top 3 similar documents
          ↓
          20. Determine RAG mode
              - Is image? → Multimodal (Vision)
              - Is PDF/DOC? → Text
          ↓
          21. Build extraction prompt
              - Fields from folder config
              - RAG examples
              - Current document
          ↓
          22. Call GPT-4o
              - Text mode OR Multimodal mode
              - Extract all fields
          ↓
          23. Parse JSON response
          ↓
          24. Store result
      ↓
      25. Calculate best values (frequency)
      ↓
      26. Save results
          - JSON: processedjsonresult/Provider_Folder_timestamp.json
          - CSV: highconfidence/ or lowconfidence/
   ↓
27. Save cost summary
    ↓
28. DONE ✅
```

---

## 📝 **EXAMPLE: Adding New Folder**

### **Scenario**
You have a new folder type: "Insurance"

### **Step 1: Add to config.json**
```json
{
  "folder_configs": {
    "GEN & HR": { ... },
    "ED & TRAIN": { ... },
    
    "Insurance": {
      "description": "Insurance and malpractice",
      "fields": [
        "malpractice_carrier",
        "malpractice_policy_number",
        "malpractice_coverage_amount",
        "npi_number"
      ]
    }
  }
}
```

### **Step 2: Run System**
```bash
python main.py
```

### **Result**
- ✅ System finds "Insurance" folder in ALL providers
- ✅ Extracts specified fields
- ✅ No code changes needed!

---

## 🎯 **CONFIDENCE HANDLING**

### **Global Threshold**
```json
{
  "extraction": {
    "confidence_threshold": 0.50
  }
}
```

### **How It Works**
```
Field Extraction Results:
├── first_name: "John" (confidence: 0.95) ✅
├── last_name: "Doe" (confidence: 0.87) ✅
├── email: "john@example.com" (confidence: 0.78) ✅
├── cell: "555-1234" (confidence: 0.45) ❌ → Becomes "NA"
└── ssn: "XXX-XX-1234" (confidence: 0.92) ✅

Best Values:
├── first_name: "John"
├── last_name: "Doe"
├── email: "john@example.com"
├── cell: "NA"  ← Below threshold
└── ssn: "XXX-XX-1234"

Min Confidence: 0.45
Category: lowconfidence  ← Because min < 0.50
```

### **Output Files**
```
lowconfidence/Provider1_GEN_HR_20260306_123456.csv
```

---

## 💡 **TIPS**

### **Tip 1: Folder Names Must Match Exactly**
```
✅ Good:
   Blob: "GEN & HR"
   Config: "GEN & HR"

❌ Bad:
   Blob: "GEN_HR"
   Config: "GEN & HR"
```

### **Tip 2: Nested Folders Supported**
```
✅ Works:
   Blob: "Documents/Personal"
   Config: "Documents/Personal": { ... }
```

### **Tip 3: Unknown Folders Use Default**
```json
{
  "default_config": {
    "fields": ["first_name", "last_name", "document_type"]
  },
  "processing": {
    "skip_unknown_folders": false  ← Set true to skip them
  }
}
```

---

## 🚀 **ADVANTAGES**

### **vs Provider-Based Configuration**

**OLD WAY (Provider-based):**
```json
{
  "Provider1": {
    "folders": ["GEN & HR", "ED & TRAIN"]
  },
  "Provider2": {
    "folders": ["GEN & HR", "Licenses"]
  },
  "Provider3": {
    "folders": ["ED & TRAIN"]
  }
}
```
❌ Must add every provider
❌ Duplicated folder configs
❌ Hard to maintain

**NEW WAY (Folder-based):**
```json
{
  "GEN & HR": {
    "fields": [...]
  },
  "ED & TRAIN": {
    "fields": [...]
  }
}
```
✅ Configure once
✅ Applies to all providers
✅ Add new provider → Works automatically!

---

## ✅ **SUMMARY**

**Your System:**
1. ✅ Folder-level configuration (not provider-level)
2. ✅ Global confidence threshold (no per-folder)
3. ✅ Auto RAG mode (image → multimodal, doc → text)
4. ✅ Priority chunking (handles large docs)
5. ✅ Universal index (provider + folder filtering)
6. ✅ Add folders anytime (just edit config.json)

**Simple, scalable, and production-ready!** 🎉
