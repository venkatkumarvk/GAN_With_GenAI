# CHUNKING TECHNIQUE

## 🎯 **SEMANTIC SENTENCE-BASED CHUNKING**

The system uses **semantic chunking with sentence-level boundaries** to handle large documents.

---

## 📊 **CHUNKING METHOD**

### **Technique: Sentence-Based Semantic Chunking**

```python
# Split at sentence boundaries
sentences = re.split(r'(?<=[.!?])\s+', text)

# Group sentences into chunks
chunk_size = 1000 characters
chunk_overlap = 200 characters
max_chunks = 5 per document
```

**Why Sentence-Based?**
- ✅ Preserves semantic meaning
- ✅ No mid-sentence cuts
- ✅ Better context retention
- ✅ Improves RAG quality

---

## 🔧 **HOW IT WORKS**

### **Step 1: Check if Chunking Needed**
```python
if len(text) > chunk_size:
    # Document needs chunking
    needs_chunking = True
else:
    # Document fits in one chunk
    needs_chunking = False
```

### **Step 2: Split into Sentences**
```python
# Regex: Split after . ! ? followed by space
pattern = r'(?<=[.!?])\s+'
sentences = re.split(pattern, text)

# Example:
text = "Hello world. This is a test. How are you?"
sentences = ["Hello world.", "This is a test.", "How are you?"]
```

### **Step 3: Group Sentences into Chunks**
```python
chunks = []
current_chunk = ""

for sentence in sentences:
    if len(current_chunk) + len(sentence) <= chunk_size:
        current_chunk += sentence + " "
    else:
        # Save current chunk
        chunks.append(current_chunk)
        # Start new chunk with overlap
        current_chunk = last_N_chars(chunk_overlap) + sentence
```

### **Step 4: Add Overlap**
```python
# Each chunk includes last 200 chars from previous chunk
# This maintains context between chunks

Chunk 1: [chars 0-1000]
Chunk 2: [chars 800-1800]  ← 200 char overlap
Chunk 3: [chars 1600-2600] ← 200 char overlap
```

### **Step 5: Limit Chunks**
```python
# Only keep first 5 chunks
chunks = chunks[:max_chunks_per_doc]

# Why? To avoid processing 100-page documents entirely
# First 5 chunks (5000 chars) is usually sufficient
```

---

## 💡 **COMPLETE EXAMPLE**

### **Input Document (3000 characters):**
```
This is sentence one. This is sentence two. This is sentence three... (3000 chars total)
```

### **Chunking Process:**

**Configuration:**
```python
chunk_size = 1000
chunk_overlap = 200
max_chunks = 5
```

**Result:**
```
Chunk 1:
  Content: Sentences 1-10 (1000 chars)
  Chunk Index: 0
  
Chunk 2:
  Content: Last 200 chars of Chunk 1 + Sentences 11-20 (1000 chars)
  Chunk Index: 1
  
Chunk 3:
  Content: Last 200 chars of Chunk 2 + Sentences 21-30 (1000 chars)
  Chunk Index: 2
```

---

## 📋 **INDEXING STRATEGY**

### **Each Chunk Indexed Separately:**

```python
for chunk in chunks:
    # Generate unique ID
    doc_id = hash(provider + folder + filename + content_hash + chunk_index)
    
    # Generate embedding
    vector = generate_embedding(chunk['text'])
    
    # Upload to Azure AI Search
    upload_document(
        id=doc_id,
        content=chunk['text'],
        vector=vector,
        chunk_index=chunk['chunk_index'],
        total_chunks=len(chunks)
    )
```

**Index Structure:**
```
Document: report.pdf (5 chunks)

documents_universal:
  - id: abc123_chunk0, content: chunk1_text, chunk_index: 0, total_chunks: 5
  - id: abc123_chunk1, content: chunk2_text, chunk_index: 1, total_chunks: 5
  - id: abc123_chunk2, content: chunk3_text, chunk_index: 2, total_chunks: 5
  - id: abc123_chunk3, content: chunk4_text, chunk_index: 3, total_chunks: 5
  - id: abc123_chunk4, content: chunk5_text, chunk_index: 4, total_chunks: 5
```

---

## 🎯 **EXTRACTION STRATEGY**

### **Use First Chunk for Extraction:**

```python
if needs_chunking:
    # Use first chunk (most relevant - usually has header/summary)
    extraction_text = chunks[0]['text']
else:
    # Use full text
    extraction_text = text

# Extract fields from extraction_text
extract_fields(extraction_text, fields)
```

**Why First Chunk?**
- Headers usually at the beginning
- Most important info typically in first pages
- Faster processing
- Good enough for most documents

---

## 📊 **RAG SEARCH ACROSS CHUNKS**

### **Search Returns Best Matching Chunks:**

```python
# Generate query embedding
query_vector = generate_embedding(extraction_text)

# Search returns top-k similar chunks (not documents)
similar_docs = search_similar(
    vector=query_vector,
    provider=provider,
    folder=folder,
    top_k=3  # Top 3 most similar chunks
)

# Could return:
# - Chunk 2 from document A
# - Chunk 1 from document B
# - Chunk 3 from document C
```

**Benefits:**
- More precise matching
- Relevant context even from large documents
- Better RAG quality

---

## 🔧 **CONFIGURATION**

### **In config.json:**
```json
{
  "rag": {
    "chunk_size": 1000,
    "chunk_overlap": 200,
    "max_chunks_per_doc": 5,
    "enable_priority_chunking": true
  }
}
```

### **Parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `chunk_size` | 1000 | Max characters per chunk |
| `chunk_overlap` | 200 | Overlap between chunks |
| `max_chunks_per_doc` | 5 | Max chunks to process |
| `enable_priority_chunking` | true | Enable/disable chunking |

---

## 💡 **ADVANCED EXAMPLES**

### **Example 1: Small Document (500 chars)**
```
Input: 500 characters
chunk_size: 1000

Result:
  - needs_chunking: False
  - chunks: 1 (full document)
  - Indexed as: Single document
```

### **Example 2: Medium Document (2500 chars)**
```
Input: 2500 characters
chunk_size: 1000
chunk_overlap: 200

Result:
  - needs_chunking: True
  - chunks: 3
    * Chunk 0: chars 0-1000
    * Chunk 1: chars 800-1800 (200 overlap)
    * Chunk 2: chars 1600-2500 (200 overlap)
  - Indexed as: 3 separate documents
```

### **Example 3: Large Document (100 pages = 50,000 chars)**
```
Input: 50,000 characters
chunk_size: 1000
max_chunks: 5

Result:
  - needs_chunking: True
  - chunks: 5 (limited!)
    * Only first 5000 chars processed
    * Rest of document ignored
  - Indexed as: 5 chunks
  - Extraction: Uses first chunk
```

---

## 🎯 **BENEFITS**

### **1. Context Length Management**
```
✅ Prevents token limit errors
✅ Handles documents up to 100+ pages
✅ No more "context too long" errors
```

### **2. Better RAG Quality**
```
✅ Semantic boundaries preserved
✅ Overlap maintains context
✅ More precise matching
```

### **3. Cost Efficiency**
```
✅ Only process relevant chunks
✅ Max 5 chunks per doc
✅ First chunk used for extraction
```

### **4. Scalability**
```
✅ Handles massive documents
✅ Constant memory usage
✅ Predictable costs
```

---

## 🔍 **COMPARISON WITH OTHER TECHNIQUES**

### **1. Fixed-Size Chunking**
```
Method: Split every N characters
❌ Cuts mid-sentence
❌ Breaks context
❌ Poor RAG quality
```

### **2. Paragraph-Based Chunking**
```
Method: Split at paragraph breaks
❌ Paragraphs can be very long
❌ Still hits token limits
❌ Inconsistent chunk sizes
```

### **3. Sentence-Based Chunking (Our Method)**
```
Method: Split at sentence boundaries + overlap
✅ Preserves meaning
✅ Consistent quality
✅ Configurable overlap
✅ No mid-sentence cuts
```

---

## ⚙️ **TUNING RECOMMENDATIONS**

### **For Short Documents (< 10 pages):**
```json
{
  "chunk_size": 2000,
  "chunk_overlap": 100,
  "max_chunks_per_doc": 3
}
```

### **For Long Documents (10-50 pages):**
```json
{
  "chunk_size": 1000,
  "chunk_overlap": 200,
  "max_chunks_per_doc": 5
}
```

### **For Very Long Documents (50+ pages):**
```json
{
  "chunk_size": 800,
  "chunk_overlap": 200,
  "max_chunks_per_doc": 10
}
```

---

## ✅ **SUMMARY**

**Chunking Technique:** Semantic Sentence-Based

**Key Features:**
- ✅ Sentence-level boundaries
- ✅ Configurable overlap (200 chars default)
- ✅ Chunk size limit (1000 chars default)
- ✅ Max chunks per document (5 default)
- ✅ First chunk used for extraction

**Benefits:**
- Handles large documents (100+ pages)
- Prevents context length errors
- Maintains semantic meaning
- Better RAG quality
- Cost-effective

**Configuration:**
```json
{
  "rag": {
    "chunk_size": 1000,
    "chunk_overlap": 200,
    "max_chunks_per_doc": 5,
    "enable_priority_chunking": true
  }
}
```

🎉 **Production-ready chunking strategy!**
