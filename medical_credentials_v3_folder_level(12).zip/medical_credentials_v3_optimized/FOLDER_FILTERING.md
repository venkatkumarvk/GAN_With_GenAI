# FOLDER FILTERING - PROCESS ONLY CONFIGURED FOLDERS

## ✅ **YES! EXACTLY CORRECT!**

The system will **ONLY process folders you configure** and **SKIP all others**.

---

## 🎯 **YOUR SCENARIO**

### **Example:**
```
Provider has 100 folders:
  - Folder_001/
  - Folder_002/
  - ...
  - GEN & HR/        ← You configured this
  - ...
  - ED & TRAIN/      ← You configured this
  - ...
  - Folder_100/
```

### **Your Config:**
```json
{
  "folder_configs": {
    "GEN & HR": {
      "fields": ["first_name", "last_name", "email"]
    },
    "ED & TRAIN": {
      "fields": ["state_license_number", "dea_license_number"]
    }
  },
  
  "processing": {
    "skip_unknown_folders": true  ← IMPORTANT! Set to true
  }
}
```

### **What Happens:**
```
✅ Process: GEN & HR (configured)
✅ Process: ED & TRAIN (configured)
❌ Skip: Folder_001 (not configured)
❌ Skip: Folder_002 (not configured)
❌ Skip: Folder_003-100 (not configured)
```

**Result:** Only 2 folders processed out of 100! ✅

---

## 🔧 **HOW IT WORKS**

### **Configuration:**
```json
{
  "processing": {
    "skip_unknown_folders": true  ← Set this to true!
  }
}
```

### **System Logic:**
```python
for folder in provider_folders:
    # Try to match folder to config
    config_name, folder_config = match_folder_to_config(folder, folder_configs)
    
    if not folder_config:
        # Folder not in config!
        if skip_unknown_folders == true:
            logger.info(f"Skipping unknown folder: {folder}")
            continue  # ✅ Skip this folder!
        else:
            # Use default config
            folder_config = default_config  # ❌ Don't want this!
    
    # Process folder
    process_documents(folder, folder_config)
```

---

## 💡 **COMPARISON**

### **Option 1: skip_unknown_folders = true (YOUR CHOICE)**
```json
{
  "processing": {
    "skip_unknown_folders": true
  }
}
```

**Behavior:**
```
Provider has 100 folders
You configured 3 folders

Result:
  ✅ Process 3 folders (only configured ones)
  ❌ Skip 97 folders (not configured)
  
Speed: FAST! (only 3% of folders processed)
```

---

### **Option 2: skip_unknown_folders = false (NOT YOUR CHOICE)**
```json
{
  "processing": {
    "skip_unknown_folders": false
  }
}
```

**Behavior:**
```
Provider has 100 folders
You configured 3 folders

Result:
  ✅ Process 3 folders (with your config)
  ✅ Process 97 folders (with default config)
  
Speed: SLOW! (all 100 folders processed)
```

**You don't want this!** ❌

---

## 📊 **COMPLETE EXAMPLE**

### **Your Blob Structure:**
```
Provider1/
  ├── GEN & HR/           ← Configured ✅
  ├── ED & TRAIN/         ← Configured ✅
  ├── Photos/             ← Not configured
  ├── Archive/            ← Not configured
  ├── Old_Files/          ← Not configured
  ├── Backup_2024/        ← Not configured
  ├── Temp/               ← Not configured
  ... (93 more folders)
```

### **Your Config:**
```json
{
  "folder_configs": {
    "GEN & HR": {
      "description": "Personal info",
      "fields": ["first_name", "last_name", "email", "cell"]
    },
    "ED & TRAIN": {
      "description": "Education and licenses",
      "fields": ["degree", "state_license_number", "dea_license_number"]
    }
  },
  
  "processing": {
    "skip_unknown_folders": true  ← Set to true!
  }
}
```

### **System Execution:**
```
INFO - Found 100 folders
INFO - 
--- Folder: GEN & HR (Config: GEN & HR) ---
INFO - Fields: ['first_name', 'last_name', 'email', 'cell']
INFO - Found 10 documents to process
INFO - Processing: Provider1/GEN & HR/doc1.pdf
INFO - Processing: Provider1/GEN & HR/doc2.pdf
... (processes all docs in GEN & HR)

INFO - 
--- Folder: ED & TRAIN (Config: ED & TRAIN) ---
INFO - Fields: ['degree', 'state_license_number', 'dea_license_number']
INFO - Found 15 documents to process
INFO - Processing: Provider1/ED & TRAIN/doc1.pdf
... (processes all docs in ED & TRAIN)

INFO - Skipping unknown folder: Photos
INFO - Skipping unknown folder: Archive
INFO - Skipping unknown folder: Old_Files
INFO - Skipping unknown folder: Backup_2024
INFO - Skipping unknown folder: Temp
... (skips 95 more folders)

INFO - Processing complete!
INFO - Total folders processed: 2 out of 100
```

**Perfect!** Only configured folders processed! ✅

---

## ⚡ **PERFORMANCE BENEFIT**

### **Scenario: Provider with 100 folders**

**Without filtering (skip_unknown_folders = false):**
```
Folders: 100
Documents per folder: 30
Total documents: 100 × 30 = 3,000
Processing time: ~8 hours
Cost: ~$150
```

**With filtering (skip_unknown_folders = true):**
```
Configured folders: 2
Documents per folder: 30
Total documents: 2 × 30 = 60
Processing time: ~10 minutes
Cost: ~$3

Savings: 98% time, 98% cost! ✅
```

---

## 🎯 **TYPICAL USE CASES**

### **Use Case 1: Medical Credentials**
```json
{
  "folder_configs": {
    "Licenses": {
      "fields": ["state_license_number", "dea_license_number"]
    },
    "Certifications": {
      "fields": ["board_cert_name", "board_cert_specialty"]
    }
  }
}
```

**Provider folders:**
- Licenses/ ✅ Process
- Certifications/ ✅ Process
- Photos/, Resumes/, References/, etc. ❌ Skip all

---

### **Use Case 2: HR Documents**
```json
{
  "folder_configs": {
    "Employment_Verification": {
      "fields": ["employee_id", "start_date", "position"]
    },
    "Tax_Documents": {
      "fields": ["ssn", "w2_year", "total_income"]
    }
  }
}
```

**Provider folders:**
- Employment_Verification/ ✅ Process
- Tax_Documents/ ✅ Process
- Training_Records/, Benefits/, Payroll/, etc. ❌ Skip all

---

## ✅ **CONFIGURATION GUIDE**

### **Step 1: List Your Target Folders**
Identify which folders contain the data you need:
```
✅ GEN & HR - Has personal info I need
✅ ED & TRAIN - Has licenses I need
❌ Photos - Don't need
❌ Archive - Don't need
```

### **Step 2: Configure Only Target Folders**
```json
{
  "folder_configs": {
    "GEN & HR": {
      "description": "Personal identification",
      "fields": ["first_name", "last_name", "email", "cell"]
    },
    "ED & TRAIN": {
      "description": "Education and licenses",
      "fields": ["degree", "state_license_number"]
    }
  }
}
```

### **Step 3: Enable Folder Filtering**
```json
{
  "processing": {
    "skip_unknown_folders": true  ← Must be true!
  }
}
```

### **Step 4: Run**
```bash
python main.py
```

**Result:** Only configured folders processed! ✅

---

## 🔍 **VERIFICATION**

### **Check Logs:**
```
INFO - Found 100 folders: ['GEN & HR', 'ED & TRAIN', 'Photos', ...]
INFO - 
--- Folder: GEN & HR (Config: GEN & HR) ---
INFO - Fields: ['first_name', 'last_name', ...]
INFO - Processing...

INFO - 
--- Folder: ED & TRAIN (Config: ED & TRAIN) ---
INFO - Fields: ['degree', 'state_license_number', ...]
INFO - Processing...

INFO - Skipping unknown folder: Photos
INFO - Skipping unknown folder: Archive
INFO - Skipping unknown folder: Old_Files
... (all other folders skipped)
```

### **Check Output:**
```bash
ls processedjsonresult/
```

**Expected:**
```
Provider1_GEN_HR_timestamp.json      ✅ Only configured folders!
Provider1_ED_TRAIN_timestamp.json    ✅
(No files from Photos, Archive, etc.) ✅
```

---

## 💡 **BEST PRACTICES**

### **1. Be Specific with Folder Names**
```
✅ Good: "Licenses", "Certifications", "Employment_Verification"
❌ Avoid: "Documents", "Files", "Data" (too generic)
```

### **2. Use Nested Folders When Needed**
```json
{
  "folder_configs": {
    "HR/Employment": {
      "fields": [...]
    },
    "HR/Benefits": {
      "fields": [...]
    }
  }
}
```

### **3. Document Your Choices**
Add comments in config to explain:
```json
{
  "folder_configs": {
    "Licenses": {
      "description": "State and DEA licenses - required for credentialing",
      "fields": ["state_license_number", "dea_license_number"]
    }
  }
}
```

---

## ✅ **SUMMARY**

**Your Question:**
> "If I put folder config, provider has 100 folders, I only need to extract those configured folders, no default extraction needed, correct?"

**Answer:** ✅ **YES! EXACTLY CORRECT!**

**Configuration:**
```json
{
  "processing": {
    "skip_unknown_folders": true  ← This is the key!
  }
}
```

**Behavior:**
- ✅ Process ONLY configured folders
- ✅ Skip ALL other folders (no default)
- ✅ Massive time and cost savings
- ✅ Clean, focused results

**Example:**
- Provider has: 100 folders
- You configure: 3 folders
- System processes: 3 folders only ✅
- System skips: 97 folders ✅

**Performance:**
- 97% faster processing
- 97% cost reduction
- 100% focused on what you need

🎉 **Perfect for your use case!**
