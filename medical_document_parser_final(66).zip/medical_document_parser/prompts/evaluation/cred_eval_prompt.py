"""
Evaluation Prompts - LLM-as-Judge Field-Level Evaluation
=========================================================

Separate from extraction prompts (prompts/cred_prompt.py).
This module defines evaluation criteria for judging extraction quality.

Each field has:
  - expected_format: what the value should look like
  - validation_rules: specific checks to perform
  - scoring_criteria: how to assign scores
  - normalization_checks: format consistency rules

Scores: 1.0 (perfect), 0.75 (minor issue), 0.5 (format issue), 0.25 (major issue), 0.0 (wrong/missing)
"""


# =============================================================================
# SYSTEM PROMPT FOR LLM JUDGE
# =============================================================================

JUDGE_SYSTEM_PROMPT = """You are a medical document extraction quality evaluator.
Your job is to evaluate each extracted field value against the defined guidelines.

For each field, you will:
1. Check if the value matches the expected format
2. Check if the value is logically valid
3. Check for normalization issues
4. Assign a score between 0.0 and 1.0
5. Provide a brief reason for the score

Scoring scale:
  1.0  = Perfect extraction, correct format, no issues
  0.75 = Correct value but minor format issue (e.g., extra spaces, slight format variation)
  0.50 = Value found but wrong format (e.g., "New York" instead of "NY", wrong date format)
  0.25 = Partially correct or uncertain value
  0.0  = Wrong value, hallucinated, or missing when data exists

IMPORTANT:
- "NY" and "New York" are the SAME state but "NY" is the correct normalized format → score 0.50 for "New York"
- "USA" and "United States" are the SAME but need normalization → score 0.50
- Empty value when no data exists in document → score 1.0 (correct behavior)
- Empty value when data EXISTS in document → score 0.0 (missed extraction)
- Dates should be MM/DD/YYYY format

Respond ONLY in JSON format. No markdown, no explanation outside JSON."""


# =============================================================================
# FIELD EVALUATION GUIDELINES
# =============================================================================

FIELD_EVALUATION_GUIDELINES = {

    # =========================================================================
    # SINGLE-VALUE FIELDS
    # =========================================================================

    "first_name": {
        "expected_format": "Capitalized single word, no titles (Dr., Mr., Mrs.), no suffixes (Jr., III)",
        "validation_rules": [
            "Must be alphabetic characters only (hyphens allowed for compound names)",
            "First letter capitalized",
            "No titles: Dr., Mr., Mrs., Ms.",
            "No suffixes: Jr., Sr., III, MD",
            "No numbers"
        ],
        "normalization_checks": [
            "All lowercase → score 0.75 (minor format issue)",
            "Includes title (Dr. John) → score 0.50",
            "Full name instead of first name only → score 0.50"
        ]
    },

    "last_name": {
        "expected_format": "Capitalized word, may include hyphen for compound names",
        "validation_rules": [
            "Alphabetic characters and hyphens only",
            "First letter capitalized",
            "No titles or suffixes",
            "No commas (Last, First format = wrong)"
        ],
        "normalization_checks": [
            "All uppercase (SMITH) → score 0.75",
            "Includes suffix (Smith Jr.) → score 0.50",
            "Full name (John Smith) → score 0.50"
        ]
    },

    "email": {
        "expected_format": "valid@email.com format",
        "validation_rules": [
            "Must contain @ symbol",
            "Must have domain (text after @)",
            "Must have TLD (.com, .org, .edu, etc.)",
            "No spaces",
            "Lowercase preferred"
        ],
        "normalization_checks": [
            "Mixed case → score 0.75",
            "Missing TLD → score 0.25",
            "Not an email format → score 0.0"
        ]
    },

    "cell": {
        "expected_format": "Phone number in standard format",
        "validation_rules": [
            "Should contain 10 digits (US)",
            "Acceptable formats: (555) 123-4567, 555-123-4567, 5551234567",
            "May include country code (+1)",
            "No letters"
        ],
        "normalization_checks": [
            "Less than 10 digits → score 0.50",
            "Contains letters → score 0.25"
        ]
    },

    "birth_date": {
        "expected_format": "MM/DD/YYYY",
        "validation_rules": [
            "Must be valid date",
            "Must be in the past",
            "Person should be between 18-100 years old (medical provider)",
            "Format: MM/DD/YYYY"
        ],
        "normalization_checks": [
            "YYYY-MM-DD format → score 0.50 (wrong format, right value)",
            "DD/MM/YYYY → score 0.50",
            "Written out (January 1, 1990) → score 0.50",
            "Future date → score 0.0"
        ]
    },

    "birth_place": {
        "expected_format": "City, State or City, Country",
        "validation_rules": [
            "Should be a recognizable place name",
            "Not a full address"
        ],
        "normalization_checks": []
    },

    "birth_city": {
        "expected_format": "City name only",
        "validation_rules": [
            "Should be a recognizable city name",
            "No state or country included"
        ],
        "normalization_checks": [
            "Includes state (Houston, TX) → score 0.75",
            "Full address → score 0.50"
        ]
    },

    "birth_state_province": {
        "expected_format": "2-letter state abbreviation or full state/province name",
        "validation_rules": [
            "Valid US state, Canadian province, or international region",
            "2-letter abbreviation preferred for US states"
        ],
        "normalization_checks": [
            "Full name instead of abbreviation (Texas vs TX) → score 0.75 (acceptable but not normalized)",
            "Invalid state code → score 0.0"
        ]
    },

    "birth_country": {
        "expected_format": "Full country name",
        "validation_rules": [
            "Recognizable country name",
            "Full name preferred (United States, not US/USA)"
        ],
        "normalization_checks": [
            "Abbreviation (US, USA) → score 0.75",
            "ISO code (US) → score 0.50"
        ]
    },

    "citizenship": {
        "expected_format": "Full country name",
        "validation_rules": [
            "Recognizable country name",
            "Should match birth_country in most cases"
        ],
        "normalization_checks": []
    },

    "degree": {
        "expected_format": "Standard medical degree abbreviation or full name",
        "validation_rules": [
            "Common: MD, DO, DDS, DMD, PharmD, DPM, PhD, RN, NP",
            "Should be a recognized medical/healthcare degree"
        ],
        "normalization_checks": [
            "Full name (Doctor of Medicine) → score 0.75 (abbreviation preferred)",
            "Non-medical degree → score 0.50"
        ]
    },

    "gender": {
        "expected_format": "Male or Female",
        "validation_rules": [
            "Must be Male or Female",
            "Not abbreviated (M/F)"
        ],
        "normalization_checks": [
            "M or F → score 0.75 (should be full word)",
            "Other formats → score 0.50"
        ]
    },

    "ssn": {
        "expected_format": "XXX-XX-XXXX or last 4 digits",
        "validation_rules": [
            "9 digits if full SSN",
            "4 digits if last-4-only",
            "May be masked: ***-**-1234",
            "No letters"
        ],
        "normalization_checks": [
            "No dashes (123456789) → score 0.75",
            "Partial (less than 4 digits) → score 0.25"
        ]
    },

    # =========================================================================
    # MULTI-VALUE FIELDS
    # =========================================================================

    "state_licenses": {
        "expected_format": "Array of license objects",
        "validation_rules": [
            "Each item must have: license_number, license_state, license_issue_date, license_expiration_date, license_status",
            "license_state must be 2-letter abbreviation (NY not New York)",
            "Dates must be MM/DD/YYYY format",
            "No duplicate entries (same number + same state = duplicate)",
            "license_status should be: Active, Inactive, or Expired"
        ],
        "normalization_checks": [
            "Full state name instead of 2-letter → score 0.50 per affected item",
            "Wrong date format → score 0.50 per affected item",
            "Duplicate entries → score 0.25 for the duplicate"
        ]
    },

    "dea_licenses": {
        "expected_format": "Array of DEA objects",
        "validation_rules": [
            "Each item must have: dea_number, dea_state, dea_issue_date, dea_expiration_date",
            "DEA number format: 2 letters + 7 digits (e.g., AB1234563)",
            "dea_state must be 2-letter abbreviation",
            "Dates must be MM/DD/YYYY",
            "No duplicates"
        ],
        "normalization_checks": [
            "DEA number wrong format → score 0.25",
            "Full state name → score 0.50"
        ]
    },

    "cds_licenses": {
        "expected_format": "Array of CDS objects",
        "validation_rules": [
            "Each item must have: cds_number, cds_state, cds_issue_date, cds_expiration_date",
            "cds_state must be 2-letter abbreviation",
            "Dates must be MM/DD/YYYY"
        ],
        "normalization_checks": [
            "Full state name → score 0.50"
        ]
    },

    "board_certifications": {
        "expected_format": "Array of board certification objects",
        "validation_rules": [
            "Each item must have: board_name, board_specialty",
            "board_name should be FULL official name (American Board of Internal Medicine, not ABIM)",
            "board_specialty should be standard specialty name"
        ],
        "normalization_checks": [
            "Abbreviation instead of full name (ABIM) → score 0.50",
            "Non-standard specialty name → score 0.75"
        ]
    },

    "other_credentials": {
        "expected_format": "Array of credential objects",
        "validation_rules": [
            "Each item must have: credential_type, credential_number, credential_issue_date, credential_expiration_date",
            "credential_type should be standard abbreviation (BLS, ACLS, NPI)",
            "Dates must be MM/DD/YYYY"
        ],
        "normalization_checks": [
            "Full name instead of abbreviation → score 0.75"
        ]
    }
}


# =============================================================================
# JUDGE OUTPUT FORMAT
# =============================================================================

JUDGE_OUTPUT_FORMAT = """{
    "evaluation": {
        "<field_name>": {
            "score": 0.0-1.0,
            "issues": ["list of specific issues found"],
            "suggestion": "how to fix if score < 1.0"
        }
    },
    "summary": {
        "total_fields": 18,
        "avg_score": 0.85,
        "perfect_fields": 15,
        "issue_fields": 3,
        "critical_fields": 0
    }
}"""


# =============================================================================
# EVALUATION MODEL CONFIG
# =============================================================================

EVALUATION_CONFIG = {
    "model": "gpt-4o",
    "max_tokens": 4000,
    "temperature": 0.0,
    "_comment": "Use cheaper model for evaluation. GPT-4o is sufficient for format checking."
}
