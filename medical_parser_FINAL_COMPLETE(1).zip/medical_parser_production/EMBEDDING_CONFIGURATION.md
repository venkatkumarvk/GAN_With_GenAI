# AZURE OPENAI EMBEDDING CONFIGURATION

## ✅ **UPDATED - ALL EMBEDDING CONFIGS COMPLETE**

---

## 📋 **CURRENT CONFIGURATION**

### **Per-Doctype Embedding Settings:**

**1. CRED (Medical Credentials):**
```json
{
  "azure_openai_embedding": {
    "endpoint": "@azureKeyVault(OpenAIEndpoint)",
    "api_key": "@azureKeyVault(OpenAIKey)",
    "deployment_name": "text-embedding-ada-002",
    "model_name": "text-embedding-ada-002",
    "dimensions": 1536,
    "api_version": "2024-05-01-preview"
  }
}
```

**2. BUS (Business Documents):**
```json
{
  "azure_openai_embedding": {
    "endpoint": "@azureKeyVault(OpenAIEndpoint)",
    "api_key": "@azureKeyVault(OpenAIKey)",
    "deployment_name": "text-embedding-ada-002",
    "model_name": "text-embedding-ada-002",
    "dimensions": 1536,
    "api_version": "2024-05-01-preview"
  }
}
```

**3. CLAIM (Insurance Claims):**
```json
{
  "azure_openai_embedding": {
    "endpoint": "@azureKeyVault(OpenAIEndpoint)",
    "api_key": "@azureKeyVault(OpenAIKey)",
    "deployment_name": "text-embedding-3-small",
    "model_name": "text-embedding-3-small",
    "dimensions": 1536,
    "api_version": "2024-05-01-preview"
  }
}
```

---

## 🔧 **EMBEDDING MODELS REFERENCE**

### **Available Azure OpenAI Embedding Models:**

| Model | Dimensions | Max Tokens | Cost (per 1K tokens) | Use Case |
|-------|------------|------------|----------------------|----------|
| `text-embedding-ada-002` | 1536 | 8191 | $0.0001 | General purpose, cost-effective |
| `text-embedding-3-small` | 1536 | 8191 | $0.00002 | Latest, 5x cheaper, better quality |
| `text-embedding-3-large` | 3072 | 8191 | $0.00013 | Highest quality, larger dimensions |

---

## ⚙️ **CONFIGURATION PARAMETERS EXPLAINED**

### **Required Parameters:**

**1. endpoint** *(string)*
- Azure OpenAI resource endpoint
- Format: `https://YOUR-RESOURCE.openai.azure.com/`
- Can use Key Vault: `@azureKeyVault(OpenAIEndpoint)`

**2. api_key** *(string)*
- Azure OpenAI API key
- Should use Key Vault: `@azureKeyVault(OpenAIKey)`
- Never hardcode in config!

**3. deployment_name** *(string)*
- Name of your embedding deployment in Azure
- Example: `text-embedding-ada-002`, `my-embedding-deployment`
- Must match deployment name in Azure OpenAI Studio

**4. model_name** *(string)*
- Underlying model name
- Options: `text-embedding-ada-002`, `text-embedding-3-small`, `text-embedding-3-large`
- Used for compatibility and cost tracking

**5. dimensions** *(integer)* **← REQUIRED!**
- Vector dimensions for the model
- `text-embedding-ada-002`: 1536
- `text-embedding-3-small`: 1536
- `text-embedding-3-large`: 3072
- **Critical for AI Search index configuration!**

**6. api_version** *(string)* **← REQUIRED!**
- Azure OpenAI API version
- Recommended: `2024-05-01-preview`
- Must match supported versions for embeddings

---

## 🎯 **WHY DIMENSIONS MATTER**

### **AI Search Index Configuration:**

When creating AI Search index, vector field must match embedding dimensions:

```python
from azure.search.documents.indexes.models import (
    SearchField,
    SearchFieldDataType,
    VectorSearch,
    VectorSearchProfile
)

# Vector field MUST match embedding dimensions
SearchField(
    name="embedding",
    type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
    searchable=True,
    vector_search_dimensions=1536,  # ← MUST match embedding model!
    vector_search_profile_name="my-vector-config"
)
```

**If dimensions don't match:**
- ❌ Index creation fails
- ❌ Document upload fails
- ❌ Vector search doesn't work
- ❌ RAG pipeline breaks

---

## 📊 **MODEL COMPARISON**

### **text-embedding-ada-002:**

**Pros:**
- ✅ Proven, stable model
- ✅ Well-documented
- ✅ Good quality embeddings
- ✅ Wide compatibility

**Cons:**
- ❌ More expensive ($0.0001 per 1K tokens)
- ❌ Older generation

**Best for:** Production systems where stability is critical

---

### **text-embedding-3-small:**

**Pros:**
- ✅ 5x cheaper ($0.00002 per 1K tokens)
- ✅ Better quality than ada-002
- ✅ Same dimensions (1536) - easy migration
- ✅ Latest generation

**Cons:**
- ❌ Newer (less proven in production)

**Best for:** Cost-sensitive applications, new projects

---

### **text-embedding-3-large:**

**Pros:**
- ✅ Highest quality embeddings
- ✅ More dimensions (3072) = better semantic understanding
- ✅ Best for complex similarity tasks

**Cons:**
- ❌ More expensive ($0.00013 per 1K tokens)
- ❌ Requires larger index storage
- ❌ Slower search (more dimensions)

**Best for:** High-accuracy requirements, complex documents

---

## 🔄 **MIGRATION GUIDE**

### **From ada-002 to 3-small (Recommended):**

**Benefits:**
- 5x cost reduction
- Better quality
- Same dimensions (no index changes needed!)

**Steps:**

**1. Deploy text-embedding-3-small in Azure:**
```bash
# In Azure OpenAI Studio:
# 1. Go to Deployments
# 2. Create New Deployment
# 3. Select: text-embedding-3-small
# 4. Name: text-embedding-3-small
```

**2. Update config.json:**
```json
{
  "azure_openai_embedding": {
    "deployment_name": "text-embedding-3-small",
    "model_name": "text-embedding-3-small",
    "dimensions": 1536,  // Same as ada-002!
    "api_version": "2024-05-01-preview"
  }
}
```

**3. No index changes needed!**
- Same dimensions (1536)
- Existing index works
- Just reindex documents with new embeddings

---

### **From ada-002 to 3-large (Advanced):**

**Steps:**

**1. Deploy text-embedding-3-large**

**2. Update config.json:**
```json
{
  "azure_openai_embedding": {
    "deployment_name": "text-embedding-3-large",
    "model_name": "text-embedding-3-large",
    "dimensions": 3072,  // Different!
    "api_version": "2024-05-01-preview"
  }
}
```

**3. Update AI Search index:**
```python
# Recreate index with new dimensions
SearchField(
    name="embedding",
    vector_search_dimensions=3072  // Updated!
)
```

**4. Reindex all documents**

---

## 💡 **BEST PRACTICES**

### **1. Use Key Vault for Secrets:**

**❌ Bad:**
```json
{
  "api_key": "sk-actual-key-here"
}
```

**✅ Good:**
```json
{
  "api_key": "@azureKeyVault(OpenAIKey)"
}
```

### **2. Match Deployment Names:**

**In Azure OpenAI Studio:**
- Deployment name: `text-embedding-ada-002`

**In config.json:**
```json
{
  "deployment_name": "text-embedding-ada-002"  // Must match!
}
```

### **3. Verify Dimensions:**

```python
# Test embedding dimensions
from openai import AzureOpenAI

client = AzureOpenAI(
    azure_endpoint=endpoint,
    api_key=api_key,
    api_version=api_version
)

response = client.embeddings.create(
    input="test",
    model="text-embedding-ada-002"
)

dimensions = len(response.data[0].embedding)
print(f"Dimensions: {dimensions}")  # Should be 1536
```

### **4. Cost Optimization:**

**For high-volume processing:**
```json
{
  "claim": {
    "azure_openai_embedding": {
      "model_name": "text-embedding-3-small",  // 5x cheaper!
      "dimensions": 1536
    }
  }
}
```

---

## 🔍 **TROUBLESHOOTING**

### **Error: "Dimensions mismatch"**

**Problem:** Index dimensions don't match embedding dimensions

**Solution:**
```python
# Check embedding config
embedding_dims = config['azure_openai_embedding']['dimensions']

# Check index config
index_dims = index_field.vector_search_dimensions

# They must match!
assert embedding_dims == index_dims
```

---

### **Error: "Deployment not found"**

**Problem:** deployment_name doesn't exist in Azure

**Solution:**
1. Check Azure OpenAI Studio → Deployments
2. Verify deployment name exactly matches
3. Update config.json with correct name

---

### **Error: "Invalid API version"**

**Problem:** api_version not supported for embeddings

**Solution:**
```json
{
  "api_version": "2024-05-01-preview"  // Use this
}
```

Supported versions:
- `2024-05-01-preview` ✅ Recommended
- `2024-02-01` ✅
- `2023-12-01-preview` ✅

---

## 📊 **COST CALCULATION**

### **Example: 1000 Documents**

**Assumptions:**
- Average document: 3000 tokens
- Total tokens: 3,000,000

**With text-embedding-ada-002:**
```
Cost = 3,000,000 / 1000 * $0.0001
     = 3,000 * $0.0001
     = $0.30
```

**With text-embedding-3-small:**
```
Cost = 3,000,000 / 1000 * $0.00002
     = 3,000 * $0.00002
     = $0.06
```

**Savings: $0.24 (80% reduction!)**

---

## ✅ **VERIFICATION CHECKLIST**

### **Before Running:**

- [ ] All embedding configs have `dimensions`
- [ ] All embedding configs have `api_version`
- [ ] Deployment names match Azure OpenAI Studio
- [ ] API keys are in Key Vault
- [ ] Index dimensions match embedding dimensions

### **Test:**

```python
# Test embedding configuration
from openai import AzureOpenAI

client = AzureOpenAI(
    azure_endpoint=config['endpoint'],
    api_key=config['api_key'],
    api_version=config['api_version']
)

# Create test embedding
response = client.embeddings.create(
    input="test document",
    model=config['deployment_name']
)

embedding = response.data[0].embedding
print(f"✓ Embedding dimensions: {len(embedding)}")
print(f"✓ Expected dimensions: {config['dimensions']}")
print(f"✓ Match: {len(embedding) == config['dimensions']}")
```

---

## 🎯 **SUMMARY**

### **What Was Missing:**

**Before:**
```json
{
  "azure_openai_embedding": {
    "endpoint": "...",
    "api_key": "...",
    "deployment_name": "text-embedding-ada-002",
    "model_name": "text-embedding-ada-002"
    // ❌ Missing: dimensions
    // ❌ Missing: api_version
  }
}
```

**After:**
```json
{
  "azure_openai_embedding": {
    "endpoint": "@azureKeyVault(OpenAIEndpoint)",
    "api_key": "@azureKeyVault(OpenAIKey)",
    "deployment_name": "text-embedding-ada-002",
    "model_name": "text-embedding-ada-002",
    "dimensions": 1536,  // ✅ Added
    "api_version": "2024-05-01-preview"  // ✅ Added
  }
}
```

### **All Doctypes Updated:**

- ✅ cred: dimensions=1536, api_version=2024-05-01-preview
- ✅ bus: dimensions=1536, api_version=2024-05-01-preview
- ✅ claim: dimensions=1536, api_version=2024-05-01-preview

### **Ready For:**

- ✅ AI Search index creation
- ✅ Vector embedding generation
- ✅ RAG search operations
- ✅ Production deployment

**🎉 All embedding configurations are now complete!**
