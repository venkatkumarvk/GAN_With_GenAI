"""
Simple Main Entry Point - Easy to Understand

Usage:
    python main.py --doctype cred --apitype general --archive true
"""

import argparse
import json
import logging
import sys
from datetime import datetime
from pathlib import Path


def setup_logging(doctype):
    """Setup simple logging"""
    # Create logs folder
    Path('logs').mkdir(exist_ok=True)
    
    # Generate log filename
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = f'logs/{doctype}_{timestamp}.log'
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    return logging.getLogger(__name__)


def load_config(config_path='config.json'):
    """Load configuration file"""
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"ERROR: Config file not found: {config_path}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"ERROR: Invalid JSON: {e}")
        sys.exit(1)


def resolve_keyvault(config, logger):
    """Resolve Key Vault secrets"""
    import re
    from keyvault_manager import KeyVaultManager
    
    # Initialize Key Vault
    logger.info("Connecting to Key Vault...")
    kv_manager = KeyVaultManager(config['azure_keyvault'])
    
    # Find and replace all @azureKeyVault(...) references
    def resolve_dict(d):
        for key, value in d.items():
            if isinstance(value, dict):
                resolve_dict(value)
            elif isinstance(value, str) and value.startswith('@azureKeyVault('):
                # Extract secret name
                match = re.match(r'@azureKeyVault\(([^)]+)\)', value)
                if match:
                    secret_name = match.group(1)
                    logger.info(f"Resolving secret: {secret_name}")
                    d[key] = kv_manager.get_secret(secret_name)
    
    resolve_dict(config)
    logger.info("✓ All Key Vault secrets resolved")
    return config


def load_prompt_module(module_name, logger):
    """Load prompt module dynamically"""
    import importlib
    
    logger.info(f"Loading prompt module: {module_name}")
    try:
        module = importlib.import_module(module_name)
        logger.info("✓ Prompt module loaded")
        return module
    except ImportError as e:
        logger.error(f"Failed to load prompt module: {e}")
        raise


def main():
    """Main entry point"""
    
    # =========================================================================
    # 1. PARSE COMMAND LINE ARGUMENTS
    # =========================================================================
    
    parser = argparse.ArgumentParser(
        description='Medical Document Parser - Simple Version',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python main.py --doctype cred --apitype general --archive true
    python main.py --doctype bus --apitype batch --archive false
    python main.py --doctype claim --apitype general
        """
    )
    
    parser.add_argument(
        '--doctype',
        type=str,
        required=True,
        help='Document type: cred, bus, claim'
    )
    
    parser.add_argument(
        '--apitype',
        type=str,
        required=True,
        choices=['general', 'batch'],
        help='API type: general (real-time) or batch (async)'
    )
    
    parser.add_argument(
        '--archive',
        type=str,
        default='true',
        choices=['true', 'false'],
        help='Enable archiving (default: true)'
    )
    
    args = parser.parse_args()
    
    # =========================================================================
    # 2. SETUP LOGGING
    # =========================================================================
    
    logger = setup_logging(args.doctype)
    
    logger.info("=" * 80)
    logger.info("MEDICAL DOCUMENT PARSER - SIMPLE VERSION")
    logger.info("=" * 80)
    logger.info(f"Document Type: {args.doctype}")
    logger.info(f"API Type: {args.apitype}")
    logger.info(f"Archive: {args.archive}")
    logger.info("=" * 80)
    
    try:
        # =====================================================================
        # 3. LOAD CONFIGURATION
        # =====================================================================
        
        logger.info("Loading configuration...")
        config = load_config('config.json')
        
        # Check if doctype exists
        if args.doctype not in config['documenttypes']:
            available = ', '.join(config['documenttypes'].keys())
            raise ValueError(
                f"Doctype '{args.doctype}' not found. Available: {available}"
            )
        
        doctype_config = config['documenttypes'][args.doctype]
        logger.info(f"✓ Loaded config for: {doctype_config['description']}")
        
        # =====================================================================
        # 4. RESOLVE KEY VAULT SECRETS
        # =====================================================================
        
        config = resolve_keyvault(config, logger)
        
        # =====================================================================
        # 5. GET OPENAI CONFIGURATION
        # =====================================================================
        
        if args.apitype not in doctype_config['azure_openai']:
            raise ValueError(f"API type '{args.apitype}' not configured")
        
        openai_config = doctype_config['azure_openai'][args.apitype]
        logger.info(f"✓ Using model: {openai_config['deployment_name']}")
        
        # =====================================================================
        # 6. LOAD PROMPT MODULE
        # =====================================================================
        
        prompt_module_name = doctype_config['prompt_module']
        prompt_module = load_prompt_module(prompt_module_name, logger)
        
        # Log field count if available
        if hasattr(prompt_module, 'FIELD_LIBRARY'):
            field_count = len(prompt_module.FIELD_LIBRARY)
            logger.info(f"✓ Loaded {field_count} fields from prompt module")
        
        # =====================================================================
        # 7. GET BATCH SIZE FROM CONFIG
        # =====================================================================
        
        batch_size = config['processing'].get('batch_size', 10)
        logger.info(f"✓ Batch size: {batch_size}")
        
        # =====================================================================
        # 8. INITIALIZE DOCUMENT PROCESSOR
        # =====================================================================
        
        logger.info("Initializing document processor...")
        from process_doc import SimpleDocumentProcessor
        
        processor = SimpleDocumentProcessor(
            config=config,
            doctype=args.doctype,
            doctype_config=doctype_config,
            openai_config=openai_config,
            prompt_module=prompt_module,
            apitype=args.apitype
        )
        
        logger.info("✓ Document processor initialized")
        
        # =====================================================================
        # 9. PROCESS DOCUMENTS
        # =====================================================================
        
        logger.info("=" * 80)
        logger.info("PROCESSING DOCUMENTS")
        logger.info("=" * 80)
        
        results = processor.process_all_documents()
        
        # =====================================================================
        # 10. ARCHIVE (if enabled)
        # =====================================================================
        
        if args.archive.lower() == 'true' and config['archive'].get('enabled', True):
            logger.info("=" * 80)
            logger.info("ARCHIVING RESULTS")
            logger.info("=" * 80)
            
            from archive_manager import ArchiveManager
            
            archive_manager = ArchiveManager(config, args.doctype)
            archive_manager.archive_results(results)
            
            logger.info("✓ Archiving complete")
        
        # =====================================================================
        # 11. PRINT SUMMARY
        # =====================================================================
        
        logger.info("=" * 80)
        logger.info("PROCESSING COMPLETE")
        logger.info("=" * 80)
        logger.info(f"Total documents: {results['total_docs']}")
        logger.info(f"High confidence: {results['high_confidence']}")
        logger.info(f"Low confidence: {results['low_confidence']}")
        logger.info(f"Total cost: ${results['total_cost']:.4f}")
        if results['total_docs'] > 0:
            logger.info(f"Avg cost per doc: ${results['avg_cost_per_doc']:.4f}")
        logger.info("=" * 80)
        
        return 0
        
    except Exception as e:
        logger.error("=" * 80)
        logger.error(f"ERROR: {str(e)}")
        logger.error("=" * 80)
        logger.exception("Full error details:")
        return 1


if __name__ == "__main__":
    sys.exit(main())
