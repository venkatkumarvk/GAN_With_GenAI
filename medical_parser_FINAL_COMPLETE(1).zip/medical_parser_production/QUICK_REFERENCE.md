# QUICK REFERENCE GUIDE

## 🚀 **Medical Document Parser - Production v3.0**

**Updated naming:** `vendortype` → `doctype`, `vendortypes` → `documenttypes`

---

## 📋 **CLI USAGE**

### **Basic Command:**
```bash
python main.py --doctype DOCTYPE --apitype APITYPE --archive ARCHIVE
```

### **Arguments:**

| Argument | Required | Values | Default | Description |
|----------|----------|--------|---------|-------------|
| `--doctype` | ✅ Yes | cred, bus, claim | - | Document type to process |
| `--apitype` | ✅ Yes | general, batch | - | OpenAI API mode |
| `--archive` | ❌ No | true, false | true | Enable archiving |

### **Examples:**

```bash
# Medical credentials (real-time)
python main.py --doctype cred --apitype general --archive true

# Business documents (batch API - 50% cheaper)
python main.py --doctype bus --apitype batch --archive false

# Insurance claims
python main.py --doctype claim --apitype general
```

---

## ⚙️ **CONFIGURATION**

### **config.json Structure:**

```json
{
  "documenttypes": {
    "cred": { /* Medical credentials */ },
    "bus": { /* Business documents */ },
    "claim": { /* Insurance claims */ }
  },
  
  "processing": {
    "batch_size": 10  // ← Change batch size here!
  }
}
```

### **Key Sections:**

| Section | Purpose |
|---------|---------|
| `azure_keyvault` | Key Vault URL |
| `azure_blob` | Blob storage containers |
| `azure_document_intelligence` | Shared OCR service |
| `documenttypes.{doctype}` | Per-doctype configuration |
| `extraction` | Confidence threshold, chunking |
| `rag` | RAG search settings |
| `archive` | Archive settings |
| `processing` | **batch_size** and other settings |

---

## 🔑 **KEY VAULT SECRETS**

**Required secrets in Azure Key Vault:**

| Secret Name | Purpose |
|-------------|---------|
| `BlobConnectionString` | Azure Blob Storage |
| `DocIntEndpoint` | Document Intelligence endpoint |
| `DocIntKey` | Document Intelligence key |
| `OpenAIEndpoint` | Azure OpenAI endpoint |
| `OpenAIKey` | Azure OpenAI key |
| `SearchEndpoint` | AI Search endpoint |
| `SearchKey` | AI Search key |
| `OpenAIBatchEndpoint` | (Optional) Batch API endpoint |
| `OpenAIBatchKey` | (Optional) Batch API key |

**Syntax in config.json:**
```json
"api_key": "@azureKeyVault(OpenAIKey)"
```

---

## 📁 **FILE STRUCTURE**

```
medical_parser_production/
├── main.py                  # CLI interface
├── config.json              # Main configuration
├── keyvault_manager.py      # Key Vault integration
├── document_processor.py    # Core processor (template)
├── archive_manager.py       # Archive management
├── helper.py                # Azure service managers
├── text_rag.py              # TEXT RAG module
├── multimodal_rag.py        # MULTIMODAL RAG module
├── semantic_chunker.py      # Adaptive chunking
├── costtracking.py          # Cost tracking
├── requirements.txt         # Dependencies
└── prompts/
    ├── cred_prompt.py       # Medical credentials
    ├── bus_prompt.py        # Business documents
    └── claim_prompt.py      # Insurance claims
```

---

## 🎯 **PER-DOCTYPE CONFIGURATION**

Each doctype has:

```json
{
  "cred": {
    "description": "Medical Credentials",
    "prompt_module": "prompts.cred_prompt",
    
    "azure_openai": {
      "general": { /* Real-time API */ },
      "batch": { /* Async batch API */ }
    },
    
    "azure_openai_embedding": { /* Embeddings */ },
    
    "azure_ai_search": {
      "index_name": "cred-universal-index",
      "auto_delete_days": 7
    },
    
    "folder_configs": {
      "GEN & HR": { "fields": [...] },
      "Licenses": { "fields": [...] }
    }
  }
}
```

---

## 📊 **OUTPUT STRUCTURE**

```
outputcontainer/
├── highconfidence/
│   └── {provider}/
│       ├── ProcessedCSVResult/{provider}_timestamp.csv
│       ├── ProcessedJSONResult/{provider}_timestamp.json
│       └── ProcessedEstimateCostTracking/{provider}_timestamp.json
│
└── lowconfidence/
    └── {provider}/
        ├── ProcessedCSVResult/{provider}_timestamp.csv
        ├── ProcessedJSONResult/{provider}_timestamp.json
        └── ProcessedEstimateCostTracking/{provider}_timestamp.json

archivecontainer/
├── processed/{provider}/{doctype}_{timestamp}.zip
└── unprocessed/{provider}/{doctype}_{timestamp}.zip
```

---

## ⚡ **QUICK SETTINGS**

### **Change Batch Size:**
```json
// config.json
{
  "processing": {
    "batch_size": 20  // Change from 10 to 20
  }
}
```

### **Change Confidence Threshold:**
```json
{
  "extraction": {
    "confidence_threshold": 0.75  // Change from 0.70 to 0.75
  }
}
```

### **Change Chunking Thresholds:**
```json
{
  "extraction": {
    "small_doc_threshold": 20000,   // More full-text docs
    "large_doc_chunk_size": 15000   // Larger chunks
  }
}
```

### **Change Index Retention:**
```json
{
  "documenttypes": {
    "cred": {
      "azure_ai_search": {
        "auto_delete_days": 14  // Keep for 14 days instead of 7
      }
    }
  }
}
```

---

## 🔄 **WORKFLOW SUMMARY**

```
1. CLI → Parse --doctype, --apitype, --archive
2. Load config.json
3. Resolve Key Vault secrets
4. Load prompt module (prompts/{doctype}_prompt.py)
5. Initialize Azure services
6. Process documents in batches (batch_size)
   ├─ OCR (Document Intelligence)
   ├─ Adaptive Chunking
   ├─ RAG Search (AI Search)
   ├─ GPT Extraction (OpenAI)
   └─ Confidence Routing (≥0.70 vs <0.70)
7. Archive (if enabled)
8. Summary report
```

---

## 💡 **COMMON TASKS**

### **Add New Doctype:**

1. Add to config.json:
```json
{
  "documenttypes": {
    "mynewtype": {
      "description": "My new document type",
      "prompt_module": "prompts.mynewtype_prompt",
      "azure_openai": { /* ... */ },
      "folder_configs": { /* ... */ }
    }
  }
}
```

2. Create `prompts/mynewtype_prompt.py`:
```python
FIELD_DEFINITIONS = { /* ... */ }
SYSTEM_PROMPT = """ ... """
```

3. Run:
```bash
python main.py --doctype mynewtype --apitype general
```

### **Change Model:**

```json
{
  "documenttypes": {
    "cred": {
      "azure_openai": {
        "general": {
          "deployment_name": "gpt-4o-mini",  // Change model
          "model_name": "gpt-4o-mini"
        }
      }
    }
  }
}
```

---

## 📚 **DOCUMENTATION**

- **README.md** - Quick start guide
- **COMPLETE_WORKFLOW_AND_FEATURES.md** - Full documentation (30+ KB)
- **QUICK_REFERENCE.md** - This file
- **config.json** - Configuration with comments

---

## ✅ **CHECKLIST**

**Before Running:**

- [ ] Installed dependencies: `pip install -r requirements.txt`
- [ ] Configured Key Vault URL in config.json
- [ ] Added all secrets to Azure Key Vault
- [ ] Created/customized prompt files for each doctype
- [ ] Set batch_size in config.json
- [ ] Reviewed confidence_threshold (default: 0.70)

**Run:**

```bash
python main.py --doctype cred --apitype general --archive true
```

**Verify:**

- [ ] Check logs/ folder for processing logs
- [ ] Check outputcontainer/ for results
- [ ] Check archivecontainer/ for archives (if enabled)
- [ ] Review cost tracking files

---

## 🎯 **KEY CHANGES FROM v2.0**

1. ✅ **Naming:** `vendortype` → `doctype`, `vendortypes` → `documenttypes`
2. ✅ **CLI:** `--vendortype` → `--doctype`
3. ✅ **Config:** All references updated
4. ✅ **Archive format:** `{vendortype}_` → `{doctype}_`
5. ✅ **Log format:** `{vendortype}_` → `{doctype}_`

---

## 📞 **TROUBLESHOOTING**

**Error: Doctype not found**
→ Check config.json has `documenttypes.{your_doctype}` section

**Error: Key Vault secret not found**
→ Verify secret exists in Key Vault with exact name

**Error: Module not found: prompts.xxx**
→ Create `prompts/{doctype}_prompt.py` file

**Low accuracy**
→ Adjust `confidence_threshold` or `chunk_size` in config.json

**Out of memory**
→ Reduce `batch_size` in config.json

---

## 🎉 **READY TO GO!**

```bash
# Simple start command:
python main.py --doctype cred --apitype general --archive true

# That's it! ✅
```
