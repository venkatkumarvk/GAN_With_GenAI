"""
Enhanced Main Script - Folder-Level Extraction
Based on working code + folder-level features
"""

import json
import logging
from datetime import datetime
from typing import Dict, List
from collections import Counter
import pandas as pd

from logging_config import setup_logging
from helper import BlobManager, OpenAIManager
from documentintelligence_ocr import OCRManager
from production_index_manager import ProductionIndexManager, ProductionChunker
from prompt_builder import PromptBuilder
from unified_rag import unified_rag_extraction
from costtracking import CostTracker


def load_config(config_path: str = "config.json") -> Dict:
    """Load configuration from JSON file"""
    with open(config_path, 'r') as f:
        return json.load(f)


def detect_folder_type(folder_name: str, config: Dict) -> str:
    """Detect folder type from name"""
    import re
    
    # Strip number prefix like "1. ", "2. " and any extra spaces
    clean_name = re.sub(r'^\d+\.\s*', '', folder_name).strip()
    
    print(f"DEBUG: folder_name='{folder_name}' → clean_name='{clean_name}'")
    print(f"DEBUG: Available configs: {list(config['folder_configs'].keys())}")
    
    # Try exact match (case-insensitive)
    for folder_type in config['folder_configs'].keys():
        if clean_name.lower() == folder_type.lower():
            print(f"DEBUG: ✓ Exact match found: '{folder_type}'")
            return folder_type
    
    # Try partial match
    for folder_type in config['folder_configs'].keys():
        if folder_type.lower() in clean_name.lower():
            print(f"DEBUG: ✓ Partial match found: '{folder_type}'")
            return folder_type
    
    print(f"DEBUG: ✗ No match found, returning 'default'")
    return 'default'


def get_folder_config(folder_type: str, config: Dict) -> Dict:
    """Get configuration for specific folder type"""
    if folder_type in config['folder_configs']:
        return config['folder_configs'][folder_type]
    else:
        return config['default_config']


def save_provider_folder_results(
    blob_manager: BlobManager,
    output_container: str,
    provider: str,
    folder: str,
    results: List[Dict],
    folder_config: Dict,
    config: Dict,
    logger: logging.Logger
):
    """Save results for a provider+folder immediately"""
    if not results:
        logger.warning(f"No results to save for {provider}/{folder}")
        return
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Calculate confidence
    all_confidences = []
    for result in results:
        for field_data in result['extracted_fields'].values():
            if isinstance(field_data, dict) and 'confidence' in field_data:
                all_confidences.append(field_data['confidence'])
    
    min_confidence = min(all_confidences) if all_confidences else 0.0
    threshold = folder_config.get('min_confidence', config['extraction']['confidence_threshold'])
    category = "highconfidence" if min_confidence >= threshold else "lowconfidence"
    
    # Confidence summary
    confidence_summary = {"high": 0, "medium": 0, "low": 0}
    for result in results:
        for field_data in result['extracted_fields'].values():
            if isinstance(field_data, dict) and 'confidence' in field_data:
                conf = field_data['confidence']
                if conf >= 0.70:
                    confidence_summary["high"] += 1
                elif conf >= 0.40:
                    confidence_summary["medium"] += 1
                else:
                    confidence_summary["low"] += 1
    
    # Prepare output data
    output_data = {
        "provider": provider,
        "folder": folder,
        "folder_type": folder_config.get('description', 'Unknown'),
        "timestamp": timestamp,
        "total_documents": len(results),
        "min_confidence": round(min_confidence, 2),
        "category": category,
        "confidence_summary": confidence_summary,
        "results": results
    }
    
    # Get fields from config
    fields = folder_config.get('fields', [])
    
    # Collect field values
    field_values = {field: [] for field in fields}
    field_confidences = {field: [] for field in fields}
    
    for result in results:
        for field in fields:
            if field in result['extracted_fields']:
                field_data = result['extracted_fields'][field]
                if isinstance(field_data, dict):
                    value = field_data.get('value', config['extraction']['na_value'])
                    confidence = field_data.get('confidence', 0.0)
                else:
                    value = field_data
                    confidence = 0.0
                field_values[field].append(value)
                field_confidences[field].append(confidence)
    
    # Calculate best values
    best_values = {}
    for field, values in field_values.items():
        if values:
            freq = Counter([v for v in values if v != config['extraction']['na_value']])
            if freq:
                best_value = freq.most_common(1)[0][0]
                value_confidences = [field_confidences[field][i] for i, v in enumerate(values) if v == best_value]
                avg_confidence = sum(value_confidences) / len(value_confidences) if value_confidences else 0.0
            else:
                best_value = config['extraction']['na_value']
                avg_confidence = 0.0
        else:
            best_value = config['extraction']['na_value']
            avg_confidence = 0.0
        
        # Status
        if avg_confidence >= 0.70:
            conf_status = "high"
        elif avg_confidence >= 0.40:
            conf_status = "medium"
        else:
            conf_status = "low"
        
        best_values[field] = {
            "value": best_value,
            "confidence": round(avg_confidence, 2),
            "status": conf_status
        }
    
    output_data["best_values"] = best_values
    
    # Output folder structure: highconfidence/Provider1/
    base_folder = f"{category}/{provider}"
    
    # 1. Save JSON
    json_path = f"{base_folder}/processedjsonresult/{provider}_{folder}_{timestamp}.json"
    blob_manager.upload_blob(
        output_container,
        json_path,
        json.dumps(output_data, indent=2),
        content_type="application/json"
    )
    logger.info(f"✅ Saved JSON: {json_path}")
    
    # 2. Save CSV
    csv_rows = []
    for field, field_info in best_values.items():
        csv_rows.append({
            "Provider": provider,
            "Folder": folder,
            "Field": field,
            "Value": field_info["value"],
            "Confidence": field_info["confidence"],
            "Status": field_info["status"]
        })
    
    csv_path = f"{base_folder}/processedcsvresult/{provider}_{folder}_{timestamp}.csv"
    df = pd.DataFrame(csv_rows)
    csv_content = df.to_csv(index=False)
    blob_manager.upload_blob(
        output_container,
        csv_path,
        csv_content,
        content_type="text/csv"
    )
    logger.info(f"✅ Saved CSV: {csv_path}")
    
    # 3. Save cost estimation
    total_fields = len(best_values)
    ocr_cost = len(results) * 0.01
    extraction_cost = len(results) * 0.02
    total_cost = ocr_cost + extraction_cost
    
    cost_data = {
        "provider": provider,
        "folder": folder,
        "timestamp": timestamp,
        "total_documents": len(results),
        "total_fields": total_fields,
        "confidence_breakdown": confidence_summary,
        "estimated_costs": {
            "ocr_cost_usd": round(ocr_cost, 4),
            "extraction_cost_usd": round(extraction_cost, 4),
            "total_cost_usd": round(total_cost, 4),
            "cost_per_document": round(total_cost / len(results), 4) if results else 0
        }
    }
    
    cost_path = f"{base_folder}/estimationcost/{provider}_{folder}_{timestamp}_cost.json"
    blob_manager.upload_blob(
        output_container,
        cost_path,
        json.dumps(cost_data, indent=2),
        content_type="application/json"
    )
    logger.info(f"✅ Saved Cost: {cost_path}")
    
    return json_path, csv_path, cost_path


def main():
    """Main execution function"""
    
    # Setup logging
    logger = setup_logging()
    logger.info("Starting Medical Credentials Extraction System - Enhanced Version")
    
    # Load configuration
    logger.info("Loading configuration...")
    config = load_config()
    
    # Initialize managers
    logger.info("Initializing Azure managers...")
    blob_manager = BlobManager(config['azure_blob']['connection_string'])
    ocr_manager = OCRManager(
        config['azure_document_intelligence']['endpoint'],
        config['azure_document_intelligence']['key']
    )
    openai_manager = OpenAIManager(
        config['azure_openai_gpt']['endpoint'],
        config['azure_openai_gpt']['api_key'],
        config['azure_openai_gpt']['api_version'],
        config['azure_openai_gpt']['deployment_name'],
        config['azure_openai_embedding']['deployment_name']
    )
    
    # Initialize production index manager
    logger.info("Initializing production index manager...")
    index_manager = ProductionIndexManager(
        search_endpoint=config['azure_search']['endpoint'],
        search_api_key=config['azure_search']['api_key'],
        index_name=config['azure_search']['universal_index_name'],
        auto_delete_days=config['azure_search']['auto_delete_days'],
        enable_auto_cleanup=config['azure_search']['enable_auto_cleanup']
    )
    
    # Create universal index
    logger.info("Creating/verifying universal index...")
    index_manager.create_universal_index(
        embedding_dimension=config['azure_openai_embedding']['dimension']
    )
    
    # Run auto-cleanup
    if config['azure_search']['enable_auto_cleanup']:
        logger.info("Running auto-cleanup...")
        deleted_count = index_manager.cleanup_old_data(
            days=config['azure_search']['auto_delete_days']
        )
        logger.info(f"Auto-cleanup complete: {deleted_count} documents deleted")
    
    # Initialize cost tracker
    cost_tracker = CostTracker(
        ocr_per_page=config['costs']['ocr_per_page'],
        embedding_per_1k=config['costs']['embedding_per_1k_tokens'],
        gpt4o_input_per_1k=config['costs']['gpt4o_input_per_1k_tokens'],
        gpt4o_output_per_1k=config['costs']['gpt4o_output_per_1k_tokens']
    )
    
    # List all blobs
    input_container = config['azure_blob']['inputcontainer']
    blobs = blob_manager.list_blobs(input_container)
    
    # Organize by provider and folder
    structure = {}  # {provider: {folder: [blobs]}}
    for blob in blobs:
        parts = blob.split('/')
        if len(parts) >= 2:
            provider = parts[0]
            folder = parts[1]
            if provider not in structure:
                structure[provider] = {}
            if folder not in structure[provider]:
                structure[provider][folder] = []
            structure[provider][folder].append(blob)
    
    logger.info(f"Found {len(structure)} providers")
    
    # Process each provider
    for provider_idx, (provider, folders) in enumerate(sorted(structure.items()), 1):
        logger.info("=" * 80)
        logger.info(f"Processing Provider {provider_idx}/{len(structure)}: {provider}")
        logger.info("=" * 80)
        logger.info(f"Found {len(folders)} folders")
        
        # Process each folder
        for folder_idx, (folder, folder_docs) in enumerate(sorted(folders.items()), 1):
            logger.info("-" * 80)
            logger.info(f"Processing Folder {folder_idx}/{len(folders)}: {folder}")
            
            # Detect folder type and get config
            folder_type = detect_folder_type(folder, config)
            
            # Skip unknown folders if configured
            if folder_type == 'default' and config['processing'].get('skip_unknown_folders', False):
                logger.warning(f"⚠️  SKIPPING folder '{folder}' - not in folder_configs")
                logger.warning(f"   To process this folder, add it to config.json folder_configs")
                continue
            
            folder_config = get_folder_config(folder_type, config)
            
            logger.info(f"Folder type: {folder_type}")
            logger.info(f"Extracting {len(folder_config['fields'])} fields")
            
            # Initialize prompt builder for this folder
            prompt_builder = PromptBuilder(
                fields=folder_config['fields'],
                mode=config['rag']['mode']
            )
            
            # Process documents in this folder
            folder_results = []
            
            for doc_idx, blob_name in enumerate(folder_docs, 1):
                logger.info(f"[{doc_idx}/{len(folder_docs)}] {blob_name.split('/')[-1]}")
                
                try:
                    # Download
                    doc_bytes = blob_manager.download_blob(input_container, blob_name)
                    if not doc_bytes:
                        logger.warning(f"  Skipping: download failed")
                        continue
                    
                    # OCR extraction
                    logger.info("  Extracting text with OCR...")
                    document_text = ocr_manager.extract_text(doc_bytes)
                    cost_tracker.add_ocr_pages(1)
                    
                    # Check text length
                    if len(document_text.strip()) < config['extraction']['min_text_length']:
                        logger.warning(f"  Skipping: text too short ({len(document_text)} chars)")
                        continue
                    
                    # Handle context length with chunker
                    chunker = ProductionChunker(
                        chunk_size=config['rag']['chunk_size'],
                        chunk_overlap=config['rag']['chunk_overlap'],
                        max_chunks=config['rag']['max_chunks_per_doc']
                    )
                    
                    # Process text - handles long documents properly
                    processed_text = chunker.handle_document(document_text)
                    
                    # Generate embedding from processed text
                    logger.info("  Generating embedding...")
                    embedding = openai_manager.get_embedding(processed_text[:2000])
                    if not embedding:
                        logger.warning(f"  Skipping: embedding failed")
                        continue
                    logger.info(f"  ✓ Embedding generated: {len(embedding)} dimensions")
                    cost_tracker.add_embedding_tokens(len(processed_text[:2000].split()))
                    
                    # Upload to index
                    doc_id = f"{provider}_{folder}_{blob_name.split('/')[-1]}"
                    doc_id = doc_id.replace(" ", "_").replace("&", "and")
                    
                    index_manager.upload_document(
                        doc_id=doc_id,
                        content=processed_text,
                        content_vector=embedding,
                        provider=provider,
                        provider_id=f"{provider}_{folder}_{datetime.now().strftime('%Y%m%d')}",
                        document_name=blob_name.split('/')[-1]
                    )
                    
                    # RAG extraction
                    logger.info("  Extracting fields with RAG...")
                    extraction_prompt = prompt_builder.build_extraction_prompt()
                    
                    extracted_data = unified_rag_extraction(
                        openai_manager=openai_manager,
                        search_manager=index_manager,
                        index_name=config['azure_search']['universal_index_name'],
                        provider=provider,
                        document_text=processed_text,
                        prompt=extraction_prompt,
                        top_k=config['rag']['top_k'],
                        mode=config['rag']['mode']
                    )
                    
                    cost_tracker.add_gpt4o_tokens(
                        input_tokens=len(extraction_prompt.split()) * 1.3,
                        output_tokens=500
                    )
                    
                    if extracted_data:
                        folder_results.append({
                            "document_name": blob_name.split('/')[-1],
                            "extracted_fields": extracted_data
                        })
                        logger.info(f"  ✓ Successfully extracted")
                    else:
                        logger.warning(f"  ✗ Extraction failed")
                        
                except Exception as e:
                    logger.error(f"  Error: {e}", exc_info=True)
                    continue
            
            # Save folder results immediately
            if folder_results:
                save_provider_folder_results(
                    blob_manager=blob_manager,
                    output_container=config['azure_blob']['outputcontainer'],
                    provider=provider,
                    folder=folder,
                    results=folder_results,
                    folder_config=folder_config,
                    config=config,
                    logger=logger
                )
    
    # Save cost summary
    logger.info("Saving cost summary...")
    cost_summary = cost_tracker.get_summary()
    cost_summary['total_providers'] = len(structure)
    cost_summary['total_documents'] = len(blobs)
    
    cost_path = f"cost_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    blob_manager.upload_blob(
        config['azure_blob']['outputcontainer'],
        cost_path,
        json.dumps(cost_summary, indent=2),
        content_type="application/json"
    )
    
    # Final summary
    logger.info("=" * 80)
    logger.info("EXTRACTION COMPLETE")
    logger.info("=" * 80)
    logger.info(f"Total providers processed: {len(structure)}")
    logger.info(f"Total documents processed: {len(blobs)}")
    cost_tracker.log_summary()
    logger.info("=" * 80)


if __name__ == "__main__":
    main()
