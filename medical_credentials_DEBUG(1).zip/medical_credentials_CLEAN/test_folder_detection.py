"""
Test Folder Detection Logic
"""

import json
import re

def detect_folder_type(folder_name: str, config: dict) -> str:
    """Detect folder type from name"""
    
    # Strip number prefix like "1. ", "2. "
    clean_name = re.sub(r'^\d+\.\s*', '', folder_name)
    
    print(f"Testing: '{folder_name}'")
    print(f"  → Clean name: '{clean_name}'")
    print(f"  → Available configs: {list(config['folder_configs'].keys())}")
    
    # Try exact match (case-insensitive)
    for folder_type in config['folder_configs'].keys():
        print(f"  → Checking exact match: '{clean_name.lower()}' == '{folder_type.lower()}' ?")
        if clean_name.lower() == folder_type.lower():
            print(f"  ✓ EXACT MATCH: '{folder_type}'")
            return folder_type
    
    # Try partial match
    for folder_type in config['folder_configs'].keys():
        print(f"  → Checking partial match: '{folder_type.lower()}' in '{clean_name.lower()}' ?")
        if folder_type.lower() in clean_name.lower():
            print(f"  ✓ PARTIAL MATCH: '{folder_type}'")
            return folder_type
    
    print(f"  ✗ NO MATCH - returning 'default'")
    return 'default'


# Load config
with open('config.json', 'r') as f:
    config = json.load(f)

print("="*70)
print("FOLDER DETECTION TEST")
print("="*70)

# Test cases
test_folders = [
    "1. GEN & HR",
    "2. ED & TRAIN",
    "GEN & HR",
    "ED & TRAIN",
    "3. REFERENCES",
    "OTHER FOLDER"
]

for folder in test_folders:
    print()
    result = detect_folder_type(folder, config)
    print(f"  → Result: '{result}'")
    print()

print("="*70)
