"""
Azure AI Evaluation SDK Wrapper - Groundedness, Relevance, Retrieval.
Uses azure-ai-evaluation package. Works with GPT-4o (not GPT-5).
All scores normalized to 0.0 - 1.0.

pip install azure-ai-evaluation
"""

import json
import logging
from typing import Dict, Any
from evaluation.metrics.base_metric import BaseMetric

logger = logging.getLogger(__name__)


class AzureAIEvalMetric(BaseMetric):
    """
    Azure AI Evaluation SDK wrapper.
    Uses shared azure_openai config from evaluation section.
    """
    
    def __init__(self, config: dict = None, openai_config: dict = None):
        self.evaluators = {}
        self.enabled_evaluators = []
        self.available = False
        
        if not config or not config.get('enabled'):
            return
        
        try:
            from azure.ai.evaluation import (
                GroundednessEvaluator,
                RelevanceEvaluator,
                RetrievalEvaluator
            )
            
            # Build model_config from shared azure_openai
            model_config = {}
            if openai_config:
                model_config = {
                    "azure_endpoint": openai_config.get('endpoint', ''),
                    "api_key": openai_config.get('api_key', ''),
                    "azure_deployment": openai_config.get('deployment', 'gpt-4o'),
                    "api_version": openai_config.get('api_version', '2024-12-01-preview')
                }
            
            if not model_config.get('azure_endpoint') or not model_config.get('api_key'):
                logger.warning("Azure AI Eval: missing credentials")
                return
            
            self.enabled_evaluators = config.get('evaluators', [])
            
            if 'groundedness' in self.enabled_evaluators:
                self.evaluators['groundedness'] = GroundednessEvaluator(model_config=model_config)
            if 'relevance' in self.enabled_evaluators:
                self.evaluators['relevance'] = RelevanceEvaluator(model_config=model_config)
            if 'retrieval' in self.enabled_evaluators:
                self.evaluators['retrieval'] = RetrievalEvaluator(model_config=model_config)
            
            self.available = True
            logger.info(f"Azure AI Eval initialized: {list(self.evaluators.keys())}")
            
        except ImportError:
            logger.warning("Azure AI Eval: azure-ai-evaluation package not installed. pip install azure-ai-evaluation")
        except Exception as e:
            logger.warning(f"Azure AI Eval: init failed: {e}")
    
    @property
    def name(self) -> str:
        return "azure_ai_eval"
    
    def evaluate_field(self, field_name: str, field_data: dict,
                       context: dict = None) -> Dict[str, Any]:
        """
        Run Azure AI evaluators on a field.
        
        Context:
            query: field search query
            rag_context: RAG chunks text
        """
        if not self.available or not self.evaluators:
            return None
        
        value = field_data.get('value', '')
        if not value:
            return None
        
        if not context:
            context = {}
        
        query = context.get('query', field_name.replace('_', ' '))
        rag_context = context.get('rag_context', '')
        response = str(value)
        
        # If no rag_context, use value as context for groundedness/retrieval
        if not rag_context:
            rag_context = f"Extracted field '{field_name}': {response}"
        
        results = {}
        
        # Groundedness
        if 'groundedness' in self.evaluators:
            try:
                result = self.evaluators['groundedness'](
                    query=query,
                    context=rag_context,
                    response=response
                )
                raw = result.get('groundedness', 0)
                norm = round(raw / 5.0, 2) if isinstance(raw, (int, float)) else 0
                results['groundedness'] = {
                    "score": norm,
                    "label": "pass" if norm >= 0.6 else "fail",
                    "reason": result.get('groundedness_reason', '')
                }
            except Exception as e:
                logger.warning(f"Groundedness failed for {field_name}: {str(e)[:100]}")
        
        # Relevance
        if 'relevance' in self.evaluators:
            try:
                result = self.evaluators['relevance'](
                    query=query,
                    response=response
                )
                raw = result.get('relevance', 0)
                norm = round(raw / 5.0, 2) if isinstance(raw, (int, float)) else 0
                results['relevance'] = {
                    "score": norm,
                    "label": "pass" if norm >= 0.6 else "fail",
                    "reason": result.get('relevance_reason', '')
                }
            except Exception as e:
                logger.warning(f"Relevance failed for {field_name}: {str(e)[:100]}")
        
        # Retrieval
        if 'retrieval' in self.evaluators:
            try:
                result = self.evaluators['retrieval'](
                    query=query,
                    context=rag_context
                )
                raw = result.get('retrieval', 0)
                norm = round(raw / 5.0, 2) if isinstance(raw, (int, float)) else 0
                results['retrieval'] = {
                    "score": norm,
                    "label": "pass" if norm >= 0.6 else "fail",
                    "reason": result.get('retrieval_reason', '')
                }
            except Exception as e:
                logger.warning(f"Retrieval failed for {field_name}: {str(e)[:100]}")
        
        return results if results else None
