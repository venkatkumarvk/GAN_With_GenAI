"""
Cost Tracking Module
===================
Tracks and calculates costs for Azure services.
Supports provider-wise breakdown and batch API (50% discount).
"""

import logging
from typing import Dict
from datetime import datetime


class CostTracker:
    """Track costs for document processing with provider-wise breakdown"""
    
    def __init__(self, config: dict = None,
                 ocr_per_page: float = 0.01,
                 embedding_per_1k: float = 0.0001,
                 gpt_input_per_1k: float = 0.0025,
                 gpt_output_per_1k: float = 0.01,
                 api_type: str = "general"):
        """
        Initialize cost tracker.
        
        Args:
            config: Configuration dictionary
            ocr_per_page: Cost per page for OCR
            embedding_per_1k: Cost per 1K tokens for embeddings
            gpt_input_per_1k: Cost per 1K input tokens for GPT
            gpt_output_per_1k: Cost per 1K output tokens for GPT
            api_type: "general" or "batch" (batch = 50% discount on GPT)
        """
        if config and isinstance(config, dict):
            costs = config.get('costs', {})
            self.ocr_per_page = costs.get('ocr_per_page', ocr_per_page)
            self.embedding_per_1k = costs.get('embedding_per_1k_tokens', embedding_per_1k)
            self.gpt_input_per_1k = costs.get('gpt_input_per_1k_tokens', gpt_input_per_1k)
            self.gpt_output_per_1k = costs.get('gpt_output_per_1k_tokens', gpt_output_per_1k)
        else:
            self.ocr_per_page = ocr_per_page
            self.embedding_per_1k = embedding_per_1k
            self.gpt_input_per_1k = gpt_input_per_1k
            self.gpt_output_per_1k = gpt_output_per_1k
        
        self.api_type = api_type
        # Batch API = 50% discount on GPT costs
        self.gpt_discount = 0.5 if api_type == "batch" else 1.0
        
        # Overall counters
        self.ocr_pages = 0
        self.embedding_tokens = 0
        self.gpt_input_tokens = 0
        self.gpt_output_tokens = 0
        
        # Provider-wise tracking
        self._current_provider = None
        self._provider_stats = {}  # {provider: {ocr_pages, embedding_tokens, gpt_input, gpt_output, docs, fields}}
        
        self.logger = logging.getLogger(__name__)
    
    def set_provider(self, provider: str):
        """Set current provider for tracking."""
        self._current_provider = provider
        if provider not in self._provider_stats:
            self._provider_stats[provider] = {
                'ocr_pages': 0,
                'embedding_tokens': 0,
                'gpt_input_tokens': 0,
                'gpt_output_tokens': 0,
                'documents': 0,
                'fields': 0
            }
    
    def add_provider_document(self):
        """Increment document count for current provider."""
        if self._current_provider and self._current_provider in self._provider_stats:
            self._provider_stats[self._current_provider]['documents'] += 1
    
    def add_provider_field(self):
        """Increment field count for current provider."""
        if self._current_provider and self._current_provider in self._provider_stats:
            self._provider_stats[self._current_provider]['fields'] += 1
    
    def _add_to_provider(self, key: str, value):
        """Add value to current provider's stats."""
        if self._current_provider and self._current_provider in self._provider_stats:
            self._provider_stats[self._current_provider][key] += value
    
    def add_ocr(self, pages: int):
        """Add OCR page count."""
        self.ocr_pages += pages
        self._add_to_provider('ocr_pages', pages)
    
    def add_ocr_pages(self, pages: int):
        """Alias for add_ocr."""
        self.add_ocr(pages)
    
    def add_embedding(self, tokens: int):
        """Add embedding token count."""
        self.embedding_tokens += tokens
        self._add_to_provider('embedding_tokens', tokens)
    
    def add_embedding_tokens(self, tokens: int):
        """Alias for add_embedding."""
        self.add_embedding(tokens)
    
    def add_gpt_tokens(self, input_tokens: int, output_tokens: int):
        """Add GPT token counts."""
        self.gpt_input_tokens += input_tokens
        self.gpt_output_tokens += output_tokens
        self._add_to_provider('gpt_input_tokens', input_tokens)
        self._add_to_provider('gpt_output_tokens', output_tokens)
    
    def add_gpt4o_tokens(self, input_tokens: int, output_tokens: int):
        """Alias for add_gpt_tokens."""
        self.add_gpt_tokens(input_tokens, output_tokens)
    
    def add_gpt4o(self, input_tokens: int, output_tokens: int):
        """Alias for add_gpt_tokens."""
        self.add_gpt_tokens(input_tokens, output_tokens)
    
    def _calculate_costs(self, ocr_pages, embedding_tokens, gpt_input, gpt_output):
        """Calculate costs for given token counts."""
        ocr_cost = ocr_pages * self.ocr_per_page
        embedding_cost = (embedding_tokens / 1000) * self.embedding_per_1k
        gpt_input_cost = (gpt_input / 1000) * self.gpt_input_per_1k * self.gpt_discount
        gpt_output_cost = (gpt_output / 1000) * self.gpt_output_per_1k * self.gpt_discount
        gpt_cost = gpt_input_cost + gpt_output_cost
        total = ocr_cost + embedding_cost + gpt_cost
        return {
            'ocr': round(ocr_cost, 4),
            'embedding': round(embedding_cost, 4),
            'gpt': round(gpt_cost, 4),
            'total': round(total, 4)
        }
    
    def get_costs(self) -> Dict[str, float]:
        """Calculate and return overall costs."""
        costs = self._calculate_costs(
            self.ocr_pages, self.embedding_tokens,
            self.gpt_input_tokens, self.gpt_output_tokens
        )
        return {
            "ocr_cost": costs['ocr'],
            "embedding_cost": costs['embedding'],
            "gpt4o_cost": costs['gpt'],
            "total_estimated": costs['total']
        }
    
    def get_summary(self) -> Dict:
        """Get complete cost summary with provider breakdown."""
        costs = self.get_costs()
        
        return {
            "total": costs["total_estimated"],
            "api_type": self.api_type,
            "discount": "50% (batch)" if self.api_type == "batch" else "none",
            "usage": {
                "ocr_pages": self.ocr_pages,
                "embedding_tokens": self.embedding_tokens,
                "gpt_input_tokens": self.gpt_input_tokens,
                "gpt_output_tokens": self.gpt_output_tokens,
                "gpt_total_tokens": self.gpt_input_tokens + self.gpt_output_tokens
            },
            "breakdown": {
                "ocr": costs["ocr_cost"],
                "embedding": costs["embedding_cost"],
                "gpt4o": costs["gpt4o_cost"]
            },
            "providers": self._get_provider_summaries()
        }
    
    def _get_provider_summaries(self) -> Dict:
        """Get per-provider cost and token summaries."""
        summaries = {}
        for provider, stats in self._provider_stats.items():
            costs = self._calculate_costs(
                stats['ocr_pages'], stats['embedding_tokens'],
                stats['gpt_input_tokens'], stats['gpt_output_tokens']
            )
            summaries[provider] = {
                'documents': stats['documents'],
                'fields': stats['fields'],
                'ocr_pages': stats['ocr_pages'],
                'tokens': {
                    'input': stats['gpt_input_tokens'],
                    'output': stats['gpt_output_tokens'],
                    'total': stats['gpt_input_tokens'] + stats['gpt_output_tokens'],
                    'embedding': stats['embedding_tokens']
                },
                'cost': costs['total']
            }
        return summaries
    
    def log_summary(self):
        """Log cost summary."""
        summary = self.get_summary()
        self.logger.info("=" * 60)
        self.logger.info("COST SUMMARY")
        self.logger.info("=" * 60)
        self.logger.info(f"OCR Pages: {summary['usage']['ocr_pages']}")
        self.logger.info(f"Embedding Tokens: {summary['usage']['embedding_tokens']:,}")
        self.logger.info(f"GPT Input Tokens: {summary['usage']['gpt_input_tokens']:,}")
        self.logger.info(f"GPT Output Tokens: {summary['usage']['gpt_output_tokens']:,}")
        self.logger.info("-" * 60)
        self.logger.info(f"OCR Cost: ${summary['breakdown']['ocr']:.4f}")
        self.logger.info(f"Embedding Cost: ${summary['breakdown']['embedding']:.4f}")
        self.logger.info(f"GPT Cost: ${summary['breakdown']['gpt4o']:.4f}")
        if self.api_type == "batch":
            self.logger.info(f"  (50% batch discount applied)")
        self.logger.info(f"TOTAL COST: ${summary['total']:.4f}")
        self.logger.info("=" * 60)
    
    def reset(self):
        """Reset all counters."""
        self.ocr_pages = 0
        self.embedding_tokens = 0
        self.gpt_input_tokens = 0
        self.gpt_output_tokens = 0
        self._provider_stats = {}
        self._current_provider = None
