"""
MEDICAL DOCUMENT PARSER - PRODUCTION WITH RAG
==============================================

Entry point. All logic lives in utils/ and services/.

Usage:
  python main.py --apitype general --doctype cred --archive false
  python main.py --apitype batch --doctype cred --archive true
"""

import sys
import argparse
from datetime import datetime

from utils.logger_helper import setup_logger, get_logger, print_section
from utils.config_loader import (
    load_configuration, validate_doctype_config,
    load_prompt_module, initialize_azure_services, discover_providers
)
from utils.provider_processor import process_providers


def main():
    """Main application entry point."""
    
    try:
        # Parse arguments
        parser = argparse.ArgumentParser(description='Medical Document Parser with RAG')
        parser.add_argument('--apitype', required=True, choices=['general', 'batch'],
                          help='API type: general (real-time) or batch (50%% cheaper)')
        parser.add_argument('--doctype', required=True,
                          help='Document type (e.g., cred)')
        parser.add_argument('--archive', required=True, choices=['true', 'false'],
                          help='Enable archiving: true or false')
        
        args = parser.parse_args()
        
        # Load config (silent - before logger)
        config = load_configuration()
        
        # Setup logger with doctype prefix
        log_config = config.get('log', {})
        log_prefix = f"{args.doctype}_{log_config.get('prefix', 'ragparser')}"
        log_filename = setup_logger(
            log_level=log_config.get('level', 'INFO'),
            log_dir=log_config.get('directory', 'logs'),
            log_prefix=log_prefix
        )
        
        logger = get_logger(__name__)
        
        # Start
        logger.info(f"Config loaded: {len(config['doctypes'])} doctypes: {', '.join(config['doctypes'].keys())}")
        
        archive_enabled = args.archive.lower() == 'true'
        
        print_section("MEDICAL DOCUMENT PARSER - RAG-BASED PRODUCTION SYSTEM", "=")
        logger.info(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Log file: {log_filename}")
        logger.info(f"Arguments: --apitype {args.apitype} --doctype {args.doctype} --archive {args.archive}")
        
        # Set runtime config
        config['extraction']['api_type'] = args.apitype
        config['extraction']['archive'] = archive_enabled
        
        rag_mode = config.get('rag', {}).get('mode', 'text')
        logger.info(f"Settings: API={args.apitype} | RAG={rag_mode} | Archive={args.archive}")
        
        # Validate, initialize, discover, process
        doctype_config = validate_doctype_config(config, args.doctype)
        prompt_module = load_prompt_module(doctype_config['prompt_module'])
        services = initialize_azure_services(config, doctype_config)
        providers, folder_structure = discover_providers(
            services['blob'], config['azure_blob']['inputcontainer']
        )
        process_providers(
            providers, folder_structure, config, services,
            args.doctype, doctype_config, prompt_module
        )
        
        # Done
        print_section("PROCESSING COMPLETE", "=")
        logger.info(f"End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Log saved: {log_filename}")
        
    except KeyboardInterrupt:
        print("\nProcess interrupted by user")
        sys.exit(1)
    except Exception as e:
        try:
            logger = get_logger(__name__)
            logger.error(f"FATAL ERROR: {str(e)}")
            logger.exception("Traceback:")
        except Exception:
            print(f"FATAL ERROR: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
