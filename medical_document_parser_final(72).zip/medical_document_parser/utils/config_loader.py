"""
Config Loader - Configuration, Validation, Service Initialization
=================================================================
"""

import os
import json
import logging
from typing import Dict

from utils.logger_helper import print_section, get_logger

logger = get_logger(__name__)


def load_configuration(config_path: str = "config/config.json") -> Dict:
    """Load configuration file (silent - no logging, called before logger setup)"""
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config file not found: {config_path}")
    
    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    return config


def validate_doctype_config(config: Dict, doctype: str) -> Dict:
    """Validate doctype-specific configuration"""
    print_section(f"STEP 2: VALIDATING DOCTYPE '{doctype}' CONFIG")
    
    try:
        logger.info(f"Checking doctype: {doctype}")
        
        if doctype not in config.get('doctypes', {}):
            available = list(config.get('doctypes', {}).keys())
            raise ValueError(f"Doctype '{doctype}' not found. Available: {available}")
        
        doctype_config = config['doctypes'][doctype]
        
        required_keys = ['azure_openai', 'azure_openai_embedding', 'azure_ai_search', 
                         'folder_configs', 'prompt_module']
        missing = [k for k in required_keys if k not in doctype_config]
        
        if missing:
            raise ValueError(f"Doctype '{doctype}' missing: {missing}")
        
        logger.info(f"Doctype '{doctype}' validated successfully")
        logger.info(f"   Prompt module: {doctype_config['prompt_module']}")
        logger.info(f"   Folder configs: {list(doctype_config['folder_configs'].keys())}")
        
        # Store current doctype in config for evaluation module
        config['_current_doctype'] = doctype
        
        return doctype_config
        
    except Exception as e:
        logger.error(f"Doctype validation failed: {str(e)}")
        raise


def load_prompt_module(prompt_module_path: str):
    """Load prompt module dynamically"""
    print_section("STEP 3: LOADING PROMPT MODULE")
    
    try:
        logger.info(f"Loading prompt module: {prompt_module_path}")
        
        module_parts = prompt_module_path.split('.')
        module_name = module_parts[-1]
        
        module = __import__(prompt_module_path, fromlist=[module_name])
        
        field_count = len(module.FIELD_LIBRARY)
        logger.info(f"Prompt module loaded - {field_count} fields available")
        
        return module
        
    except Exception as e:
        logger.error(f"Prompt module loading failed: {str(e)}")
        raise


def initialize_azure_services(config: Dict, doctype_config: Dict):
    """Initialize Azure service connections"""
    print_section("STEP 4: INITIALIZING AZURE SERVICES")
    
    services = {}
    
    try:
        from services.keyvault_manager import KeyVaultManager, resolve_config_values
        from services.azure_clients import BlobManager, OpenAIManager, SearchManager
        from services.ocr import DocumentIntelligenceOCR
        from services.cost_tracker import CostTracker
        
        # Key Vault
        logger.info("Initializing Key Vault Manager...")
        vault_url = config.get('azure_keyvault', {}).get('vault_url')
        kv_manager = KeyVaultManager(vault_url)
        services['keyvault'] = kv_manager
        
        logger.info("Resolving configuration values...")
        resolve_config_values(config, kv_manager)
        resolve_config_values(doctype_config, kv_manager)
        logger.info("Configuration values resolved")
        
        # Blob Storage
        logger.info("Initializing Blob Storage...")
        blob_manager = BlobManager(config['azure_blob']['connection_string'])
        services['blob'] = blob_manager
        logger.info("Blob Storage initialized")
        
        # Document Intelligence (OCR)
        logger.info("Initializing Document Intelligence...")
        doc_intel_config = config['azure_document_intelligence']
        ocr_manager = DocumentIntelligenceOCR({
            'endpoint': doc_intel_config['endpoint'],
            'key': doc_intel_config['key'],
            'api_version': doc_intel_config.get('api_version', '2024-07-31-preview')
        })
        services['ocr'] = ocr_manager
        logger.info("Document Intelligence initialized")
        
        # OpenAI Manager
        logger.info("Initializing OpenAI Manager...")
        openai_config = doctype_config['azure_openai']['general']
        embedding_config = doctype_config['azure_openai_embedding']
        batch_config = doctype_config['azure_openai'].get('batch')
        
        openai_manager = OpenAIManager(
            openai_config=openai_config,
            embedding_config=embedding_config,
            batch_config=batch_config
        )
        services['openai'] = openai_manager
        
        if batch_config:
            logger.info(f"OpenAI Manager initialized - Model: {openai_config['model_name']}, Batch: {batch_config['deployment_name']}")
        else:
            logger.info(f"OpenAI Manager initialized - Model: {openai_config['model_name']}")
        
        # AI Search Manager
        logger.info("Initializing AI Search...")
        search_config = doctype_config['azure_ai_search']
        embedding_dims = doctype_config['azure_openai_embedding'].get(
            'dimensions', doctype_config['azure_openai_embedding'].get('dimension', 1536)
        )
        
        search_manager = SearchManager(
            endpoint=search_config['endpoint'],
            api_key=search_config['key'],
            index_name=search_config['index_name'],
            vector_dimensions=embedding_dims
        )
        
        logger.info(f"Checking if index '{search_config['index_name']}' exists...")
        try:
            created = search_manager.create_universal_index()
            if created:
                logger.info(f"OK Created new index: {search_config['index_name']}")
            else:
                logger.info(f"OK Index already exists: {search_config['index_name']}")
        except Exception as e:
            logger.warning(f"Index check/creation: {e}")
        
        services['search'] = search_manager
        logger.info(f"AI Search initialized - Index: {search_config['index_name']}")
        
        # Cost Tracker
        api_type = config.get('extraction', {}).get('api_type', 'general')
        cost_tracker = CostTracker(config.get('costs', {}), api_type=api_type)
        services['cost_tracker'] = cost_tracker
        logger.info(f"Cost Tracker initialized (api_type: {api_type})")
        
        # SQL Logger
        from services.sql_logger import SQLLogger
        sql_logger = SQLLogger(config)
        services['sql_logger'] = sql_logger
        
        logger.info("All Azure services initialized successfully!")
        return services
        
    except Exception as e:
        logger.error(f"Azure services initialization failed: {str(e)}")
        raise


def discover_providers(blob_manager, input_container: str):
    """Discover all providers"""
    print_section("STEP 5: DISCOVERING PROVIDERS")
    
    try:
        logger.info(f"Scanning container: {input_container}")
        
        folder_structure = blob_manager.get_folder_structure(input_container)
        providers = list(folder_structure.keys())
        
        logger.info(f"Found {len(providers)} providers")
        
        if len(providers) == 0:
            logger.warning("No providers found")
            return [], {}
        
        for i, provider in enumerate(providers[:5], 1):
            folders = folder_structure[provider]
            logger.info(f"   {i}. {provider} ({len(folders)} folders)")
        
        if len(providers) > 5:
            logger.info(f"   ... and {len(providers) - 5} more providers")
        
        return providers, folder_structure
        
    except Exception as e:
        logger.error(f"Provider discovery failed: {str(e)}")
        raise
