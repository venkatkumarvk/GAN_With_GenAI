"""
Provider Processor - Document and Provider Processing
======================================================

Handles:
  - process_document_with_rag: routes to text or multimodal RAG
  - process_single_provider: processes all documents for one provider
  - process_providers: batch loop over all providers + final summary
"""

import os
import logging
from datetime import datetime
from typing import Dict, List

from utils.logger_helper import print_section, get_logger
from utils.aggregator import calculate_best_values
from utils.result_saver import save_results

logger = logging.getLogger(__name__)


def process_document_with_rag(doc_blob, provider: str, folder: str, fields: List[str],
                              services: Dict, config: Dict, prompt_module) -> Dict:
    """Process document using RAG extraction. Routes to text or multimodal."""
    doc_name = doc_blob.name.split('/')[-1]
    rag_mode = config.get('rag', {}).get('mode', 'text')
    api_type = config.get('extraction', {}).get('api_type', 'general')
    
    logger.info(f"      Mode: {rag_mode.upper()} RAG | API: {api_type.upper()} ({len(fields)} fields)")
    
    try:
        doc_bytes = services['blob'].download_blob(
            config['azure_blob']['inputcontainer'], doc_blob.name
        )
        
        if not doc_bytes:
            logger.error(f"      Failed to download {doc_name}")
            return None
        
        _, ext = os.path.splitext(doc_name)
        
        parallel_workers = config.get('extraction', {}).get('parallel_workers', 1)
        rag_config = config.get('rag', {})
        rag_params = dict(
            doc_bytes=doc_bytes,
            doc_name=doc_name,
            extension=ext,
            provider=provider,
            folder=folder,
            fields=fields,
            ocr=services['ocr'],
            openai_manager=services['openai'],
            search_manager=services['search'],
            cost_tracker=services['cost_tracker'],
            prompt_module=prompt_module,
            api_type=api_type,
            parallel_workers=parallel_workers,
            rag_config=rag_config
        )
        
        if rag_mode == 'multimodal':
            from extraction.multimodal_rag import process_document_multimodal_rag
            extracted_data, success = process_document_multimodal_rag(**rag_params)
        else:
            from extraction.text_rag import process_document_text_rag
            extracted_data, success = process_document_text_rag(**rag_params)
        
        if not success:
            logger.error(f"      RAG extraction failed for {doc_name}")
            return None
        
        return extracted_data
        
    except Exception as e:
        logger.error(f"      Document processing failed: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return None


def process_single_provider(provider: str, folder_structure: Dict, blob_manager,
                            config: Dict, services: Dict, doctype: str,
                            doctype_config: Dict, prompt_module, archiver=None):
    """Process a single provider's documents with RAG."""
    sql_logger = services.get('sql_logger')
    sql_doc_id = None
    matching_folder = None
    
    try:
        services['cost_tracker'].set_provider(provider)
        
        api_type = config.get('extraction', {}).get('api_type', 'general')
        source_path = f"{config.get('azure_blob', {}).get('inputcontainer', '')}/{provider}"
        
        if provider not in folder_structure:
            logger.warning(f"   Provider not found")
            return
        
        provider_folders = folder_structure[provider]
        folder_configs = doctype_config['folder_configs']
        provider_folder_names = list(provider_folders.keys()) if isinstance(provider_folders, dict) else provider_folders
        
        for folder_name in folder_configs.keys():
            if folder_name in provider_folder_names:
                matching_folder = folder_name
                break
        
        if not matching_folder:
            logger.warning(f"   No matching folder found")
            logger.warning(f"   Expected: {list(folder_configs.keys())}")
            logger.warning(f"   Found: {provider_folder_names}")
            return
        
        logger.info(f"   Processing folder: {matching_folder}")
        
        folder_path = f"{provider}/{matching_folder}"
        documents = blob_manager.list_blobs_in_folder(
            config['azure_blob']['inputcontainer'], folder_path
        )
        
        logger.info(f"   Found {len(documents)} documents (including all subfolders)")
        
        if sql_logger:
            sql_doc_id = sql_logger.insert_begin(
                provider_name=provider,
                document_type=doctype,
                api_type=api_type,
                source_folder_path=source_path,
                file_count=len(documents)
            )
        
        if len(documents) == 0:
            logger.warning(f"   No documents to process")
            return
        
        fields = folder_configs[matching_folder]['fields']
        logger.info(f"   Extracting {len(fields)} fields using PER-FIELD RAG")
        
        all_documents_data = []
        
        if sql_logger and sql_doc_id:
            sql_logger.update_status(sql_doc_id, "PROCESSING",
                f"Processing {len(documents)} documents with {len(fields)} fields")
        
        for doc_idx, doc_blob in enumerate(documents, 1):
            relative_path = doc_blob.name.replace(f"{provider}/", "")
            logger.info(f"   Document {doc_idx}/{len(documents)}: {relative_path}")
            
            if sql_logger and sql_doc_id and doc_idx % 5 == 0:
                sql_logger.update_status(sql_doc_id, "PROCESSING",
                    f"Document {doc_idx}/{len(documents)}",
                    ocr_status="IN_PROGRESS", ocr_desc=f"{doc_idx}/{len(documents)} docs OCR'd",
                    embedding_status="IN_PROGRESS", embedding_desc="Embedding chunks",
                    search_status="IN_PROGRESS", search_desc="Indexing",
                    parsing_status="IN_PROGRESS", parsing_desc=f"Extracting {len(fields)} fields")
            
            extracted_data = process_document_with_rag(
                doc_blob, provider, matching_folder, fields, services, config, prompt_module
            )
            
            if not extracted_data:
                continue
            
            all_documents_data.append({
                'document_name': doc_blob.name.split('/')[-1],
                'relative_path': relative_path,
                'fields': extracted_data
            })
            
            logger.info(f"      Document processed successfully with RAG")
            services['cost_tracker'].add_provider_document()
        
        if all_documents_data:
            logger.info(f"   Aggregating results from {len(all_documents_data)} documents...")
            
            if sql_logger and sql_doc_id:
                sql_logger.update_status(sql_doc_id, "AGGREGATING",
                    f"Aggregating {len(all_documents_data)} documents",
                    ocr_status="COMPLETED", ocr_desc=f"{len(documents)} documents OCR'd",
                    embedding_status="COMPLETED", embedding_desc="All chunks embedded",
                    search_status="COMPLETED", search_desc="All chunks indexed",
                    parsing_status="COMPLETED", parsing_desc=f"{len(fields)} fields extracted")
            
            final_results = calculate_best_values(
                all_documents_data, fields, matching_folder, prompt_module=prompt_module
            )
            
            logger.info(f"   Saving aggregated results...")
            avg_confidence = save_results(
                provider, final_results,
                config['azure_blob']['outputcontainer'],
                config['azure_blob']['inputcontainer'],
                services['blob'], config, len(documents),
                matching_folder, documents,
                cost_tracker=services['cost_tracker'],
                sql_doc_key=sql_doc_id
            )
            logger.info(f"   Provider processing complete - Confidence: {avg_confidence:.2f}")
            
            # SQL complete
            confidence_threshold = config.get('extraction', {}).get('confidence_threshold', 0.70)
            confidences = [v.get('confidence', 0) for v in final_results.values()
                          if isinstance(v, dict) and 'confidence' in v]
            min_conf = min(confidences) if confidences else 0
            routing = "highconfidence" if min_conf >= confidence_threshold else "lowconfidence"
            
            output_container = config['azure_blob']['outputcontainer']
            provider_out = f"{provider}_{sql_doc_id}" if sql_doc_id else provider
            target_path = f"{output_container}/{routing}/{provider_out}"
            
            if sql_logger and sql_doc_id:
                sql_logger.update_complete(sql_doc_id,
                    status="COMPLETED",
                    status_desc=f"Routing: {routing}",
                    target_folder_path=target_path
                )
            
            archive_enabled = config.get('extraction', {}).get('archive', False)
            if archive_enabled and archiver is not None:
                archiver.add_provider(provider, documents, routing)
                if sql_logger and sql_doc_id:
                    sql_logger.update_complete(sql_doc_id,
                        status="COMPLETED",
                        status_desc=f"Archived. Routing: {routing}",
                        target_folder_path=target_path,
                        archive_folder_path=f"archivecontainer/{routing}/{provider_out}"
                    )
            else:
                if sql_logger and sql_doc_id:
                    sql_logger.update_complete(sql_doc_id,
                        status="COMPLETED",
                        status_desc=f"Routing: {routing}. No archive.",
                        target_folder_path=target_path,
                        archive_folder_path="No archive"
                    )
        else:
            logger.warning(f"   No data extracted from any document")
            if sql_logger and sql_doc_id:
                sql_logger.update_complete(sql_doc_id,
                    status="NO_DATA",
                    status_desc="No data extracted from any document"
                )
            archive_enabled = config.get('extraction', {}).get('archive', False)
            if archive_enabled and archiver is not None:
                archiver.add_provider(provider, documents, "unprocessed")
        
    except Exception as e:
        logger.error(f"   Provider failed: {str(e)}")
        logger.exception("   Traceback:")
        
        if sql_logger and sql_doc_id:
            sql_logger.update_complete(sql_doc_id,
                status="FAILED", status_desc=str(e)[:200]
            )
        
        archive_enabled = config.get('extraction', {}).get('archive', False)
        if archive_enabled and archiver is not None:
            try:
                folder_path = f"{provider}/{matching_folder}" if matching_folder else provider
                documents = blob_manager.list_blobs_in_folder(
                    config['azure_blob']['inputcontainer'], folder_path
                )
                if documents:
                    archiver.add_provider(provider, documents, "unprocessed")
            except Exception:
                pass


def process_providers(providers: List[str], folder_structure: Dict, config: Dict,
                     services: Dict, doctype: str, doctype_config: Dict, prompt_module):
    """Process all providers in batches."""
    print_section("STEP 6: PROCESSING PROVIDERS WITH RAG")
    
    try:
        batch_size = config['processing'].get('batch_size', 10)
        total_providers = len(providers)
        total_batches = (total_providers + batch_size - 1) // batch_size
        
        # Auto-cleanup
        search_config = doctype_config.get('azure_ai_search', {})
        auto_cleanup = search_config.get('enable_auto_cleanup', False)
        auto_delete_days = search_config.get('auto_delete_days', 7)
        
        if auto_cleanup and services.get('search'):
            logger.info(f"   Auto-cleanup: deleting search index data older than {auto_delete_days} days...")
            deleted = services['search'].delete_old_documents(auto_delete_days)
            if deleted > 0:
                logger.info(f"   Auto-cleanup: removed {deleted} old chunks")
            else:
                logger.info(f"   Auto-cleanup: no old data to remove")
        
        logger.info(f"Processing configuration:")
        logger.info(f"   Total providers: {total_providers}")
        logger.info(f"   Batch size: {batch_size}")
        logger.info(f"   RAG mode: {config['rag']['mode']}")
        logger.info(f"   Total batches: {total_batches}")
        
        if total_providers == 0:
            logger.warning("No providers to process")
            return
        
        archive_enabled = config.get('extraction', {}).get('archive', False)
        archiver = None
        if archive_enabled:
            from services.archive_manager import ArchiveManager
            archiver = ArchiveManager(blob_manager=services['blob'], config=config, doctype=doctype)
            logger.info(f"   Archive: ENABLED")
        
        for batch_num in range(total_batches):
            start_idx = batch_num * batch_size
            end_idx = min(start_idx + batch_size, total_providers)
            batch_providers = providers[start_idx:end_idx]
            
            logger.info("")
            logger.info("=" * 80)
            logger.info(f"BATCH {batch_num + 1}/{total_batches} (Providers {start_idx + 1}-{end_idx})")
            logger.info("=" * 80)
            
            for provider_idx, provider in enumerate(batch_providers, 1):
                global_idx = start_idx + provider_idx
                logger.info("")
                logger.info(f"Provider {global_idx}/{total_providers}: {provider}")
                logger.info("-" * 80)
                
                process_single_provider(
                    provider, folder_structure, services['blob'],
                    config, services, doctype, doctype_config,
                    prompt_module, archiver=archiver
                )
        
        if archiver is not None:
            logger.info("")
            logger.info("=" * 80)
            logger.info("ARCHIVING")
            logger.info("=" * 80)
            archiver.finalize()
        
        # Final summary
        _print_final_summary(services, config)
        
    except Exception as e:
        logger.error(f"Processing failed: {str(e)}")
        raise


def _print_final_summary(services: Dict, config: Dict):
    """Print final summary with costs and token usage."""
    cost_summary = services['cost_tracker'].get_summary()
    rag_mode = config.get('rag', {}).get('mode', 'text')
    api_type = config.get('extraction', {}).get('api_type', 'general')
    archive_enabled = config.get('extraction', {}).get('archive', False)
    provider_stats = cost_summary.get('providers', {})
    usage = cost_summary['usage']
    breakdown = cost_summary['breakdown']
    
    processed_list = [p for p, s in provider_stats.items() if s['documents'] > 0]
    unprocessed_list = [p for p, s in provider_stats.items() if s['documents'] == 0]
    total_docs = sum(s['documents'] for s in provider_stats.values())
    
    logger.info("")
    logger.info("=" * 80)
    logger.info("FINAL SUMMARY")
    logger.info("=" * 80)
    
    logger.info(f"  RAG mode        : {rag_mode.upper()}")
    logger.info(f"  API type        : {api_type.upper()}")
    logger.info(f"  Archive         : {'YES' if archive_enabled else 'NO'}")
    
    logger.info("")
    logger.info(f"  Providers       : {len(provider_stats)} total")
    logger.info(f"    Processed     : {len(processed_list)}")
    logger.info(f"    Unprocessed   : {len(unprocessed_list)}")
    if unprocessed_list:
        for p in unprocessed_list:
            logger.info(f"      - {p}")
    
    logger.info("")
    logger.info(f"  Documents       : {total_docs}")
    logger.info(f"  Pages (OCR)     : {usage['ocr_pages']}")
    
    logger.info("")
    logger.info(f"  Tokens (overall)")
    logger.info(f"    Input         : {usage['gpt_input_tokens']:,}")
    logger.info(f"    Output        : {usage['gpt_output_tokens']:,}")
    logger.info(f"    Total         : {usage['gpt_total_tokens']:,}")
    logger.info(f"    Embedding     : {usage['embedding_tokens']:,}")
    
    if provider_stats:
        logger.info("")
        logger.info(f"  Tokens (per provider)")
        for prov, stats in provider_stats.items():
            t = stats['tokens']
            logger.info(
                f"    {prov}: {stats['documents']} docs, {stats['ocr_pages']} pages, "
                f"input={t['input']:,}, output={t['output']:,}, "
                f"embedding={t['embedding']:,}, cost=${stats['cost']:.4f}"
            )
    
    logger.info("")
    logger.info(f"  Cost ({api_type.upper()} API)")
    logger.info(f"    OCR           : ${breakdown['ocr']:.4f}")
    logger.info(f"    Embeddings    : ${breakdown['embedding']:.4f}")
    logger.info(f"    GPT           : ${breakdown['gpt4o']:.4f}")
    logger.info(f"    TOTAL         : ${cost_summary['total']:.4f}")
    
    logger.info("")
    logger.info("=" * 80)
