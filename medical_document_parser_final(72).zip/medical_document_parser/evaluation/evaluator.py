"""
Universal LLM-as-Judge Evaluator
==================================

UNIVERSAL: No field-specific code. Reads rules from eval_prompt module
and applies them dynamically. Never edit this file for new fields/doctypes.

Supported rule types:
  max_length, min_length, exact_length, regex, contains, not_contains,
  in_list, capitalized, all_alpha, all_digits, date_format,
  state_abbreviation, email_format, no_duplicates
"""

import re
import json
import logging
import os
import sys
from typing import Dict

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

logger = logging.getLogger(__name__)

# US state abbreviations for validation
US_STATES = {
    'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
    'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD',
    'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ',
    'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC',
    'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY',
    'DC', 'PR', 'VI', 'GU', 'AS', 'MP'
}


class LLMJudge:
    """Universal evaluator. Reads rules from eval prompt, applies dynamically."""
    
    def __init__(self, config: dict = None, eval_prompt_module=None):
        self.client = None
        self.deployment = None
        self.guidelines = {}
        self.system_prompt = ""
        
        if eval_prompt_module:
            self.guidelines = getattr(eval_prompt_module, 'FIELD_EVALUATION_GUIDELINES', {})
            self.system_prompt = getattr(eval_prompt_module, 'JUDGE_SYSTEM_PROMPT', '')
            eval_cfg = getattr(eval_prompt_module, 'EVALUATION_CONFIG', {})
            self.model = eval_cfg.get('model', 'gpt-5')
            self.max_tokens = eval_cfg.get('max_tokens', 4000)
            self.temperature = eval_cfg.get('temperature', 0.0)
        else:
            self.model = 'gpt-5'
            self.max_tokens = 4000
            self.temperature = 0.0
        
        if config:
            self._init_client(config)
    
    def _init_client(self, config: dict):
        """Initialize Azure OpenAI client."""
        try:
            from openai import AzureOpenAI
            eval_config = config.get('azure_openai', {})
            if eval_config.get('endpoint') and eval_config.get('api_key'):
                self.client = AzureOpenAI(
                    azure_endpoint=eval_config['endpoint'],
                    api_key=eval_config['api_key'],
                    api_version=eval_config.get('api_version', '2024-12-01-preview')
                )
                self.deployment = eval_config.get('deployment', self.model)
                logger.info(f"LLM Judge initialized: deployment={self.deployment}")
        except ImportError:
            logger.warning("LLM Judge: openai not installed")
    
    def evaluate_and_enrich(self, extracted_data: dict) -> dict:
        """
        Evaluate fields and add eval_score + eval_description.
        Only adds when evaluation finds something to report.
        """
        for field_name, field_data in extracted_data.items():
            guideline = self.guidelines.get(field_name, {})
            if not guideline:
                continue
            
            # Single-value field
            if isinstance(field_data, dict) and 'value' in field_data:
                value = field_data.get('value', '')
                if not value:
                    continue
                
                rules = guideline.get('rules', [])
                score, issues = self._apply_rules(value, rules)
                
                # LLM judge for deeper analysis
                if self.client and issues:
                    llm_result = self._llm_judge(field_name, field_data, guideline)
                    if llm_result:
                        score = min(score, llm_result.get('score', 1.0))
                        issues = list(set(issues + llm_result.get('issues', [])))
                
                field_data['eval_score'] = round(score, 2)
                field_data['eval_description'] = '; '.join(issues) if issues else ''
            
            # Multi-value field
            elif isinstance(field_data, list):
                if not field_data:
                    continue
                
                sub_field_rules = guideline.get('sub_field_rules', {})
                
                # Evaluate each item's sub-fields
                for item in field_data:
                    if not isinstance(item, dict):
                        continue
                    for sub_field, sub_data in item.items():
                        if sub_field == 'id':
                            continue
                        if not isinstance(sub_data, dict) or not sub_data.get('value'):
                            continue
                        
                        rules = sub_field_rules.get(sub_field, [])
                        score, issues = self._apply_rules(sub_data['value'], rules)
                        
                        sub_data['eval_score'] = round(score, 2)
                        sub_data['eval_description'] = '; '.join(issues) if issues else ''
                
                # Check for duplicates (field-level rule)
                field_rules = guideline.get('rules', [])
                dup_rules = [r for r in field_rules if r.get('type') == 'no_duplicates']
                if dup_rules:
                    dup_indices = self._find_duplicate_indices(field_data)
                    dup_rule = dup_rules[0]
                    for idx in dup_indices:
                        item = field_data[idx]
                        for sub_field, sub_data in item.items():
                            if sub_field == 'id':
                                continue
                            if isinstance(sub_data, dict):
                                sub_data['eval_score'] = dup_rule.get('score', 0.25)
                                sub_data['eval_description'] = dup_rule.get('message', 'Duplicate entry')
        
        return extracted_data
    
    def _apply_rules(self, value: str, rules: list) -> tuple:
        """Apply rules to a value. Returns (score, issues)."""
        score = 1.0
        issues = []
        
        for rule in rules:
            rule_type = rule.get('type', '')
            params = rule.get('params', {})
            fail_score = rule.get('score', 0.50)
            message = rule.get('message', f'{rule_type} check failed')
            
            passed = self._check_rule(rule_type, value, params)
            
            if not passed:
                score = min(score, fail_score)
                issues.append(message)
        
        return score, issues
    
    def _check_rule(self, rule_type: str, value: str, params: dict) -> bool:
        """Check a single rule. Returns True if passes, False if fails."""
        
        if rule_type == 'max_length':
            return len(value) <= params.get('max', 999)
        
        elif rule_type == 'min_length':
            return len(value) >= params.get('min', 1)
        
        elif rule_type == 'exact_length':
            return len(value) == params.get('length', 0)
        
        elif rule_type == 'regex':
            pattern = params.get('pattern', '')
            try:
                return bool(re.search(pattern, value))
            except re.error:
                return True  # invalid regex = skip
        
        elif rule_type == 'contains':
            values = params.get('values', [])
            return any(v in value for v in values)
        
        elif rule_type == 'not_contains':
            values = params.get('values', [])
            return not any(v in value for v in values)
        
        elif rule_type == 'in_list':
            values = params.get('values', [])
            return value in values
        
        elif rule_type == 'capitalized':
            return len(value) > 0 and value[0].isupper()
        
        elif rule_type == 'all_alpha':
            allowed = params.get('allowed_chars', '')
            return all(c.isalpha() or c in allowed for c in value)
        
        elif rule_type == 'all_digits':
            return value.isdigit()
        
        elif rule_type == 'date_format':
            # Check MM/DD/YYYY
            return bool(re.match(r'^\d{2}/\d{2}/\d{4}$', value))
        
        elif rule_type == 'state_abbreviation':
            # Accept 2-letter OR full name (2-letter preferred but both valid)
            if len(value) == 2 and value.upper() in US_STATES:
                return True
            # Full state name = not a failure, just not normalized
            if len(value) > 2:
                return False  # will get the score from the rule
            return False
        
        elif rule_type == 'email_format':
            return bool(re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', value))
        
        # Unknown rule type = pass
        return True
    
    def _find_duplicate_indices(self, items: list) -> list:
        """Find indices of duplicate items (keep first, mark rest)."""
        signatures = {}
        duplicates = []
        
        for idx, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            sig_parts = []
            for key, val in sorted(item.items()):
                if key == 'id':
                    continue
                if isinstance(val, dict):
                    v = str(val.get('value', '')).strip().lower()
                    if v and 'date' not in key and 'status' not in key:
                        sig_parts.append(v)
            sig = '|'.join(sig_parts)
            if not sig:
                continue
            if sig in signatures:
                duplicates.append(idx)
            else:
                signatures[sig] = idx
        
        return duplicates
    
    def _llm_judge(self, field_name: str, field_data, guideline: dict) -> dict:
        """Call LLM for deeper evaluation."""
        if not self.client:
            return None
        try:
            prompt = f"""Evaluate this extracted field:
Field: {field_name}
Value: {json.dumps(field_data, indent=2)}
Expected format: {guideline.get('expected_format', '')}

Return JSON only: {{"score": 0.0-1.0, "issues": ["list"], "suggestion": "fix"}}"""

            response = self.client.chat.completions.create(
                model=self.deployment,
                messages=[
                    {"role": "system", "content": self.system_prompt or "Evaluate data quality. JSON only."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            content = response.choices[0].message.content
            if not content:
                return None
            clean = content.strip()
            start = clean.find('{')
            end = clean.rfind('}')
            if start != -1 and end != -1:
                return json.loads(clean[start:end+1])
            return None
        except Exception as e:
            logger.warning(f"LLM Judge failed for {field_name}: {e}")
            return None


def load_eval_prompt_module(module_path: str):
    """Load evaluation prompt module dynamically."""
    try:
        parts = module_path.split('.')
        return __import__(module_path, fromlist=[parts[-1]])
    except ImportError:
        logger.warning(f"Eval prompt module not found: {module_path}")
        return None
