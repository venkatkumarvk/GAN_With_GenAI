"""
SQL Logger - Provider-level logging to Azure SQL Server
========================================================

Table: dbo.XLogDocumentParserRAG
Config key: "sql_logging" (separate from file "logging")
"""

import logging
from datetime import datetime

try:
    import pyodbc
    PYODBC_AVAILABLE = True
except ImportError:
    PYODBC_AVAILABLE = False


class SQLLogger:
    def __init__(self, config: dict):
        self.logger = logging.getLogger(__name__)
        self.enabled = False
        self.conn_str = None
        self.table_name = None
        
        if not PYODBC_AVAILABLE:
            self.logger.warning("SQL Logger: pyodbc not installed. Disabled.")
            return
        
        sql_log_config = config.get('sql_logging', {})
        if not sql_log_config.get('enabled', False):
            self.logger.info("SQL Logger: disabled in config")
            return
        
        sql_config = config.get('sql_server', {})
        self.conn_str = sql_config.get('connection_string')
        
        if not self.conn_str:
            self.logger.warning("SQL Logger: no connection_string. Disabled.")
            return
        
        self.table_name = sql_log_config.get('table_name', 'dbo.XLogDocumentParserRAG')
        self.enabled = True
        self.logger.info(f"SQL Logger: enabled -> {self.table_name}")
    
    def _get_uid(self) -> str:
        if not self.conn_str:
            return "system"
        for part in self.conn_str.split(";"):
            if part.strip().upper().startswith("UID="):
                return part.split("=")[1].strip()
        return "system"
    
    def insert_begin(self, provider_name: str, document_type: str, api_type: str,
                     source_folder_path: str = "", file_count: int = 0) -> int:
        if not self.enabled:
            return None
        try:
            conn = pyodbc.connect(self.conn_str)
            cursor = conn.cursor()
            created_by = self._get_uid()
            created_on = datetime.now()
            
            insert_query = f"""
                INSERT INTO {self.table_name} (
                    ProviderName, DocumentType, APIType,
                    SourceFolderPath, TargetFolderPath, ArchiveFolderPath,
                    FileCount, Status, StatusDesc,
                    AzureAISearchStatus, AzureAISearchStatusDesc,
                    AzureEmbeddingStatus, AzureEmbeddingStatusDesc,
                    AzureParsingStatus, AzureParsingStatusDesc,
                    AzureOCRStatus, AzureOCRStatusDesc,
                    CREATED_ON, CREATED_BY
                )
                OUTPUT INSERTED.DocumentParserRAG_Key
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            
            cursor.execute(insert_query,
                provider_name, document_type, api_type,
                source_folder_path, "", "",
                file_count,
                "BEGIN", "Started processing provider",
                "", "", "", "", "", "", "", "",
                created_on, created_by
            )
            result = cursor.fetchone()
            conn.commit()
            
            if result:
                doc_key = result[0]
                self.logger.info(f"SQL Logger: INSERT provider={provider_name}, key={doc_key}")
                return doc_key
            return None
        except Exception as e:
            self.logger.error(f"SQL Logger: INSERT error: {e}")
            return None
        finally:
            try:
                cursor.close()
                conn.close()
            except Exception:
                pass
    
    def update_status(self, doc_key: int, status: str, status_desc: str,
                      ocr_status=None, ocr_desc=None,
                      embedding_status=None, embedding_desc=None,
                      search_status=None, search_desc=None,
                      parsing_status=None, parsing_desc=None):
        if not self.enabled or doc_key is None:
            return
        try:
            conn = pyodbc.connect(self.conn_str)
            cursor = conn.cursor()
            updated_by = self._get_uid()
            updated_on = datetime.now()
            
            set_parts = ["Status = ?", "StatusDesc = ?", "UPDATED_ON = ?", "UPDATED_BY = ?"]
            params = [status, status_desc, updated_on, updated_by]
            
            if ocr_status is not None:
                set_parts.extend(["AzureOCRStatus = ?", "AzureOCRStatusDesc = ?"])
                params.extend([ocr_status, ocr_desc or ""])
            if embedding_status is not None:
                set_parts.extend(["AzureEmbeddingStatus = ?", "AzureEmbeddingStatusDesc = ?"])
                params.extend([embedding_status, embedding_desc or ""])
            if search_status is not None:
                set_parts.extend(["AzureAISearchStatus = ?", "AzureAISearchStatusDesc = ?"])
                params.extend([search_status, search_desc or ""])
            if parsing_status is not None:
                set_parts.extend(["AzureParsingStatus = ?", "AzureParsingStatusDesc = ?"])
                params.extend([parsing_status, parsing_desc or ""])
            
            params.append(doc_key)
            cursor.execute(f"UPDATE {self.table_name} SET {', '.join(set_parts)} WHERE DocumentParserRAG_Key = ?", *params)
            conn.commit()
        except Exception as e:
            self.logger.error(f"SQL Logger: UPDATE error: {e}")
        finally:
            try:
                cursor.close()
                conn.close()
            except Exception:
                pass
    
    def update_complete(self, doc_key: int, status: str, status_desc: str,
                        target_folder_path: str = "", archive_folder_path: str = ""):
        if not self.enabled or doc_key is None:
            return
        try:
            conn = pyodbc.connect(self.conn_str)
            cursor = conn.cursor()
            updated_by = self._get_uid()
            updated_on = datetime.now()
            
            cursor.execute(f"""
                UPDATE {self.table_name}
                SET Status = ?, StatusDesc = ?,
                    TargetFolderPath = ?, ArchiveFolderPath = ?,
                    UPDATED_ON = ?, UPDATED_BY = ?
                WHERE DocumentParserRAG_Key = ?
            """, status, status_desc, target_folder_path, archive_folder_path or "",
                updated_on, updated_by, doc_key)
            conn.commit()
            self.logger.info(f"SQL Logger: COMPLETE key={doc_key}, status={status}")
        except Exception as e:
            self.logger.error(f"SQL Logger: COMPLETE error: {e}")
        finally:
            try:
                cursor.close()
                conn.close()
            except Exception:
                pass
