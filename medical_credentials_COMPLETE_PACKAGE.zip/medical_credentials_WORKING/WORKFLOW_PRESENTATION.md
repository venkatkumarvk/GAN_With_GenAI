# Medical Credentials Extraction - Complete Workflow
## Clear, Presentation-Ready Diagram

```
╔═════════════════════════════════════════════════════════════╗
║                    START SYSTEM                              ║
╚═════════════════════════════════════════════════════════════╝
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 1: LOAD CONFIGURATION                                  │
│  • Read config.json                                          │
│  • Load Azure credentials                                    │
│  • Load field definitions (flexible list)                    │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 2: INITIALIZE ALL MANAGERS                             │
│  • Blob Storage Manager                                      │
│  • OCR Manager (Azure Document Intelligence)                 │
│  • OpenAI Manager (GPT-4o + Embeddings)                      │
│  • Index Manager (Azure AI Search)                           │
│  • Cost Tracker                                              │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 3: CREATE UNIVERSAL INDEX                              │
│  • Check if index "documents_universal" exists               │
│  • If NOT exists → Create new index                          │
│  • If exists → Use existing index                            │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 4: AUTO-CLEANUP OLD DATA                               │
│  • Calculate: cutoff = today - auto_delete_days              │
│  • Find all documents with timestamp < cutoff                │
│  • Delete these old documents from index                     │
│  • Log: "Deleted X documents from Y providers"               │
│                                                              │
│  Example (3 days):                                           │
│    Today = Day 4                                             │
│    Cutoff = Day 4 - 3 days = Day 1                           │
│    Action = Delete all docs from Day 1 or earlier            │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 5: LIST ALL PROVIDER FOLDERS                           │
│  • Scan input container                                      │
│  • Extract unique provider names from paths                  │
│  • Example: Provider1/, Provider2/, Provider3/              │
└─────────────────────────────────────────────────────────────┘
                              ↓
╔═════════════════════════════════════════════════════════════╗
║          OUTER LOOP: FOR EACH PROVIDER                       ║
║          (Provider1, Provider2, Provider3, ...)              ║
╚═════════════════════════════════════════════════════════════╝
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 6: GET ALL DOCUMENTS FOR CURRENT PROVIDER              │
│  • List all files in provider's folder                       │
│  • Example: Provider1/doc1.pdf, Provider1/doc2.pdf          │
└─────────────────────────────────────────────────────────────┘
                              ↓
╔═════════════════════════════════════════════════════════════╗
║       INNER LOOP: FOR EACH DOCUMENT                          ║
║       (doc1.pdf, doc2.pdf, doc3.pdf, ...)                    ║
╚═════════════════════════════════════════════════════════════╝
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 7: DOWNLOAD DOCUMENT                                   │
│  • Download file bytes from Blob Storage                     │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 8: OCR TEXT EXTRACTION                                 │
│  • Send document to Azure Document Intelligence              │
│  • Extract all text content                                  │
│  • Cost: 1 page = $0.01                                      │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 9: VALIDATE TEXT LENGTH                                │
│  • Check: text length >= 10 characters?                      │
│  • If NO → Skip document (likely portrait/photo)             │
│  • If YES → Continue processing                              │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 10: HANDLE LONG DOCUMENTS                              │
│  • Check document length                                     │
│  • If < 12,000 chars → Use as-is                             │
│  • If > 12,000 chars → Apply 5 techniques:                   │
│    1. Smart truncation                                       │
│    2. Semantic chunking                                      │
│    3. Intelligent summarization                              │
│    4. Dynamic RAG reduction                                  │
│    5. Token-exact truncation                                 │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 11: GENERATE EMBEDDING                                 │
│  • Send text to Azure OpenAI Embeddings API                  │
│  • Model: text-embedding-3-large                             │
│  • Get 3072-dimensional vector                               │
│  • Cost: tokens × $0.0001 per 1K tokens                      │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 12: UPLOAD TO UNIVERSAL INDEX                          │
│  • Generate unique ID: provider_documentname                 │
│  • Store in index with:                                      │
│    - Text content                                            │
│    - Embedding vector (3072 dims)                            │
│    - Metadata: provider, timestamp, document_name            │
│  • Now this document is in the index!                        │
└─────────────────────────────────────────────────────────────┘
                              ↓
        ┌───────────────────────────────────────┐
        │  NOW DOCUMENT IS IN INDEX!            │
        │  We can use it for RAG search         │
        └───────────────────────────────────────┘
                              ↓
╔═════════════════════════════════════════════════════════════╗
║              RAG EXTRACTION BEGINS                           ║
║         (Uses documents ALREADY in index)                    ║
╚═════════════════════════════════════════════════════════════╝
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 13: RAG SEARCH FOR SIMILAR DOCUMENTS                   │
│                                                              │
│  Query: Use current document's embedding                     │
│  Filter: provider = current_provider_name                    │
│  Search: Find top 3 most similar documents                   │
│                                                              │
│  Result: 3 similar documents from SAME provider              │
│                                                              │
│  Example:                                                    │
│    Current doc: Provider1/doc5.pdf                           │
│    RAG finds: Provider1/doc1.pdf ← 95% similar               │
│               Provider1/doc3.pdf ← 92% similar               │
│               Provider1/doc2.pdf ← 88% similar               │
│                                                              │
│  These 3 docs become "examples" for GPT-4o!                  │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 14: BUILD COMPLETE EXTRACTION PROMPT                   │
│                                                              │
│  PART 1 - System Instructions:                              │
│    "You are a medical credentialing expert..."               │
│    "Extract these fields: first_name, last_name..."          │
│    "Use NA if field not found..."                            │
│                                                              │
│  PART 2 - RAG Examples (from Step 13):                       │
│    "Here are 3 similar documents:"                           │
│    Example 1: [doc1.pdf text + extracted fields]             │
│    Example 2: [doc3.pdf text + extracted fields]             │
│    Example 3: [doc2.pdf text + extracted fields]             │
│                                                              │
│  PART 3 - Current Document:                                  │
│    "Now extract from THIS document:"                         │
│    [Current document text - doc5.pdf]                        │
│                                                              │
│  PART 4 - Output Format:                                     │
│    "Return JSON with all fields, NA for missing values"      │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 15: CALL GPT-4o FOR EXTRACTION                         │
│  • Send complete prompt from Step 14                         │
│  • Model: GPT-4o (gpt-4o deployment)                         │
│  • Temperature: 0.0 (deterministic)                          │
│  • Max tokens: 4000                                          │
│  • GPT-4o learns from the 3 RAG examples                     │
│  • GPT-4o extracts fields from current document              │
│  • Cost: (input + output) tokens × rates                     │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 16: PARSE GPT-4o RESPONSE                              │
│  • Get response text from GPT-4o                             │
│  • Remove markdown: ```json...```                            │
│  • Parse as JSON                                             │
│  • Extract: {field: {value, confidence}}                     │
│                                                              │
│  Example output:                                             │
│    {                                                         │
│      "first_name": {"value": "John", "confidence": 0.95},    │
│      "last_name": {"value": "Doe", "confidence": 0.95},      │
│      "email": {"value": "NA", "confidence": 0.50}            │
│    }                                                         │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 17: STORE DOCUMENT RESULT                              │
│  • Save extracted fields for this document                   │
│  • Store: document_name + all_fields + confidence_scores     │
└─────────────────────────────────────────────────────────────┘
                              ↓
╔═════════════════════════════════════════════════════════════╗
║     LOOP BACK TO STEP 7 FOR NEXT DOCUMENT                    ║
║     (Until all documents in provider processed)              ║
╚═════════════════════════════════════════════════════════════╝
                              ↓
        ┌───────────────────────────────────────┐
        │  ALL DOCUMENTS PROCESSED!             │
        │  Now aggregate results per provider    │
        └───────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 18: CALCULATE CONFIDENCE CATEGORY                      │
│  • Collect all confidence scores from all documents          │
│  • Find minimum confidence across all fields                 │
│  • Determine category:                                       │
│    - min_confidence >= 0.50 → "highconfidence"               │
│    - min_confidence < 0.50 → "lowconfidence"                 │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 19: FREQUENCY-BASED FIELD SELECTION                    │
│                                                              │
│  For EACH field (first_name, last_name, email...):           │
│    1. Collect all values from all documents                  │
│    2. Exclude "NA" values                                    │
│    3. Count frequency of each value                          │
│    4. Select MOST COMMON value                               │
│                                                              │
│  Example for "first_name":                                   │
│    doc1: "John"  ┐                                           │
│    doc2: "John"  ├─ 3 times → Select "John" ✓                │
│    doc3: "John"  ┘                                           │
│    doc4: "James" ── 1 time                                   │
│    doc5: "NA"    ── Skip                                     │
│                                                              │
│  Result: Best value per field = CSV row                      │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 20: SAVE JSON (ALL DETAILS)                            │
│  • Path: processedjsonresult/Provider_timestamp.json         │
│  • Contains:                                                 │
│    - Provider name                                           │
│    - Total documents count                                   │
│    - Min confidence score                                    │
│    - Category (highconfidence/lowconfidence)                 │
│    - ALL documents with ALL fields + confidence              │
│  • Upload to output container                                │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 21: SAVE CSV (BEST VALUES)                             │
│  • Path: highconfidence/ or lowconfidence/                   │
│  • Filename: Provider_timestamp.csv                          │
│  • Contains: 1 row with BEST values (from Step 19)           │
│  • Headers: all field names                                  │
│  • Upload to output container                                │
└─────────────────────────────────────────────────────────────┘
                              ↓
╔═════════════════════════════════════════════════════════════╗
║     LOOP BACK TO STEP 6 FOR NEXT PROVIDER                    ║
║     (Until all providers processed)                          ║
╚═════════════════════════════════════════════════════════════╝
                              ↓
        ┌───────────────────────────────────────┐
        │  ALL PROVIDERS PROCESSED!             │
        │  Generate final summary               │
        └───────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 22: SAVE COST SUMMARY                                  │
│  • Calculate all costs:                                      │
│    - OCR: total_pages × $0.01/page                           │
│    - Embeddings: total_tokens × $0.0001/1K                   │
│    - GPT-4o Input: total_input_tokens × $0.0025/1K           │
│    - GPT-4o Output: total_output_tokens × $0.01/1K           │
│  • Path: estimatecost/summary_timestamp.json                 │
│  • Upload to output container                                │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 23: LOG FINAL SUMMARY                                  │
│  • Total providers processed                                 │
│  • Total documents processed                                 │
│  • Total estimated cost                                      │
│  • Breakdown by service (OCR, Embeddings, GPT-4o)            │
│  • Save to: logs/extraction_timestamp.log                    │
└─────────────────────────────────────────────────────────────┘
                              ↓
╔═════════════════════════════════════════════════════════════╗
║                     ✅ COMPLETE                              ║
╚═════════════════════════════════════════════════════════════╝
```

---

## 🔑 KEY CLARIFICATION: Steps 13-15 Workflow

### **THE CONFUSION:**
People ask: "How can Step 14 use RAG examples from Step 13 if Step 13 is AFTER Step 12?"

### **THE ANSWER:**
```
Step 12: Upload CURRENT document to index
         ↓
         NOW this document is searchable!
         ↓
Step 13: Search index for SIMILAR documents
         (Finds documents from PREVIOUS runs!)
         ↓
         Returns 3 similar documents that were 
         uploaded in earlier processing
         ↓
Step 14: Build prompt with:
         - RAG examples (from Step 13 = older docs)
         - Current document (from Step 12 = new doc)
         ↓
Step 15: GPT-4o learns from old docs,
         extracts from new doc
```

### **EXAMPLE TIMELINE:**

**First Document (doc1.pdf):**
```
Step 12: Upload doc1.pdf → Index now has: [doc1.pdf]
Step 13: Search → Found 0 similar docs (index empty before this)
Step 14: Build prompt with 0 RAG examples
Step 15: Extract without examples
```

**Second Document (doc2.pdf):**
```
Step 12: Upload doc2.pdf → Index now has: [doc1.pdf, doc2.pdf]
Step 13: Search → Found 1 similar doc (doc1.pdf)
Step 14: Build prompt with 1 RAG example (doc1.pdf)
Step 15: Extract using doc1.pdf as example
```

**Fifth Document (doc5.pdf):**
```
Step 12: Upload doc5.pdf → Index now has: [doc1-5.pdf]
Step 13: Search → Found 3 similar docs (doc1, doc3, doc2)
Step 14: Build prompt with 3 RAG examples
Step 15: Extract using 3 examples
```

---

## 📊 LOOPS EXPLAINED

### **Two Nested Loops:**

```
OUTER LOOP (Providers):
  ├─ Provider1
  │   └─ INNER LOOP (Documents):
  │       ├─ doc1.pdf → Steps 7-17
  │       ├─ doc2.pdf → Steps 7-17
  │       └─ doc3.pdf → Steps 7-17
  │   └─ Steps 18-21: Save Provider1 results
  │
  ├─ Provider2
  │   └─ INNER LOOP (Documents):
  │       ├─ doc1.pdf → Steps 7-17
  │       └─ doc2.pdf → Steps 7-17
  │   └─ Steps 18-21: Save Provider2 results
  │
  └─ Provider3
      └─ INNER LOOP (Documents):
          └─ doc1.pdf → Steps 7-17
      └─ Steps 18-21: Save Provider3 results

Steps 22-23: Save overall summary
```

---

## 🎯 PRESENTATION TIPS

### **Slide 1: High-Level Flow**
```
Configuration → Initialize → Index Setup → 
Auto-Cleanup → Process Providers → Save Results
```

### **Slide 2: Document Processing Loop**
```
Download → OCR → Validate → Handle Length → 
Embed → Upload → RAG Search → Extract → Store
```

### **Slide 3: RAG Magic (Steps 13-15)**
```
Step 12: Upload current doc ✓
         ↓
Step 13: Find similar docs (from PAST uploads)
         ↓
Step 14: Build prompt:
         "Learn from these 3 examples [old docs]
          Now extract from this doc [new doc]"
         ↓
Step 15: GPT-4o extracts using examples
```

### **Slide 4: Provider Results**
```
All docs processed → Calculate confidence → 
Select best values → Save JSON + CSV
```

---

## 📁 Output Structure

```
outputcontainer/
├── processedjsonresult/
│   └── Provider1_20260227_123456.json    ← ALL details
├── highconfidence/
│   └── Provider1_20260227_123456.csv     ← BEST values
├── lowconfidence/
│   └── Provider2_20260227_123500.csv     ← BEST values
└── estimatecost/
    └── summary_20260227_123520.json      ← Costs

logs/
└── extraction_20260227_123445.log        ← Full log
```

---

## ✅ SUMMARY FOR PRESENTATION

**Steps 1-5:** System setup (one time)

**Steps 6-17:** Document processing (repeated for each doc)
  - Step 12: Upload doc to index
  - Step 13: Search for similar docs (finds old docs)
  - Step 14-15: Use old docs as examples to extract from new doc

**Steps 18-21:** Provider aggregation (after all docs)

**Steps 22-23:** Final summary (after all providers)

**Key Insight:** RAG examples come from PREVIOUSLY processed documents, not the current document!
