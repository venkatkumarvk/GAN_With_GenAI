# Medical Credentials Extraction - Complete Workflow

```
┌─────────────────────────────────────────────────────────────┐
│                    START SYSTEM                              │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  1. LOAD CONFIGURATION                                       │
│     • Read config.json                                       │
│     • Get Azure credentials                                  │
│     • Get field list (flexible)                              │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  2. INITIALIZE MANAGERS                                      │
│     • Blob Storage Manager                                   │
│     • OCR Manager (Document Intelligence)                    │
│     • OpenAI Manager (GPT-4o + Embeddings)                   │
│     • Index Manager (Azure Search)                           │
│     • Cost Tracker                                           │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  3. CREATE/VERIFY UNIVERSAL INDEX                            │
│     • Index name: documents_universal                        │
│     • If exists → Skip                                       │
│     • If not exists → Create with schema                     │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  4. AUTO-CLEANUP (Before Processing)                         │
│     • Calculate cutoff: today - auto_delete_days             │
│     • Find documents older than cutoff                       │
│     • Delete old documents                                   │
│     • Log: "Deleted X documents"                             │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  5. LIST ALL PROVIDERS                                       │
│     • Scan input container                                   │
│     • Find unique provider folders                           │
│     • Example: Provider1/, Provider2/, Provider3/           │
└─────────────────────────────────────────────────────────────┘
                              ↓
                    ┌─────────────────┐
                    │ For Each Provider│
                    └─────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  6. GET PROVIDER DOCUMENTS                                   │
│     • List all files in provider folder                      │
│     • Example: Provider1/doc1.pdf, Provider1/doc2.pdf       │
└─────────────────────────────────────────────────────────────┘
                              ↓
                    ┌──────────────────┐
                    │ For Each Document │
                    └──────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  7. DOWNLOAD DOCUMENT                                        │
│     • Download from Blob Storage                             │
│     • Get bytes                                              │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  8. OCR EXTRACTION                                           │
│     • Send document to Document Intelligence                 │
│     • Extract text content                                   │
│     • Track cost: 1 page = $0.01                             │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  9. CHECK TEXT LENGTH                                        │
│     • If text < 10 chars → Skip (portrait/photo)             │
│     • If text >= 10 chars → Continue                         │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  10. HANDLE CONTEXT LENGTH                                   │
│      • If text < 12,000 chars → Use as-is                    │
│      • If text > 12,000 chars → Truncate/Chunk               │
│      • Apply 5 techniques to prevent errors                  │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  11. GENERATE EMBEDDING                                      │
│      • Send text to text-embedding-3-large                   │
│      • Get 3072-dimensional vector                           │
│      • Track cost: tokens × $0.0001/1K                       │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  12. UPLOAD TO UNIVERSAL INDEX                               │
│      • Document ID: provider_filename                        │
│      • Content: extracted text                               │
│      • Vector: embedding                                     │
│      • Metadata: provider, timestamp, document_name          │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  13. RAG SEARCH (Provider Filtered)                          │
│      • Search index with document embedding                  │
│      • Filter: provider = current_provider                   │
│      • Get top 3 similar documents                           │
│      • These become RAG examples                             │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  14. BUILD EXTRACTION PROMPT                                 │
│      • System: field definitions (from prompt_config.py)     │
│      • RAG Examples: 3 similar documents                     │
│      • Current Document: text to extract                     │
│      • Instructions: "Extract all fields, use NA if missing" │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  15. CALL GPT-4o                                             │
│      • Send prompt to GPT-4o                                 │
│      • Temperature: 0.0 (deterministic)                      │
│      • Max tokens: 4000                                      │
│      • Track cost: input + output tokens                     │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  16. PARSE JSON RESPONSE                                     │
│      • Get GPT-4o output                                     │
│      • Remove markdown (```json)                             │
│      • Parse as JSON                                         │
│      • Get: {field: {value, confidence}}                     │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  17. STORE RESULT                                            │
│      • Save extracted fields                                 │
│      • Document name + all fields + confidence               │
└─────────────────────────────────────────────────────────────┘
                              ↓
                    ┌────────────────────┐
                    │ Repeat for All Docs│
                    └────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  18. CALCULATE MIN CONFIDENCE                                │
│      • Check all extracted fields                            │
│      • Find lowest confidence score                          │
│      • Determine category:                                   │
│        - >= 0.50 → highconfidence                            │
│        - < 0.50 → lowconfidence                              │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  19. FREQUENCY-BASED SELECTION                               │
│      • For each field, collect all values                    │
│      • Count frequency (ignore "NA")                         │
│      • Select most common value                              │
│      • This is the "best" value for CSV                      │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  20. SAVE JSON RESULT                                        │
│      • Path: processedjsonresult/Provider_timestamp.json     │
│      • Contains: All documents + all fields + confidence     │
│      • Upload to output container                            │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  21. SAVE CSV RESULT                                         │
│      • Path: highconfidence/ or lowconfidence/               │
│      • File: Provider_timestamp.csv                          │
│      • Contains: 1 row with best values for all fields       │
│      • Upload to output container                            │
└─────────────────────────────────────────────────────────────┘
                              ↓
                    ┌─────────────────────┐
                    │ Repeat for All       │
                    │ Providers            │
                    └─────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  22. SAVE COST SUMMARY                                       │
│      • Calculate total costs:                                │
│        - OCR: pages × $0.01                                  │
│        - Embeddings: tokens × $0.0001/1K                     │
│        - GPT-4o: tokens × rates                              │
│      • Path: estimatecost/summary_timestamp.json             │
│      • Upload to output container                            │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  23. LOG FINAL SUMMARY                                       │
│      • Total providers processed                             │
│      • Total documents processed                             │
│      • Total costs                                           │
│      • Save to logs/extraction_timestamp.log                 │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                        END                                   │
│                    ✅ COMPLETE                               │
└─────────────────────────────────────────────────────────────┘
```

---

## Output Files Created

```
outputcontainer/
├── processedjsonresult/
│   ├── Provider1_20260227_123456.json
│   ├── Provider2_20260227_123500.json
│   └── Provider3_20260227_123510.json
│
├── highconfidence/
│   ├── Provider1_20260227_123456.csv
│   └── Provider3_20260227_123510.csv
│
├── lowconfidence/
│   └── Provider2_20260227_123500.csv
│
└── estimatecost/
    └── summary_20260227_123520.json

logs/
└── extraction_20260227_123445.log
```

---

## Key Points

**Steps 1-5:** System initialization (one-time per run)

**Steps 6-17:** Document processing loop (repeated for each document)

**Steps 18-21:** Provider results (after all documents processed)

**Steps 22-23:** Final summary (after all providers processed)

**Auto-cleanup:** Runs at Step 4, BEFORE any processing starts

**Provider filtering:** At Step 13, ensures RAG examples are from same provider only
