# Folder-Level Extraction Guide

## ✅ **WHAT'S NEW:**

### **1. Folder-Level Extraction**
Different fields per folder!

```
Provider1/
├── 1. GEN & HR/        ← Extracts 12 personal fields
│   ├── doc1.pdf
│   └── doc2.pdf
│
└── 2. ED & TRAIN/      ← Extracts 15 license fields
    ├── doc3.pdf
    └── doc4.pdf
```

### **2. Clean Output Structure**
```
outputcontainer/
├── highconfidence/
│   └── Provider1/                      ← Just provider!
│       ├── processedjsonresult/        ← JSON files
│       ├── processedcsvresult/         ← CSV files
│       └── estimationcost/             ← Cost files
│
└── lowconfidence/
    └── Provider2/
        ├── processedjsonresult/
        ├── processedcsvresult/
        └── estimationcost/
```

### **3. Working Embedding**
Uses YOUR proven code - no errors!

```python
# Process actual OCR text
processed_text = chunker.handle_document(document_text)

# Generate embedding from actual text
embedding = openai_manager.get_embedding(processed_text[:2000])
```

---

## 🚀 **HOW TO USE:**

### **Option 1: Use Original (Simple)**
```bash
# Your working code - no folder features
python main.py
```

### **Option 2: Use Enhanced (Folder-Level)**
```bash
# New version with folder-level extraction
python main_enhanced.py
```

---

## 📊 **COMPARISON:**

| Feature | main.py (Original) | main_enhanced.py (New) |
|---------|-------------------|----------------------|
| **Embedding** | ✅ Works | ✅ Works (same code!) |
| **Folder-level fields** | ❌ No | ✅ Yes |
| **Output structure** | Basic | ✅ Provider/3 folders |
| **Config** | Simple | ✅ Per-folder config |

---

## 📋 **FOLDER CONFIGS:**

### **In config_enhanced.json:**

```json
{
  "folder_configs": {
    "GEN & HR": {
      "description": "Personal info",
      "fields": [
        "first_name",
        "last_name",
        "email",
        ...
      ]
    },
    
    "ED & TRAIN": {
      "description": "Licenses",
      "fields": [
        "degree",
        "state_license_number",
        ...
      ]
    }
  }
}
```

---

## ✅ **KEY POINT - NO DATA LOSS:**

**Both versions save ALL extracted data!**

### **Original (main.py):**
```
Saves:
- processedjsonresult/Provider1_timestamp.json  ← All data
- highconfidence/Provider1_timestamp.csv        ← Best values
- estimatecost/summary_timestamp.json           ← Costs
```

### **Enhanced (main_enhanced.py):**
```
Saves:
- Provider1/processedjsonresult/Provider1_Folder_timestamp.json  ← All data
- Provider1/processedcsvresult/Provider1_Folder_timestamp.csv    ← Best values
- Provider1/estimationcost/Provider1_Folder_timestamp_cost.json  ← Costs
```

**Both have complete data in JSON!** ✅

---

## 🎯 **OUTPUT FILES:**

### **1. JSON (Complete Data):**
```json
{
  "provider": "Provider1",
  "folder": "GEN & HR",
  "total_documents": 10,
  "results": [
    {
      "document_name": "doc1.pdf",
      "extracted_fields": {
        "first_name": {"value": "John", "confidence": 0.95},
        "last_name": {"value": "Smith", "confidence": 0.92},
        ...
      }
    },
    ...
  ],
  "best_values": {
    "first_name": {"value": "John", "confidence": 0.95, "status": "high"}
  }
}
```

**All documents + all fields + all confidences = NO DATA LOSS!** ✅

### **2. CSV (Summary):**
```csv
Provider,Folder,Field,Value,Confidence,Status
Provider1,GEN & HR,first_name,John,0.95,high
Provider1,GEN & HR,last_name,Smith,0.92,high
```

### **3. Cost Estimation:**
```json
{
  "provider": "Provider1",
  "folder": "GEN & HR",
  "total_documents": 10,
  "estimated_costs": {
    "total_cost_usd": 0.30
  }
}
```

---

## ✅ **EMBEDDING - GUARANTEED TO WORK:**

**Uses YOUR EXACT CODE:**

```python
# Line 1: OCR extraction
document_text = ocr_manager.extract_text(doc_bytes)

# Line 2: Process text
processed_text = chunker.handle_document(document_text)

# Line 3: Generate embedding
embedding = openai_manager.get_embedding(processed_text[:2000])
```

**No image conversion, no placeholders, just actual text!** ✅

---

## 🎯 **RECOMMENDED SETUP:**

### **Start with Original:**
```bash
# Test with your working code first
python main.py
```

**Once working, upgrade to Enhanced:**
```bash
# Use folder-level features
cp config_enhanced.json config.json
python main_enhanced.py
```

---

## 📊 **EXAMPLE WORKFLOW:**

### **Input:**
```
inputcontainer/
└── ANAND-NICHOLS, SONIA/
    ├── 1. GEN & HR/
    │   ├── CV 2023.docx
    │   └── License.pdf
    │
    └── 2. ED & TRAIN/
        └── DEA_Card.jpg
```

### **Processing (Enhanced):**
```
Processing Provider 1/1: ANAND-NICHOLS, SONIA
  Processing Folder 1/2: 1. GEN & HR
    Folder type: GEN & HR
    Extracting 12 fields
    [1/2] CV 2023.docx
      ✓ OCR extracted: 5112 chars
      ✓ Embedding generated: 3072 dimensions
      ✓ Successfully extracted
    [2/2] License.pdf
      ✓ OCR extracted: 2547 chars
      ✓ Embedding generated: 3072 dimensions
      ✓ Successfully extracted
    ✅ Saved: 3 files
  
  Processing Folder 2/2: 2. ED & TRAIN
    Folder type: ED & TRAIN
    Extracting 15 fields
    [1/1] DEA_Card.jpg
      ✓ OCR extracted: 450 chars
      ✓ Embedding generated: 3072 dimensions
      ✓ Successfully extracted
    ✅ Saved: 3 files
```

### **Output:**
```
outputcontainer/
└── highconfidence/
    └── ANAND-NICHOLS, SONIA/
        ├── processedjsonresult/
        │   ├── ANAND-NICHOLS, SONIA_GEN & HR_20260305.json
        │   └── ANAND-NICHOLS, SONIA_ED & TRAIN_20260305.json
        │
        ├── processedcsvresult/
        │   ├── ANAND-NICHOLS, SONIA_GEN & HR_20260305.csv
        │   └── ANAND-NICHOLS, SONIA_ED & TRAIN_20260305.csv
        │
        └── estimationcost/
            ├── ANAND-NICHOLS, SONIA_GEN & HR_20260305_cost.json
            └── ANAND-NICHOLS, SONIA_ED & TRAIN_20260305_cost.json
```

**Clean, organized, complete!** ✅

---

## ✅ **SUMMARY:**

| Aspect | Status |
|--------|--------|
| **Embedding** | ✅ Your proven code (works!) |
| **Folder-level** | ✅ Different fields per folder |
| **Output structure** | ✅ Provider/3 subfolders |
| **Data loss** | ✅ None! All in JSON |
| **Easy to use** | ✅ Just change config |

---

**TWO VERSIONS INCLUDED:**
1. **main.py** - Your original (proven working)
2. **main_enhanced.py** - New (folder-level + working embedding)

**Both work! Choose what you need!** ✅
