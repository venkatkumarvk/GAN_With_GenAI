"""
Document Intelligence OCR Module
Azure Document Intelligence v1.0.0b4
Supports base64 encoding for document submission
"""

import logging
from typing import Tuple
import base64


class DocumentIntelligenceOCR:
    """
    OCR Manager using Azure Document Intelligence v1.0.0b4
    Supports 11 file types with base64 encoding
    """
    
    SUPPORTED_EXTENSIONS = {
        'pdf', 'docx', 'doc', 'jpg', 'jpeg', 'png', 
        'gif', 'bmp', 'tiff', 'tif', 'webp', 'txt'
    }
    
    def __init__(self, endpoint: str, key: str):
        """
        Initialize Document Intelligence client
        
        Args:
            endpoint: Azure Document Intelligence endpoint
            key: Azure Document Intelligence key
        """
        from azure.ai.documentintelligence import DocumentIntelligenceClient
        from azure.core.credentials import AzureKeyCredential
        
        self.client = DocumentIntelligenceClient(
            endpoint=endpoint,
            credential=AzureKeyCredential(key)
        )
        self.logger = logging.getLogger(__name__)
    
    def is_supported(self, filename: str) -> bool:
        """Check if file type is supported"""
        extension = filename.lower().split('.')[-1]
        return extension in self.SUPPORTED_EXTENSIONS
    
    def get_file_type(self, filename: str) -> str:
        """Get file type category"""
        extension = filename.lower().split('.')[-1]
        
        if extension == 'pdf':
            return 'pdf'
        elif extension in ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tiff', 'tif', 'webp']:
            return 'image'
        elif extension in ['doc', 'docx']:
            return 'document'
        elif extension == 'txt':
            return 'text'
        else:
            return 'unknown'
    
    def extract_text(self, document_bytes: bytes, filename: str = "document.pdf") -> Tuple[str, bool, str]:
        """
        Extract text from document using Azure Document Intelligence
        
        Args:
            document_bytes: Document bytes
            filename: Original filename (for type detection)
        
        Returns:
            Tuple of (extracted_text, is_supported, file_type)
        """
        try:
            # Check if supported
            if not self.is_supported(filename):
                file_type = self.get_file_type(filename)
                self.logger.warning(f"Unsupported file type: {filename}")
                return "", False, file_type
            
            file_type = self.get_file_type(filename)
            
            # Convert to base64 (required for v1.0.0b4)
            base64_source = base64.b64encode(document_bytes).decode('utf-8')
            
            # Analyze document with prebuilt-read model
            self.logger.debug(f"Analyzing document: {filename} (type: {file_type})")
            
            poller = self.client.begin_analyze_document(
                model_id="prebuilt-read",
                analyze_request={
                    "base64Source": base64_source
                }
            )
            
            # Get result
            result = poller.result()
            
            # Extract text from all pages
            extracted_text = ""
            
            # Handle different response formats
            if hasattr(result, 'content') and result.content:
                # Direct content attribute
                extracted_text = result.content
            elif hasattr(result, 'pages') and result.pages:
                # Pages-based extraction
                for page in result.pages:
                    if hasattr(page, 'lines') and page.lines:
                        for line in page.lines:
                            if hasattr(line, 'content'):
                                extracted_text += line.content + "\n"
            elif hasattr(result, 'paragraphs') and result.paragraphs:
                # Paragraph-based extraction
                for paragraph in result.paragraphs:
                    if hasattr(paragraph, 'content'):
                        extracted_text += paragraph.content + "\n"
            
            # Clean up text
            extracted_text = extracted_text.strip()
            
            if not extracted_text:
                self.logger.warning(f"No text extracted from {filename}")
                return "", True, file_type
            
            self.logger.info(f"Extracted {len(extracted_text)} characters from {filename}")
            return extracted_text, True, file_type
            
        except Exception as e:
            self.logger.error(f"OCR extraction error for {filename}: {e}")
            return "", False, self.get_file_type(filename)


# Backward compatibility with old OCRManager
class OCRManager:
    """Backward compatible OCR Manager wrapper"""
    
    def __init__(self, endpoint: str, key: str):
        """Initialize with Document Intelligence"""
        self.doc_intel = DocumentIntelligenceOCR(endpoint, key)
        self.logger = logging.getLogger(__name__)
    
    def extract_text(self, document_bytes: bytes, filename: str = "document.pdf") -> str:
        """
        Extract text from document
        
        Args:
            document_bytes: Document bytes
            filename: Original filename
        
        Returns:
            Extracted text string
        """
        text, is_supported, file_type = self.doc_intel.extract_text(document_bytes, filename)
        
        if not is_supported:
            self.logger.warning(f"Unsupported file type: {filename}")
            return ""
        
        return text


# Test code
if __name__ == "__main__":
    print("="*70)
    print("DOCUMENT INTELLIGENCE OCR - TEST")
    print("="*70)
    print("\nSupported file types:")
    for ext in sorted(DocumentIntelligenceOCR.SUPPORTED_EXTENSIONS):
        print(f"  - .{ext}")
    print("\n✅ Module loaded successfully!")
