# Medical Credentials Extraction - Simple Workflow
## Easy to understand for everyone

```
╔═════════════════════════════════════════════════════════════╗
║                         START                                ║
╚═════════════════════════════════════════════════════════════╝
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  1. SETUP                                                    │
│     Load configuration and connect to Azure                  │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  2. PREPARE DATABASE                                         │
│     Create storage for documents (called "index")            │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  3. CLEANUP OLD DATA                                         │
│     Delete documents older than X days (e.g., 30 days)       │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  4. FIND PROVIDERS                                           │
│     List all provider folders (Provider1, Provider2, etc.)   │
└─────────────────────────────────────────────────────────────┘
                              ↓
╔═════════════════════════════════════════════════════════════╗
║          FOR EACH PROVIDER (repeat this section)             ║
╚═════════════════════════════════════════════════════════════╝
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  5. GET DOCUMENTS                                            │
│     List all PDF/image files for this provider               │
└─────────────────────────────────────────────────────────────┘
                              ↓
╔═════════════════════════════════════════════════════════════╗
║        FOR EACH DOCUMENT (repeat this section)               ║
╚═════════════════════════════════════════════════════════════╝
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  6. READ DOCUMENT                                            │
│     Download file and extract text using OCR                 │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  7. SAVE TO DATABASE                                         │
│     Store document text in the index                         │
└─────────────────────────────────────────────────────────────┘
                              ↓
        ┌───────────────────────────────────────┐
        │    Database now has this document!    │
        └───────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  8. FIND SIMILAR DOCUMENTS                                   │
│     Search database for 3 similar documents                  │
│     (from same provider, already processed)                  │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  9. EXTRACT FIELDS USING AI                                  │
│     Give AI:                                                 │
│     • 3 example documents (from step 8)                      │
│     • Current document (to extract)                          │
│     • Field list (first_name, last_name, etc.)               │
│                                                              │
│     AI learns from examples and extracts fields              │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  10. SAVE RESULTS                                            │
│      Store extracted data for this document                  │
└─────────────────────────────────────────────────────────────┘
                              ↓
╔═════════════════════════════════════════════════════════════╗
║           REPEAT steps 6-10 for next document                ║
╚═════════════════════════════════════════════════════════════╝
                              ↓
        ┌───────────────────────────────────────┐
        │   All documents processed!            │
        └───────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  11. SELECT BEST VALUES                                      │
│      For each field, pick most common value                  │
│      Example: if "John" appears 8 times, "James" 2 times     │
│               → Select "John"                                │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  12. SAVE PROVIDER RESULTS                                   │
│      • CSV file: Best values (1 row)                         │
│      • JSON file: All documents with details                 │
└─────────────────────────────────────────────────────────────┘
                              ↓
╔═════════════════════════════════════════════════════════════╗
║           REPEAT steps 5-12 for next provider                ║
╚═════════════════════════════════════════════════════════════╝
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  13. SAVE COST REPORT                                        │
│      Track how much we spent on Azure services               │
└─────────────────────────────────────────────────────────────┘
                              ↓
╔═════════════════════════════════════════════════════════════╗
║                          DONE                                ║
╚═════════════════════════════════════════════════════════════╝
```

---

## 🔑 Key Concept: How Steps 7-9 Work Together

```
Step 7: Put document in database
        ↓
        Database: [doc1, doc2, doc3, doc4] ← Now has 4 docs
        ↓
Step 8: Search database → Find 3 similar ones
        ↓
        Found: doc1, doc3, doc2 (from earlier)
        ↓
Step 9: AI learns from doc1, doc3, doc2
        Then extracts from doc4 (current)
```

**Simple analogy:**
- You save your homework (Step 7)
- You look at 3 similar past homeworks (Step 8)  
- You learn from them to do current homework (Step 9)

---

## 📊 What You Get

```
Output Files:
├── CSV files        → Best values per provider (1 row each)
├── JSON files       → All documents with full details
└── Cost report      → Total spending on Azure
```

---

## ⏱️ Timeline Example (5 documents)

```
Doc1: Save → Search (0 found) → Extract without examples
Doc2: Save → Search (1 found) → Extract using 1 example
Doc3: Save → Search (2 found) → Extract using 2 examples
Doc4: Save → Search (3 found) → Extract using 3 examples
Doc5: Save → Search (3 found) → Extract using 3 examples

Result: System gets better as it processes more documents!
```

---

## 🗑️ Auto-Cleanup (Step 3)

**Set to 3 days:**
```
Day 1: Upload docs → Keep (0 days old)
Day 2: Upload docs → Keep (1 day old)
Day 3: Upload docs → Keep (2 days old)
Day 4: Upload docs → DELETE Day 1 docs (3+ days old)
Day 5: Upload docs → DELETE Day 2 docs (3+ days old)
```

**Set to 30 days:**
```
Day 1-30: Upload docs → Keep all
Day 31: Upload docs → DELETE Day 1 docs (30+ days old)
```

---

## 🎯 Summary

**13 simple steps:**
1. Setup system
2. Create database
3. Delete old data
4. Find providers
5. Get documents
6. Read text
7. Save to database
8. Find similar docs
9. Extract with AI
10. Save results
11. Pick best values
12. Save final files
13. Save costs

**That's it!** ✅
