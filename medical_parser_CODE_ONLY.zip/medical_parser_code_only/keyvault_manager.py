"""
Key Vault Manager - Handle Azure Key Vault secrets
"""

from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential
import logging

class KeyVaultManager:
    def __init__(self, keyvault_config):
        """
        Initialize Key Vault Manager
        
        Args:
            keyvault_config: {"vault_url": "https://..."}
        """
        self.logger = logging.getLogger(__name__)
        self.vault_url = keyvault_config['vault_url']
        
        self.credential = DefaultAzureCredential()
        self.client = SecretClient(vault_url=self.vault_url, credential=self.credential)
        self.cache = {}  # Cache secrets to avoid multiple calls
    
    def get_secret(self, secret_name):
        """
        Get secret from Key Vault with caching
        
        Args:
            secret_name: Name of secret in Key Vault
            
        Returns:
            Secret value as string
        """
        # Check cache first
        if secret_name in self.cache:
            return self.cache[secret_name]
        
        try:
            self.logger.info(f"Fetching secret: {secret_name}")
            secret = self.client.get_secret(secret_name)
            self.cache[secret_name] = secret.value
            return secret.value
        except Exception as e:
            self.logger.error(f"Failed to get secret '{secret_name}': {str(e)}")
            raise
