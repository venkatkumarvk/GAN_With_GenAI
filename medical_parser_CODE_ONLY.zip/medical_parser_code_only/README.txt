MEDICAL DOCUMENT PARSER - PRODUCTION CODE
==========================================

CORE FILES:
-----------
main.py                      - Main CLI application
config.json                  - Configuration file (update with your Azure credentials)
requirements.txt             - Python dependencies

AZURE SERVICE MANAGERS:
-----------------------
keyvault_manager.py          - Azure Key Vault integration
helper.py                    - Azure Blob, OpenAI, AI Search managers
documentintelligence_ocr.py  - Document Intelligence OCR (v1.0.0b4)

RAG IMPLEMENTATION:
-------------------
text_rag.py                  - TEXT mode RAG processing
multimodal_rag.py            - MULTIMODAL mode RAG processing
prompt_builder.py            - Dynamic prompt construction
semantic_chunker.py          - Adaptive chunking strategy

PROCESSING:
-----------
document_processor.py        - Document processing template (needs integration)
archive_manager.py           - Provider-based archiving
costtracking.py              - Cost tracking per document

PROMPTS:
--------
prompts/cred_prompt.py       - Medical credentials (27 fields)
prompts/bus_prompt.py        - Business documents
prompts/claim_prompt.py      - Insurance claims

INSTALLATION:
-------------
pip install -r requirements.txt

CONFIGURATION:
--------------
1. Update config.json with your Azure Key Vault URL
2. Add secrets to Azure Key Vault (see config.json for required secrets)

USAGE:
------
python main.py --doctype cred --apitype general --archive true

MODELS USED:
------------
- GPT-5 (all doctypes)
- Document Intelligence 1.0.0b4
- text-embedding-ada-002 or text-embedding-3-small

BATCH SIZE:
-----------
Configured in config.json: processing.batch_size (default: 10)

SCALABILITY:
------------
Handles 1000+ providers efficiently through batch processing
