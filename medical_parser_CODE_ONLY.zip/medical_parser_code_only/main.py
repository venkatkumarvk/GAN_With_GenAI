"""
Medical Document Parser - Production Version v3.0
Usage: python main.py --doctype cred --apitype general --archive true
"""

import argparse
import json
import logging
import sys
from datetime import datetime
from pathlib import Path

# Import custom modules
from keyvault_manager import KeyVaultManager
from document_processor import DocumentProcessor
from archive_manager import ArchiveManager


def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description='Medical Document Parser - Production v3.0',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py --doctype cred --apitype general --archive true
  python main.py --doctype bus --apitype batch --archive false
  python main.py --doctype claim --apitype general
        """
    )
    
    parser.add_argument(
        '--doctype',
        type=str,
        required=True,
        help='Document type to process (e.g., cred, bus, claim)'
    )
    
    parser.add_argument(
        '--apitype',
        type=str,
        required=True,
        choices=['general', 'batch'],
        help='OpenAI API type: general (real-time) or batch (async)'
    )
    
    parser.add_argument(
        '--archive',
        type=str,
        default='true',
        choices=['true', 'false'],
        help='Enable archiving: true or false (default: true)'
    )
    
    parser.add_argument(
        '--config',
        type=str,
        default='config.json',
        help='Path to config file (default: config.json)'
    )
    
    return parser.parse_args()


def setup_logging(config, doctype):
    """Setup logging configuration"""
    log_config = config.get('logging', {})
    
    if not log_config.get('enabled', True):
        logging.disable(logging.CRITICAL)
        return
    
    # Create logs folder
    log_folder = log_config.get('log_folder', 'logs')
    Path(log_folder).mkdir(parents=True, exist_ok=True)
    
    # Generate log filename
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_format = log_config.get('log_file_format', '{doctype}_{timestamp}.log')
    log_filename = log_format.format(doctype=doctype, timestamp=timestamp)
    log_path = Path(log_folder) / log_filename
    
    # Setup logging
    log_level = getattr(logging, log_config.get('level', 'INFO'))
    
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_path, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    return logging.getLogger(__name__)


def load_config(config_path):
    """Load configuration from JSON file"""
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        return config
    except FileNotFoundError:
        print(f"ERROR: Config file not found: {config_path}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"ERROR: Invalid JSON in config file: {e}")
        sys.exit(1)


def resolve_keyvault_values(config, kv_manager, logger):
    """
    Replace @azureKeyVault(variablename) with actual values from Key Vault
    
    Example:
        "@azureKeyVault(OpenAIKey)" -> actual key from Key Vault
    """
    import re
    
    def resolve_value(value, path=""):
        if isinstance(value, str) and value.startswith('@azureKeyVault('):
            # Extract secret name
            match = re.match(r'@azureKeyVault\(([^)]+)\)', value)
            if match:
                secret_name = match.group(1)
                logger.debug(f"Resolving Key Vault secret at {path}: {secret_name}")
                try:
                    return kv_manager.get_secret(secret_name)
                except Exception as e:
                    logger.error(f"Failed to resolve secret '{secret_name}' at {path}: {e}")
                    raise
        return value
    
    def resolve_dict(d, path=""):
        for key, value in d.items():
            current_path = f"{path}.{key}" if path else key
            if isinstance(value, dict):
                resolve_dict(value, current_path)
            elif isinstance(value, str):
                d[key] = resolve_value(value, current_path)
        return d
    
    return resolve_dict(config)


def validate_doctype(config, doctype):
    """Validate that doctype exists in config"""
    if 'doctypes' not in config:
        raise ValueError("Config missing 'doctypes' section")
    
    if doctype not in config['doctypes']:
        available = ', '.join(config['doctypes'].keys())
        raise ValueError(
            f"Vendortype '{doctype}' not found in config. "
            f"Available: {available}"
        )


def main():
    """Main entry point"""
    # Parse CLI arguments
    args = parse_arguments()
    
    # Load configuration
    config = load_config(args.config)
    
    # Setup logging (before Key Vault to catch errors)
    logger = setup_logging(config, args.doctype)
    
    logger.info("=" * 80)
    logger.info("Medical Document Parser - Production v3.0")
    logger.info("=" * 80)
    logger.info(f"Document Type: {args.doctype}")
    logger.info(f"API Type: {args.apitype}")
    logger.info(f"Archive: {args.archive}")
    logger.info(f"Config: {args.config}")
    
    try:
        # Validate doctype
        validate_doctype(config, args.doctype)
        
        # Initialize Key Vault Manager
        logger.info("Initializing Key Vault Manager...")
        kv_manager = KeyVaultManager(config['azure_keyvault'])
        
        # Resolve all Key Vault references
        logger.info("Resolving Key Vault secrets...")
        config = resolve_keyvault_values(config, kv_manager, logger)
        logger.info("✓ All Key Vault secrets resolved")
        
        # Get doctype configuration
        doctype_config = config['doctypes'][args.doctype]
        logger.info(f"✓ Loaded doctype config: {doctype_config['description']}")
        
        # Get OpenAI model config based on apitype
        if args.apitype not in doctype_config['azure_openai']:
            raise ValueError(
                f"API type '{args.apitype}' not found in doctype config. "
                f"Available: {list(doctype_config['azure_openai'].keys())}"
            )
        
        openai_config = doctype_config['azure_openai'][args.apitype]
        logger.info(f"✓ Using OpenAI deployment: {openai_config['deployment_name']}")
        
        # Get batch_size from config
        batch_size = config['processing'].get('batch_size', 10)
        logger.info(f"✓ Processing batch size: {batch_size}")
        
        # Load prompt module dynamically
        prompt_module_name = doctype_config['prompt_module']
        logger.info(f"Loading prompt module: {prompt_module_name}")
        
        try:
            import importlib
            prompt_module = importlib.import_module(prompt_module_name)
            logger.info("✓ Prompt module loaded successfully")
        except ImportError as e:
            logger.error(f"Failed to import prompt module '{prompt_module_name}': {e}")
            logger.error(f"Make sure the file exists: {prompt_module_name.replace('.', '/')}.py")
            raise
        
        # Initialize Document Processor
        logger.info("Initializing Document Processor...")
        processor = DocumentProcessor(
            config=config,
            doctype=args.doctype,
            doctype_config=doctype_config,
            openai_config=openai_config,
            prompt_module=prompt_module,
            apitype=args.apitype
        )
        
        # Process documents
        logger.info("=" * 80)
        logger.info("Starting document processing...")
        logger.info("=" * 80)
        
        results = processor.process_all_documents()
        
        # Archive if enabled
        if args.archive.lower() == 'true' and config['archive'].get('enabled', True):
            logger.info("=" * 80)
            logger.info("Archiving documents...")
            logger.info("=" * 80)
            
            archive_manager = ArchiveManager(config, args.doctype)
            archive_manager.archive_results(results)
            
            logger.info("✓ Archiving complete")
        
        # Print summary
        logger.info("=" * 80)
        logger.info("PROCESSING SUMMARY")
        logger.info("=" * 80)
        logger.info(f"Total documents: {results['total_docs']}")
        logger.info(f"High confidence: {results['high_confidence']}")
        logger.info(f"Low confidence: {results['low_confidence']}")
        logger.info(f"Total cost: ${results['total_cost']:.4f}")
        logger.info(f"Average cost per doc: ${results['avg_cost_per_doc']:.4f}")
        logger.info("=" * 80)
        logger.info("✓ Processing complete!")
        logger.info("=" * 80)
        
        return 0
        
    except Exception as e:
        logger.error("=" * 80)
        logger.error(f"ERROR: {str(e)}")
        logger.error("=" * 80)
        logger.exception("Full traceback:")
        return 1


if __name__ == "__main__":
    sys.exit(main())
