"""
Insurance Claim Prompt Configuration  
"""

FIELD_DEFINITIONS = {
    'claim_number': {
        'field_type': 'single',
        'description': 'Insurance claim number'
    },
    
    'patient_name': {
        'field_type': 'single',
        'description': 'Patient name'
    }
}

SYSTEM_PROMPT = """
You are an insurance claim extraction specialist.
"""

OUTPUT_FORMAT = """
Return JSON format with confidence scores.
"""
