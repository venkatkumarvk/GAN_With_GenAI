"""
Business Document Prompt Configuration
"""

FIELD_DEFINITIONS = {
    'vendor_name': {
        'field_type': 'single',
        'description': 'Vendor company name'
    },
    
    'invoice_number': {
        'field_type': 'single',
        'description': 'Invoice number'
    }
}

SYSTEM_PROMPT = """
You are a business document extraction specialist.
"""

OUTPUT_FORMAT = """
Return JSON format with confidence scores.
"""
