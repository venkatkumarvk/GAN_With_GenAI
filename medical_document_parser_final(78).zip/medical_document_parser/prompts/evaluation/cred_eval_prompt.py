"""
Evaluation Prompts - LLM-as-Judge Field-Level Evaluation
=========================================================

UNIVERSAL DESIGN: Only this file changes for new fields/doctypes.
evaluator.py reads rules from here and applies them dynamically.

Rule types (evaluator knows how to apply these):
  - "max_length": value must be <= N chars
  - "min_length": value must be >= N chars
  - "exact_length": value must be exactly N chars
  - "regex": value must match regex pattern
  - "contains": value must contain substring
  - "not_contains": value must NOT contain substring
  - "in_list": value must be one of listed values
  - "capitalized": first letter must be uppercase
  - "all_alpha": only alphabetic chars (+ allowed_chars)
  - "all_digits": only numeric digits
  - "date_format": must match MM/DD/YYYY
  - "state_abbreviation": must be 2-letter US state
  - "email_format": must be valid email
  - "no_duplicates": multi-value field must not have duplicate entries

Each rule has: type, params (optional), score (what to give if FAILS), message
"""


# =============================================================================
# SYSTEM PROMPT FOR LLM JUDGE
# =============================================================================

JUDGE_SYSTEM_PROMPT = """You are a document extraction quality evaluator.
Evaluate each extracted field value against the defined guidelines.

Scoring scale:
  1.0  = Perfect extraction, correct format
  0.75 = Correct value but minor format issue
  0.50 = Value found but wrong format
  0.25 = Partially correct or uncertain
  0.0  = Wrong value, hallucinated, or missing when data exists

Respond ONLY in JSON format:
{"score": 0.0-1.0, "issues": ["list"], "suggestion": "fix"}"""


# =============================================================================
# EVALUATION MODEL CONFIG
# =============================================================================

EVALUATION_CONFIG = {
    "model": "gpt-5",
    "max_tokens": 4000,
    "temperature": 0.0
}


# =============================================================================
# FIELD EVALUATION GUIDELINES - Universal Rule-Based
# =============================================================================
# 
# HOW TO ADD NEW FIELDS:
#   Just add a new entry with rules. evaluator.py applies them automatically.
#
# HOW TO ADD NEW DOCTYPES:
#   Create prompts/evaluation/invoice_eval_prompt.py with same structure.
#   Copy this file, change the field names and rules.
#
# RULE FORMAT:
#   {"type": "rule_type", "score": 0.5, "message": "What's wrong"}
#   {"type": "rule_type", "params": {"key": "value"}, "score": 0.5, "message": "..."}
#
# =============================================================================

FIELD_EVALUATION_GUIDELINES = {

    # =========================================================================
    # SINGLE-VALUE FIELDS
    # =========================================================================

    "first_name": {
        "expected_format": "Capitalized single word, no titles or suffixes",
        "rules": [
            {"type": "capitalized", "score": 0.75, "message": "Name not capitalized"},
            {"type": "all_alpha", "params": {"allowed_chars": "-' "}, "score": 0.50, "message": "Name contains invalid characters"},
            {"type": "not_contains", "params": {"values": ["Dr.", "Mr.", "Mrs.", "Ms.", "Jr.", "Sr.", "III", "IV"]}, "score": 0.50, "message": "Name contains title or suffix"},
            {"type": "max_length", "params": {"max": 50}, "score": 0.25, "message": "Name too long (may contain full name)"}
        ]
    },

    "last_name": {
        "expected_format": "Capitalized word, may include hyphen",
        "rules": [
            {"type": "capitalized", "score": 0.75, "message": "Name not capitalized"},
            {"type": "all_alpha", "params": {"allowed_chars": "-' "}, "score": 0.50, "message": "Name contains invalid characters"},
            {"type": "not_contains", "params": {"values": ["Dr.", "Mr.", "Mrs.", "Ms.", ","]}, "score": 0.50, "message": "Name contains title or comma"}
        ]
    },

    "email": {
        "expected_format": "valid@email.com",
        "rules": [
            {"type": "email_format", "score": 0.0, "message": "Invalid email format"},
            {"type": "not_contains", "params": {"values": [" "]}, "score": 0.25, "message": "Email contains spaces"}
        ]
    },

    "cell": {
        "expected_format": "Phone number (10+ digits)",
        "rules": [
            {"type": "min_length", "params": {"min": 10}, "score": 0.50, "message": "Phone number too short"},
            {"type": "regex", "params": {"pattern": "\\d{3}.*\\d{3}.*\\d{4}"}, "score": 0.50, "message": "Does not match phone format"}
        ]
    },

    "birth_date": {
        "expected_format": "MM/DD/YYYY",
        "rules": [
            {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY format"}
        ]
    },

    "birth_place": {
        "expected_format": "City, State or City, Country",
        "rules": []
    },

    "birth_city": {
        "expected_format": "City name only",
        "rules": [
            {"type": "capitalized", "score": 0.75, "message": "City not capitalized"}
        ]
    },

    "birth_state_province": {
        "expected_format": "2-letter state abbreviation or full state/province name",
        "rules": [
            {"type": "state_abbreviation", "score": 0.75, "message": "Use 2-letter state abbreviation"}
        ]
    },

    "birth_country": {
        "expected_format": "Full country name",
        "rules": [
            {"type": "capitalized", "score": 0.75, "message": "Country not capitalized"},
            {"type": "min_length", "params": {"min": 3}, "score": 0.50, "message": "Use full country name, not abbreviation"}
        ]
    },

    "citizenship": {
        "expected_format": "Full country name",
        "rules": [
            {"type": "capitalized", "score": 0.75, "message": "Not capitalized"},
            {"type": "min_length", "params": {"min": 3}, "score": 0.50, "message": "Use full country name"}
        ]
    },

    "degree": {
        "expected_format": "Medical degree (MD, DO, DDS, etc.)",
        "rules": [
            {"type": "min_length", "params": {"min": 2}, "score": 0.25, "message": "Degree too short"}
        ]
    },

    "gender": {
        "expected_format": "Male or Female",
        "rules": [
            {"type": "in_list", "params": {"values": ["Male", "Female"]}, "score": 0.75, "message": "Use 'Male' or 'Female'"}
        ]
    },

    "ssn": {
        "expected_format": "XXX-XX-XXXX or last 4 digits",
        "rules": [
            {"type": "regex", "params": {"pattern": "^(\\d{3}-\\d{2}-\\d{4}|\\d{9}|\\*{3}-\\*{2}-\\d{4}|\\d{4})$"}, "score": 0.25, "message": "SSN format invalid (expected 9 digits, last 4, or masked)"}
        ]
    },

    # =========================================================================
    # MULTI-VALUE FIELDS (sub-field rules)
    # =========================================================================

    "state_licenses": {
        "expected_format": "Array of license objects",
        "rules": [
            {"type": "no_duplicates", "score": 0.25, "message": "Duplicate license entry"}
        ],
        "sub_field_rules": {
            "license_number": [
                {"type": "min_length", "params": {"min": 3}, "score": 0.25, "message": "License number too short"}
            ],
            "license_state": [
                {"type": "state_abbreviation", "score": 0.50, "message": "Use 2-letter state abbreviation"}
            ],
            "license_issue_date": [
                {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}
            ],
            "license_expiration_date": [
                {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}
            ],
            "license_status": [
                {"type": "in_list", "params": {"values": ["Active", "Inactive", "Expired"]}, "score": 0.75, "message": "Status should be Active, Inactive, or Expired"}
            ]
        }
    },

    "dea_licenses": {
        "expected_format": "Array of DEA objects",
        "rules": [
            {"type": "no_duplicates", "score": 0.25, "message": "Duplicate DEA entry"}
        ],
        "sub_field_rules": {
            "dea_number": [
                {"type": "exact_length", "params": {"length": 9}, "score": 0.25, "message": "DEA number should be 9 characters (2 letters + 7 digits)"}
            ],
            "dea_state": [
                {"type": "state_abbreviation", "score": 0.50, "message": "Use 2-letter state abbreviation"}
            ],
            "dea_issue_date": [
                {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}
            ],
            "dea_expiration_date": [
                {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}
            ]
        }
    },

    "cds_licenses": {
        "expected_format": "Array of CDS objects",
        "rules": [
            {"type": "no_duplicates", "score": 0.25, "message": "Duplicate CDS entry"}
        ],
        "sub_field_rules": {
            "cds_number": [
                {"type": "min_length", "params": {"min": 3}, "score": 0.25, "message": "CDS number too short"}
            ],
            "cds_state": [
                {"type": "state_abbreviation", "score": 0.50, "message": "Use 2-letter state abbreviation"}
            ],
            "cds_issue_date": [
                {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}
            ],
            "cds_expiration_date": [
                {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}
            ]
        }
    },

    "board_certifications": {
        "expected_format": "Array of board certification objects",
        "rules": [
            {"type": "no_duplicates", "score": 0.25, "message": "Duplicate board certification"}
        ],
        "sub_field_rules": {
            "board_name": [
                {"type": "min_length", "params": {"min": 6}, "score": 0.50, "message": "Use full board name, not abbreviation"}
            ],
            "board_specialty": [
                {"type": "min_length", "params": {"min": 3}, "score": 0.50, "message": "Specialty too short"}
            ]
        }
    },

    "other_credentials": {
        "expected_format": "Array of credential objects",
        "rules": [
            {"type": "no_duplicates", "score": 0.25, "message": "Duplicate credential"}
        ],
        "sub_field_rules": {
            "credential_type": [
                {"type": "min_length", "params": {"min": 2}, "score": 0.25, "message": "Credential type too short"}
            ],
            "credential_number": [],
            "credential_issue_date": [
                {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}
            ],
            "credential_expiration_date": [
                {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}
            ]
        }
    },

    "npi": {
        "expected_format": "10-digit NPI number with optional dates",
        "rules": [],
        "sub_field_rules": {
            "npi_number": [
                {"type": "exact_length", "params": {"length": 10}, "score": 0.25, "message": "NPI should be exactly 10 digits"}
            ],
            "npi_issue_date": [
                {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}
            ],
            "npi_expiration_date": [
                {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}
            ]
        }
    },

    "drivers_license": {
        "expected_format": "Driver's license with state and dates",
        "rules": [],
        "sub_field_rules": {
            "dl_number": [
                {"type": "min_length", "params": {"min": 3}, "score": 0.25, "message": "License number too short"}
            ],
            "dl_state": [
                {"type": "state_abbreviation", "score": 0.50, "message": "Use 2-letter state abbreviation"}
            ],
            "dl_issue_date": [
                {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}
            ],
            "dl_expiration_date": [
                {"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}
            ]
        }
    },

    "bls_certification": {
        "expected_format": "BLS certification with dates",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate BLS entry"}],
        "sub_field_rules": {
            "bls_issue_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}],
            "bls_expiration_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    },

    "tb_vaccine": {
        "expected_format": "TB test/vaccine with dates",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate TB entry"}],
        "sub_field_rules": {
            "tb_issue_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}],
            "tb_expiration_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    },

    "tdap_immunization": {
        "expected_format": "TDAP immunization with dates",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate TDAP entry"}],
        "sub_field_rules": {
            "tdap_issue_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}],
            "tdap_expiration_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    },

    "flu_vaccine": {
        "expected_format": "Flu vaccine with dates",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate flu entry"}],
        "sub_field_rules": {
            "flu_issue_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}],
            "flu_expiration_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    },

    "flu_declination": {
        "expected_format": "Flu declination with dates",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate declination entry"}],
        "sub_field_rules": {
            "flu_declination_issue_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}],
            "flu_declination_expiration_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    },

    "background_check": {
        "expected_format": "Background check with dates",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate background check"}],
        "sub_field_rules": {
            "bg_issue_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}],
            "bg_expiration_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    },

    "cnim_license": {
        "expected_format": "CNIM license with dates",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate CNIM entry"}],
        "sub_field_rules": {
            "cnim_issue_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}],
            "cnim_expiration_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    },

    "covid_vaccine": {
        "expected_format": "COVID vaccine with dates",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate COVID vaccine"}],
        "sub_field_rules": {
            "covid_issue_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}],
            "covid_expiration_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    },

    "hepb_vaccine": {
        "expected_format": "Hepatitis B vaccine with dates",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate HepB vaccine"}],
        "sub_field_rules": {
            "hepb_issue_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}],
            "hepb_expiration_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    },

    "mmr_vaccine": {
        "expected_format": "MMR vaccine with dates",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate MMR vaccine"}],
        "sub_field_rules": {
            "mmr_issue_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}],
            "mmr_expiration_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    },

    "varicella_vaccine": {
        "expected_format": "Varicella vaccine with dates",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate varicella vaccine"}],
        "sub_field_rules": {
            "varicella_issue_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}],
            "varicella_expiration_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    },

    "malpractice_claims": {
        "expected_format": "Malpractice claims with incident date",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate malpractice claim"}],
        "sub_field_rules": {
            "malpractice_incident_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    },

    "file_uploaded": {
        "expected_format": "Yes or No",
        "rules": [
            {"type": "in_list", "params": {"values": ["Yes", "No", "Uploaded", "Submitted"]}, "score": 0.75, "message": "Should be Yes/No or equivalent"}
        ]
    },

    "insurance": {
        "expected_format": "Insurance details with name, address, policy, dates",
        "rules": [{"type": "no_duplicates", "score": 0.25, "message": "Duplicate insurance entry"}],
        "sub_field_rules": {
            "insurance_name": [{"type": "min_length", "params": {"min": 3}, "score": 0.25, "message": "Insurance name too short"}],
            "insurance_state": [{"type": "state_abbreviation", "score": 0.50, "message": "Use 2-letter state abbreviation"}],
            "insurance_email": [{"type": "email_format", "score": 0.50, "message": "Invalid email format"}],
            "insurance_policy_number": [{"type": "min_length", "params": {"min": 3}, "score": 0.25, "message": "Policy number too short"}],
            "insurance_expiration_date": [{"type": "date_format", "score": 0.50, "message": "Date should be MM/DD/YYYY"}]
        }
    }
}


# =============================================================================
# JUDGE OUTPUT FORMAT
# =============================================================================

JUDGE_OUTPUT_FORMAT = """{
    "score": 0.0-1.0,
    "issues": ["list of issues"],
    "suggestion": "how to fix"
}"""
