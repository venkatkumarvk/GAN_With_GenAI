"""
Logger Helper - Production Logging
====================================

Centralized logging for the medical document parser.

Features:
  - Dual output: timestamped log file + console
  - Structured format: timestamp | module | level | message
  - Processing context tracker: provider/document/field tracking
  - Duration tracking for performance monitoring
  - Summary report at end of run
  - JSON log for machine parsing (optional)

Log file output example:
  2025-03-24 10:15:32 | main | INFO | [STEP 1/6] Loading configuration
  2025-03-24 10:15:33 | main | INFO | [STEP 4/6] Initializing Azure services
  2025-03-24 10:15:35 | text_rag | INFO | [Provider: SMITH-JOHN] [Doc: license.pdf] [Field: 3/46 email] RAG: 3 chunks found
  2025-03-24 10:15:36 | text_rag | INFO | [Provider: SMITH-JOHN] [Doc: license.pdf] [Field: 3/46 email] Result: john@hospital.com (conf: 0.95) [1.2s]
  2025-03-24 10:16:00 | main | INFO | [SUMMARY] Providers: 5 | Documents: 23 | Fields: 1058 | Cost: $3.42 | Duration: 28s

Usage:
    from utils.logger_helper import setup_logger, get_logger, ProcessingContext

    # Call once at startup (main.py)
    log_file = setup_logger(log_level="INFO", log_dir="logs")
    logger = get_logger(__name__)

    # Track processing context
    ctx = ProcessingContext()
    ctx.set_provider("SMITH-JOHN")
    ctx.set_document("license.pdf")
    ctx.set_field(3, 46, "email")
    logger.info(f"{ctx} RAG: 3 chunks found")
    logger.info(f"{ctx} Result: john@hospital.com (conf: 0.95) [{ctx.field_elapsed():.1f}s]")
"""

import os
import sys
import json
import logging
import time
from datetime import datetime
from typing import Optional, Dict


# =============================================================================
# MODULE STATE
# =============================================================================

_configured = False
_log_filename = None
_json_log_filename = None
_start_time = None


# =============================================================================
# PROCESSING CONTEXT TRACKER
# =============================================================================

class ProcessingContext:
    """
    Tracks current processing state for structured log messages.
    
    Usage:
        ctx = ProcessingContext()
        ctx.set_provider("SMITH-JOHN")
        ctx.set_document("license.pdf")
        ctx.set_field(3, 46, "email")
        
        logger.info(f"{ctx} Extracted value")
        # Output: [Provider: SMITH-JOHN] [Doc: license.pdf] [Field: 3/46 email] Extracted value
    """
    
    def __init__(self):
        self.provider = None
        self.document = None
        self.field_index = None
        self.field_total = None
        self.field_name = None
        self._provider_start = None
        self._document_start = None
        self._field_start = None
        
        # Counters for summary
        self.total_providers = 0
        self.total_documents = 0
        self.total_fields_extracted = 0
        self.total_errors = 0
        self.high_confidence_count = 0
        self.low_confidence_count = 0
    
    def set_provider(self, name: str):
        """Set current provider being processed."""
        self.provider = name
        self.document = None
        self.field_name = None
        self._provider_start = time.time()
        self.total_providers += 1
    
    def set_document(self, name: str):
        """Set current document being processed."""
        self.document = name
        self.field_name = None
        self._document_start = time.time()
        self.total_documents += 1
    
    def set_field(self, index: int, total: int, name: str):
        """Set current field being extracted."""
        self.field_index = index
        self.field_total = total
        self.field_name = name
        self._field_start = time.time()
        self.total_fields_extracted += 1
    
    def record_error(self):
        """Record an extraction error."""
        self.total_errors += 1
    
    def record_confidence(self, confidence: float, threshold: float = 0.70):
        """Record confidence result for summary."""
        if confidence >= threshold:
            self.high_confidence_count += 1
        else:
            self.low_confidence_count += 1
    
    def provider_elapsed(self) -> float:
        """Seconds since current provider started."""
        if self._provider_start:
            return time.time() - self._provider_start
        return 0.0
    
    def document_elapsed(self) -> float:
        """Seconds since current document started."""
        if self._document_start:
            return time.time() - self._document_start
        return 0.0
    
    def field_elapsed(self) -> float:
        """Seconds since current field started."""
        if self._field_start:
            return time.time() - self._field_start
        return 0.0
    
    def get_summary(self) -> Dict:
        """Get processing summary statistics."""
        return {
            'total_providers': self.total_providers,
            'total_documents': self.total_documents,
            'total_fields': self.total_fields_extracted,
            'total_errors': self.total_errors,
            'high_confidence': self.high_confidence_count,
            'low_confidence': self.low_confidence_count,
            'total_duration_seconds': time.time() - _start_time if _start_time else 0
        }
    
    def __str__(self) -> str:
        """Format context as log prefix."""
        parts = []
        if self.provider:
            parts.append(f"[Provider: {self.provider}]")
        if self.document:
            parts.append(f"[Doc: {self.document}]")
        if self.field_name:
            parts.append(f"[Field: {self.field_index}/{self.field_total} {self.field_name}]")
        return " ".join(parts)


# =============================================================================
# LOGGER SETUP
# =============================================================================

def setup_logger(
    log_level: str = "INFO",
    log_dir: str = "logs",
    log_prefix: str = "app",
    enable_json_log: bool = False
) -> str:
    """
    Configure root logger with file + console handlers.
    
    Call this ONCE at application startup (in main.py).
    All modules using logging.getLogger(__name__) will
    automatically use this configuration.
    
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        log_dir: Directory for log files
        log_prefix: Prefix for log filename
        enable_json_log: Also write JSON-formatted log (for machine parsing)
    
    Returns:
        Log file path
    """
    global _configured, _log_filename, _json_log_filename, _start_time
    
    if _configured:
        return _log_filename
    
    _start_time = time.time()
    
    # Create logs directory
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # Generate timestamped filenames
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    _log_filename = os.path.join(log_dir, f"{log_prefix}_{timestamp}.log")
    
    # Fix encoding for Windows
    if sys.platform == 'win32':
        if sys.stdout.encoding != 'utf-8':
            sys.stdout.reconfigure(encoding='utf-8')
        if sys.stderr.encoding != 'utf-8':
            sys.stderr.reconfigure(encoding='utf-8')
    
    # Configure root logger
    level = getattr(logging, log_level.upper(), logging.INFO)
    
    # Detailed format for file (includes module name)
    file_formatter = logging.Formatter(
        '%(asctime)s | %(name)s | %(levelname)-7s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Cleaner format for console (no module name, less clutter)
    console_formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-7s | %(message)s',
        datefmt='%H:%M:%S'
    )
    
    # File handler (detailed)
    file_handler = logging.FileHandler(_log_filename, encoding='utf-8')
    file_handler.setLevel(level)
    file_handler.setFormatter(file_formatter)
    
    # Console handler (clean)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(console_formatter)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)
    
    # Optional JSON log handler
    if enable_json_log:
        _json_log_filename = os.path.join(
            log_dir, f"{log_prefix}_{timestamp}.jsonl"
        )
        json_handler = logging.FileHandler(_json_log_filename, encoding='utf-8')
        json_handler.setLevel(level)
        json_handler.setFormatter(JsonFormatter())
        root_logger.addHandler(json_handler)
    
    _configured = True
    
    # Log startup info
    logger = logging.getLogger(__name__)
    logger.info("=" * 80)
    logger.info("MEDICAL DOCUMENT PARSER - LOG STARTED")
    logger.info("=" * 80)
    logger.info(f"Timestamp  : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"Log file   : {_log_filename}")
    logger.info(f"Log level  : {log_level}")
    if _json_log_filename:
        logger.info(f"JSON log   : {_json_log_filename}")
    logger.info("=" * 80)
    
    return _log_filename


class JsonFormatter(logging.Formatter):
    """Format log records as JSON lines (one JSON object per line)."""
    
    def format(self, record):
        log_entry = {
            'timestamp': datetime.fromtimestamp(record.created).strftime(
                '%Y-%m-%d %H:%M:%S.%f'
            )[:-3],
            'level': record.levelname,
            'module': record.name,
            'message': record.getMessage(),
            'line': record.lineno
        }
        if record.exc_info and record.exc_info[0]:
            log_entry['exception'] = self.formatException(record.exc_info)
        return json.dumps(log_entry)


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def get_logger(name: str) -> logging.Logger:
    """
    Get a named logger instance.
    
    Args:
        name: Logger name (typically __name__)
    
    Returns:
        logging.Logger instance
    """
    if not _configured:
        # Don't auto-setup with default prefix
        # main.py will call setup_logger() with correct prefix
        pass
    return logging.getLogger(name)


def get_log_filename() -> Optional[str]:
    """Get the current log file path."""
    return _log_filename


def print_section(title: str, char: str = "=", logger: logging.Logger = None):
    """Print a formatted section header to log."""
    if logger is None:
        logger = logging.getLogger()
    logger.info("")
    logger.info(char * 80)
    logger.info(title)
    logger.info(char * 80)


def log_summary(ctx: ProcessingContext, cost_summary: Dict = None,
                logger: logging.Logger = None):
    """
    Log final processing summary.
    
    Call at end of main() to write a summary block.
    
    Args:
        ctx: ProcessingContext with accumulated stats
        cost_summary: Cost tracker summary dict
        logger: Logger instance
    """
    if logger is None:
        logger = logging.getLogger()
    
    summary = ctx.get_summary()
    duration = summary['total_duration_seconds']
    
    logger.info("")
    logger.info("=" * 80)
    logger.info("PROCESSING SUMMARY")
    logger.info("=" * 80)
    logger.info(f"  Providers processed : {summary['total_providers']}")
    logger.info(f"  Documents processed : {summary['total_documents']}")
    logger.info(f"  Fields extracted    : {summary['total_fields']}")
    logger.info(f"  Errors              : {summary['total_errors']}")
    logger.info(f"  High confidence     : {summary['high_confidence']}")
    logger.info(f"  Low confidence      : {summary['low_confidence']}")
    logger.info(f"  Total duration      : {duration:.1f}s ({duration/60:.1f}m)")
    
    if cost_summary:
        logger.info("-" * 80)
        logger.info("COST BREAKDOWN")
        logger.info("-" * 80)
        total = cost_summary.get('total', 0)
        logger.info(f"  OCR cost            : ${cost_summary.get('breakdown', {}).get('ocr', 0):.4f}")
        logger.info(f"  Embedding cost      : ${cost_summary.get('breakdown', {}).get('embedding', 0):.4f}")
        logger.info(f"  GPT cost            : ${cost_summary.get('breakdown', {}).get('gpt4o', 0):.4f}")
        logger.info(f"  TOTAL COST          : ${total:.4f}")
        
        if summary['total_documents'] > 0:
            logger.info(f"  Cost per document   : ${total / summary['total_documents']:.4f}")
    
    logger.info("=" * 80)

