# File Type Support Documentation

## ✅ SUPPORTED FILE TYPES

### **Documents**
| Format | Extension | Description |
|--------|-----------|-------------|
| **PDF** | .pdf | Portable Document Format |
| **Word** | .docx, .doc | Microsoft Word documents |
| **Text** | .txt | Plain text files |

### **Images**
| Format | Extension | Description |
|--------|-----------|-------------|
| **JPEG** | .jpg, .jpeg | Joint Photographic Experts Group |
| **PNG** | .png | Portable Network Graphics |
| **GIF** | .gif | Graphics Interchange Format |
| **BMP** | .bmp | Bitmap Image File |
| **TIFF** | .tiff, .tif | Tagged Image File Format |
| **WebP** | .webp | Web Picture format |

---

## ❌ UNSUPPORTED FILE TYPES (Will Be Skipped)

### **Spreadsheets**
- .xlsx, .xls (Microsoft Excel)
- .csv (Comma Separated Values) *
- .ods (OpenDocument Spreadsheet)

*Note: CSV files can be read as text, but table structure is lost

### **Presentations**
- .pptx, .ppt (Microsoft PowerPoint)
- .odp (OpenDocument Presentation)

### **Multimedia**
- .mp3, .wav, .m4a (Audio)
- .mp4, .avi, .mov, .mkv (Video)

### **Archives**
- .zip, .rar, .7z, .tar, .gz

### **Executables**
- .exe, .dll, .app, .dmg

### **Other**
- .xml, .json (Structured data - no visual rendering)
- .html, .htm (Web pages - requires rendering)
- .rtf (Rich Text Format - limited support)
- Any other file types not explicitly listed as supported

---

## 🔍 HOW FILE TYPE DETECTION WORKS

### **Automatic Detection:**

```python
from documentintelligence_ocr import DocumentIntelligenceOCR

ocr = DocumentIntelligenceOCR(endpoint, key)

# Check if file is supported
is_supported = ocr.is_supported("license.pdf")  # True
is_supported = ocr.is_supported("data.xlsx")    # False

# Get file type
file_type = ocr.get_file_type("photo.jpg")      # 'image'
file_type = ocr.get_file_type("license.pdf")    # 'pdf'
file_type = ocr.get_file_type("data.xlsx")      # 'unsupported'
```

### **File Type Categories:**

| Category | Types | Processing Method |
|----------|-------|-------------------|
| **pdf** | .pdf | Azure Document Intelligence |
| **image** | .jpg, .png, .gif, .bmp, .tiff, .webp | Azure Document Intelligence |
| **document** | .docx, .doc | Azure Document Intelligence |
| **text** | .txt | Direct text extraction |
| **unsupported** | All others | Skipped (logged) |

---

## 📊 PROCESSING BEHAVIOR

### **Supported Files:**

```
Input: license.pdf
↓
Check: is_supported("license.pdf") → True
↓
Extract: Azure Document Intelligence OCR
↓
Result: Text content extracted ✅
↓
Continue: Field extraction
```

### **Unsupported Files:**

```
Input: spreadsheet.xlsx
↓
Check: is_supported("spreadsheet.xlsx") → False
↓
Log: "⏭️ Skipping spreadsheet.xlsx: unsupported file type"
↓
Result: File skipped (NO ERROR!) ✅
↓
Continue: Next file
```

---

## 📝 LOG OUTPUT EXAMPLES

### **Supported File:**
```
[1/100] license.pdf
  File type: pdf
  Mode: TEXT (text length: 2547 chars)
✓ Successfully extracted
```

### **Unsupported File:**
```
[2/100] data.xlsx
⏭️  Skipping data.xlsx: unsupported file type (unsupported)
```

### **Mixed Files:**
```
Processing Provider1/Licenses...
[1/10] state_license.pdf     → ✓ Processed (pdf)
[2/10] dea_card.jpg          → ✓ Processed (image)
[3/10] notes.txt             → ✓ Processed (text)
[4/10] spreadsheet.xlsx      → ⏭️  Skipped (unsupported)
[5/10] backup.zip            → ⏭️  Skipped (unsupported)
[6/10] certificate.png       → ✓ Processed (image)
[7/10] document.docx         → ✓ Processed (document)
[8/10] photo.bmp             → ✓ Processed (image)
[9/10] video.mp4             → ⏭️  Skipped (unsupported)
[10/10] scan.tiff            → ✓ Processed (image)

Results: 7 processed, 3 skipped
```

---

## 📈 STATISTICS

### **OCR Statistics (in logs):**

```
===========================================================
OCR STATISTICS
===========================================================
Documents processed: 145
Pages processed: 387
Unsupported files: 8
Unsupported file list:
  - Provider1/Licenses/backup.xlsx
  - Provider1/Personal/archive.zip
  - Provider2/Education/video.mp4
  - Provider2/Work_History/audio.mp3
  - Provider3/Insurance/data.csv
  - Provider3/References/presentation.pptx
  - Provider4/Licenses/script.exe
  - Provider5/Personal/code.py
===========================================================
```

### **Cost Summary (in JSON):**

```json
{
  "total_documents_processed": 145,
  "total_documents_skipped": 8,
  "ocr_statistics": {
    "total_documents_processed": 145,
    "total_pages_processed": 387,
    "unsupported_files_count": 8,
    "unsupported_files": [
      "Provider1/Licenses/backup.xlsx",
      "Provider1/Personal/archive.zip",
      ...
    ]
  }
}
```

---

## 🎯 BEST PRACTICES

### **1. Organize by File Type**

```
✅ GOOD:
Provider1/
├── Licenses/
│   ├── state_license.pdf      ← Supported
│   ├── dea_card.jpg           ← Supported
│   └── certificate.png        ← Supported
└── Documents/
    ├── backup_data.xlsx       ← Will be skipped
    └── archive.zip            ← Will be skipped
```

### **2. Pre-Filter Files**

Before uploading to Azure Blob:
```bash
# Upload only supported types
find . -type f \( -name "*.pdf" -o -name "*.jpg" -o -name "*.png" -o -name "*.docx" \) -exec az storage blob upload ...
```

### **3. Monitor Unsupported Files**

Check logs regularly:
```bash
grep "⏭️  Skipping" logs/extraction_*.log
```

Review cost summary:
```bash
cat outputcontainer/estimatecost/summary_*.json | jq '.ocr_statistics.unsupported_files'
```

---

## 🔧 CONFIGURATION

### **No Configuration Needed!**

File type detection is automatic. No settings in `config.json` required.

### **Optional: Custom File Type Handling**

If you need to add support for custom file types, edit `documentintelligence_ocr.py`:

```python
SUPPORTED_EXTENSIONS = {
    # Add your custom type
    'custom': 'application/custom',
    
    # Existing types...
    'pdf': 'application/pdf',
    'jpg': 'image/jpeg',
    ...
}
```

---

## ❓ FAQ

### **Q: Can I convert unsupported files?**
**A:** Yes! Convert before upload:
- Excel → PDF: Use Excel "Save as PDF"
- PowerPoint → PDF: Use PowerPoint "Save as PDF"  
- Video frames → Images: Extract key frames as JPG/PNG

### **Q: What if I upload unsupported files?**
**A:** System will:
1. Detect unsupported file
2. Log warning message
3. Skip file (no error!)
4. Continue with next file
5. Report in statistics

### **Q: Do unsupported files cost money?**
**A:** No! Skipped files:
- ✅ No OCR cost
- ✅ No embedding cost
- ✅ No GPT-4o cost
- ✅ $0.00 total cost

### **Q: How do I know which files were skipped?**
**A:** Check three places:
1. **Logs:** `logs/extraction_*.log` (search "Skipping")
2. **Cost Summary:** `estimatecost/summary_*.json` → `ocr_statistics.unsupported_files`
3. **Console Output:** During execution

---

## ✅ SUMMARY

| Aspect | Behavior |
|--------|----------|
| **Supported files** | Processed normally ✅ |
| **Unsupported files** | Skipped (logged) ⏭️ |
| **Errors** | None! No crashes ✅ |
| **Cost** | Only for supported files ✅ |
| **Statistics** | Tracked in logs + JSON ✅ |
| **Configuration** | Automatic (no setup) ✅ |

**System is production-ready with graceful handling of ALL file types!** 🎉
