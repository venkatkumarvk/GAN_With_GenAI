"""
Document Intelligence OCR Module
=================================
Centralized OCR processing for all document types
Uses: azure-ai-documentintelligence==1.0.0b4

Supports: PDF, DOCX, DOC, JPG, JPEG, PNG, GIF, BMP, TIFF, WEBP, TXT

Features:
- Multi-format support
- Base64 encoding for v1.0.0b4
- Flexible response parsing
- Unsupported file detection (no errors!)
- Image preprocessing
- Error handling
- Cost tracking
"""

import logging
from typing import Tuple, Optional
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential
from PIL import Image
from io import BytesIO
import os
import base64


class DocumentIntelligenceOCR:
    """
    Comprehensive OCR processor for multiple document formats
    Compatible with azure-ai-documentintelligence==1.0.0b4
    """
    
    # Supported file extensions
    SUPPORTED_EXTENSIONS = {
        # Documents
        'pdf': 'application/pdf',
        'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'doc': 'application/msword',
        
        # Images
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'png': 'image/png',
        'gif': 'image/gif',
        'bmp': 'image/bmp',
        'tiff': 'image/tiff',
        'tif': 'image/tiff',
        'webp': 'image/webp',
        
        # Text
        'txt': 'text/plain'
    }
    
    def __init__(self, endpoint: str, key: str):
        """
        Initialize Document Intelligence client (v1.0.0b4)
        
        Args:
            endpoint: Azure Document Intelligence endpoint
            key: Azure Document Intelligence key
        """
        self.client = DocumentIntelligenceClient(
            endpoint=endpoint, 
            credential=AzureKeyCredential(key)
        )
        self.logger = logging.getLogger(__name__)
        
        # Statistics
        self.total_pages_processed = 0
        self.total_docs_processed = 0
        self.unsupported_files = []
    
    def is_supported(self, filename: str) -> bool:
        """Check if file type is supported"""
        extension = self._get_extension(filename)
        return extension in self.SUPPORTED_EXTENSIONS
    
    def get_file_type(self, filename: str) -> str:
        """Get file type category"""
        extension = self._get_extension(filename)
        
        if extension == 'pdf':
            return 'pdf'
        elif extension in ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tiff', 'tif', 'webp']:
            return 'image'
        elif extension in ['docx', 'doc']:
            return 'document'
        elif extension == 'txt':
            return 'text'
        else:
            return 'unsupported'
    
    def extract_text(self, document_bytes: bytes, filename: str) -> Tuple[str, bool, str]:
        """
        Extract text from document
        
        Args:
            document_bytes: Document content as bytes
            filename: Name of the file
            
        Returns:
            Tuple of (extracted_text, is_supported, file_type)
        """
        file_type = self.get_file_type(filename)
        
        # Check if supported
        if file_type == 'unsupported':
            extension = self._get_extension(filename)
            self.logger.warning(f"⚠️  Unsupported file type: {filename} (.{extension})")
            self.unsupported_files.append(filename)
            return "", False, "unsupported"
        
        # Process based on file type
        try:
            if file_type == 'text':
                text = self._extract_from_text(document_bytes)
            else:
                text = self._extract_with_document_intelligence(document_bytes, filename)
            
            self.total_docs_processed += 1
            self.logger.info(f"✓ Extracted {len(text)} chars from {filename} ({file_type})")
            
            return text, True, file_type
            
        except Exception as e:
            self.logger.error(f"✗ OCR error for {filename}: {e}")
            return "", False, file_type
    
    def _extract_with_document_intelligence(self, document_bytes: bytes, filename: str) -> str:
        """
        Extract text using Azure Document Intelligence v1.0.0b4
        Handles different response formats flexibly
        
        Args:
            document_bytes: Document content
            filename: File name for logging
            
        Returns:
            Extracted text
        """
        try:
            # Preprocess image if needed
            file_type = self.get_file_type(filename)
            if file_type == 'image':
                document_bytes = self._preprocess_image(document_bytes, filename)
            
            # Convert to base64 (for v1.0.0b4)
            base64_source = base64.b64encode(document_bytes).decode('utf-8')
            
            # Call Document Intelligence
            poller = self.client.begin_analyze_document(
                model_id="prebuilt-read",
                analyze_request={
                    "base64Source": base64_source
                }
            )
            result = poller.result()
            
            # Debug: Log result type and attributes
            self.logger.debug(f"Result type: {type(result)}")
            self.logger.debug(f"Result attributes: {dir(result)}")
            
            # Extract text - try multiple approaches
            text_content = ""
            page_count = 0
            
            # Approach 1: Try result.pages
            if hasattr(result, 'pages') and result.pages:
                self.logger.debug("Using result.pages")
                for page in result.pages:
                    page_count += 1
                    if hasattr(page, 'lines') and page.lines:
                        for line in page.lines:
                            if hasattr(line, 'content'):
                                text_content += line.content + "\n"
            
            # Approach 2: Try result.content (direct text)
            elif hasattr(result, 'content') and result.content:
                self.logger.debug("Using result.content")
                text_content = result.content
                page_count = 1
            
            # Approach 3: Try result as dict
            elif isinstance(result, dict):
                self.logger.debug("Result is dict, trying to parse")
                if 'pages' in result:
                    for page in result['pages']:
                        page_count += 1
                        if 'lines' in page:
                            for line in page['lines']:
                                text_content += line.get('content', '') + "\n"
                elif 'content' in result:
                    text_content = result['content']
                    page_count = 1
            
            # Approach 4: Try result.analyze_result (nested structure)
            elif hasattr(result, 'analyze_result'):
                self.logger.debug("Using result.analyze_result")
                analyze_result = result.analyze_result
                if hasattr(analyze_result, 'pages') and analyze_result.pages:
                    for page in analyze_result.pages:
                        page_count += 1
                        if hasattr(page, 'lines') and page.lines:
                            for line in page.lines:
                                if hasattr(line, 'content'):
                                    text_content += line.content + "\n"
            
            # Fallback: Convert result to string and log
            else:
                self.logger.warning(f"Unknown result format. Result: {str(result)[:500]}")
                text_content = str(result)
                page_count = 1
            
            self.total_pages_processed += page_count
            self.logger.debug(f"  Pages processed: {page_count}")
            
            return text_content.strip()
            
        except Exception as e:
            self.logger.error(f"Document Intelligence error: {e}", exc_info=True)
            raise
    
    def _extract_from_text(self, document_bytes: bytes) -> str:
        """Extract text from plain text file"""
        try:
            text = document_bytes.decode('utf-8')
            return text
        except UnicodeDecodeError:
            try:
                text = document_bytes.decode('latin-1')
                return text
            except Exception as e:
                self.logger.warning(f"Text decoding error: {e}")
                return ""
    
    def _preprocess_image(self, image_bytes: bytes, filename: str) -> bytes:
        """Preprocess image for better OCR quality"""
        try:
            img = Image.open(BytesIO(image_bytes))
            
            if img.mode not in ('RGB', 'L'):
                img = img.convert('RGB')
            
            max_dimension = 4096
            if img.width > max_dimension or img.height > max_dimension:
                ratio = min(max_dimension / img.width, max_dimension / img.height)
                new_size = (int(img.width * ratio), int(img.height * ratio))
                img = img.resize(new_size, Image.Resampling.LANCZOS)
                self.logger.debug(f"  Resized image: {new_size}")
            
            output = BytesIO()
            img.save(output, format='PNG', optimize=True)
            return output.getvalue()
            
        except Exception as e:
            self.logger.warning(f"Image preprocessing failed: {e}, using original")
            return image_bytes
    
    def _get_extension(self, filename: str) -> str:
        """Get file extension in lowercase without dot"""
        _, ext = os.path.splitext(filename)
        return ext.lower().lstrip('.')
    
    def get_statistics(self) -> dict:
        """Get OCR processing statistics"""
        return {
            'total_documents_processed': self.total_docs_processed,
            'total_pages_processed': self.total_pages_processed,
            'unsupported_files_count': len(self.unsupported_files),
            'unsupported_files': self.unsupported_files
        }
    
    def log_statistics(self):
        """Log OCR statistics"""
        stats = self.get_statistics()
        self.logger.info("="*60)
        self.logger.info("OCR STATISTICS")
        self.logger.info("="*60)
        self.logger.info(f"Documents processed: {stats['total_documents_processed']}")
        self.logger.info(f"Pages processed: {stats['total_pages_processed']}")
        self.logger.info(f"Unsupported files: {stats['unsupported_files_count']}")
        if stats['unsupported_files']:
            self.logger.info("Unsupported file list:")
            for f in stats['unsupported_files']:
                self.logger.info(f"  - {f}")
        self.logger.info("="*60)
    
    def reset_statistics(self):
        """Reset statistics counters"""
        self.total_pages_processed = 0
        self.total_docs_processed = 0
        self.unsupported_files = []


def create_ocr_manager(endpoint: str, key: str) -> DocumentIntelligenceOCR:
    """Create OCR manager instance"""
    return DocumentIntelligenceOCR(endpoint, key)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("="*60)
    print("DOCUMENT INTELLIGENCE OCR v1.0.0b4")
    print("Flexible response parsing for different API formats")
    print("="*60)
    
    print("\n✅ SUPPORTED FILE TYPES:")
    print("-"*60)
    print("\n📄 Documents: PDF, Word, Text")
    print("🖼️  Images: JPEG, PNG, GIF, BMP, TIFF, WebP")
    print("❌ Unsupported: Excel, PowerPoint, Audio, Video, etc.")
    
    print("\n" + "="*60)
    print("Features:")
    print("  - Base64 encoding for document submission")
    print("  - Flexible response parsing (4 approaches)")
    print("  - Debug logging to identify correct format")
    print("="*60)
