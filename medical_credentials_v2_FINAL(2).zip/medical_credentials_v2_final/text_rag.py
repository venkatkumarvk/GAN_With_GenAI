"""
Text RAG Extraction
==================
Uses text-only RAG for document extraction
"""

import logging
from typing import Dict, List
import json


def text_rag_extraction(
    openai_manager,
    search_manager,
    index_name: str,
    provider: str,
    document_text: str,
    prompt: str,
    top_k: int = 3
) -> Dict:
    """
    Extract fields using text-based RAG
    
    Args:
        openai_manager: OpenAI manager instance
        search_manager: Search manager instance
        index_name: Name of search index
        provider: Provider name for filtering
        document_text: Text content to extract from
        prompt: Extraction prompt
        top_k: Number of RAG examples
        
    Returns:
        Dict with extracted fields or None
    """
    logger = logging.getLogger(__name__)
    
    try:
        # Generate embedding for document
        query_vector = openai_manager.get_embedding(document_text[:2000])
        if not query_vector:
            logger.error("Failed to generate embedding")
            return None
        
        # Vector search with provider filter
        filter_expr = f"provider eq '{provider}'"
        similar_docs = search_manager.vector_search(
            index_name=index_name,
            query_vector=query_vector,
            top_k=top_k,
            filter_expression=filter_expr
        )
        
        logger.info(f"Found {len(similar_docs)} similar documents for RAG")
        
        # Build final prompt with RAG examples
        final_prompt = prompt
        if similar_docs:
            final_prompt += "\n\n## SIMILAR DOCUMENTS (for reference):\n"
            for idx, doc in enumerate(similar_docs, 1):
                final_prompt += f"\n### Example {idx}:\n{doc['content'][:500]}...\n"
        
        final_prompt += f"\n\n## CURRENT DOCUMENT TO EXTRACT:\n{document_text}\n"
        final_prompt += "\nReturn ONLY the JSON object with all fields. Use 'NA' for missing values."
        
        # Call GPT-4o
        messages = [
            {"role": "system", "content": "You are an expert medical credentialing specialist."},
            {"role": "user", "content": final_prompt}
        ]
        
        response = openai_manager.chat_completion(messages, temperature=0.0, max_tokens=4000)
        
        if not response:
            logger.error("No response from GPT-4o")
            return None
        
        # Parse JSON response
        try:
            # Remove markdown if present
            if "```json" in response:
                response = response.split("```json")[1].split("```")[0].strip()
            elif "```" in response:
                response = response.split("```")[1].split("```")[0].strip()
            
            extracted_data = json.loads(response)
            return extracted_data
        except json.JSONDecodeError as e:
            logger.error(f"JSON parse error: {e}\nResponse: {response[:500]}")
            return None
            
    except Exception as e:
        logger.error(f"Text RAG extraction error: {e}")
        return None
