"""
Multimodal RAG Extraction
========================
Uses vision + text RAG for document extraction
"""

import logging
from typing import Dict, List
import json
import base64


def multimodal_rag_extraction(
    openai_manager,
    search_manager,
    index_name: str,
    provider: str,
    document_image_base64: str,
    prompt: str,
    top_k: int = 3
) -> Dict:
    """
    Extract fields using multimodal (vision) RAG
    
    Args:
        openai_manager: OpenAI manager instance
        search_manager: Search manager instance
        index_name: Name of search index
        provider: Provider name for filtering
        document_image_base64: Base64 encoded image
        prompt: Extraction prompt
        top_k: Number of RAG examples
        
    Returns:
        Dict with extracted fields or None
    """
    logger = logging.getLogger(__name__)
    
    try:
        # For multimodal, we can't generate embedding from image directly
        # So we'll search based on provider only
        filter_expr = f"provider eq '{provider}'"
        
        # Get random samples from provider
        similar_docs = search_manager.vector_search(
            index_name=index_name,
            query_vector=[0.0] * 3072,  # Dummy vector
            top_k=top_k,
            filter_expression=filter_expr
        )
        
        logger.info(f"Found {len(similar_docs)} documents for multimodal RAG")
        
        # Build multimodal prompt
        messages = [
            {"role": "system", "content": "You are an expert medical credentialing specialist."}
        ]
        
        # Add text examples if available
        if similar_docs:
            example_text = "## SIMILAR DOCUMENTS (for reference):\n"
            for idx, doc in enumerate(similar_docs, 1):
                example_text += f"\n### Example {idx}:\n{doc['content'][:300]}...\n"
            messages.append({"role": "user", "content": example_text})
        
        # Add current document image
        messages.append({
            "role": "user",
            "content": [
                {"type": "text", "text": prompt + "\n\nExtract from this document image:"},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{document_image_base64}"}
                }
            ]
        })
        
        # Call GPT-4o with vision
        response = openai_manager.chat_completion(messages, temperature=0.0, max_tokens=4000)
        
        if not response:
            logger.error("No response from GPT-4o vision")
            return None
        
        # Parse JSON response
        try:
            if "```json" in response:
                response = response.split("```json")[1].split("```")[0].strip()
            elif "```" in response:
                response = response.split("```")[1].split("```")[0].strip()
            
            extracted_data = json.loads(response)
            return extracted_data
        except json.JSONDecodeError as e:
            logger.error(f"JSON parse error: {e}\nResponse: {response[:500]}")
            return None
            
    except Exception as e:
        logger.error(f"Multimodal RAG extraction error: {e}")
        return None
