"""
Azure Helper Classes for Document Processing
============================================
Manages: Blob Storage, OpenAI, Azure Search

NOTE: OCR is now handled by separate documentintelligence_ocr.py module
"""

import logging
from azure.storage.blob import BlobServiceClient, ContentSettings
from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SimpleField,
    SearchableField,
    SearchFieldDataType,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile,
    SearchField
)
import hashlib
import json
from typing import Dict, List, Optional


class BlobManager:
    """Manage Azure Blob Storage operations"""
    
    def __init__(self, connection_string: str):
        self.blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        self.logger = logging.getLogger(__name__)
    
    def list_blobs(self, container_name: str, folder_prefix: str = "") -> List[str]:
        """List all blobs in a container with optional folder prefix"""
        try:
            container_client = self.blob_service_client.get_container_client(container_name)
            blobs = []
            for blob in container_client.list_blobs(name_starts_with=folder_prefix):
                if not blob.name.endswith('/'):  # Skip folders
                    blobs.append(blob.name)
            return blobs
        except Exception as e:
            self.logger.error(f"Error listing blobs: {e}")
            return []
    
    def download_blob(self, container_name: str, blob_name: str) -> bytes:
        """Download blob content as bytes"""
        try:
            blob_client = self.blob_service_client.get_blob_client(container_name, blob_name)
            return blob_client.download_blob().readall()
        except Exception as e:
            self.logger.error(f"Error downloading blob {blob_name}: {e}")
            return None
    
    def upload_blob(self, container_name: str, blob_name: str, data, content_type: str = None):
        """Upload data to blob storage"""
        try:
            blob_client = self.blob_service_client.get_blob_client(container_name, blob_name)
            
            content_settings = None
            if content_type:
                content_settings = ContentSettings(content_type=content_type)
            
            blob_client.upload_blob(data, overwrite=True, content_settings=content_settings)
            self.logger.info(f"Uploaded blob: {blob_name}")
            return True
        except Exception as e:
            self.logger.error(f"Error uploading blob {blob_name}: {e}")
            return False
    
    def blob_exists(self, container_name: str, blob_name: str) -> bool:
        """Check if blob exists"""
        try:
            blob_client = self.blob_service_client.get_blob_client(container_name, blob_name)
            return blob_client.exists()
        except Exception as e:
            self.logger.error(f"Error checking blob existence: {e}")
            return False


class OpenAIManager:
    """Manage Azure OpenAI operations"""
    
    def __init__(self, endpoint: str, api_key: str, api_version: str, 
                 gpt_deployment: str, embedding_deployment: str):
        self.client = AzureOpenAI(
            azure_endpoint=endpoint,
            api_key=api_key,
            api_version=api_version
        )
        self.gpt_deployment = gpt_deployment
        self.embedding_deployment = embedding_deployment
        self.logger = logging.getLogger(__name__)
    
    def get_embedding(self, text: str, dimension: int = 3072) -> List[float]:
        """Generate embedding for text"""
        try:
            response = self.client.embeddings.create(
                input=text,
                model=self.embedding_deployment,
                dimensions=dimension
            )
            return response.data[0].embedding
        except Exception as e:
            self.logger.error(f"Embedding generation error: {e}")
            return None
    
    def chat_completion(self, messages: List[Dict], temperature: float = 0.0, 
                       max_tokens: int = 4000) -> Optional[str]:
        """Get chat completion from GPT model"""
        try:
            response = self.client.chat.completions.create(
                model=self.gpt_deployment,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens
            )
            return response.choices[0].message.content
        except Exception as e:
            self.logger.error(f"Chat completion error: {e}")
            return None


class SearchManager:
    """Manage Azure AI Search operations"""
    
    def __init__(self, endpoint: str, api_key: str):
        self.endpoint = endpoint
        self.api_key = api_key
        self.credential = AzureKeyCredential(api_key)
        self.index_client = SearchIndexClient(endpoint=endpoint, credential=self.credential)
        self.logger = logging.getLogger(__name__)
    
    def create_index(self, index_name: str, embedding_dimension: int = 3072):
        """Create search index with vector search"""
        try:
            fields = [
                SimpleField(name="id", type=SearchFieldDataType.String, key=True),
                SearchableField(name="content", type=SearchFieldDataType.String),
                SearchField(
                    name="content_vector",
                    type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                    searchable=True,
                    vector_search_dimensions=embedding_dimension,
                    vector_search_profile_name="vector-profile"
                ),
                SimpleField(name="provider", type=SearchFieldDataType.String, filterable=True),
                SimpleField(name="provider_id", type=SearchFieldDataType.String, filterable=True),
                SimpleField(name="document_name", type=SearchFieldDataType.String),
                SimpleField(name="upload_timestamp", type=SearchFieldDataType.DateTimeOffset, filterable=True)
            ]
            
            vector_search = VectorSearch(
                algorithms=[HnswAlgorithmConfiguration(name="hnsw-algorithm")],
                profiles=[VectorSearchProfile(name="vector-profile", algorithm_configuration_name="hnsw-algorithm")]
            )
            
            index = SearchIndex(name=index_name, fields=fields, vector_search=vector_search)
            self.index_client.create_or_update_index(index)
            self.logger.info(f"Index '{index_name}' created/updated successfully")
            return True
        except Exception as e:
            self.logger.error(f"Error creating index: {e}")
            return False
    
    def index_exists(self, index_name: str) -> bool:
        """Check if index exists"""
        try:
            self.index_client.get_index(index_name)
            return True
        except:
            return False
    
    def upload_document(self, index_name: str, document: Dict):
        """Upload single document to index"""
        try:
            search_client = SearchClient(self.endpoint, index_name, self.credential)
            search_client.upload_documents(documents=[document])
            return True
        except Exception as e:
            self.logger.error(f"Error uploading document: {e}")
            return False
    
    def vector_search(self, index_name: str, query_vector: List[float], 
                     top_k: int = 3, filter_expression: str = None) -> List[Dict]:
        """Perform vector search"""
        try:
            search_client = SearchClient(self.endpoint, index_name, self.credential)
            
            results = search_client.search(
                search_text=None,
                vector_queries=[{
                    "kind": "vector",
                    "vector": query_vector,
                    "fields": "content_vector",
                    "k": top_k
                }],
                filter=filter_expression,
                select=["id", "content", "document_name", "provider"]
            )
            
            return [{"id": r["id"], "content": r["content"], 
                    "document_name": r["document_name"], "provider": r.get("provider", "")} 
                   for r in results]
        except Exception as e:
            self.logger.error(f"Vector search error: {e}")
            return []


def generate_document_id(provider: str, document_name: str) -> str:
    """Generate unique document ID using hash"""
    unique_string = f"{provider}_{document_name}"
    return hashlib.md5(unique_string.encode()).hexdigest()
