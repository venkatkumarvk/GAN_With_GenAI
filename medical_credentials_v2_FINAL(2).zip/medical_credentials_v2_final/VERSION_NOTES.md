# Version Compatibility Notes

## Azure Document Intelligence Version

**This project uses: `azure-ai-documentintelligence==1.0.0b4`**

---

## 📦 Package Information

### **Installed Package:**
```bash
pip install azure-ai-documentintelligence==1.0.0b4
```

### **Import Statement:**
```python
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeDocumentRequest, AnalyzeResult
from azure.core.credentials import AzureKeyCredential
```

---

## 🔄 Version Differences

### **v1.0.0b4 (Current - Using This):**
```python
# Client initialization
client = DocumentIntelligenceClient(
    endpoint=endpoint,
    credential=AzureKeyCredential(key)
)

# Analyze document
poller = client.begin_analyze_document(
    model_id="prebuilt-read",
    analyze_request=document_bytes,
    content_type="application/octet-stream"
)
result: AnalyzeResult = poller.result()

# Access pages
for page in result.pages:
    for line in page.lines:
        text += line.content
```

### **Old Version (azure-ai-formrecognizer):**
```python
# DON'T USE THIS - Old API
from azure.ai.formrecognizer import DocumentAnalysisClient

client = DocumentAnalysisClient(
    endpoint=endpoint,
    credential=AzureKeyCredential(key)
)

poller = client.begin_analyze_document(
    "prebuilt-read",
    document_bytes
)
```

---

## ✅ What's Included in This Project

### **Correct Version (v1.0.0b4):**
- ✅ `requirements.txt` specifies `azure-ai-documentintelligence==1.0.0b4`
- ✅ `documentintelligence_ocr.py` uses correct imports
- ✅ All API calls use v1.0.0b4 syntax
- ✅ Tested and working

---

## 🚀 Installation

### **Fresh Install:**
```bash
# Install all dependencies with correct versions
pip install -r requirements.txt
```

### **Verify Installation:**
```python
import azure.ai.documentintelligence
print(azure.ai.documentintelligence.__version__)
# Output: 1.0.0b4
```

---

## ⚠️ Common Issues

### **Issue 1: Wrong Package Name**
```bash
# ❌ WRONG - Old package
pip install azure-ai-formrecognizer

# ✅ CORRECT - New package
pip install azure-ai-documentintelligence==1.0.0b4
```

### **Issue 2: Import Error**
```python
# ❌ WRONG - Old import
from azure.ai.formrecognizer import DocumentAnalysisClient

# ✅ CORRECT - New import
from azure.ai.documentintelligence import DocumentIntelligenceClient
```

### **Issue 3: API Method Changed**
```python
# ❌ WRONG - Old API
poller = client.begin_analyze_document(
    "prebuilt-read",    # String only
    document_bytes
)

# ✅ CORRECT - New API
poller = client.begin_analyze_document(
    model_id="prebuilt-read",              # Named parameter
    analyze_request=document_bytes,        # Named parameter
    content_type="application/octet-stream"
)
```

---

## 📋 Requirements.txt (Complete)

```txt
# Azure SDK - Document Intelligence (v1.0.0b4)
azure-ai-documentintelligence==1.0.0b4

# Azure SDK - Other Services
azure-storage-blob==12.19.0
azure-search-documents==11.4.0
azure-core==1.29.5

# OpenAI
openai==1.12.0

# Data Processing
pandas==2.1.4
numpy==1.26.2

# Image Processing
Pillow==10.2.0

# Utilities
python-dotenv==1.0.0
tiktoken==0.5.2

# Optional
openpyxl==3.1.2
```

---

## 🔍 How to Check Your Version

### **Method 1: Python**
```python
import azure.ai.documentintelligence
print(f"Version: {azure.ai.documentintelligence.__version__}")
```

### **Method 2: pip**
```bash
pip show azure-ai-documentintelligence
```

**Expected Output:**
```
Name: azure-ai-documentintelligence
Version: 1.0.0b4
Summary: Microsoft Azure Document Intelligence Client Library for Python
...
```

---

## 🆕 Migration Guide (If Coming from Old Version)

### **Step 1: Uninstall Old Package**
```bash
pip uninstall azure-ai-formrecognizer
```

### **Step 2: Install New Package**
```bash
pip install azure-ai-documentintelligence==1.0.0b4
```

### **Step 3: Update Imports**
```python
# Old
from azure.ai.formrecognizer import DocumentAnalysisClient

# New
from azure.ai.documentintelligence import DocumentIntelligenceClient
```

### **Step 4: Update API Calls**
See code examples above

---

## ✅ Verification Checklist

Before running the project:

- [ ] Installed: `azure-ai-documentintelligence==1.0.0b4`
- [ ] Removed: `azure-ai-formrecognizer` (if present)
- [ ] Verified: `pip show azure-ai-documentintelligence` shows 1.0.0b4
- [ ] No import errors when running `python documentintelligence_ocr.py`

---

## 📞 Support

### **If You Get Import Errors:**
1. Check installed version: `pip show azure-ai-documentintelligence`
2. Reinstall: `pip install --force-reinstall azure-ai-documentintelligence==1.0.0b4`
3. Verify: `python -c "import azure.ai.documentintelligence; print('OK')"`

### **If API Calls Fail:**
1. Check endpoint and key in `config.json`
2. Verify Azure subscription has Document Intelligence enabled
3. Check quota and limits in Azure portal

---

## 🎯 Summary

| Aspect | Value |
|--------|-------|
| **Package Name** | azure-ai-documentintelligence |
| **Version** | 1.0.0b4 |
| **Import** | from azure.ai.documentintelligence import DocumentIntelligenceClient |
| **Status** | ✅ Production Ready |
| **Tested** | ✅ Working |

**This project is configured and tested with v1.0.0b4!** ✅
