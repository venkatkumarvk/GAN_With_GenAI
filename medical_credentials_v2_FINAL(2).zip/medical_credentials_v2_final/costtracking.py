"""
Cost Tracking Module
===================
Tracks and calculates costs for Azure services
"""

import logging
from typing import Dict


class CostTracker:
    """Track costs for document processing"""
    
    def __init__(self, ocr_per_page: float = 0.01, 
                 embedding_per_1k: float = 0.0001,
                 gpt4o_input_per_1k: float = 0.0025,
                 gpt4o_output_per_1k: float = 0.01):
        """
        Initialize cost tracker
        
        Args:
            ocr_per_page: Cost per page for OCR
            embedding_per_1k: Cost per 1K tokens for embeddings
            gpt4o_input_per_1k: Cost per 1K input tokens for GPT-4o
            gpt4o_output_per_1k: Cost per 1K output tokens for GPT-4o
        """
        self.ocr_per_page = ocr_per_page
        self.embedding_per_1k = embedding_per_1k
        self.gpt4o_input_per_1k = gpt4o_input_per_1k
        self.gpt4o_output_per_1k = gpt4o_output_per_1k
        
        self.ocr_pages = 0
        self.embedding_tokens = 0
        self.gpt4o_input_tokens = 0
        self.gpt4o_output_tokens = 0
        
        self.logger = logging.getLogger(__name__)
    
    def add_ocr_pages(self, pages: int):
        """Add OCR page count"""
        self.ocr_pages += pages
    
    def add_embedding_tokens(self, tokens: int):
        """Add embedding token count"""
        self.embedding_tokens += tokens
    
    def add_gpt4o_tokens(self, input_tokens: int, output_tokens: int):
        """Add GPT-4o token counts"""
        self.gpt4o_input_tokens += input_tokens
        self.gpt4o_output_tokens += output_tokens
    
    def get_costs(self) -> Dict[str, float]:
        """Calculate and return all costs"""
        ocr_cost = self.ocr_pages * self.ocr_per_page
        embedding_cost = (self.embedding_tokens / 1000) * self.embedding_per_1k
        gpt4o_input_cost = (self.gpt4o_input_tokens / 1000) * self.gpt4o_input_per_1k
        gpt4o_output_cost = (self.gpt4o_output_tokens / 1000) * self.gpt4o_output_per_1k
        gpt4o_cost = gpt4o_input_cost + gpt4o_output_cost
        total_cost = ocr_cost + embedding_cost + gpt4o_cost
        
        return {
            "ocr_cost": round(ocr_cost, 4),
            "embedding_cost": round(embedding_cost, 4),
            "gpt4o_input_cost": round(gpt4o_input_cost, 4),
            "gpt4o_output_cost": round(gpt4o_output_cost, 4),
            "gpt4o_cost": round(gpt4o_cost, 4),
            "total_estimated": round(total_cost, 4)
        }
    
    def get_summary(self) -> Dict:
        """Get complete cost summary"""
        costs = self.get_costs()
        return {
            "usage": {
                "ocr_pages": self.ocr_pages,
                "embedding_tokens": self.embedding_tokens,
                "gpt4o_input_tokens": self.gpt4o_input_tokens,
                "gpt4o_output_tokens": self.gpt4o_output_tokens
            },
            "costs": costs
        }
    
    def log_summary(self):
        """Log cost summary"""
        summary = self.get_summary()
        self.logger.info("=" * 60)
        self.logger.info("COST SUMMARY")
        self.logger.info("=" * 60)
        self.logger.info(f"OCR Pages: {summary['usage']['ocr_pages']}")
        self.logger.info(f"Embedding Tokens: {summary['usage']['embedding_tokens']:,}")
        self.logger.info(f"GPT-4o Input Tokens: {summary['usage']['gpt4o_input_tokens']:,}")
        self.logger.info(f"GPT-4o Output Tokens: {summary['usage']['gpt4o_output_tokens']:,}")
        self.logger.info("-" * 60)
        self.logger.info(f"OCR Cost: ${summary['costs']['ocr_cost']:.4f}")
        self.logger.info(f"Embedding Cost: ${summary['costs']['embedding_cost']:.4f}")
        self.logger.info(f"GPT-4o Cost: ${summary['costs']['gpt4o_cost']:.4f}")
        self.logger.info(f"TOTAL COST: ${summary['costs']['total_estimated']:.4f}")
        self.logger.info("=" * 60)
    
    def reset(self):
        """Reset all counters"""
        self.ocr_pages = 0
        self.embedding_tokens = 0
        self.gpt4o_input_tokens = 0
        self.gpt4o_output_tokens = 0
