"""
Medical Credentials Extraction - V2 FINAL
==========================================
Features:
1. Folder-level field extraction (70% cost savings)
2. Save per provider/folder (crash protection)
3. Skip unknown folders (process only what you need)
4. Multimodal support (text + images)
5. Auto mode detection (text vs vision)
"""

import json
import logging
from datetime import datetime
from typing import Dict, List
import pandas as pd
from collections import Counter
import base64
from io import BytesIO
from PIL import Image

from logging_config import setup_logging
from helper import BlobManager, OCRManager, OpenAIManager
from production_index_manager import ProductionIndexManager, ProductionChunker
from prompt_builder import PromptBuilder
from unified_rag import unified_rag_extraction
from costtracking import CostTracker


def load_config(config_path: str = "config.json") -> Dict:
    """Load configuration from JSON file"""
    with open(config_path, 'r') as f:
        return json.load(f)


def detect_folder_type(folder_name: str, config: Dict) -> str:
    """
    Detect folder type from folder name
    Returns None if no config found (for skipping)
    """
    folder_lower = folder_name.lower()
    
    # Check exact matches in folder_configs
    for folder_type in config['folder_configs'].keys():
        if folder_type.lower() in folder_lower:
            return folder_type
    
    # Partial matches
    if 'license' in folder_lower or 'lic' in folder_lower:
        if 'Licenses' in config['folder_configs']:
            return 'Licenses'
    elif 'personal' in folder_lower or 'identity' in folder_lower:
        if 'Personal' in config['folder_configs']:
            return 'Personal'
    elif 'education' in folder_lower or 'school' in folder_lower:
        if 'Education' in config['folder_configs']:
            return 'Education'
    elif 'cert' in folder_lower or 'board' in folder_lower:
        if 'Certifications' in config['folder_configs']:
            return 'Certifications'
    elif 'work' in folder_lower or 'employ' in folder_lower or 'history' in folder_lower:
        if 'Work_History' in config['folder_configs']:
            return 'Work_History'
    elif 'insurance' in folder_lower or 'malpractice' in folder_lower:
        if 'Insurance' in config['folder_configs']:
            return 'Insurance'
    
    # Check skip setting
    if config['processing'].get('skip_unknown_folders', False):
        return None  # Skip this folder
    else:
        return 'default'  # Use default config


def get_folder_config(folder_type: str, config: Dict) -> Dict:
    """Get configuration for specific folder type"""
    if folder_type in config['folder_configs']:
        return config['folder_configs'][folder_type]
    else:
        return config['default_config']


def convert_to_base64(image_bytes: bytes) -> str:
    """Convert image bytes to base64 string"""
    try:
        # Open image and convert to PNG
        img = Image.open(BytesIO(image_bytes))
        buffered = BytesIO()
        img.convert('RGB').save(buffered, format="PNG")
        return base64.b64encode(buffered.getvalue()).decode('utf-8')
    except Exception as e:
        logging.error(f"Error converting image to base64: {e}")
        return None


def is_image_file(filename: str) -> bool:
    """Check if file is an image"""
    image_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp']
    return any(filename.lower().endswith(ext) for ext in image_extensions)


def save_provider_results(
    blob_manager: BlobManager,
    output_container: str,
    provider: str,
    folder: str,
    results: List[Dict],
    folder_config: Dict,
    config: Dict,
    logger: logging.Logger
):
    """Save results for a provider+folder immediately"""
    if not results:
        logger.warning(f"No results to save for {provider}/{folder}")
        return
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Calculate min confidence
    all_confidences = []
    for result in results:
        for field_data in result['extracted_fields'].values():
            if isinstance(field_data, dict) and 'confidence' in field_data:
                all_confidences.append(field_data['confidence'])
    
    min_confidence = min(all_confidences) if all_confidences else 0.0
    threshold = folder_config.get('min_confidence', config['extraction']['confidence_threshold'])
    category = "highconfidence" if min_confidence >= threshold else "lowconfidence"
    
    # Prepare JSON output
    output_data = {
        "provider": provider,
        "folder": folder,
        "folder_type": folder_config.get('description', 'Unknown'),
        "timestamp": timestamp,
        "total_documents": len(results),
        "min_confidence": round(min_confidence, 2),
        "category": category,
        "results": results
    }
    
    # Save JSON
    json_path = f"processedjsonresult/{provider}_{folder}_{timestamp}.json"
    blob_manager.upload_blob(
        output_container,
        json_path,
        json.dumps(output_data, indent=2),
        content_type="application/json"
    )
    logger.info(f"✅ Saved JSON: {json_path}")
    
    # Frequency-based selection for CSV
    fields = folder_config['fields']
    field_values = {field: [] for field in fields}
    
    for result in results:
        for field in fields:
            if field in result['extracted_fields']:
                field_data = result['extracted_fields'][field]
                value = field_data.get('value', config['extraction']['na_value']) if isinstance(field_data, dict) else field_data
                field_values[field].append(value)
    
    # Select most frequent value
    best_values = {}
    for field, values in field_values.items():
        if values:
            freq = Counter([v for v in values if v != config['extraction']['na_value']])
            if freq:
                best_values[field] = freq.most_common(1)[0][0]
            else:
                best_values[field] = config['extraction']['na_value']
        else:
            best_values[field] = config['extraction']['na_value']
    
    # Save CSV
    csv_path = f"{category}/{provider}_{folder}_{timestamp}.csv"
    df = pd.DataFrame([best_values])
    csv_content = df.to_csv(index=False)
    blob_manager.upload_blob(
        output_container,
        csv_path,
        csv_content,
        content_type="text/csv"
    )
    logger.info(f"✅ Saved CSV: {csv_path}")
    
    return json_path, csv_path


def process_document(
    document_blob: str,
    provider: str,
    folder: str,
    folder_config: Dict,
    blob_manager: BlobManager,
    ocr_manager: OCRManager,
    openai_manager: OpenAIManager,
    index_manager: ProductionIndexManager,
    chunker: ProductionChunker,
    prompt_builder: PromptBuilder,
    cost_tracker: CostTracker,
    config: Dict,
    logger: logging.Logger
) -> Dict:
    """Process a single document (text or image)"""
    try:
        # Download document
        input_container = config['azure_blob']['inputcontainer']
        doc_bytes = blob_manager.download_blob(input_container, document_blob)
        if not doc_bytes:
            logger.warning(f"Skipping {document_blob}: download failed")
            return None
        
        document_name = document_blob.split('/')[-1]
        
        # Check if image file
        is_image = is_image_file(document_name)
        
        # OCR extraction
        document_text = ocr_manager.extract_text(doc_bytes)
        cost_tracker.add_ocr_pages(1)
        
        # Determine mode: text or multimodal
        multimodal_threshold = config['processing'].get('multimodal_threshold', 50)
        text_length = len(document_text.strip())
        
        if text_length < multimodal_threshold:
            # Text too short - use multimodal (vision)
            mode = "multimodal"
            logger.info(f"  Mode: MULTIMODAL (text length: {text_length} chars)")
            
            # Convert to base64 for vision
            image_base64 = convert_to_base64(doc_bytes)
            if not image_base64:
                logger.warning(f"Skipping {document_blob}: base64 conversion failed")
                return None
            
            document_text_for_index = f"[Image Document] {document_name}"
            
        else:
            # Text long enough - use text mode
            mode = "text"
            logger.info(f"  Mode: TEXT (text length: {text_length} chars)")
            image_base64 = None
            document_text_for_index = document_text
        
        # Handle context length
        processed_text = chunker.handle_document(document_text_for_index)
        
        # Generate embedding
        embedding = openai_manager.get_embedding(processed_text[:2000])
        if not embedding:
            logger.warning(f"Skipping {document_blob}: embedding failed")
            return None
        cost_tracker.add_embedding_tokens(len(processed_text.split()))
        
        # Upload to universal index
        doc_id = f"{provider}_{folder}_{document_name}"
        index_manager.upload_document(
            doc_id=doc_id,
            content=processed_text,
            content_vector=embedding,
            provider=provider,
            provider_id=f"{provider}_{folder}_{datetime.now().strftime('%Y%m%d')}",
            document_name=document_name
        )
        
        # Build extraction prompt
        extraction_prompt = prompt_builder.build_extraction_prompt()
        
        # RAG extraction with appropriate mode
        extracted_data = unified_rag_extraction(
            openai_manager=openai_manager,
            search_manager=index_manager,
            index_name=config['azure_search']['universal_index_name'],
            provider=provider,
            document_text=document_text if mode == "text" else None,
            document_image_base64=image_base64 if mode == "multimodal" else None,
            prompt=extraction_prompt,
            top_k=config['rag']['top_k'],
            mode=mode
        )
        
        # Track costs
        cost_tracker.add_gpt4o_tokens(
            input_tokens=int(len(extraction_prompt.split()) * 1.3),
            output_tokens=500
        )
        
        if extracted_data:
            logger.info(f"✓ Successfully extracted from {document_blob}")
            return {
                "document_name": document_name,
                "extraction_mode": mode,
                "extracted_fields": extracted_data
            }
        else:
            logger.warning(f"✗ Extraction failed for {document_blob}")
            return None
            
    except Exception as e:
        logger.error(f"Error processing {document_blob}: {e}", exc_info=True)
        return None


def main():
    """Main execution function"""
    
    # Setup logging
    logger = setup_logging()
    logger.info("="*80)
    logger.info("MEDICAL CREDENTIALS EXTRACTION - V2 FINAL")
    logger.info("Features: Folder-Level + Save Per Provider + Skip Unknown + Multimodal")
    logger.info("="*80)
    
    # Load configuration
    logger.info("Loading configuration...")
    config = load_config()
    
    # Log configurations
    logger.info(f"Folder configurations: {len(config['folder_configs'])} types")
    for folder_type, folder_config in config['folder_configs'].items():
        logger.info(f"  • {folder_type}: {len(folder_config['fields'])} fields")
    
    skip_unknown = config['processing'].get('skip_unknown_folders', False)
    logger.info(f"Skip unknown folders: {skip_unknown}")
    logger.info(f"Multimodal threshold: {config['processing'].get('multimodal_threshold', 50)} chars")
    
    # Initialize managers
    logger.info("Initializing Azure managers...")
    blob_manager = BlobManager(config['azure_blob']['connection_string'])
    ocr_manager = OCRManager(
        config['azure_document_intelligence']['endpoint'],
        config['azure_document_intelligence']['key']
    )
    openai_manager = OpenAIManager(
        config['azure_openai_gpt']['endpoint'],
        config['azure_openai_gpt']['api_key'],
        config['azure_openai_gpt']['api_version'],
        config['azure_openai_gpt']['deployment_name'],
        config['azure_openai_embedding']['deployment_name']
    )
    
    # Initialize index manager
    logger.info("Initializing production index manager...")
    index_manager = ProductionIndexManager(
        search_endpoint=config['azure_search']['endpoint'],
        search_api_key=config['azure_search']['api_key'],
        index_name=config['azure_search']['universal_index_name'],
        auto_delete_days=config['azure_search']['auto_delete_days'],
        enable_auto_cleanup=config['azure_search']['enable_auto_cleanup']
    )
    
    # Create universal index
    logger.info("Creating/verifying universal index...")
    index_manager.create_universal_index(
        embedding_dimension=config['azure_openai_embedding']['dimension']
    )
    
    # Run auto-cleanup
    if config['azure_search']['enable_auto_cleanup']:
        logger.info("Running auto-cleanup...")
        deleted_count = index_manager.cleanup_old_data(
            days=config['azure_search']['auto_delete_days']
        )
        logger.info(f"Auto-cleanup complete: {deleted_count} documents deleted")
    
    # Initialize cost tracker
    cost_tracker = CostTracker(
        ocr_per_page=config['costs']['ocr_per_page'],
        embedding_per_1k=config['costs']['embedding_per_1k_tokens'],
        gpt4o_input_per_1k=config['costs']['gpt4o_input_per_1k_tokens'],
        gpt4o_output_per_1k=config['costs']['gpt4o_output_per_1k_tokens']
    )
    
    # Initialize chunker
    chunker = ProductionChunker(
        max_doc_length_chars=config['processing']['max_doc_length_chars'],
        max_prompt_tokens=config['processing']['max_prompt_tokens'],
        chunk_size=config['rag']['chunk_size'],
        chunk_overlap=config['rag']['chunk_overlap']
    )
    
    # List all blobs
    input_container = config['azure_blob']['inputcontainer']
    output_container = config['azure_blob']['outputcontainer']
    all_blobs = blob_manager.list_blobs(input_container)
    
    # Organize by Provider/Folder structure
    provider_folders = {}
    for blob in all_blobs:
        parts = blob.split('/')
        if len(parts) >= 3:  # Provider/Folder/Document
            provider = parts[0]
            folder = parts[1]
            
            if provider not in provider_folders:
                provider_folders[provider] = {}
            if folder not in provider_folders[provider]:
                provider_folders[provider][folder] = []
            
            provider_folders[provider][folder].append(blob)
    
    logger.info(f"Found {len(provider_folders)} providers")
    
    # Track statistics
    total_providers = len(provider_folders)
    total_folders_processed = 0
    total_folders_skipped = 0
    total_documents_processed = 0
    text_mode_count = 0
    multimodal_mode_count = 0
    
    # Process each provider
    for provider_idx, (provider, folders) in enumerate(sorted(provider_folders.items()), 1):
        logger.info("="*80)
        logger.info(f"PROVIDER {provider_idx}/{total_providers}: {provider}")
        logger.info(f"Folders: {len(folders)}")
        logger.info("="*80)
        
        # Process each folder
        for folder_idx, (folder, documents) in enumerate(sorted(folders.items()), 1):
            logger.info("-"*80)
            logger.info(f"Folder {folder_idx}/{len(folders)}: {provider}/{folder}")
            logger.info(f"Documents: {len(documents)}")
            logger.info("-"*80)
            
            # Detect folder type
            folder_type = detect_folder_type(folder, config)
            
            # Skip if no config
            if folder_type is None:
                logger.info(f"⏭️  SKIPPING {folder} - No configuration found")
                logger.info(f"   To process this folder, add '{folder}' to config.json folder_configs")
                total_folders_skipped += 1
                continue
            
            folder_config = get_folder_config(folder_type, config)
            
            logger.info(f"✅ Processing as: {folder_type}")
            logger.info(f"Fields to extract: {len(folder_config['fields'])}")
            logger.info(f"Fields: {', '.join(folder_config['fields'][:5])}...")
            
            # Initialize prompt builder
            prompt_builder = PromptBuilder(
                fields=folder_config['fields'],
                mode=config['rag']['mode']
            )
            
            # Process documents
            folder_results = []
            checkpoint_interval = config['processing']['checkpoint_interval']
            
            for doc_idx, document_blob in enumerate(documents, 1):
                logger.info(f"[{doc_idx}/{len(documents)}] {document_blob.split('/')[-1]}")
                
                result = process_document(
                    document_blob=document_blob,
                    provider=provider,
                    folder=folder,
                    folder_config=folder_config,
                    blob_manager=blob_manager,
                    ocr_manager=ocr_manager,
                    openai_manager=openai_manager,
                    index_manager=index_manager,
                    chunker=chunker,
                    prompt_builder=prompt_builder,
                    cost_tracker=cost_tracker,
                    config=config,
                    logger=logger
                )
                
                if result:
                    folder_results.append(result)
                    total_documents_processed += 1
                    
                    # Count mode usage
                    if result.get('extraction_mode') == 'text':
                        text_mode_count += 1
                    elif result.get('extraction_mode') == 'multimodal':
                        multimodal_mode_count += 1
                
                # Checkpoint save
                if checkpoint_interval > 0 and (doc_idx % checkpoint_interval == 0):
                    if folder_results:
                        logger.info(f"💾 Checkpoint at {doc_idx} documents...")
                        save_provider_results(
                            blob_manager=blob_manager,
                            output_container=output_container,
                            provider=provider,
                            folder=folder,
                            results=folder_results,
                            folder_config=folder_config,
                            config=config,
                            logger=logger
                        )
            
            # Save final results
            if folder_results:
                logger.info(f"💾 Saving final results for {provider}/{folder}...")
                json_path, csv_path = save_provider_results(
                    blob_manager=blob_manager,
                    output_container=output_container,
                    provider=provider,
                    folder=folder,
                    results=folder_results,
                    folder_config=folder_config,
                    config=config,
                    logger=logger
                )
                logger.info(f"✅ SAVED: {provider}/{folder}")
                logger.info(f"   JSON: {json_path}")
                logger.info(f"   CSV: {csv_path}")
                logger.info(f"   Documents: {len(folder_results)}")
                total_folders_processed += 1
            else:
                logger.warning(f"⚠️  No results for {provider}/{folder}")
    
    # Save cost summary
    logger.info("="*80)
    logger.info("Saving cost summary...")
    cost_summary = cost_tracker.get_summary()
    cost_summary['total_providers'] = total_providers
    cost_summary['total_folders_processed'] = total_folders_processed
    cost_summary['total_folders_skipped'] = total_folders_skipped
    cost_summary['total_documents'] = total_documents_processed
    cost_summary['text_mode_count'] = text_mode_count
    cost_summary['multimodal_mode_count'] = multimodal_mode_count
    
    cost_path = f"estimatecost/summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    blob_manager.upload_blob(
        output_container,
        cost_path,
        json.dumps(cost_summary, indent=2),
        content_type="application/json"
    )
    
    # Final summary
    logger.info("="*80)
    logger.info("EXTRACTION COMPLETE - V2 FINAL")
    logger.info("="*80)
    logger.info(f"Providers processed: {total_providers}")
    logger.info(f"Folders processed: {total_folders_processed}")
    logger.info(f"Folders skipped: {total_folders_skipped}")
    logger.info(f"Documents processed: {total_documents_processed}")
    logger.info(f"  Text mode: {text_mode_count}")
    logger.info(f"  Multimodal mode: {multimodal_mode_count}")
    cost_tracker.log_summary()
    logger.info("="*80)
    logger.info("✅ All results saved!")
    logger.info("✅ Crash-proof - each folder saved immediately!")
    logger.info("✅ Multimodal support - handles text AND images!")
    logger.info("="*80)


if __name__ == "__main__":
    main()
