"""
Unified RAG Interface
====================
Automatically chooses text or multimodal RAG based on document type
"""

import logging
from typing import Dict
from text_rag import text_rag_extraction
from multimodal_rag import multimodal_rag_extraction


def unified_rag_extraction(
    openai_manager,
    search_manager,
    index_name: str,
    provider: str,
    document_text: str = None,
    document_image_base64: str = None,
    prompt: str = "",
    top_k: int = 3,
    mode: str = "auto"
) -> Dict:
    """
    Unified RAG extraction - automatically chooses text or multimodal
    
    Args:
        openai_manager: OpenAI manager instance
        search_manager: Search manager instance
        index_name: Name of search index
        provider: Provider name for filtering
        document_text: Text content (for text mode)
        document_image_base64: Base64 image (for multimodal mode)
        prompt: Extraction prompt
        top_k: Number of RAG examples
        mode: "auto", "text", or "multimodal"
        
    Returns:
        Dict with extracted fields or None
    """
    logger = logging.getLogger(__name__)
    
    # Auto-detect mode
    if mode == "auto":
        if document_text and len(document_text.strip()) > 50:
            mode = "text"
        elif document_image_base64:
            mode = "multimodal"
        else:
            logger.error("Cannot auto-detect mode: no valid input provided")
            return None
    
    logger.info(f"Using {mode} RAG mode")
    
    # Execute appropriate RAG
    if mode == "text":
        if not document_text:
            logger.error("Text mode requires document_text")
            return None
        return text_rag_extraction(
            openai_manager=openai_manager,
            search_manager=search_manager,
            index_name=index_name,
            provider=provider,
            document_text=document_text,
            prompt=prompt,
            top_k=top_k
        )
    
    elif mode == "multimodal":
        if not document_image_base64:
            logger.error("Multimodal mode requires document_image_base64")
            return None
        return multimodal_rag_extraction(
            openai_manager=openai_manager,
            search_manager=search_manager,
            index_name=index_name,
            provider=provider,
            document_image_base64=document_image_base64,
            prompt=prompt,
            top_k=top_k
        )
    
    else:
        logger.error(f"Unknown mode: {mode}")
        return None
