"""
Import Test - Verify All Imports Work
======================================
Run this to verify all imports are correct before running main.py
"""

import sys

print("="*60)
print("IMPORT TEST - Medical Credentials V2")
print("="*60)

# Test 1: Document Intelligence OCR
print("\n1. Testing documentintelligence_ocr...")
try:
    from documentintelligence_ocr import DocumentIntelligenceOCR
    print("   ✅ DocumentIntelligenceOCR imported successfully")
except ImportError as e:
    print(f"   ❌ FAILED: {e}")
    sys.exit(1)

# Test 2: Helper modules
print("\n2. Testing helper modules...")
try:
    from helper import BlobManager, OpenAIManager
    print("   ✅ BlobManager imported successfully")
    print("   ✅ OpenAIManager imported successfully")
except ImportError as e:
    print(f"   ❌ FAILED: {e}")
    sys.exit(1)

# Test 3: Verify no OCRManager in helper
print("\n3. Checking helper.py is clean...")
try:
    import helper
    if hasattr(helper, 'OCRManager'):
        print("   ❌ FAILED: OCRManager still exists in helper.py!")
        sys.exit(1)
    else:
        print("   ✅ helper.py is clean (no OCRManager)")
except Exception as e:
    print(f"   ❌ FAILED: {e}")
    sys.exit(1)

# Test 4: Prompt Builder
print("\n4. Testing prompt_builder...")
try:
    from prompt_builder import ExtractionPromptBuilder
    print("   ✅ ExtractionPromptBuilder imported successfully")
except ImportError as e:
    print(f"   ❌ FAILED: {e}")
    sys.exit(1)

# Test 5: Production Index Manager
print("\n5. Testing production_index_manager...")
try:
    from production_index_manager import ProductionIndexManager, ProductionChunker
    print("   ✅ ProductionIndexManager imported successfully")
    print("   ✅ ProductionChunker imported successfully")
except ImportError as e:
    print(f"   ❌ FAILED: {e}")
    sys.exit(1)

# Test 6: RAG modules
print("\n6. Testing RAG modules...")
try:
    from unified_rag import unified_rag_extraction
    from text_rag import text_rag_extraction
    from multimodal_rag import multimodal_rag_extraction
    print("   ✅ unified_rag_extraction imported successfully")
    print("   ✅ text_rag_extraction imported successfully")
    print("   ✅ multimodal_rag_extraction imported successfully")
except ImportError as e:
    print(f"   ❌ FAILED: {e}")
    sys.exit(1)

# Test 7: Cost tracking
print("\n7. Testing costtracking...")
try:
    from costtracking import CostTracker
    print("   ✅ CostTracker imported successfully")
except ImportError as e:
    print(f"   ❌ FAILED: {e}")
    sys.exit(1)

# Test 8: Logging config
print("\n8. Testing logging_config...")
try:
    from logging_config import setup_logging
    print("   ✅ setup_logging imported successfully")
except ImportError as e:
    print(f"   ❌ FAILED: {e}")
    sys.exit(1)

# Test 9: Azure SDK versions
print("\n9. Checking Azure SDK versions...")
try:
    import azure.ai.documentintelligence
    print(f"   ✅ azure-ai-documentintelligence version: {azure.ai.documentintelligence.__version__}")
    
    # Check it's the correct version
    expected = "1.0.0b4"
    if azure.ai.documentintelligence.__version__ == expected:
        print(f"   ✅ Correct version: {expected}")
    else:
        print(f"   ⚠️  Warning: Expected {expected}, got {azure.ai.documentintelligence.__version__}")
except Exception as e:
    print(f"   ❌ FAILED: {e}")
    sys.exit(1)

# Test 10: Check for old imports
print("\n10. Checking for old imports...")
try:
    # This should fail
    from azure.ai.formrecognizer import DocumentAnalysisClient
    print("   ⚠️  WARNING: Old azure.ai.formrecognizer is still installed")
    print("   ⚠️  This might cause conflicts!")
except ImportError:
    print("   ✅ No old azure.ai.formrecognizer (good!)")

print("\n" + "="*60)
print("✅ ALL IMPORT TESTS PASSED!")
print("="*60)
print("\nYou can now run: python main.py")
print("="*60)
