# Medical Credentials Extraction - Folder-Level Only

## ✅ CLEAN VERSION - ONLY FOLDER-LEVEL EXTRACTION

This package contains ONLY the folder-level extraction system.
All unnecessary files removed.

---

## 📁 FILES INCLUDED (13 files):

### **Core Python Files (11):**
1. **main.py** - Folder-level extraction (main script)
2. **documentintelligence_ocr.py** - OCR with base64 (v1.0.0b4)
3. **helper.py** - Blob & OpenAI managers
4. **production_index_manager.py** - Azure AI Search
5. **prompt_builder.py** - Prompt generation
6. **prompt_config.py** - Field configurations
7. **unified_rag.py** - Unified RAG
8. **text_rag.py** - Text RAG
9. **multimodal_rag.py** - Vision RAG
10. **costtracking.py** - Cost tracking
11. **logging_config.py** - Logging

### **Config Files (2):**
12. **config.json** - Configuration (ADD YOUR CREDENTIALS HERE!)
13. **requirements.txt** - Dependencies

---

## 🚀 QUICK START:

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Edit config.json - Add your Azure credentials
nano config.json

# 3. Run
python main.py
```

---

## 📊 INPUT STRUCTURE:

```
inputcontainer/
└── Provider1/
    ├── 1. GEN & HR/           ← 12 personal fields
    │   ├── CV.docx
    │   └── License.pdf
    │
    └── 2. ED & TRAIN/         ← 15 license fields
        └── DEA.jpg
```

---

## 📊 OUTPUT STRUCTURE:

```
outputcontainer/
└── highconfidence/
    └── Provider1/
        ├── processedjsonresult/
        │   ├── Provider1_GEN & HR_20260305.json
        │   └── Provider1_ED & TRAIN_20260305.json
        │
        ├── processedcsvresult/
        │   ├── Provider1_GEN & HR_20260305.csv
        │   └── Provider1_ED & TRAIN_20260305.csv
        │
        └── estimationcost/
            ├── Provider1_GEN & HR_20260305_cost.json
            └── Provider1_ED & TRAIN_20260305_cost.json
```

---

## ⚙️ FOLDER CONFIGURATION:

Edit `config.json` to define fields per folder:

```json
{
  "folder_configs": {
    "GEN & HR": {
      "fields": ["first_name", "last_name", "email", ...]
    },
    "ED & TRAIN": {
      "fields": ["degree", "state_license_number", ...]
    }
  }
}
```

---

## ✅ FEATURES:

- ✅ Folder-level extraction (different fields per folder)
- ✅ Base64 encoding (Document Intelligence v1.0.0b4)
- ✅ Working embedding (your proven code)
- ✅ Provider/3 subfolder output structure
- ✅ No data loss (all in JSON)
- ✅ Cost tracking per folder
- ✅ Supports 11 file types

---

## 🎯 SUPPORTED FILES:

- PDF (.pdf)
- Word (.doc, .docx)
- Images (.jpg, .jpeg, .png, .gif, .bmp, .tiff, .tif, .webp)
- Text (.txt)

---

## 📋 REQUIREMENTS:

- Python 3.8+
- Azure Blob Storage
- Azure Document Intelligence
- Azure OpenAI (GPT-4o + Embeddings)
- Azure AI Search

---

## ✅ READY TO USE!

No extra files, no confusion - just the essentials!
