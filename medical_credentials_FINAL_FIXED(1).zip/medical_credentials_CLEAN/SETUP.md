# SETUP GUIDE

## 📋 STEP-BY-STEP:

### **Step 1: Install Dependencies**
```bash
pip install -r requirements.txt
```

### **Step 2: Configure Azure Credentials**

Edit `config.json` and fill in your Azure details:

```json
{
  "azure_blob": {
    "connection_string": "YOUR_BLOB_CONNECTION_STRING",
    "inputcontainer": "inputcontainer",
    "outputcontainer": "outputcontainer"
  },
  
  "azure_document_intelligence": {
    "endpoint": "YOUR_DOC_INTEL_ENDPOINT",
    "key": "YOUR_DOC_INTEL_KEY"
  },
  
  "azure_openai_gpt": {
    "endpoint": "YOUR_OPENAI_ENDPOINT",
    "api_key": "YOUR_OPENAI_KEY",
    "deployment_name": "gpt-4o"
  },
  
  "azure_openai_embedding": {
    "endpoint": "YOUR_OPENAI_ENDPOINT",
    "api_key": "YOUR_OPENAI_KEY",
    "deployment_name": "text-embedding-3-large"
  },
  
  "azure_search": {
    "endpoint": "YOUR_SEARCH_ENDPOINT",
    "api_key": "YOUR_SEARCH_KEY"
  }
}
```

### **Step 3: Configure Folders**

Define which fields to extract per folder:

```json
{
  "folder_configs": {
    "GEN & HR": {
      "description": "Personal information",
      "fields": [
        "first_name",
        "last_name",
        "email",
        "cell",
        "birth_date",
        "citizenship",
        "gender",
        "ssn"
      ]
    },
    
    "ED & TRAIN": {
      "description": "Licenses",
      "fields": [
        "degree",
        "state_license_number",
        "dea_license_number"
      ]
    }
  }
}
```

### **Step 4: Run**
```bash
python main.py
```

---

## ✅ VERIFICATION:

Test imports before running:
```bash
python -c "from prompt_builder import PromptBuilder; print('✓')"
python -c "from documentintelligence_ocr import OCRManager; print('✓')"
python -c "from helper import BlobManager, OpenAIManager; print('✓')"
```

All should print ✓!

---

## 🎯 EXPECTED OUTPUT:

```
Processing Provider 1/1: Provider1
  Processing Folder 1/2: 1. GEN & HR
    Folder type: GEN & HR
    Extracting 12 fields
    [1/2] CV.docx
      ✓ OCR extracted: 5112 chars
      ✓ Embedding generated: 3072 dimensions
      ✓ Successfully extracted
    ✅ Saved: 3 files

  Processing Folder 2/2: 2. ED & TRAIN
    Folder type: ED & TRAIN
    Extracting 15 fields
    [1/1] DEA.jpg
      ✓ OCR extracted: 450 chars
      ✓ Embedding generated: 3072 dimensions
      ✓ Successfully extracted
    ✅ Saved: 3 files

EXTRACTION COMPLETE
Total providers processed: 1
Total documents processed: 3
```

---

## 📊 OUTPUT FILES:

```
outputcontainer/highconfidence/Provider1/
├── processedjsonresult/
│   ├── Provider1_GEN & HR_timestamp.json    ← All data
│   └── Provider1_ED & TRAIN_timestamp.json
│
├── processedcsvresult/
│   ├── Provider1_GEN & HR_timestamp.csv     ← Summary
│   └── Provider1_ED & TRAIN_timestamp.csv
│
└── estimationcost/
    ├── Provider1_GEN & HR_timestamp_cost.json    ← Costs
    └── Provider1_ED & TRAIN_timestamp_cost.json
```

---

## 🎯 THAT'S IT!

Simple, clean, ready to use!
