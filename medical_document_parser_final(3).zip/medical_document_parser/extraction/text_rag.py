"""
Text RAG Extraction Module
===========================

Text-based extraction pipeline:
  OCR -> Semantic Chunking -> Embedding -> AI Search Index -> 
  Per-field RAG Search -> Text-only GPT Extraction

Config: rag.mode = "text"

For each field:
  1. Search AI Search index for chunks most relevant to this field
  2. Send retrieved text chunks to GPT (text-only, no vision)
  3. Extract field value with confidence score

Adding new document types:
  1. Create new prompt file in prompts/ (copy cred_prompt.py as template)
  2. Add doctype entry in config.json with folder_configs and fields
  3. Done - this module adapts automatically via prompt_module parameter
"""

import logging
import hashlib
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)


def process_document_text_rag(
    doc_bytes: bytes,
    doc_name: str,
    extension: str,
    provider: str,
    folder: str,
    fields: List[str],
    ocr,
    openai_manager,
    search_manager,
    cost_tracker,
    prompt_module
) -> Tuple[Dict, bool]:
    """
    Extract fields using text-based RAG.
    
    Each field gets its own RAG search to find the most relevant
    document chunks, then GPT extracts the value from those chunks.
    
    Args:
        doc_bytes: Document bytes
        doc_name: Document name
        extension: File extension
        provider: Provider name
        folder: Folder name
        fields: List of field names to extract
        ocr: OCR service
        openai_manager: OpenAI service
        search_manager: AI Search service
        cost_tracker: Cost tracker
        prompt_module: Prompt module with FIELD_LIBRARY
    
    Returns:
        (extracted_data, success)
    """
    logger.info(f"    Document: {doc_name} - Text RAG extraction")
    
    # ========================================================================
    # STEP 1: OCR
    # ========================================================================
    text, pages, success = ocr.extract_text(doc_bytes, extension)
    
    if not success or len(text) < 100:
        logger.warning(f"      FAILED: Insufficient text")
        return {}, False
    
    cost_tracker.add_ocr(pages)
    logger.info(f"      Step 1: OCR complete ({len(text)} chars, {pages} pages)")
    
    # ========================================================================
    # STEP 2: SEMANTIC CHUNKING (zero data loss)
    # ========================================================================
    from extraction.semantic_chunker import SemanticChunkerV2
    
    chunker = SemanticChunkerV2(
        target_chunk_size=3000,
        min_chunk_size=500,
        max_chunk_size=6000,
        overlap_size=300,
        adaptive=True
    )
    
    chunks = chunker.chunk_document(text, doc_name)
    summary = chunker.get_chunk_summary(chunks)
    logger.info(f"      Step 2: {summary['total_chunks']} chunks "
               f"({summary['total_text_length']} chars)")
    
    # ========================================================================
    # STEP 3: GENERATE EMBEDDINGS AND INDEX ALL CHUNKS
    # ========================================================================
    content_hash = hashlib.md5(text.encode('utf-8')).hexdigest()
    
    uploaded_chunks = 0
    for chunk in chunks:
        try:
            chunk_embedding, tokens = openai_manager.generate_embedding(chunk['text'])
            cost_tracker.add_embedding(tokens)
            
            chunk_doc_id = f"{content_hash}_{chunk['chunk_index']}"
            
            success = search_manager.upload_document(
                doc_id=chunk_doc_id,
                content=chunk['text'],
                vector=chunk_embedding,
                provider=provider,
                folder=folder,
                document_name=doc_name,
                chunk_index=chunk['chunk_index'],
                total_chunks=chunk['total_chunks']
            )
            
            if success:
                uploaded_chunks += 1
        except Exception as e:
            logger.warning(f"      Failed to upload chunk {chunk['chunk_index']}: {e}")
            continue
    
    if uploaded_chunks == 0:
        logger.warning(f"      FAILED: Could not upload any chunks")
        return {}, False
    
    logger.info(f"      Step 3: Indexed {uploaded_chunks}/{len(chunks)} chunks")
    
    # ========================================================================
    # STEP 4: EXTRACT EACH FIELD WITH FIELD-SPECIFIC RAG SEARCH
    # ========================================================================
    logger.info(f"      Step 4: Extracting {len(fields)} fields...")
    
    FIELD_LIBRARY = getattr(prompt_module, 'FIELD_LIBRARY', {})
    SYSTEM_PROMPT_CONFIG = getattr(prompt_module, 'SYSTEM_PROMPT_CONFIG', {})
    
    extracted_data = {}
    
    for field_idx, field_name in enumerate(fields, 1):
        try:
            field_info = FIELD_LIBRARY.get(field_name, {})
            field_desc = field_info.get('description', field_name)
            
            logger.info(f"        Field {field_idx}/{len(fields)}: {field_name}")
            
            # --- 4A: Field-specific RAG search ---
            field_query_parts = [
                field_name.replace('_', ' '),
                field_desc
            ]
            hints = field_info.get('extraction_hints', [])
            if hints:
                field_query_parts.append(' '.join(hints[:2]))
            
            field_query_text = ' '.join(field_query_parts)
            field_embedding, query_tokens = openai_manager.generate_embedding(
                field_query_text
            )
            cost_tracker.add_embedding(query_tokens)
            
            similar_docs = search_manager.search_similar(
                vector=field_embedding,
                provider=provider,
                folder=folder,
                top_k=3
            )
            
            logger.info(f"          RAG: {len(similar_docs)} chunks found")
            
            # --- 4B: Build prompt with RAG-retrieved context ---
            prompt = _build_field_prompt(
                field_name=field_name,
                field_info=field_info,
                similar_docs=similar_docs,
                fallback_text=chunks[0]['text'] if chunks else "",
                system_config=SYSTEM_PROMPT_CONFIG
            )
            
            # --- 4C: GPT extraction (TEXT ONLY - no vision) ---
            result, tokens = openai_manager.extract_fields(
                prompt=prompt,
                temperature=0.1,
                use_vision=False
            )
            
            cost_tracker.add_gpt_tokens(
                input_tokens=tokens['input_tokens'],
                output_tokens=tokens['output_tokens']
            )
            
            if field_name in result:
                extracted_data[field_name] = result[field_name]
                value = result[field_name].get('value', 'Unknown')
                conf = result[field_name].get('confidence', 0.0)
                logger.info(f"          Result: {value} (conf: {conf:.2f})")
            else:
                extracted_data[field_name] = {
                    'value': 'Unknown', 'confidence': 0.0
                }
                logger.info(f"          WARNING: Field not in response")
        
        except Exception as e:
            logger.error(f"          ERROR: {e}")
            extracted_data[field_name] = {
                'value': 'Unknown', 'confidence': 0.0
            }
    
    logger.info(
        f"      Step 4 complete: {len(extracted_data)}/{len(fields)} fields"
    )
    
    return extracted_data, True


def _build_field_prompt(
    field_name: str,
    field_info: dict,
    similar_docs: list,
    fallback_text: str,
    system_config: dict
) -> str:
    """
    Build extraction prompt for a single field using RAG-retrieved context.
    
    Args:
        field_name: Name of field to extract
        field_info: Field definition from FIELD_LIBRARY
        similar_docs: RAG search results (relevant chunks)
        fallback_text: Fallback text if no RAG results
        system_config: System prompt configuration
    
    Returns:
        Complete prompt string
    """
    field_desc = field_info.get('description', field_name)
    
    parts = []
    
    # System role
    parts.append(system_config.get('role', 'You are a data extraction assistant.'))
    parts.append("")
    
    # Task
    parts.append(f"TASK: Extract the '{field_name}' field from the document.")
    parts.append("")
    
    # Field definition
    parts.append("FIELD DEFINITION:")
    parts.append(f"  Name: {field_name}")
    parts.append(f"  Description: {field_desc}")
    parts.append(f"  Type: {field_info.get('type', 'string')}")
    
    if 'format' in field_info:
        parts.append(f"  Format: {field_info['format']}")
    if 'examples' in field_info:
        parts.append(f"  Valid examples: {', '.join(field_info['examples'])}")
    if 'validation' in field_info:
        parts.append(f"  Validation: {field_info['validation']}")
    parts.append("")
    
    # Document context from RAG
    parts.append("DOCUMENT CONTENT (most relevant sections):")
    parts.append("-" * 40)
    
    if similar_docs:
        total_chars = 0
        max_chars = 8000
        
        for idx, doc in enumerate(similar_docs, 1):
            doc_content = doc.get('content', '')
            doc_score = doc.get('score', 0)
            
            if total_chars + len(doc_content) > max_chars:
                remaining = max_chars - total_chars
                if remaining > 200:
                    parts.append(f"\n[Section {idx} (relevance: {doc_score:.2f})]:")
                    parts.append(doc_content[:remaining])
                break
            
            parts.append(f"\n[Section {idx} (relevance: {doc_score:.2f})]:")
            parts.append(doc_content)
            total_chars += len(doc_content)
    else:
        parts.append(fallback_text)
    
    parts.append("-" * 40)
    parts.append("")
    
    # Output format
    parts.append("OUTPUT FORMAT (JSON only, no markdown):")
    parts.append("Extract a value. If not found, use low confidence.")
    parts.append("")
    parts.append('{')
    parts.append(f'  "{field_name}": {{')
    parts.append('    "value": "extracted_value",')
    parts.append('    "confidence": 0.00-1.00')
    parts.append('  }')
    parts.append('}')
    parts.append("")
    
    # Rules
    rules = system_config.get('rules', [])
    if rules:
        parts.append("RULES:")
        for rule in rules[:3]:
            parts.append(f"  - {rule}")
    
    return "\n".join(parts)
