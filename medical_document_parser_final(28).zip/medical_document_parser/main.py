"""
MEDICAL DOCUMENT PARSER - PRODUCTION WITH RAG
"""

import os
import sys
import json
import logging
import argparse
from datetime import datetime
from typing import Dict, List, Any

from utils.logger_helper import setup_logger, get_logger, print_section

# Initialize logging (file + console)
log_filename = setup_logger(log_level="INFO", log_dir="logs")
logger = get_logger(__name__)


def load_configuration(config_path: str = "config/config.json") -> Dict:
    """Load and validate configuration file"""
    print_section("STEP 1: LOADING CONFIGURATION")
    
    try:
        logger.info(f"Looking for config file: {config_path}")
        
        if not os.path.exists(config_path):
            logger.error(f"Config file not found: {config_path}")
            raise FileNotFoundError(f"Config file not found: {config_path}")
        
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        logger.info(f"Config file loaded successfully")
        logger.info(f"Found {len(config['doctypes'])} doctypes: {', '.join(config['doctypes'].keys())}")
        
        return config
        
    except Exception as e:
        logger.error(f"Configuration loading failed: {str(e)}")
        raise


def validate_doctype_config(config: Dict, doctype: str) -> Dict:
    """Validate doctype-specific configuration"""
    print_section(f"STEP 2: VALIDATING DOCTYPE '{doctype}' CONFIG")
    
    try:
        logger.info(f"Checking doctype: {doctype}")
        
        if doctype not in config['doctypes']:
            raise ValueError(f"Doctype '{doctype}' not configured")
        
        doctype_config = config['doctypes'][doctype]
        folders = list(doctype_config['folder_configs'].keys())
        logger.info(f"Doctype '{doctype}' found with folders: {', '.join(folders)}")
        
        return doctype_config
        
    except Exception as e:
        logger.error(f"Doctype validation failed: {str(e)}")
        raise


def load_prompt_module(prompt_module_path: str):
    """Load prompt module dynamically"""
    print_section("STEP 3: LOADING PROMPT MODULE")
    
    try:
        logger.info(f"Loading prompt module: {prompt_module_path}")
        
        module_parts = prompt_module_path.split('.')
        module_name = module_parts[-1]
        
        module = __import__(prompt_module_path, fromlist=[module_name])
        
        field_count = len(module.FIELD_LIBRARY)
        logger.info(f"Prompt module loaded - {field_count} fields available")
        
        return module
        
    except Exception as e:
        logger.error(f"Prompt module loading failed: {str(e)}")
        raise


def initialize_azure_services(config: Dict, doctype_config: Dict):
    """Initialize Azure service connections"""
    print_section("STEP 4: INITIALIZING AZURE SERVICES")
    
    services = {}
    
    try:
        from services.keyvault_manager import KeyVaultManager, resolve_config_values
        from services.azure_clients import BlobManager, OpenAIManager, SearchManager
        from services.ocr import DocumentIntelligenceOCR
        from services.cost_tracker import CostTracker
        
        # Key Vault
        logger.info("Initializing Key Vault Manager...")
        vault_url = config.get('azure_keyvault', {}).get('vault_url')
        kv_manager = KeyVaultManager(vault_url)
        services['keyvault'] = kv_manager
        
        logger.info("Resolving configuration values...")
        resolve_config_values(config, kv_manager)
        resolve_config_values(doctype_config, kv_manager)
        logger.info("Configuration values resolved")
        
        # Blob Storage
        logger.info("Initializing Blob Storage...")
        blob_manager = BlobManager(config['azure_blob']['connection_string'])
        services['blob'] = blob_manager
        logger.info("Blob Storage initialized")
        
        # Document Intelligence (OCR)
        logger.info("Initializing Document Intelligence...")
        doc_intel_config = config['azure_document_intelligence']
        ocr_manager = DocumentIntelligenceOCR({
            'endpoint': doc_intel_config['endpoint'],
            'key': doc_intel_config['key'],
            'api_version': doc_intel_config.get('api_version', '2024-07-31-preview')
        })
        services['ocr'] = ocr_manager
        logger.info("Document Intelligence initialized")
        
        # OpenAI Manager (for extraction + embeddings)
        logger.info("Initializing OpenAI Manager...")
        openai_config = doctype_config['azure_openai']['general']
        embedding_config = doctype_config['azure_openai_embedding']
        
        # Get batch config if available
        batch_config = doctype_config['azure_openai'].get('batch')
        
        openai_manager = OpenAIManager(
            openai_config=openai_config,
            embedding_config=embedding_config,
            batch_config=batch_config  # Optional - for Batch API
        )
        services['openai'] = openai_manager
        
        if batch_config:
            logger.info(f"OpenAI Manager initialized - Model: {openai_config['model_name']}, Batch deployment: {batch_config['deployment_name']}")
        else:
            logger.info(f"OpenAI Manager initialized - Model: {openai_config['model_name']}")
        
        # AI Search Manager (for RAG)
        logger.info("Initializing AI Search...")
        search_config = doctype_config['azure_ai_search']
        
        # Get embedding dimensions from embedding config (must match!)
        embedding_dims = doctype_config['azure_openai_embedding'].get(
            'dimensions', doctype_config['azure_openai_embedding'].get('dimension', 1536)
        )
        
        search_manager = SearchManager(
            endpoint=search_config['endpoint'],
            api_key=search_config['key'],
            index_name=search_config['index_name'],
            vector_dimensions=embedding_dims
        )
        
        # Auto-create index if it doesn't exist (PRODUCTION READY!)
        logger.info(f"Checking if index '{search_config['index_name']}' exists...")
        try:
            created = search_manager.create_universal_index()
            if created:
                logger.info(f"OK Created new index: {search_config['index_name']}")
            else:
                logger.info(f"OK Index already exists: {search_config['index_name']}")
        except Exception as e:
            logger.warning(f"Index check/creation: {e}")
            logger.info("Continuing with existing index...")
        
        services['search'] = search_manager
        logger.info(f"AI Search initialized - Index: {search_config['index_name']}")
        
        # Cost Tracker (pass api_type for batch discount calculation)
        api_type = config.get('extraction', {}).get('api_type', 'general')
        cost_tracker = CostTracker(config.get('costs', {}), api_type=api_type)
        services['cost_tracker'] = cost_tracker
        logger.info(f"Cost Tracker initialized (api_type: {api_type})")
        
        logger.info("All Azure services initialized successfully!")
        
        return services
        
    except Exception as e:
        logger.error(f"Azure services initialization failed: {str(e)}")
        raise


def discover_providers(blob_manager, input_container: str):
    """Discover all providers"""
    print_section("STEP 5: DISCOVERING PROVIDERS")
    
    try:
        logger.info(f"Scanning container: {input_container}")
        
        folder_structure = blob_manager.get_folder_structure(input_container)
        providers = list(folder_structure.keys())
        
        logger.info(f"Found {len(providers)} providers")
        
        if len(providers) == 0:
            logger.warning("No providers found")
            return [], {}
        
        for i, provider in enumerate(providers[:5], 1):
            folders = folder_structure[provider]
            logger.info(f"   {i}. {provider} ({len(folders)} folders)")
        
        if len(providers) > 5:
            logger.info(f"   ... and {len(providers) - 5} more providers")
        
        return providers, folder_structure
        
    except Exception as e:
        logger.error(f"Provider discovery failed: {str(e)}")
        raise


def process_document_with_rag(doc_blob, provider: str, folder: str, fields: List[str],
                              services: Dict, config: Dict, prompt_module) -> Dict:
    """
    Process document using RAG extraction.
    
    Routes to text or multimodal based on config['rag']['mode']:
      - "text": OCR text + text-only GPT extraction
      - "multimodal": OCR text + document image + GPT Vision extraction
    
    Both modes use field-specific RAG search internally for accuracy.
    """
    doc_name = doc_blob.name.split('/')[-1]
    rag_mode = config.get('rag', {}).get('mode', 'text')
    api_type = config.get('extraction', {}).get('api_type', 'general')
    
    logger.info(f"      Mode: {rag_mode.upper()} RAG | API: {api_type.upper()} ({len(fields)} fields)")
    
    try:
        # Download document
        doc_bytes = services['blob'].download_blob(
            config['azure_blob']['inputcontainer'],
            doc_blob.name
        )
        
        if not doc_bytes:
            logger.error(f"      Failed to download {doc_name}")
            return None
        
        # Get document extension
        _, ext = os.path.splitext(doc_name)
        
        # Common parameters for both modes
        rag_params = dict(
            doc_bytes=doc_bytes,
            doc_name=doc_name,
            extension=ext,
            provider=provider,
            folder=folder,
            fields=fields,
            ocr=services['ocr'],
            openai_manager=services['openai'],
            search_manager=services['search'],
            cost_tracker=services['cost_tracker'],
            prompt_module=prompt_module,
            api_type=api_type
        )
        
        # Route based on config mode
        if rag_mode == 'multimodal':
            from extraction.multimodal_rag import process_document_multimodal_rag
            extracted_data, success = process_document_multimodal_rag(**rag_params)
        else:
            from extraction.text_rag import process_document_text_rag
            extracted_data, success = process_document_text_rag(**rag_params)
        
        if not success:
            logger.error(f"      RAG extraction failed for {doc_name}")
            return None
        
        return extracted_data
        
    except Exception as e:
        logger.error(f"      Document processing failed: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return None


def calculate_best_values(documents: List[Dict], fields: List[str], folder_name: str) -> Dict:
    """
    Calculate best values using BOTH frequency and confidence (POC logic)
    
    Strategy:
    1. Group values by frequency (most common value wins)
    2. If tie in frequency, choose highest confidence
    3. Track source file and folder for each field
    
    Args:
        documents: List of processed documents with fields
        fields: List of field names
        folder_name: Folder name for source tracking
    
    Returns:
        Dict with best values including source tracking
    """
    from collections import Counter
    
    best_values = {}
    
    for field in fields:
        field_occurrences = []  # List of (value, confidence, file) tuples
        
        for doc in documents:
            if field in doc['fields']:
                field_data = doc['fields'][field]
                
                if isinstance(field_data, dict):
                    value = field_data.get('value') or 'NA'
                    confidence = field_data.get('confidence') or 0
                    
                    # CRITICAL FIX: Ignore "Unknown" values with low confidence (<0.50)
                    # These are just noise from documents that don't have the field
                    if confidence is not None and value != 'NA':
                        # Skip "Unknown" with low confidence
                        if str(value).lower() == 'unknown' and float(confidence) < 0.50:
                            continue  # Don't count this occurrence
                        
                        field_occurrences.append((
                            value,
                            float(confidence),
                            doc.get('document_name', 'Unknown')
                        ))
        
        if field_occurrences:
            # Count frequency of each value
            value_counts = Counter([v[0] for v in field_occurrences])
            
            # Get most common value
            most_common_value, max_frequency = value_counts.most_common(1)[0]
            
            # Get all occurrences of the most common value
            candidates = [occ for occ in field_occurrences if occ[0] == most_common_value]
            
            # Pick the one with highest confidence
            best_occurrence = max(candidates, key=lambda x: x[1])
            best_value, best_confidence, source_file = best_occurrence
            
            # Calculate average confidence for this value
            confidences_for_value = [occ[1] for occ in candidates]
            avg_confidence = sum(confidences_for_value) / len(confidences_for_value)
            
            best_values[field] = {
                'value': best_value,
                'confidence': round(avg_confidence, 2),
                'source_folder': folder_name,
                'source_file': source_file,
                'frequency': max_frequency,
                'total_documents': len(documents)
            }
        else:
            # Field not found in any document
            best_values[field] = {
                'value': 'NA',
                'confidence': 0.0,
                'source_folder': folder_name,
                'source_file': 'Not found',
                'frequency': 0,
                'total_documents': len(documents)
            }
    
    return best_values


def save_results(provider: str, extracted_data: Dict, output_container: str,
                input_container: str, blob_manager, 
                config: Dict, total_documents: int, folder_name: str,
                source_documents: list = None, cost_tracker=None):
    """
    Save extraction results to output container
    
    Output structure per provider:
      highconfidence/ or lowconfidence/
        PROVIDER_NAME/
          ProcessedJSONResult/provider_timestamp.json
          ProcessedCSVResult/provider_timestamp.csv
          ProcessedProviderCostEstimation/provider_timestamp.json
          SourceDocuments/original_file1.pdf, original_file2.jpg, ...
    """
    try:
        import csv
        from io import StringIO
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        extraction_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Calculate confidence metrics
        confidences = []
        for field_data in extracted_data.values():
            if isinstance(field_data, dict) and 'confidence' in field_data:
                confidences.append(field_data.get('confidence', 0))
        
        # Calculate both for reporting
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0
        min_confidence = min(confidences) if confidences else 0
        
        # Determine folder based on MIN confidence (stricter!)
        # If ANY field is below threshold  ->  lowconfidence for review
        confidence_threshold = config.get('extraction', {}).get('confidence_threshold', 0.70)
        
        if min_confidence >= confidence_threshold:
            output_folder = "highconfidence"
            logger.info(f"      Routing: HIGH confidence (min: {min_confidence:.2f}, avg: {avg_confidence:.2f})")
        else:
            output_folder = "lowconfidence"
            logger.info(f"      Routing: LOW confidence (min: {min_confidence:.2f}, avg: {avg_confidence:.2f})")
        
        # Provider ID = provider_timestamp (unique Azure AI Search ID)
        provider_id = f"{provider}_{timestamp}"
        
        # Prepare JSON output with metadata
        json_output = {
            'provider_name': provider,
            'provider_id': provider_id,
            'extraction_datetime': extraction_datetime,
            'total_documents_processed': total_documents,
            'folders_processed': folder_name,
            'confidence_metrics': {
                'min_confidence': round(min_confidence, 2),
                'avg_confidence': round(avg_confidence, 2),
                'threshold': confidence_threshold,
                'routing': output_folder
            },
            'fields': extracted_data
        }
        
        # JSON output
        json_path = f"{output_folder}/{provider}/ProcessedJSONResult/{provider}_{timestamp}.json"
        json_content = json.dumps(json_output, indent=2)
        blob_manager.upload_blob(output_container, json_path, json_content)
        logger.info(f"      Saved JSON: {json_path}")
        
        # Provider Cost Estimation JSON
        # Uses actual tracked costs from CostTracker
        provider_cost_estimation = {
            'provider_name': provider,
            'provider_id': provider_id,
            'extraction_datetime': extraction_datetime,
            'total_documents_processed': total_documents,
            'confidence_metrics': {
                'min_confidence': round(min_confidence, 2),
                'avg_confidence': round(avg_confidence, 2),
                'threshold': confidence_threshold,
                'routing': output_folder
            }
        }
        
        # Add actual cost data if cost_tracker is available
        if cost_tracker is not None:
            summary = cost_tracker.get_summary()
            provider_data = summary.get('providers', {}).get(provider, {})
            
            if provider_data:
                tokens = provider_data.get('tokens', {})
                provider_cost_estimation['token_usage'] = {
                    'gpt_input_tokens': tokens.get('input', 0),
                    'gpt_output_tokens': tokens.get('output', 0),
                    'gpt_total_tokens': tokens.get('total', 0),
                    'embedding_tokens': tokens.get('embedding', 0)
                }
                provider_cost_estimation['pages_processed'] = provider_data.get('ocr_pages', 0)
                
                cost_bd = provider_data.get('cost_breakdown', {})
                provider_cost_estimation['estimated_cost'] = {
                    'api_type': summary.get('api_type', 'general'),
                    'ocr_cost': cost_bd.get('ocr', 0),
                    'embedding_cost': cost_bd.get('embedding', 0),
                    'gpt_cost': cost_bd.get('gpt', 0),
                    'total_cost': provider_data.get('cost', 0),
                    'note': 'Batch API cost is 50% reduced compared to general API'
                        if summary.get('api_type') == 'batch'
                        else 'Standard general API pricing'
                }
        
        cost_path = f"{output_folder}/{provider}/ProcessedProviderCostEstimation/{provider}_{timestamp}.json"
        cost_content = json.dumps(provider_cost_estimation, indent=2)
        blob_manager.upload_blob(output_container, cost_path, cost_content)
        logger.info(f"      Saved Cost Estimation: {cost_path}")
        
        # CSV output - SINGLE ROW format (POC style)
        csv_lines = []
        
        # Get field order from extracted_data
        field_order = list(extracted_data.keys())
        
        # Build headers (only essential columns)
        headers = [
            'provider_name',
            'extraction_datetime',
            'total_documents_processed'
        ]
        
        # Add field columns (4 columns per field)
        for field in field_order:
            headers.append(f'{field}')
            headers.append(f'{field}_confidence')
            headers.append(f'{field}_source_folder')
            headers.append(f'{field}_source_file')
        
        csv_lines.append(','.join(headers))
        
        # Escape function for CSV values
        def escape_csv(value):
            """Escape CSV values - wrap in quotes if contains comma, quote, or newline"""
            value_str = str(value)
            if ',' in value_str or '"' in value_str or '\n' in value_str or '\r' in value_str:
                # Escape quotes by doubling them
                value_str = value_str.replace('"', '""')
                return f'"{value_str}"'
            return value_str
        
        # Build ONE row for the provider (only essential columns)
        row_values = [
            escape_csv(provider),                    # provider_name
            escape_csv(extraction_datetime),         # extraction_datetime
            escape_csv(total_documents)              # total_documents_processed
        ]
        
        # Add field values
        for field in field_order:
            field_data = extracted_data[field]
            if isinstance(field_data, dict):
                row_values.append(escape_csv(field_data.get('value', 'NA')))
                row_values.append(escape_csv(field_data.get('confidence', 0)))
                row_values.append(escape_csv(field_data.get('source_folder', folder_name)))
                row_values.append(escape_csv(field_data.get('source_file', 'multiple')))
            else:
                # Fallback if format is wrong
                row_values.append(escape_csv(field_data))
                row_values.append(escape_csv(0))
                row_values.append(escape_csv(folder_name))
                row_values.append(escape_csv('unknown'))
        
        csv_lines.append(','.join(row_values))
        
        # Save CSV
        csv_path = f"{output_folder}/{provider}/ProcessedCSVResult/{provider}_{timestamp}.csv"
        csv_content = '\n'.join(csv_lines)
        blob_manager.upload_blob(output_container, csv_path, csv_content)
        logger.info(f"      Saved CSV: {csv_path}")
        
        # Copy source documents to output container (preserve folder structure)
        if source_documents:
            source_count = 0
            for doc_blob in source_documents:
                try:
                    # Preserve folder structure relative to provider
                    # Input: SMITH-JOHN/1. GEN & HR/subfolder/file.pdf
                    # Output: highconfidence/SMITH-JOHN/SourceDocuments/1. GEN & HR/subfolder/file.pdf
                    relative_path = doc_blob.name.replace(
                        f"{provider}/", "", 1
                    )
                    doc_bytes = blob_manager.download_blob(
                        input_container, doc_blob.name
                    )
                    if doc_bytes:
                        source_path = f"{output_folder}/{provider}/SourceDocuments/{relative_path}"
                        blob_manager.upload_blob(
                            output_container, source_path, doc_bytes
                        )
                        source_count += 1
                except Exception as e:
                    logger.warning(f"      Could not copy source doc {doc_blob.name}: {e}")
            logger.info(f"      Saved SourceDocuments: {source_count} files")
        
        logger.info(f"      Confidence: MIN={min_confidence:.2f}, AVG={avg_confidence:.2f} -> {output_folder}")
        
        return min_confidence
        
    except Exception as e:
        logger.error(f"      Failed to save results: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        raise


def process_single_provider(provider: str, folder_structure: Dict, blob_manager, 
                            config: Dict, services: Dict, doctype: str, 
                            doctype_config: Dict, prompt_module, archiver=None):
    """Process a single provider's documents with RAG"""
    try:
        # Set current provider for cost tracking
        services['cost_tracker'].set_provider(provider)
        
        if provider not in folder_structure:
            logger.warning(f"   Provider not found")
            return
        
        provider_folders = folder_structure[provider]
        folder_configs = doctype_config['folder_configs']
        
        # Get folder names
        provider_folder_names = list(provider_folders.keys()) if isinstance(provider_folders, dict) else provider_folders
        
        # Find matching folder
        matching_folder = None
        for folder_name in folder_configs.keys():
            if folder_name in provider_folder_names:
                matching_folder = folder_name
                break
        
        if not matching_folder:
            logger.warning(f"   No matching folder found")
            logger.warning(f"   Expected: {list(folder_configs.keys())}")
            logger.warning(f"   Found: {provider_folder_names}")
            return
        
        logger.info(f"   Processing folder: {matching_folder}")
        
        # Get documents
        folder_path = f"{provider}/{matching_folder}"
        documents = blob_manager.list_blobs_in_folder(
            config['azure_blob']['inputcontainer'],
            folder_path
        )
        
        logger.info(f"   Found {len(documents)} documents (including all subfolders)")
        
        if len(documents) == 0:
            logger.warning(f"   No documents to process")
            return
        
        # Get fields
        fields = folder_configs[matching_folder]['fields']
        logger.info(f"   Extracting {len(fields)} fields using PER-FIELD RAG")
        logger.info(f"   Each field gets its own best 3 examples for maximum accuracy")
        
        # Store ALL extracted data from all documents (not just aggregated)
        all_documents_data = []
        
        # Process each document with RAG
        for doc_idx, doc_blob in enumerate(documents, 1):
            # Extract subfolder path from blob name
            relative_path = doc_blob.name.replace(f"{provider}/", "")
            
            logger.info(f"   Document {doc_idx}/{len(documents)}: {relative_path}")
            
            extracted_data = process_document_with_rag(
                doc_blob,
                provider,
                matching_folder,
                fields,
                services,
                config,
                prompt_module  # Pass prompt_module
            )
            
            if not extracted_data:
                continue
            
            # Store document data with metadata
            all_documents_data.append({
                'document_name': doc_blob.name.split('/')[-1],
                'relative_path': relative_path,
                'fields': extracted_data
            })
            
            logger.info(f"      Document processed successfully with RAG")
            services['cost_tracker'].add_provider_document()
        
        # Aggregate results using FREQUENCY + CONFIDENCE (POC logic)
        if all_documents_data:
            logger.info(f"   Aggregating results from {len(all_documents_data)} documents...")
            
            # Calculate best values using frequency and confidence
            final_results = calculate_best_values(
                all_documents_data, 
                fields,
                matching_folder
            )
            
            # Save aggregated results + source documents
            logger.info(f"   Saving aggregated results...")
            avg_confidence = save_results(
                provider,
                final_results,
                config['azure_blob']['outputcontainer'],
                config['azure_blob']['inputcontainer'],
                services['blob'],
                config,
                len(documents),
                matching_folder,
                documents,
                cost_tracker=services['cost_tracker']
            )
            logger.info(f"   Provider processing complete - Confidence: {avg_confidence:.2f}")
            
            # Queue for archive if enabled (--archive true)
            # processedprovider/highconfidence/ or processedprovider/lowconfidence/
            archive_enabled = config.get('extraction', {}).get('archive', False)
            if archive_enabled and archiver is not None:
                confidence_threshold = config.get('extraction', {}).get(
                    'confidence_threshold', 0.70
                )
                confidences = [
                    v.get('confidence', 0) for v in final_results.values()
                    if isinstance(v, dict) and 'confidence' in v
                ]
                min_conf = min(confidences) if confidences else 0
                
                routing = "highconfidence" if min_conf >= confidence_threshold else "lowconfidence"
                archiver.add_provider(provider, documents, routing)
        else:
            logger.warning(f"   No data extracted from any document")
            
            # Queue as unprocessed (processing failed, no data)
            archive_enabled = config.get('extraction', {}).get('archive', False)
            if archive_enabled and archiver is not None:
                archiver.add_provider(provider, documents, "unprocessed")
        
    except Exception as e:
        logger.error(f"   Provider failed: {str(e)}")
        logger.exception("   Traceback:")
        
        # Queue as unprocessed (exception during processing)
        archive_enabled = config.get('extraction', {}).get('archive', False)
        if archive_enabled and archiver is not None:
            try:
                folder_path = f"{provider}/{matching_folder}" if matching_folder else provider
                documents = blob_manager.list_blobs_in_folder(
                    config['azure_blob']['inputcontainer'], folder_path
                )
                if documents:
                    archiver.add_provider(provider, documents, "unprocessed")
            except Exception:
                pass


def process_providers(providers: List[str], folder_structure: Dict, config: Dict, 
                     services: Dict, doctype: str, doctype_config: Dict, prompt_module):
    """Process all providers in batches"""
    print_section("STEP 6: PROCESSING PROVIDERS WITH RAG")
    
    try:
        batch_size = config['processing'].get('batch_size', 10)
        total_providers = len(providers)
        total_batches = (total_providers + batch_size - 1) // batch_size
        
        logger.info(f"Processing configuration:")
        logger.info(f"   Total providers: {total_providers}")
        logger.info(f"   Batch size: {batch_size}")
        logger.info(f"   RAG mode: {config['rag']['mode']}")
        logger.info(f"   Total batches: {total_batches}")
        
        if total_providers == 0:
            logger.warning("No providers to process")
            return
        
        # Create archiver if archive is enabled
        archive_enabled = config.get('extraction', {}).get('archive', False)
        archiver = None
        if archive_enabled:
            from services.archive_manager import ArchiveManager
            archiver = ArchiveManager(
                blob_manager=services['blob'],
                config=config,
                doctype=doctype
            )
            logger.info(f"   Archive: ENABLED")
        
        # Process in batches
        for batch_num in range(total_batches):
            start_idx = batch_num * batch_size
            end_idx = min(start_idx + batch_size, total_providers)
            batch_providers = providers[start_idx:end_idx]
            
            logger.info("")
            logger.info("=" * 80)
            logger.info(f"BATCH {batch_num + 1}/{total_batches} (Providers {start_idx + 1}-{end_idx})")
            logger.info("=" * 80)
            
            for provider_idx, provider in enumerate(batch_providers, 1):
                global_idx = start_idx + provider_idx
                logger.info("")
                logger.info(f"Provider {global_idx}/{total_providers}: {provider}")
                logger.info("-" * 80)
                
                process_single_provider(
                    provider,
                    folder_structure,
                    services['blob'], 
                    config, 
                    services, 
                    doctype,
                    doctype_config,
                    prompt_module,
                    archiver=archiver
                )
        
        # Finalize archive (create single zip with all providers)
        if archiver is not None:
            logger.info("")
            logger.info("=" * 80)
            logger.info("ARCHIVING")
            logger.info("=" * 80)
            archiver.finalize()
        
        # ================================================================
        # FINAL SUMMARY
        # ================================================================
        cost_summary = services['cost_tracker'].get_summary()
        rag_mode = config.get('rag', {}).get('mode', 'text')
        api_type = config.get('extraction', {}).get('api_type', 'general')
        archive_enabled = config.get('extraction', {}).get('archive', False)
        provider_stats = cost_summary.get('providers', {})
        usage = cost_summary['usage']
        breakdown = cost_summary['breakdown']
        
        # Count processed vs unprocessed
        processed_list = [p for p, s in provider_stats.items() if s['documents'] > 0]
        unprocessed_list = [p for p, s in provider_stats.items() if s['documents'] == 0]
        total_docs = sum(s['documents'] for s in provider_stats.values())
        
        logger.info("")
        logger.info("=" * 80)
        logger.info("FINAL SUMMARY")
        logger.info("=" * 80)
        
        # Run info
        logger.info(f"  RAG mode        : {rag_mode.upper()}")
        logger.info(f"  API type        : {api_type.upper()}")
        logger.info(f"  Archive         : {'YES' if archive_enabled else 'NO'}")
        
        # Provider counts
        logger.info("")
        logger.info(f"  Providers       : {len(provider_stats)} total")
        logger.info(f"    Processed     : {len(processed_list)}")
        logger.info(f"    Unprocessed   : {len(unprocessed_list)}")
        if unprocessed_list:
            for p in unprocessed_list:
                logger.info(f"      - {p}")
        
        # Pages and docs
        logger.info("")
        logger.info(f"  Documents       : {total_docs}")
        logger.info(f"  Pages (OCR)     : {usage['ocr_pages']}")
        
        # Token consumption - overall
        logger.info("")
        logger.info(f"  Tokens (overall)")
        logger.info(f"    Input         : {usage['gpt_input_tokens']:,}")
        logger.info(f"    Output        : {usage['gpt_output_tokens']:,}")
        logger.info(f"    Total         : {usage['gpt_total_tokens']:,}")
        logger.info(f"    Embedding     : {usage['embedding_tokens']:,}")
        
        # Token consumption - per provider
        if provider_stats:
            logger.info("")
            logger.info(f"  Tokens (per provider)")
            for prov, stats in provider_stats.items():
                t = stats['tokens']
                logger.info(
                    f"    {prov}: "
                    f"{stats['documents']} docs, "
                    f"{stats['ocr_pages']} pages, "
                    f"input={t['input']:,}, "
                    f"output={t['output']:,}, "
                    f"embedding={t['embedding']:,}, "
                    f"cost=${stats['cost']:.4f}"
                )
        
        # Cost
        logger.info("")
        logger.info(f"  Cost ({api_type.upper()} API)")
        logger.info(f"    OCR           : ${breakdown['ocr']:.4f}")
        logger.info(f"    Embeddings    : ${breakdown['embedding']:.4f}")
        logger.info(f"    GPT           : ${breakdown['gpt4o']:.4f}")
        logger.info(f"    TOTAL         : ${cost_summary['total']:.4f}")
        
        logger.info("")
        logger.info("=" * 80)
        
    except Exception as e:
        logger.error(f"Processing failed: {str(e)}")
        raise


def main():
    """Main application entry point"""
    
    try:
        # Parse command-line arguments
        parser = argparse.ArgumentParser(description='Medical Document Parser with RAG')
        parser.add_argument('--apitype', required=True, choices=['general', 'batch'], 
                          help='API type: general (real-time) or batch (50%% cheaper)')
        parser.add_argument('--doctype', required=True, 
                          help='Document type (e.g., cred)')
        parser.add_argument('--archive', required=True, choices=['true', 'false'],
                          help='Enable archiving: true or false')
        
        args = parser.parse_args()
        
        # Convert string 'true'/'false' to boolean
        archive_enabled = args.archive.lower() == 'true'
        
        print_section("MEDICAL DOCUMENT PARSER - RAG-BASED PRODUCTION SYSTEM", "=")
        logger.info(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Log file: {log_filename}")
        logger.info(f"Arguments: --apitype {args.apitype} --doctype {args.doctype} --archive {args.archive}")
        
        # Load configuration
        config = load_configuration()
        
        # Override config with command-line arguments
        config['extraction']['api_type'] = args.apitype
        config['extraction']['archive'] = archive_enabled
        
        # Get RAG mode from config
        rag_mode = config.get('rag', {}).get('mode', 'text')
        logger.info(f"Settings: API={args.apitype} | RAG={rag_mode} | Archive={args.archive}")
        
        # Validate and initialize
        doctype_config = validate_doctype_config(config, args.doctype)
        prompt_module = load_prompt_module(doctype_config['prompt_module'])
        services = initialize_azure_services(config, doctype_config)
        providers, folder_structure = discover_providers(services['blob'], config['azure_blob']['inputcontainer'])
        process_providers(providers, folder_structure, config, services, args.doctype, doctype_config, prompt_module)
        
        print_section("PROCESSING COMPLETE", "=")
        logger.info(f"End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Log saved: {log_filename}")
        logger.info(f"Check output container for results!")
        
    except KeyboardInterrupt:
        logger.warning("Process interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error("FATAL ERROR")
        logger.error(f"   {str(e)}")
        logger.exception("Traceback:")
        sys.exit(1)


if __name__ == "__main__":
    main()
