"""
IMPROVED Multimodal RAG Module - Handles multi-page documents with page-by-page vision extraction

KEY IMPROVEMENTS:
1. Converts PDF pages to images using PyMuPDF (fitz)
2. Processes each page separately with GPT Vision
3. Aggregates results from all pages
4. Handles DOC/DOCX by converting to PDF first, then to images
5. Direct image files (JPG, PNG) sent as-is

WORKFLOW:
- PDF → Convert each page to image → Base64 → GPT Vision (per page) → Aggregate
- DOC/DOCX → Convert to PDF → Convert pages to images → GPT Vision (per page) → Aggregate  
- Images → Base64 → GPT Vision → Extract
"""

import logging
import base64
import fitz  # PyMuPDF
from typing import Dict, Tuple, List
from io import BytesIO

def convert_pdf_pages_to_images(pdf_bytes: bytes, logger: logging.Logger) -> List[Dict]:
    """
    Convert each PDF page to a base64-encoded PNG image
    
    Args:
        pdf_bytes: PDF file as bytes
        logger: Logger instance
    
    Returns:
        List of dicts with {'page': int, 'base64': str, 'format': 'png'}
    """
    images = []
    
    try:
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        total_pages = len(doc)
        
        logger.info(f"Converting {total_pages} PDF pages to images...")
        
        for page_num in range(total_pages):
            page = doc[page_num]
            
            # Render page to high-quality image
            # Matrix(2, 2) = 2x zoom = 144 DPI (good for OCR and vision)
            pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))
            
            # Convert to PNG bytes
            img_bytes = pix.tobytes("png")
            
            # Encode to base64
            base64_image = base64.b64encode(img_bytes).decode('utf-8')
            
            images.append({
                'page': page_num + 1,
                'base64': base64_image,
                'format': 'png',
                'width': pix.width,
                'height': pix.height
            })
            
            logger.info(f"  Page {page_num + 1}/{total_pages}: {pix.width}x{pix.height} → {len(base64_image)} chars base64")
        
        doc.close()
        logger.info(f"✓ Converted {total_pages} pages to images")
        
        return images
        
    except Exception as e:
        logger.error(f"Error converting PDF to images: {e}")
        return []


def convert_doc_to_pdf(doc_bytes: bytes, logger: logging.Logger) -> bytes:
    """
    Convert DOC/DOCX to PDF using python-docx and reportlab
    
    Args:
        doc_bytes: DOC/DOCX file as bytes
        logger: Logger instance
    
    Returns:
        PDF bytes
    """
    try:
        from docx import Document
        from reportlab.lib.pagesizes import letter
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet
        
        # Load DOCX
        doc = Document(BytesIO(doc_bytes))
        
        # Create PDF
        pdf_buffer = BytesIO()
        pdf_doc = SimpleDocTemplate(pdf_buffer, pagesize=letter)
        styles = getSampleStyleSheet()
        story = []
        
        # Extract text from DOCX
        for para in doc.paragraphs:
            if para.text.strip():
                story.append(Paragraph(para.text, styles['Normal']))
                story.append(Spacer(1, 12))
        
        # Build PDF
        pdf_doc.build(story)
        
        pdf_bytes = pdf_buffer.getvalue()
        logger.info(f"✓ Converted DOC/DOCX to PDF ({len(pdf_bytes)} bytes)")
        
        return pdf_bytes
        
    except Exception as e:
        logger.error(f"Error converting DOC/DOCX to PDF: {e}")
        return None


def process_multimodal_rag(
    doc_bytes: bytes,
    doc_info: dict,
    provider: str,
    folder: str,
    folder_config: dict,
    ocr,
    openai_manager,
    search_manager,
    cost_tracker,
    config: dict,
    logger: logging.Logger
) -> Tuple[Dict, bool]:
    """
    Process document using IMPROVED MULTIMODAL RAG mode
    
    IMPROVEMENTS:
    - Multi-page PDFs: Convert each page to image, process separately
    - DOC/DOCX: Convert to PDF, then to images
    - Images: Process directly
    - Aggregate results from all pages using frequency + confidence
    
    Args:
        doc_bytes: Binary document content
        doc_info: Document metadata (name, extension, folder)
        provider: Provider name
        folder: Folder name
        folder_config: Folder configuration with fields
        ocr: OCR manager instance
        openai_manager: OpenAI manager instance
        search_manager: Search manager instance
        cost_tracker: Cost tracking instance
        config: System configuration
        logger: Logger instance
    
    Returns:
        Tuple of (extracted_data, success)
    """
    
    doc_name = doc_info['name']
    extension = doc_info['extension'].lower()
    rag_config = config['rag']
    
    try:
        # Step 1: Convert to images based on file type
        logger.info(f"Step 1: Converting document to images...")
        
        images = []
        
        if extension == '.pdf':
            # PDF: Convert each page to image
            images = convert_pdf_pages_to_images(doc_bytes, logger)
            
        elif extension in ['.doc', '.docx']:
            # DOC/DOCX: Convert to PDF first, then to images
            logger.info(f"  Converting DOC/DOCX to PDF first...")
            pdf_bytes = convert_doc_to_pdf(doc_bytes, logger)
            if pdf_bytes:
                images = convert_pdf_pages_to_images(pdf_bytes, logger)
            
        elif extension in ['.jpg', '.jpeg', '.png', '.tiff', '.bmp', '.gif', '.webp']:
            # Image: Use directly
            base64_image = base64.b64encode(doc_bytes).decode('utf-8')
            images = [{
                'page': 1,
                'base64': base64_image,
                'format': extension[1:]  # Remove dot
            }]
            logger.info(f"✓ Step 1 Complete: Direct image ({len(base64_image)} chars base64)")
        
        else:
            logger.error(f"❌ Unsupported file type: {extension}")
            return {}, False
        
        if not images:
            logger.error(f"❌ FAILED Step 1: Could not convert document to images")
            return {}, False
        
        logger.info(f"✓ Step 1 Complete: {len(images)} page(s) converted to images")
        
        # Step 2: Extract OCR text for RAG search (text-based)
        logger.info(f"Step 2: Running OCR for text-based RAG search...")
        text, pages, success = ocr.extract_text(doc_bytes, extension)
        
        if not success or len(text) < 100:
            logger.warning(f"⚠️ OCR failed or insufficient text, but continuing with vision-only mode")
            text = ""  # Continue without text-based RAG
        else:
            logger.info(f"✓ Step 2 Complete: Extracted {len(text)} characters from {pages} pages")
            cost_tracker.add_ocr(pages)
        
        # Step 3: Generate embedding and RAG search (if we have text)
        similar_docs = []
        if len(text) >= 100:
            logger.info(f"Step 3: Generating embedding for RAG search...")
            
            # Generate embedding
            search_vector, embedding_tokens = openai_manager.generate_embedding(text[:8000])  # Limit to 8K
            cost_tracker.add_embedding(embedding_tokens)
            
            # Index document
            import hashlib
            content_hash = hashlib.md5(text.encode('utf-8', errors='ignore')).hexdigest()
            
            search_manager.index_document(
                document_id=f"{provider}_{folder}_{doc_name}_{content_hash}",
                content=text,
                vector=search_vector,
                metadata={
                    'provider': provider,
                    'folder': folder,
                    'document': doc_name
                }
            )
            
            # RAG search
            logger.info(f"Step 4: RAG search for similar documents...")
            similar_docs = search_manager.search_similar(
                search_vector, provider, folder, rag_config['top_k']
            )
            logger.info(f"✓ Step 4 Complete: Found {len(similar_docs)} similar docs")
        else:
            logger.info(f"Step 3-4: Skipping text-based RAG (no text available)")
        
        # Step 5: Process each page with GPT Vision
        logger.info(f"Step 5: Processing {len(images)} page(s) with GPT Vision...")
        
        all_page_results = []
        
        for img_data in images:
            page_num = img_data['page']
            base64_image = img_data['base64']
            
            logger.info(f"  Processing page {page_num}/{len(images)} with vision...")
            
            # Build prompt with RAG examples (if available)
            from prompt_builder import build_extraction_prompt
            prompt = build_extraction_prompt(
                text=f"Page {page_num} of {len(images)}",  # Minimal text context
                fields=folder_config['fields'],
                rag_examples=similar_docs,
                folder_description=folder_config.get('description', '')
            )
            
            # Call GPT Vision with image
            extracted_data, tokens = openai_manager.extract_fields(
                prompt,
                use_vision=True,
                image_base64=base64_image
            )
            
            if extracted_data:
                all_page_results.append({
                    'page': page_num,
                    'fields': extracted_data
                })
                logger.info(f"    ✓ Page {page_num}: Extracted {len(extracted_data)} fields")
            else:
                logger.warning(f"    ⚠️ Page {page_num}: No data extracted")
            
            cost_tracker.add_gpt4o(tokens['input_tokens'], tokens['output_tokens'])
        
        logger.info(f"✓ Step 5 Complete: Processed {len(images)} pages")
        
        # Step 6: Aggregate results from all pages using frequency + confidence
        logger.info(f"Step 6: Aggregating results from {len(all_page_results)} pages...")
        
        final_results = aggregate_page_results(
            all_page_results,
            folder_config['fields'],
            logger
        )
        
        logger.info(f"✓ Step 6 Complete: Aggregated {len(final_results)} fields")
        
        return final_results, True
        
    except Exception as e:
        logger.error(f"Error in MULTIMODAL RAG processing for {doc_name}: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return {}, False


def aggregate_page_results(page_results: List[Dict], fields: List[str], logger: logging.Logger) -> Dict:
    """
    Aggregate field extractions from multiple pages using frequency + confidence
    
    Strategy (same as multi-document aggregation):
    1. Group values by frequency (most common wins)
    2. If tie, choose highest confidence
    3. Track source page
    
    Args:
        page_results: List of {'page': int, 'fields': dict}
        fields: List of field names
        logger: Logger instance
    
    Returns:
        Dict with best values for each field
    """
    from collections import Counter
    
    best_values = {}
    
    for field in fields:
        field_occurrences = []  # List of (value, confidence, page) tuples
        
        for page_data in page_results:
            page_num = page_data['page']
            page_fields = page_data['fields']
            
            if field in page_fields:
                field_data = page_fields[field]
                
                if isinstance(field_data, dict):
                    value = field_data.get('value', 'NA')
                    confidence = field_data.get('confidence', 0)
                    
                    if confidence is not None and value != 'NA':
                        field_occurrences.append((value, float(confidence), page_num))
        
        if field_occurrences:
            # Count frequency
            value_counts = Counter([v[0] for v in field_occurrences])
            most_common_value, max_frequency = value_counts.most_common(1)[0]
            
            # Get all occurrences of most common value
            candidates = [occ for occ in field_occurrences if occ[0] == most_common_value]
            
            # Pick highest confidence
            best_occurrence = max(candidates, key=lambda x: x[1])
            best_value, best_confidence, source_page = best_occurrence
            
            # Calculate average confidence
            confidences_for_value = [occ[1] for occ in candidates]
            avg_confidence = sum(confidences_for_value) / len(confidences_for_value)
            
            best_values[field] = {
                'value': best_value,
                'confidence': round(avg_confidence, 2),
                'source_page': source_page,
                'frequency': max_frequency,
                'total_pages': len(page_results)
            }
            
            logger.info(f"  {field}: '{best_value}' (conf={avg_confidence:.2f}, freq={max_frequency}/{len(page_results)}, page={source_page})")
        else:
            # Field not found in any page
            best_values[field] = {
                'value': 'NA',
                'confidence': 0.0,
                'source_page': 'Not found',
                'frequency': 0,
                'total_pages': len(page_results)
            }
    
    return best_values
