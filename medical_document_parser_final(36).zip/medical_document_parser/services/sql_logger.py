"""
SQL Logger - Provider-level logging to Azure SQL Server
========================================================

Logs each provider's processing status to dbo.XLogDocumentParserRAG table.
One row per provider with status updates at each processing step.

Config requirements:
    "sql_server": {
        "connection_string": "@azureKeyVault(SQLServerDocumentProcessor)"
    },
    "logging": {
        "enabled": true,
        "table_name": "dbo.XLogDocumentParserRAG"
    }
"""

import logging
from datetime import datetime

try:
    import pyodbc
    PYODBC_AVAILABLE = True
except ImportError:
    PYODBC_AVAILABLE = False


class SQLLogger:
    """
    SQL Server logger for provider processing status.
    
    Lifecycle per provider:
        1. insert_begin() -> returns document_id (auto-generated PK)
        2. update_status() -> update status at each step (OCR, embedding, search, parsing)
        3. update_complete() -> final status with target/archive paths
    """
    
    def __init__(self, config: dict):
        """
        Initialize SQL Logger from config.
        
        Args:
            config: Full config dict containing sql_server and logging sections
        """
        self.logger = logging.getLogger(__name__)
        self.enabled = False
        self.conn_str = None
        self.table_name = None
        
        # Check if pyodbc is available
        if not PYODBC_AVAILABLE:
            self.logger.warning("SQL Logger: pyodbc not installed. SQL logging disabled.")
            return
        
        # Check if logging is enabled in config
        logging_config = config.get('logging', {})
        if not logging_config.get('enabled', False):
            self.logger.info("SQL Logger: disabled in config")
            return
        
        # Get connection string
        sql_config = config.get('sql_server', {})
        self.conn_str = sql_config.get('connection_string')
        
        if not self.conn_str:
            self.logger.warning("SQL Logger: no connection_string in config. Disabled.")
            return
        
        self.table_name = logging_config.get('table_name', 'dbo.XLogDocumentParserRAG')
        self.enabled = True
        self.logger.info(f"SQL Logger: enabled -> {self.table_name}")
    
    def _get_uid(self) -> str:
        """Extract UID from connection string or return 'system'."""
        if not self.conn_str:
            return "system"
        for part in self.conn_str.split(";"):
            if part.strip().upper().startswith("UID="):
                return part.split("=")[1].strip()
        return "system"
    
    def insert_begin(self, provider_name: str, document_type: str, api_type: str,
                     source_file_path: str = "") -> int:
        """
        Insert initial log row when provider processing begins.
        
        Args:
            provider_name: Provider name (e.g., "SMITH-JOHN")
            document_type: Doctype (e.g., "cred")
            api_type: "general" or "batch"
            source_file_path: Input container path
        
        Returns:
            document_id (DocumentParserRAG_Key) for subsequent updates, or None
        """
        if not self.enabled:
            return None
        
        try:
            conn = pyodbc.connect(self.conn_str)
            cursor = conn.cursor()
            
            created_by = self._get_uid()
            created_on = datetime.now()
            
            insert_query = f"""
                INSERT INTO {self.table_name} (
                    ProviderName, DocumentType, APIType,
                    FileName, SourceFilePath,
                    TargetFilePath, ArchiveFilePath,
                    Status, StatusDesc,
                    AzureAISearchStatus, AzureAISearchStatusDesc,
                    AzureEmbeddingStatus, AzureEmbeddingStatusDesc,
                    AzureParsingStatus, AzureParsingStatusDesc,
                    AzureOCRStatus, AzureOCRStatusDesc,
                    CREATED_ON, CREATED_BY
                )
                OUTPUT INSERTED.DocumentParserRAG_Key
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            
            cursor.execute(insert_query,
                provider_name, document_type, api_type,
                "", source_file_path,
                "", "",
                "BEGIN", "Started processing provider",
                "", "", "", "", "", "", "", "",
                created_on, created_by
            )
            
            result = cursor.fetchone()
            conn.commit()
            
            if result:
                document_id = result[0]
                self.logger.info(f"SQL Logger: INSERT provider={provider_name}, id={document_id}")
                return document_id
            else:
                self.logger.error("SQL Logger: INSERT returned no ID")
                return None
                
        except Exception as e:
            self.logger.error(f"SQL Logger: INSERT error: {e}")
            return None
        finally:
            try:
                cursor.close()
                conn.close()
            except Exception:
                pass
    
    def update_status(self, document_id: int, status: str, status_desc: str,
                      ocr_status: str = None, ocr_desc: str = None,
                      embedding_status: str = None, embedding_desc: str = None,
                      search_status: str = None, search_desc: str = None,
                      parsing_status: str = None, parsing_desc: str = None):
        """
        Update provider processing status at each step.
        
        Args:
            document_id: PK from insert_begin()
            status: Overall status (e.g., "PROCESSING", "OCR_COMPLETE")
            status_desc: Human-readable description
            ocr_status/desc: Azure OCR step status
            embedding_status/desc: Azure embedding step status
            search_status/desc: Azure AI Search step status
            parsing_status/desc: Azure GPT parsing step status
        """
        if not self.enabled or document_id is None:
            return
        
        try:
            conn = pyodbc.connect(self.conn_str)
            cursor = conn.cursor()
            
            updated_by = self._get_uid()
            updated_on = datetime.now()
            
            # Build dynamic SET clause - only update non-None fields
            set_parts = ["Status = ?", "StatusDesc = ?", "UPDATED_ON = ?", "UPDATED_BY = ?"]
            params = [status, status_desc, updated_on, updated_by]
            
            if ocr_status is not None:
                set_parts.append("AzureOCRStatus = ?")
                set_parts.append("AzureOCRStatusDesc = ?")
                params.extend([ocr_status, ocr_desc or ""])
            
            if embedding_status is not None:
                set_parts.append("AzureEmbeddingStatus = ?")
                set_parts.append("AzureEmbeddingStatusDesc = ?")
                params.extend([embedding_status, embedding_desc or ""])
            
            if search_status is not None:
                set_parts.append("AzureAISearchStatus = ?")
                set_parts.append("AzureAISearchStatusDesc = ?")
                params.extend([search_status, search_desc or ""])
            
            if parsing_status is not None:
                set_parts.append("AzureParsingStatus = ?")
                set_parts.append("AzureParsingStatusDesc = ?")
                params.extend([parsing_status, parsing_desc or ""])
            
            params.append(document_id)
            
            update_query = f"""
                UPDATE {self.table_name}
                SET {', '.join(set_parts)}
                WHERE DocumentParserRAG_Key = ?
            """
            
            cursor.execute(update_query, *params)
            conn.commit()
            
            self.logger.debug(f"SQL Logger: UPDATE id={document_id}, status={status}")
            
        except Exception as e:
            self.logger.error(f"SQL Logger: UPDATE error: {e}")
        finally:
            try:
                cursor.close()
                conn.close()
            except Exception:
                pass
    
    def update_complete(self, document_id: int, status: str, status_desc: str,
                        target_file_path: str = "", archive_file_path: str = "",
                        file_name: str = ""):
        """
        Final update when provider processing completes or fails.
        
        Args:
            document_id: PK from insert_begin()
            status: Final status ("COMPLETED", "FAILED", "HIGH_CONFIDENCE", "LOW_CONFIDENCE")
            status_desc: Description
            target_file_path: Output blob path (highconfidence/ or lowconfidence/)
            archive_file_path: Archive blob path (if archiving enabled)
            file_name: Output filename (JSON/CSV)
        """
        if not self.enabled or document_id is None:
            return
        
        try:
            conn = pyodbc.connect(self.conn_str)
            cursor = conn.cursor()
            
            updated_by = self._get_uid()
            updated_on = datetime.now()
            
            update_query = f"""
                UPDATE {self.table_name}
                SET Status = ?,
                    StatusDesc = ?,
                    FileName = ?,
                    TargetFilePath = ?,
                    ArchiveFilePath = ?,
                    UPDATED_ON = ?,
                    UPDATED_BY = ?
                WHERE DocumentParserRAG_Key = ?
            """
            
            cursor.execute(update_query,
                status, status_desc, file_name,
                target_file_path, archive_file_path or "",
                updated_on, updated_by, document_id
            )
            conn.commit()
            
            self.logger.info(f"SQL Logger: COMPLETE id={document_id}, status={status}")
            
        except Exception as e:
            self.logger.error(f"SQL Logger: COMPLETE error: {e}")
        finally:
            try:
                cursor.close()
                conn.close()
            except Exception:
                pass
