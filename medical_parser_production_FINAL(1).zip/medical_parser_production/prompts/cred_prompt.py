"""
Medical Credentials Prompt Configuration
"""

FIELD_DEFINITIONS = {
    'first_name': {
        'field_type': 'single',
        'description': 'Provider first name',
        'examples': ['John', 'Mary', 'Robert']
    },
    
    'last_name': {
        'field_type': 'single',
        'description': 'Provider last name',
        'examples': ['Smith', 'Johnson', 'Lee']
    },
    
    'state_licenses': {
        'field_type': 'array',
        'description': 'ALL state medical licenses',
        'array_schema': {
            'license_number': 'State license number',
            'state': 'State abbreviation',
            'expiration': 'Expiration date',
            'issue_date': 'Issue date'
        }
    }
}

SYSTEM_PROMPT = """
You are a medical credentials extraction specialist.
Extract provider information with high accuracy.
"""

OUTPUT_FORMAT = """
Return JSON format with confidence scores.
"""
