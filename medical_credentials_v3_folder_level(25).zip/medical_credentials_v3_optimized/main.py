"""
MEDICAL CREDENTIALS EXTRACTION - FOLDER-LEVEL OPTIMIZED
========================================================
Features:
- Folder-level extraction (process specific folders across all providers)
- Priority chunking (semantic chunking before indexing)
- Document Intelligence v1.0.0b4
- Both text and multimodal RAG modes
- Universal index with provider+folder filtering
"""

import json
import logging
import os
from datetime import datetime
from collections import Counter
from typing import Dict, List, Tuple

# Import optimized modules
from helper import BlobManager, OpenAIManager, SearchManager, generate_document_id
from documentintelligence_ocr import DocumentIntelligenceOCR
from semantic_chunker import process_for_chunking
from costtracking import CostTracker
from logging_config import setup_logging
from prompt_builder import build_extraction_prompt


def load_config() -> dict:
    """Load configuration from config.json"""
    with open('config.json', 'r') as f:
        return json.load(f)


def get_folder_config(config: dict, folder_name: str) -> dict:
    """
    Get configuration for a specific folder
    
    Args:
        config: Full configuration
        folder_name: Folder name to look up
    
    Returns:
        Folder configuration (fields, description) or None if not found
    """
    # Check if folder has specific config
    if folder_name in config.get('folder_configs', {}):
        return config['folder_configs'][folder_name]
    
    # No config found
    return None


def match_folder_to_config(folder_path: str, folder_configs: dict) -> Tuple[str, dict]:
    """
    Match a folder path to configured folder
    
    Args:
        folder_path: Full folder path (e.g., "Personal/2024" or "Licenses")
        folder_configs: Configured folders from config.json
    
    Returns:
        Tuple of (matched_config_name, config_dict)
    """
    # Exact match first
    if folder_path in folder_configs:
        return folder_path, folder_configs[folder_path]
    
    # Check if folder path starts with any configured folder
    for config_name in folder_configs:
        if folder_path.startswith(config_name):
            return config_name, folder_configs[config_name]
    
    # No match - return None
    return None, None


def process_document(doc_info: dict, blob_manager: BlobManager, ocr: DocumentIntelligenceOCR,
                    openai_manager: OpenAIManager, search_manager: SearchManager,
                    folder_config: dict, rag_config: dict, cost_tracker: CostTracker,
                    logger: logging.Logger) -> Dict:
    """Process single document with chunking and RAG"""
    
    doc_name = doc_info['filename']
    provider = doc_info['provider']
    folder = doc_info['folder']
    
    logger.info(f"Processing: {provider}/{folder}/{doc_name}")
    
    # Download document
    logger.info(f"Step 1: Downloading document...")
    doc_bytes = blob_manager.download_blob(
        config['azure_blob']['inputcontainer'],
        doc_info['blob_name']
    )
    
    if not doc_bytes:
        logger.error(f"❌ FAILED Step 1: Could not download {doc_name}")
        return None
    logger.info(f"✓ Step 1 Complete: Downloaded {len(doc_bytes)} bytes")
    
    # OCR extraction
    logger.info(f"Step 2: Running OCR...")
    text, pages, success = ocr.extract_text(doc_bytes, doc_info['extension'])
    
    if not success:
        logger.error(f"❌ FAILED Step 2: OCR failed for {doc_name}")
        return None
    logger.info(f"✓ Step 2 Complete: Extracted {len(text)} characters from {pages} pages")
    
    cost_tracker.add_ocr(pages)
    
    # Check minimum text length
    min_length = config['extraction']['min_text_length']
    if len(text) < min_length:
        logger.warning(f"❌ FAILED Step 3: Insufficient text ({len(text)} < {min_length} chars) for {doc_name}")
        return None
    logger.info(f"✓ Step 3 Complete: Text length sufficient ({len(text)} chars)")
    
    # Generate content hash for uniqueness (prevents overwrite on re-upload)
    import hashlib
    content_hash = hashlib.md5(text.encode('utf-8', errors='ignore')).hexdigest()
    
    # Priority chunking
    logger.info(f"Step 4: Chunking document...")
    needs_chunking, chunks, strategy = process_for_chunking(
        text, rag_config, f"{provider}_{folder}_{doc_name}"
    )
    logger.info(f"✓ Step 4 Complete: needs_chunking={needs_chunking}, chunks={len(chunks) if chunks else 0}")
    
    if needs_chunking:
        logger.info(f"Chunking: {len(chunks)} chunks created for {doc_name}")
        
        # Index all chunks
        for chunk in chunks:
            vector, embedding_tokens = openai_manager.generate_embedding(chunk['text'])
            cost_tracker.add_embedding(embedding_tokens)
            
            doc_id = generate_document_id(provider, folder, doc_name, 
                                          chunk['chunk_index'], content_hash)
            
            search_manager.upload_document(
                doc_id=doc_id,
                content=chunk['text'],
                vector=vector,
                provider=provider,
                folder=folder,
                document_name=doc_name,
                chunk_index=chunk['chunk_index'],
                total_chunks=chunk['total_chunks']
            )
        
        # Use first chunk for extraction
        extraction_text = chunks[0]['text']
    else:
        # Index full document
        vector, embedding_tokens = openai_manager.generate_embedding(text)
        cost_tracker.add_embedding(embedding_tokens)
        
        doc_id = generate_document_id(provider, folder, doc_name, 
                                      content_hash=content_hash)
        
        search_manager.upload_document(
            doc_id=doc_id,
            content=text,
            vector=vector,
            provider=provider,
            folder=folder,
            document_name=doc_name
        )
        
        extraction_text = text
    
    # RAG search (provider + folder filtered)
    search_vector, embedding_tokens = openai_manager.generate_embedding(extraction_text)
    cost_tracker.add_embedding(embedding_tokens)
    
    similar_docs = search_manager.search_similar(
        search_vector, provider, folder, rag_config['top_k']
    )
    
    # Determine RAG mode from global config
    rag_mode = config['rag']['mode']  # "text" or "multimodal"
    is_image = doc_info['extension'] in ['.jpg', '.jpeg', '.png', '.tiff', '.bmp', '.gif', '.webp']
    
    # Use multimodal only if: (1) mode is multimodal AND (2) file is image
    use_multimodal = (rag_mode == 'multimodal') and is_image
    
    # Build prompt
    logger.info(f"Step 7: Building extraction prompt...")
    prompt = build_extraction_prompt(
        text=extraction_text,
        fields=folder_config['fields'],
        rag_examples=similar_docs,
        folder_description=folder_config.get('description', '')
    )
    logger.info(f"✓ Step 7 Complete: Prompt built ({len(prompt)} chars)")
    
    # Extract fields
    logger.info(f"Step 8: Calling GPT-4o for extraction...")
    if use_multimodal:
        import base64
        image_base64 = base64.b64encode(doc_bytes).decode('utf-8')
        extracted_data, tokens = openai_manager.extract_fields(
            prompt, use_vision=True, image_base64=image_base64
        )
        logger.info(f"✓ Step 8 Complete: Used MULTIMODAL RAG for {doc_name}")
    else:
        extracted_data, tokens = openai_manager.extract_fields(prompt)
        logger.info(f"✓ Step 8 Complete: Used TEXT RAG for {doc_name}")
    
    logger.info(f"GPT-4o tokens: input={tokens['input_tokens']}, output={tokens['output_tokens']}")
    
    # Debug: Log sample field to check format
    if extracted_data and len(extracted_data) > 0:
        first_field = list(extracted_data.keys())[0]
        first_value = extracted_data[first_field]
        logger.info(f"Sample field format - {first_field}: {type(first_value).__name__} = {first_value}")
    else:
        logger.error(f"❌ WARNING: extracted_data is empty or None!")
    
    cost_tracker.add_gpt4o(tokens['input_tokens'], tokens['output_tokens'])
    cost_tracker.add_embedding(len(extraction_text) // 4)  # Estimate
    
    return {
        'document_name': doc_name,
        'fields': extracted_data,
        'rag_mode': 'multimodal' if use_multimodal else 'text',
        'chunked': needs_chunking,
        'chunks_count': len(chunks) if needs_chunking else 1
    }


def calculate_best_values(documents: List[Dict], fields: List[str], 
                          confidence_threshold: float = 0.50) -> Tuple[Dict, str]:
    """
    Calculate best values using BOTH frequency and confidence
    
    Strategy:
    1. Group values by frequency (most common)
    2. If tie in frequency, choose highest confidence
    3. Return the best value with its average confidence
    4. If field not found or low confidence, still include it as-is
    
    Args:
        documents: List of processed documents
        fields: List of field names
        confidence_threshold: Minimum confidence for highconfidence category
    
    Returns:
        Tuple of (best_values dict, category string)
    """
    best_values = {}
    min_confidence = 1.0
    
    for field in fields:
        field_occurrences = []  # List of (value, confidence) tuples
        
        for doc in documents:
            if field in doc['fields']:
                field_data = doc['fields'][field]
                
                # STRICT: Only accept dict format with confidence
                if isinstance(field_data, dict):
                    value = field_data.get('value', 'NA')
                    confidence = field_data.get('confidence')
                    
                    # CRITICAL: Confidence MUST exist and be valid
                    if confidence is None:
                        raise ValueError(f"❌ CRITICAL ERROR: Field '{field}' missing confidence score! GPT-4o must return confidence for ALL fields.")
                    
                    # Ensure confidence is float
                    try:
                        confidence = float(confidence)
                        if not (0.0 <= confidence <= 1.0):
                            raise ValueError(f"❌ CRITICAL ERROR: Field '{field}' confidence {confidence} out of range [0.0, 1.0]")
                    except (ValueError, TypeError) as e:
                        raise ValueError(f"❌ CRITICAL ERROR: Field '{field}' confidence '{confidence}' is not a valid number: {e}")
                else:
                    # REJECT string format - GPT-4o MUST return proper format
                    raise ValueError(
                        f"❌ CRITICAL ERROR: Field '{field}' returned as string '{field_data}' instead of dict with confidence!\n"
                        f"GPT-4o is NOT following the required format.\n"
                        f"Required: {{'value': '...', 'confidence': 0.XX}}\n"
                        f"Got: '{field_data}'\n\n"
                        f"CHECK:\n"
                        f"1. Is your deployment GPT-4o (not GPT-3.5)?\n"
                        f"2. Check logs for GPT-4o response format\n"
                        f"3. Review prompt_config.py output_format"
                    )
                
                # Include ALL values (even NA), don't filter
                field_occurrences.append((value, confidence))
        
        # Select best value using frequency AND confidence
        if field_occurrences:
            # Count frequency of each value
            from collections import defaultdict
            value_groups = defaultdict(list)  # value -> list of confidences
            
            for value, confidence in field_occurrences:
                value_groups[value].append(confidence)
            
            # Find highest frequency
            max_frequency = max(len(confidences) for confidences in value_groups.values())
            
            # Get all values with max frequency
            top_values = [
                (value, confidences) 
                for value, confidences in value_groups.items() 
                if len(confidences) == max_frequency
            ]
            
            # If tie in frequency, choose highest average confidence
            if len(top_values) > 1:
                best_value, best_confidences = max(
                    top_values, 
                    key=lambda x: sum(x[1]) / len(x[1])  # Average confidence
                )
            else:
                best_value, best_confidences = top_values[0]
            
            avg_confidence = sum(best_confidences) / len(best_confidences)
            
            best_values[field] = {
                'value': best_value,
                'confidence': round(avg_confidence, 2)
            }
            min_confidence = min(min_confidence, avg_confidence)
        else:
            # Field not extracted from any document - skip it completely
            # Don't add to best_values - it simply won't appear in output
            continue
    
    # Determine category: If ANY field has confidence < threshold → lowconfidence
    category = 'lowconfidence' if min_confidence < confidence_threshold else 'highconfidence'
    return best_values, category


def save_provider_results(blob_manager: BlobManager, provider: str, 
                         all_folders_data: Dict[str, Dict],
                         config: dict, cost_tracker, logger: logging.Logger):
    """
    Save results for entire provider (all folders combined)
    ONE ROW in CSV per provider
    
    Structure:
      {category}/
        {provider}/
          ProcessedJSONResult/{provider}_{timestamp}.json
          ProcessedCSVResult/{provider}_{timestamp}.csv
          ProcessedEstimateCostTracking/{provider}_{timestamp}.json
    
    Args:
        all_folders_data: Dict of {folder_name: {documents, best_values, category}}
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Determine overall category (if ANY folder is low confidence, entire provider is low)
    categories = [data['category'] for data in all_folders_data.values()]
    overall_category = 'lowconfidence' if 'lowconfidence' in categories else 'highconfidence'
    
    # Base path
    base_path = f"{overall_category}/{provider}"
    
    # Collect all fields from all folders
    all_fields = {}
    total_documents = 0
    
    for folder_name, folder_data in all_folders_data.items():
        total_documents += len(folder_data['documents'])
        # Merge best values from all folders
        for field, field_data in folder_data['best_values'].items():
            # Use the highest confidence value if field appears in multiple folders
            if field not in all_fields or field_data['confidence'] > all_fields[field]['confidence']:
                # Find which document had this value
                source_file = 'Unknown'
                for doc in folder_data['documents']:
                    if field in doc.get('fields', {}):
                        doc_field_data = doc['fields'][field]
                        doc_value = doc_field_data.get('value', '') if isinstance(doc_field_data, dict) else doc_field_data
                        if str(doc_value) == str(field_data['value']):
                            source_file = doc.get('document_name', 'Unknown')
                            break
                
                all_fields[field] = {
                    'value': field_data['value'],
                    'confidence': field_data['confidence'],
                    'folder': folder_name,
                    'file': source_file
                }
    
    # JSON result - Complete data
    json_result = {
        'provider': provider,
        'timestamp': timestamp,
        'total_documents_processed': total_documents,
        'folders': all_folders_data,
        'combined_fields': all_fields,
        'category': overall_category
    }
    
    json_path = f"{base_path}/ProcessedJSONResult/{provider}_{timestamp}.json"
    blob_manager.upload_blob(
        config['azure_blob']['outputcontainer'],
        json_path,
        json.dumps(json_result, indent=2),
        'application/json'
    )
    logger.info(f"Saved JSON: {json_path}")
    
    # CSV result - ONE ROW for entire provider
    csv_lines = []
    
    # Get field order from first folder config (they should all have same fields)
    first_folder = list(all_folders_data.keys())[0]
    # Get original field order from config (not sorted!)
    field_order = list(all_fields.keys())  # Will be in the order they were added
    
    # Build headers
    headers = [
        'provider_name',
        'provider_id',
        'extraction_datetime',
        'total_documents_processed',
        'folders_processed'
    ]
    
    # Add field columns IN CONFIG ORDER
    for field in field_order:
        headers.append(f'{field}')
        headers.append(f'{field}_confidence')
        headers.append(f'{field}_source_folder')
        headers.append(f'{field}_source_file')
    
    csv_lines.append(','.join(headers))
    
    # Build ONE row for the provider
    extraction_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    folders_list = '; '.join(all_folders_data.keys())  # Use semicolon to avoid CSV issues
    
    # provider_id = providername_timestamp
    provider_id = f"{provider}_{timestamp}"
    
    # Escape function for CSV values
    def escape_csv(value):
        """Escape CSV values - wrap in quotes if contains comma, quote, or newline"""
        value_str = str(value)
        if ',' in value_str or '"' in value_str or '\n' in value_str or '\r' in value_str:
            # Escape quotes by doubling them
            value_str = value_str.replace('"', '""')
            return f'"{value_str}"'
        return value_str
    
    row_values = [
        escape_csv(provider),  # provider_name
        escape_csv(provider_id),  # provider_id with timestamp
        escape_csv(extraction_datetime),  # extraction_datetime
        escape_csv(total_documents),  # total_documents_processed
        escape_csv(folders_list)  # folders_processed
    ]
    
    # Add field values IN CONFIG ORDER
    for field in field_order:
        field_data = all_fields[field]
        row_values.append(escape_csv(field_data['value']))
        row_values.append(escape_csv(field_data['confidence']))
        row_values.append(escape_csv(field_data['folder']))
        row_values.append(escape_csv(field_data['file']))
    
    csv_lines.append(','.join(row_values))
    
    csv_path = f"{base_path}/ProcessedCSVResult/{provider}_{timestamp}.csv"
    blob_manager.upload_blob(
        config['azure_blob']['outputcontainer'],
        csv_path,
        '\n'.join(csv_lines),
        'text/csv'
    )
    logger.info(f"Saved CSV: {csv_path}")
    
    # Cost tracking
    cost_summary = cost_tracker.get_summary()
    cost_path = f"{base_path}/ProcessedEstimateCostTracking/{provider}_{timestamp}.json"
    blob_manager.upload_blob(
        config['azure_blob']['outputcontainer'],
        cost_path,
        json.dumps(cost_summary, indent=2),
        'application/json'
    )
    logger.info(f"Saved Cost: {cost_path}")


def main():
    """Main execution"""
    global config
    
    # Load config
    config = load_config()
    logger = setup_logging(config)
    
    logger.info("="*80)
    logger.info("MEDICAL CREDENTIALS EXTRACTION - FOLDER-LEVEL OPTIMIZED")
    logger.info("="*80)
    
    # Initialize managers
    logger.info("Initializing managers...")
    logger.info(f"RAG Mode: {config['rag']['mode']}")  # Show global RAG mode
    
    blob_manager = BlobManager(config['azure_blob']['connection_string'])
    
    ocr = DocumentIntelligenceOCR(
        config['azure_document_intelligence']['endpoint'],
        config['azure_document_intelligence']['key']
    )
    
    openai_manager = OpenAIManager(
        config['azure_openai_gpt'],
        config['azure_openai_embedding']
    )
    
    search_manager = SearchManager(
        config['azure_search']['endpoint'],
        config['azure_search']['api_key'],
        config['azure_search']['universal_index_name'],
        config['azure_openai_embedding']['dimension']
    )
    
    cost_tracker = CostTracker(config)
    
    # Create universal index
    logger.info("Setting up universal index...")
    if search_manager.create_universal_index():
        logger.info("✓ Index created")
    else:
        logger.info("✓ Index exists")
    
    # Auto-cleanup
    if config['azure_search']['enable_auto_cleanup']:
        logger.info("Running auto-cleanup...")
        deleted = search_manager.delete_old_documents(config['azure_search']['auto_delete_days'])
        logger.info(f"✓ Deleted {deleted} old documents")
    
    # Get folder structure
    logger.info("Analyzing folder structure...")
    folder_structure = blob_manager.get_folder_structure(config['azure_blob']['inputcontainer'])
    
    total_providers = len(folder_structure)
    logger.info(f"Found {total_providers} providers")
    
    # Process each provider
    total_docs_processed = 0
    total_docs_found = 0
    processed_providers = []
    unprocessed_providers = []
    
    for provider, provider_folders in folder_structure.items():
        logger.info(f"\n{'='*80}")
        logger.info(f"PROVIDER: {provider}")
        logger.info(f"{'='*80}")
        logger.info(f"Found {len(provider_folders)} folders: {provider_folders}")
        
        # Collect all folder results for this provider
        provider_folders_data = {}
        provider_doc_count = 0
        
        # Process each folder
        for folder in provider_folders:
            # Match folder to config
            config_name, folder_config = match_folder_to_config(folder, config.get('folder_configs', {}))
            
            # Skip if not configured
            if not folder_config:
                logger.info(f"Skipping unconfigured folder: {folder}")
                continue
            
            logger.info(f"\n--- Folder: {folder} (Config: {config_name}) ---")
            logger.info(f"Fields: {folder_config['fields']}")
            logger.info(f"Description: {folder_config.get('description', 'N/A')}")
            
            # Get documents in folder
            documents_list = blob_manager.list_folder_documents(
                config['azure_blob']['inputcontainer'],
                provider,
                folder
            )
            
            # Filter by supported formats
            supported = config['extraction']['supported_formats']
            documents_list = [d for d in documents_list if d['extension'] in supported]
            
            total_docs_found += len(documents_list)
            logger.info(f"Found {len(documents_list)} documents to process")
            
            # Process documents
            processed_docs = []
            for doc_info in documents_list:
                result = process_document(
                    doc_info, blob_manager, ocr, openai_manager, search_manager,
                    folder_config, config['rag'], cost_tracker, logger
                )
                
                if result:
                    processed_docs.append(result)
                    total_docs_processed += 1
                    provider_doc_count += 1
            
            # Calculate best values for this folder
            if processed_docs:
                best_values, category = calculate_best_values(
                    processed_docs, 
                    folder_config['fields'],
                    config['extraction']['confidence_threshold']
                )
                
                # Store folder data (don't save yet - collect all folders first)
                provider_folders_data[folder] = {
                    'documents': processed_docs,
                    'best_values': best_values,
                    'category': category
                }
        
        # Save ALL folders for this provider at once (ONE CSV row per provider)
        if provider_folders_data:
            save_provider_results(
                blob_manager, provider, provider_folders_data,
                config, cost_tracker, logger
            )
            processed_providers.append(provider)
        else:
            unprocessed_providers.append(provider)
    
    # Final comprehensive summary
    logger.info(f"\n{'='*80}")
    logger.info("FINAL SUMMARY")
    logger.info(f"{'='*80}")
    
    # Provider statistics
    logger.info(f"\nPROVIDER STATISTICS:")
    logger.info(f"  Total providers found: {total_providers}")
    logger.info(f"  Processed providers: {len(processed_providers)}")
    logger.info(f"  Unprocessed providers: {len(unprocessed_providers)}")
    if processed_providers:
        logger.info(f"  Processed list: {', '.join(processed_providers)}")
    if unprocessed_providers:
        logger.info(f"  Unprocessed list: {', '.join(unprocessed_providers)}")
    
    # Document statistics
    logger.info(f"\nDOCUMENT STATISTICS:")
    logger.info(f"  Total files found: {total_docs_found}")
    logger.info(f"  Processed files: {total_docs_processed}")
    logger.info(f"  Unprocessed files: {total_docs_found - total_docs_processed}")
    
    # Cost breakdown
    cost_summary = cost_tracker.get_summary()
    logger.info(f"\nCOST BREAKDOWN:")
    logger.info(f"  Total cost: ${cost_summary['total']:.4f}")
    logger.info(f"  OCR cost: ${cost_summary['breakdown']['ocr']:.4f}")
    logger.info(f"  Embedding cost: ${cost_summary['breakdown']['embedding']:.4f}")
    logger.info(f"  GPT-4o cost: ${cost_summary['breakdown']['gpt4o']:.4f}")
    
    # Configuration
    logger.info(f"\nCONFIGURATION:")
    logger.info(f"  RAG mode: {config['rag']['mode']}")
    logger.info(f"  Confidence threshold: {config['extraction']['confidence_threshold']*100:.0f}%")
    logger.info(f"  Index strategy: {config['azure_search']['index_strategy']}")
    
    # Storage paths
    output_container = config['azure_blob']['outputcontainer']
    logger.info(f"\nSTORAGE PATHS:")
    logger.info(f"  Log file: {config['logging']['log_folder']}/extraction_*.log")
    logger.info(f"  Output container: {output_container}")
    logger.info(f"  High confidence CSV: {output_container}/highconfidence/{{provider}}/ProcessedCSVResult/{{provider}}_{{timestamp}}.csv")
    logger.info(f"  High confidence JSON: {output_container}/highconfidence/{{provider}}/ProcessedJSONResult/{{provider}}_{{timestamp}}.json")
    logger.info(f"  High confidence Cost: {output_container}/highconfidence/{{provider}}/ProcessedEstimateCostTracking/{{provider}}_{{timestamp}}.json")
    logger.info(f"  Low confidence CSV: {output_container}/lowconfidence/{{provider}}/ProcessedCSVResult/{{provider}}_{{timestamp}}.csv")
    logger.info(f"  Low confidence JSON: {output_container}/lowconfidence/{{provider}}/ProcessedJSONResult/{{provider}}_{{timestamp}}.json")
    logger.info(f"  Low confidence Cost: {output_container}/lowconfidence/{{provider}}/ProcessedEstimateCostTracking/{{provider}}_{{timestamp}}.json")
    
    logger.info(f"\n{'='*80}")
    logger.info("✓ Processing complete - Check output container for results")
    logger.info(f"{'='*80}\n")


if __name__ == "__main__":
    main()
