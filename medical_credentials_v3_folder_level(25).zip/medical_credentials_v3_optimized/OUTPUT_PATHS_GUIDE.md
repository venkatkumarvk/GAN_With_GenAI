# OUTPUT PATHS GUIDE

## 📂 **COMPLETE FILE PATH STRUCTURE**

All output files are saved to Azure Blob Storage with organized paths based on confidence level.

---

## 🎯 **PATH STRUCTURE**

### **Format:**
```
{outputcontainer}/{category}/{provider}/ProcessedXXXResult/{provider}_{timestamp}.{ext}
```

### **Components:**
- **outputcontainer:** Azure Blob container name from config.json
- **category:** `highconfidence` or `lowconfidence`
- **provider:** Provider name (e.g., ANAND-NICHOLS)
- **timestamp:** Format `YYYYMMDD_HHMMSS` (e.g., 20260306_123456)

---

## 📊 **COMPLETE PATH EXAMPLES**

### **High Confidence Provider:**

**CSV File:**
```
outputcontainer/highconfidence/ANAND-NICHOLS/ProcessedCSVResult/ANAND-NICHOLS_20260306_123456.csv
```

**JSON File:**
```
outputcontainer/highconfidence/ANAND-NICHOLS/ProcessedJSONResult/ANAND-NICHOLS_20260306_123456.json
```

**Cost Tracking File:**
```
outputcontainer/highconfidence/ANAND-NICHOLS/ProcessedEstimateCostTracking/ANAND-NICHOLS_20260306_123456.json
```

---

### **Low Confidence Provider:**

**CSV File:**
```
outputcontainer/lowconfidence/ANAND-NICHOLS/ProcessedCSVResult/ANAND-NICHOLS_20260306_123456.csv
```

**JSON File:**
```
outputcontainer/lowconfidence/ANAND-NICHOLS/ProcessedJSONResult/ANAND-NICHOLS_20260306_123456.json
```

**Cost Tracking File:**
```
outputcontainer/lowconfidence/ANAND-NICHOLS/ProcessedEstimateCostTracking/ANAND-NICHOLS_20260306_123456.json
```

---

## 🔍 **FINDING YOUR FILES**

### **In Azure Portal:**

1. Go to **Azure Storage Account**
2. Click **Containers**
3. Open **outputcontainer** (or your container name)
4. Navigate folder structure:
   ```
   outputcontainer/
   ├── highconfidence/
   │   ├── Provider1/
   │   │   ├── ProcessedCSVResult/
   │   │   │   └── Provider1_20260306_123456.csv
   │   │   ├── ProcessedJSONResult/
   │   │   │   └── Provider1_20260306_123456.json
   │   │   └── ProcessedEstimateCostTracking/
   │   │       └── Provider1_20260306_123456.json
   │   └── Provider2/
   │       └── ...
   └── lowconfidence/
       └── Provider3/
           └── ...
   ```

---

## 💡 **EXAMPLE SUMMARY OUTPUT**

### **What You'll See in Logs:**

```
================================================================================
FINAL SUMMARY
================================================================================

PROVIDER STATISTICS:
  Total providers found: 3
  Processed providers: 2
  Unprocessed providers: 1
  Processed list: ANAND-NICHOLS, Provider2
  Unprocessed list: Provider3

DOCUMENT STATISTICS:
  Total files found: 25
  Processed files: 20
  Unprocessed files: 5

COST BREAKDOWN:
  Total cost: $0.0868
  OCR cost: $0.0800
  Embedding cost: $0.0004
  GPT-4o cost: $0.0067

CONFIGURATION:
  RAG mode: text
  Confidence threshold: 70%
  Index strategy: universal

STORAGE PATHS:
  Log file: logs/extraction_20260306_123456.log
  Output container: outputcontainer
  High confidence CSV: outputcontainer/highconfidence/{provider}/ProcessedCSVResult/{provider}_{timestamp}.csv
  High confidence JSON: outputcontainer/highconfidence/{provider}/ProcessedJSONResult/{provider}_{timestamp}.json
  High confidence Cost: outputcontainer/highconfidence/{provider}/ProcessedEstimateCostTracking/{provider}_{timestamp}.json
  Low confidence CSV: outputcontainer/lowconfidence/{provider}/ProcessedCSVResult/{provider}_{timestamp}.csv
  Low confidence JSON: outputcontainer/lowconfidence/{provider}/ProcessedJSONResult/{provider}_{timestamp}.json
  Low confidence Cost: outputcontainer/lowconfidence/{provider}/ProcessedEstimateCostTracking/{provider}_{timestamp}.json

================================================================================
✓ Processing complete - Check output container for results
================================================================================
```

---

## 📋 **FILE NAMING CONVENTION**

### **Pattern:**
```
{provider_name}_{YYYYMMDD_HHMMSS}.{extension}
```

### **Examples:**
```
ANAND-NICHOLS_20260306_123456.csv
ANAND-NICHOLS_20260306_123456.json
Provider2_20260306_140530.csv
John-Doe_20260307_091520.json
```

### **Components:**
- **provider_name:** Exact provider folder name
- **YYYYMMDD:** Date (2026-03-06 → 20260306)
- **HHMMSS:** Time (12:34:56 → 123456)
- **extension:** csv, json (based on file type)

---

## 🎯 **CATEGORY DETERMINATION**

### **How Providers are Categorized:**

**High Confidence:**
```
All fields have confidence >= threshold (e.g., 70%)

Example:
  first_name: 0.95
  last_name: 0.82
  email: 0.75
  cell: 0.70  ← Minimum
  
  Minimum: 0.70 >= 0.70 (threshold)
  → highconfidence/
```

**Low Confidence:**
```
ANY field has confidence < threshold

Example:
  first_name: 0.95
  last_name: 0.82
  email: 0.75
  cell: 0.65  ← Below threshold!
  
  Minimum: 0.65 < 0.70 (threshold)
  → lowconfidence/
```

---

## 📂 **ACCESSING FILES**

### **Method 1: Azure Portal**
```
1. Azure Portal
2. Storage Account
3. Containers
4. outputcontainer
5. Browse folders
6. Download files
```

### **Method 2: Azure Storage Explorer**
```
1. Download Azure Storage Explorer
2. Connect to your storage account
3. Navigate to outputcontainer
4. Browse and download
```

### **Method 3: Python Script**
```python
from azure.storage.blob import BlobServiceClient

# Connect
blob_service = BlobServiceClient.from_connection_string(conn_str)
container_client = blob_service.get_container_client("outputcontainer")

# List all CSV files for a provider
blobs = container_client.list_blobs(
    name_starts_with="highconfidence/ANAND-NICHOLS/ProcessedCSVResult/"
)

for blob in blobs:
    print(blob.name)
    # Download
    blob_client = container_client.get_blob_client(blob.name)
    with open(f"local_{blob.name.split('/')[-1]}", "wb") as f:
        f.write(blob_client.download_blob().readall())
```

### **Method 4: Azure CLI**
```bash
# List files
az storage blob list \
  --container-name outputcontainer \
  --prefix highconfidence/ANAND-NICHOLS/ \
  --account-name your-account

# Download file
az storage blob download \
  --container-name outputcontainer \
  --name highconfidence/ANAND-NICHOLS/ProcessedCSVResult/ANAND-NICHOLS_20260306_123456.csv \
  --file local_file.csv \
  --account-name your-account
```

---

## 🔍 **FINDING SPECIFIC FILES**

### **By Provider:**
```
Path pattern:
  {category}/{provider_name}/

Examples:
  highconfidence/ANAND-NICHOLS/
  lowconfidence/Provider2/
```

### **By File Type:**
```
CSV files:
  */ProcessedCSVResult/*.csv

JSON files:
  */ProcessedJSONResult/*.json

Cost tracking:
  */ProcessedEstimateCostTracking/*.json
```

### **By Date:**
```
Today's files:
  *_{YYYYMMDD}_*.{ext}
  
Example for March 6, 2026:
  *_20260306_*.csv
```

### **By Confidence:**
```
High confidence only:
  highconfidence/**/*

Low confidence only:
  lowconfidence/**/*
```

---

## 💰 **COST TRACKING REMOVED**

### **What Changed:**

**Before:**
```
COST BREAKDOWN:
  Total cost: $0.0868
  OCR cost: $0.0800
  Embedding cost: $0.0004
  GPT-4o cost: $0.0067
  Azure AI Search cost: $0.0000 (included in subscription)  ← REMOVED!
```

**After:**
```
COST BREAKDOWN:
  Total cost: $0.0868
  OCR cost: $0.0800
  Embedding cost: $0.0004
  GPT-4o cost: $0.0067
```

**Why:** Azure AI Search cost is included in subscription, not per-query.

---

## 📊 **FILE CONTENTS**

### **CSV File:**
```csv
provider_name,provider_id,extraction_datetime,total_documents_processed,folders_processed,first_name,first_name_confidence,first_name_source_folder,first_name_source_file,...
ANAND-NICHOLS,ANAND-NICHOLS_20260306_123456,2026-03-06 12:34:56,15,"GEN & HR; ED & TRAIN",Anand,0.95,GEN & HR,CV_2025.pdf,...
```

### **JSON File:**
```json
{
  "provider": "ANAND-NICHOLS",
  "timestamp": "20260306_123456",
  "total_documents_processed": 15,
  "folders": {
    "GEN & HR": {...},
    "ED & TRAIN": {...}
  },
  "combined_fields": {
    "first_name": {
      "value": "Anand",
      "confidence": 0.95,
      "folder": "GEN & HR",
      "file": "CV_2025.pdf"
    }
  },
  "category": "highconfidence"
}
```

### **Cost Tracking File:**
```json
{
  "provider": "ANAND-NICHOLS",
  "timestamp": "20260306_123456",
  "total_cost": 0.0868,
  "breakdown": {
    "ocr": 0.0800,
    "embedding": 0.0004,
    "gpt4o": 0.0067
  },
  "documents_processed": 15
}
```

---

## ✅ **SUMMARY**

**Output Structure:**
```
outputcontainer/
├── highconfidence/
│   └── {provider}/
│       ├── ProcessedCSVResult/{provider}_{timestamp}.csv
│       ├── ProcessedJSONResult/{provider}_{timestamp}.json
│       └── ProcessedEstimateCostTracking/{provider}_{timestamp}.json
└── lowconfidence/
    └── {provider}/
        ├── ProcessedCSVResult/{provider}_{timestamp}.csv
        ├── ProcessedJSONResult/{provider}_{timestamp}.json
        └── ProcessedEstimateCostTracking/{provider}_{timestamp}.json
```

**Files Per Provider:** 3 total
- 1 CSV (field data)
- 1 JSON (complete data)
- 1 JSON (cost tracking)

**Summary Changes:**
- ✅ Removed Azure AI Search cost line
- ✅ Added complete full paths for all file types
- ✅ Shows exact naming convention with placeholders

**Everything organized and easy to find!** 🎉
