"""
Main Execution Script for Medical Credentials Extraction
========================================================
Production-ready document processing with RAG
"""

import json
import logging
from datetime import datetime
from typing import Dict, List
import pandas as pd

from logging_config import setup_logging
from helper import BlobManager, OCRManager, OpenAIManager
from production_index_manager import ProductionIndexManager, ProductionChunker
from prompt_builder import PromptBuilder
from unified_rag import unified_rag_extraction
from costtracking import CostTracker


def load_config(config_path: str = "config.json") -> Dict:
    """Load configuration from JSON file"""
    with open(config_path, 'r') as f:
        return json.load(f)


def main():
    """Main execution function"""
    
    # Setup logging
    logger = setup_logging()
    logger.info("Starting Medical Credentials Extraction System")
    
    # Load configuration
    logger.info("Loading configuration...")
    config = load_config()
    
    # Initialize managers
    logger.info("Initializing Azure managers...")
    blob_manager = BlobManager(config['azure_blob']['connection_string'])
    ocr_manager = OCRManager(
        config['azure_document_intelligence']['endpoint'],
        config['azure_document_intelligence']['key']
    )
    openai_manager = OpenAIManager(
        config['azure_openai_gpt']['endpoint'],
        config['azure_openai_gpt']['api_key'],
        config['azure_openai_gpt']['api_version'],
        config['azure_openai_gpt']['deployment_name'],
        config['azure_openai_embedding']['deployment_name']
    )
    
    # Initialize production index manager with auto-cleanup
    logger.info("Initializing production index manager...")
    index_manager = ProductionIndexManager(
        search_endpoint=config['azure_search']['endpoint'],
        search_api_key=config['azure_search']['api_key'],
        index_name=config['azure_search']['universal_index_name'],
        auto_delete_days=config['azure_search']['auto_delete_days'],
        enable_auto_cleanup=config['azure_search']['enable_auto_cleanup']
    )
    
    # Create universal index
    logger.info("Creating/verifying universal index...")
    index_manager.create_universal_index(
        embedding_dimension=config['azure_openai_embedding']['dimension']
    )
    
    # Run auto-cleanup BEFORE processing
    if config['azure_search']['enable_auto_cleanup']:
        logger.info("Running auto-cleanup...")
        deleted_count = index_manager.cleanup_old_data(
            days=config['azure_search']['auto_delete_days']
        )
        logger.info(f"Auto-cleanup complete: {deleted_count} documents deleted")
    
    # Initialize cost tracker
    cost_tracker = CostTracker(
        ocr_per_page=config['costs']['ocr_per_page'],
        embedding_per_1k=config['costs']['embedding_per_1k_tokens'],
        gpt4o_input_per_1k=config['costs']['gpt4o_input_per_1k_tokens'],
        gpt4o_output_per_1k=config['costs']['gpt4o_output_per_1k_tokens']
    )
    
    # Initialize prompt builder
    prompt_builder = PromptBuilder(
        fields=config['extraction']['fields'],
        mode=config['rag']['mode']
    )
    
    # List provider folders
    input_container = config['azure_blob']['inputcontainer']
    blobs = blob_manager.list_blobs(input_container)
    
    # Get unique provider folders
    providers = set()
    for blob in blobs:
        if '/' in blob:
            provider = blob.split('/')[0]
            providers.add(provider)
    
    logger.info(f"Found {len(providers)} providers to process")
    
    # Process each provider
    for provider_idx, provider in enumerate(sorted(providers), 1):
        logger.info("=" * 80)
        logger.info(f"Processing Provider {provider_idx}/{len(providers)}: {provider}")
        logger.info("=" * 80)
        
        # Get documents for this provider
        provider_docs = [b for b in blobs if b.startswith(f"{provider}/")]
        logger.info(f"Found {len(provider_docs)} documents")
        
        # Process each document
        provider_results = []
        for doc_idx, blob_name in enumerate(provider_docs, 1):
            logger.info(f"Processing document {doc_idx}/{len(provider_docs)}: {blob_name}")
            
            try:
                # Download document
                doc_bytes = blob_manager.download_blob(input_container, blob_name)
                if not doc_bytes:
                    logger.warning(f"Skipping {blob_name}: download failed")
                    continue
                
                # OCR extraction
                logger.info("Extracting text with OCR...")
                document_text = ocr_manager.extract_text(doc_bytes)
                cost_tracker.add_ocr_pages(1)
                
                # Skip if too short (likely portrait/photo)
                if len(document_text.strip()) < config['extraction']['min_text_length']:
                    logger.warning(f"Skipping {blob_name}: text too short ({len(document_text)} chars)")
                    continue
                
                # Handle context length
                chunker = ProductionChunker(
                    max_doc_length_chars=config['processing']['max_doc_length_chars'],
                    max_prompt_tokens=config['processing']['max_prompt_tokens'],
                    chunk_size=config['rag']['chunk_size'],
                    chunk_overlap=config['rag']['chunk_overlap']
                )
                
                processed_text = chunker.handle_document(document_text)
                
                # Generate embedding
                logger.info("Generating embedding...")
                embedding = openai_manager.get_embedding(processed_text[:2000])
                if not embedding:
                    logger.warning(f"Skipping {blob_name}: embedding failed")
                    continue
                cost_tracker.add_embedding_tokens(len(processed_text.split()))
                
                # Upload to universal index with provider tag
                doc_id = f"{provider}_{blob_name.replace('/', '_')}"
                index_manager.upload_document(
                    doc_id=doc_id,
                    content=processed_text,
                    content_vector=embedding,
                    provider=provider,
                    provider_id=f"{provider}_{datetime.now().strftime('%Y%m%d')}",
                    document_name=blob_name.split('/')[-1]
                )
                
                # RAG extraction with provider filter
                logger.info("Extracting fields with RAG...")
                extraction_prompt = prompt_builder.build_extraction_prompt()
                
                extracted_data = unified_rag_extraction(
                    openai_manager=openai_manager,
                    search_manager=index_manager,
                    index_name=config['azure_search']['universal_index_name'],
                    provider=provider,
                    document_text=processed_text,
                    prompt=extraction_prompt,
                    top_k=config['rag']['top_k'],
                    mode=config['rag']['mode']
                )
                
                # Track GPT-4o costs (estimate)
                cost_tracker.add_gpt4o_tokens(
                    input_tokens=len(extraction_prompt.split()) * 1.3,
                    output_tokens=500
                )
                
                if extracted_data:
                    provider_results.append({
                        "document_name": blob_name.split('/')[-1],
                        "extracted_fields": extracted_data
                    })
                    logger.info(f"✓ Successfully extracted fields from {blob_name}")
                else:
                    logger.warning(f"✗ Extraction failed for {blob_name}")
                    
            except Exception as e:
                logger.error(f"Error processing {blob_name}: {e}", exc_info=True)
                continue
        
        # Save provider results
        if provider_results:
            logger.info(f"Saving results for {provider}...")
            
            # Calculate min confidence
            all_confidences = []
            for result in provider_results:
                for field_data in result['extracted_fields'].values():
                    if isinstance(field_data, dict) and 'confidence' in field_data:
                        all_confidences.append(field_data['confidence'])
            
            min_confidence = min(all_confidences) if all_confidences else 0.0
            category = "highconfidence" if min_confidence >= config['extraction']['confidence_threshold'] else "lowconfidence"
            
            # Prepare output
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_data = {
                "provider": provider,
                "timestamp": timestamp,
                "total_documents": len(provider_results),
                "min_confidence": round(min_confidence, 2),
                "category": category,
                "results": provider_results
            }
            
            # Save JSON
            output_container = config['azure_blob']['outputcontainer']
            json_path = f"processedjsonresult/{provider}_{timestamp}.json"
            blob_manager.upload_blob(
                output_container,
                json_path,
                json.dumps(output_data, indent=2),
                content_type="application/json"
            )
            
            # Save CSV (frequency-based selection)
            csv_data = []
            field_values = {field: [] for field in config['extraction']['fields']}
            
            # Collect all values
            for result in provider_results:
                for field in config['extraction']['fields']:
                    if field in result['extracted_fields']:
                        field_data = result['extracted_fields'][field]
                        value = field_data.get('value', config['extraction']['na_value']) if isinstance(field_data, dict) else field_data
                        field_values[field].append(value)
            
            # Select most frequent value
            best_values = {}
            for field, values in field_values.items():
                if values:
                    # Count frequencies
                    from collections import Counter
                    freq = Counter([v for v in values if v != config['extraction']['na_value']])
                    if freq:
                        best_values[field] = freq.most_common(1)[0][0]
                    else:
                        best_values[field] = config['extraction']['na_value']
                else:
                    best_values[field] = config['extraction']['na_value']
            
            csv_path = f"{category}/{provider}_{timestamp}.csv"
            df = pd.DataFrame([best_values])
            csv_content = df.to_csv(index=False)
            blob_manager.upload_blob(
                output_container,
                csv_path,
                csv_content,
                content_type="text/csv"
            )
            
            logger.info(f"✓ Saved results: {json_path}, {csv_path}")
    
    # Save cost summary
    logger.info("Saving cost summary...")
    cost_summary = cost_tracker.get_summary()
    cost_summary['provider'] = 'ALL'
    cost_summary['total_documents'] = len(blobs)
    
    cost_path = f"estimatecost/summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    blob_manager.upload_blob(
        config['azure_blob']['outputcontainer'],
        cost_path,
        json.dumps(cost_summary, indent=2),
        content_type="application/json"
    )
    
    # Log final summary
    logger.info("=" * 80)
    logger.info("EXTRACTION COMPLETE")
    logger.info("=" * 80)
    logger.info(f"Total providers processed: {len(providers)}")
    logger.info(f"Total documents processed: {len(blobs)}")
    cost_tracker.log_summary()
    logger.info("=" * 80)


if __name__ == "__main__":
    main()
