"""
Azure AI Evaluation SDK Wrapper - Groundedness, Relevance, Retrieval.
Uses azure-ai-evaluation package. Costs tokens per call.
"""

import logging
from typing import Dict, Any
from evaluation.metrics.base_metric import BaseMetric

logger = logging.getLogger(__name__)


class AzureAIEvalMetric(BaseMetric):
    """
    Wraps Azure AI Evaluation SDK evaluators.
    Supports: groundedness, relevance, retrieval.
    
    Config:
        {
            "enabled": true,
            "evaluators": ["groundedness", "relevance", "retrieval"],
            "model_config": {
                "azure_endpoint": "...",
                "api_key": "...",
                "azure_deployment": "gpt-4o"
            }
        }
    """
    
    def __init__(self, config: dict = None):
        self.evaluators = {}
        self.enabled_evaluators = []
        self.available = False
        
        if not config or not config.get('enabled'):
            return
        
        try:
            from azure.ai.evaluation import (
                GroundednessEvaluator,
                RelevanceEvaluator,
                RetrievalEvaluator
            )
            
            model_config = config.get('model_config', {})
            if not model_config.get('azure_endpoint') or not model_config.get('api_key'):
                logger.warning("Azure AI Eval: no model_config credentials")
                return
            
            self.enabled_evaluators = config.get('evaluators', [])
            
            if 'groundedness' in self.enabled_evaluators:
                self.evaluators['groundedness'] = GroundednessEvaluator(model_config=model_config)
            if 'relevance' in self.enabled_evaluators:
                self.evaluators['relevance'] = RelevanceEvaluator(model_config=model_config)
            if 'retrieval' in self.enabled_evaluators:
                self.evaluators['retrieval'] = RetrievalEvaluator(model_config=model_config)
            
            self.available = True
            logger.info(f"Azure AI Eval initialized: {list(self.evaluators.keys())}")
            
        except ImportError:
            logger.warning("Azure AI Eval: azure-ai-evaluation package not installed")
        except Exception as e:
            logger.warning(f"Azure AI Eval: initialization failed: {e}")
    
    @property
    def name(self) -> str:
        return "azure_ai_eval"
    
    def evaluate_field(self, field_name: str, field_data: dict,
                       context: dict = None) -> Dict[str, Any]:
        """
        Run Azure AI evaluators on a field.
        
        Context must contain:
            query: field search query text
            context: RAG chunks text (joined)
            response: extracted value
        
        Returns:
            {
                "groundedness": {"score": 5, "label": "pass", "reason": "..."},
                "relevance": {"score": 4, "label": "pass", "reason": "..."},
                "retrieval": {"score": 5, "label": "pass", "reason": "..."}
            }
        """
        if not self.available or not self.evaluators:
            return None
        
        value = field_data.get('value', '')
        if not value:
            return None
        
        if not context:
            return None
        
        query = context.get('query', field_name.replace('_', ' '))
        rag_context = context.get('rag_context', '')
        response = str(value)
        
        results = {}
        
        # Groundedness: query + context + response
        if 'groundedness' in self.evaluators and rag_context:
            try:
                result = self.evaluators['groundedness'](
                    query=query,
                    context=rag_context,
                    response=response
                )
                results['groundedness'] = {
                    "score": result.get('groundedness', 0),
                    "label": "pass" if result.get('groundedness', 0) >= 3 else "fail",
                    "reason": result.get('groundedness_reason', '')
                }
            except Exception as e:
                logger.warning(f"Groundedness eval failed for {field_name}: {e}")
        
        # Relevance: query + response
        if 'relevance' in self.evaluators:
            try:
                result = self.evaluators['relevance'](
                    query=query,
                    response=response
                )
                results['relevance'] = {
                    "score": result.get('relevance', 0),
                    "label": "pass" if result.get('relevance', 0) >= 3 else "fail",
                    "reason": result.get('relevance_reason', '')
                }
            except Exception as e:
                logger.warning(f"Relevance eval failed for {field_name}: {e}")
        
        # Retrieval: query + context
        if 'retrieval' in self.evaluators and rag_context:
            try:
                result = self.evaluators['retrieval'](
                    query=query,
                    context=rag_context
                )
                results['retrieval'] = {
                    "score": result.get('retrieval', 0),
                    "label": "pass" if result.get('retrieval', 0) >= 3 else "fail",
                    "reason": result.get('retrieval_reason', '')
                }
            except Exception as e:
                logger.warning(f"Retrieval eval failed for {field_name}: {e}")
        
        return results if results else None
