"""
Evaluation Runner - Config-driven orchestrator for all metrics.
Runs selected metrics and enriches extracted_data with evaluation results.

Output structure per field:
    "first_name": {
        "value": "John", "confidence": 0.96, ...,
        "evaluation": {
            "llm_judge": {"score": 1.0, "description": "No issues found"},
            "hallucination": {"score": 1.0, "found_in_source": true},
            "groundedness": {"score": 5, "label": "pass"},
            ...
        }
    }

Provider-level summary added to JSON output:
    "evaluation_summary": {
        "hallucination_rate": 0.05,
        "completeness": 0.82,
        "avg_groundedness": 4.2,
        ...
    }
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class EvalRunner:
    """Config-driven evaluation runner. Universal -- never edit for new fields."""
    
    def __init__(self, eval_config: dict, eval_prompt_module=None):
        """
        Initialize with doctype evaluation config.
        
        Args:
            eval_config: evaluation section from doctype config
            eval_prompt_module: evaluation prompt module for LLM judge
        """
        self.enabled = eval_config.get('enabled', False)
        self.metrics_config = eval_config.get('metrics', {})
        self.metrics = []
        
        if not self.enabled:
            return
        
        self._init_metrics(eval_config, eval_prompt_module)
    
    def _init_metrics(self, eval_config: dict, eval_prompt_module):
        """Initialize enabled metrics."""
        
        # LLM-as-Judge
        if eval_config.get('llm_judge', False):
            try:
                from evaluation.evaluator import LLMJudge
                judge = LLMJudge(config=eval_config, eval_prompt_module=eval_prompt_module)
                self.metrics.append(('llm_judge', judge))
                logger.info("Eval metric enabled: llm_judge")
            except Exception as e:
                logger.warning(f"LLM Judge init failed: {e}")
        
        # Hallucination Detection (free)
        if self.metrics_config.get('hallucination', False):
            try:
                from evaluation.metrics.hallucination import HallucinationMetric
                self.metrics.append(('hallucination', HallucinationMetric()))
                logger.info("Eval metric enabled: hallucination")
            except Exception as e:
                logger.warning(f"Hallucination metric init failed: {e}")
        
        # Completeness (free, provider-level)
        if self.metrics_config.get('completeness', False):
            try:
                from evaluation.metrics.completeness import CompletenessMetric
                self.metrics.append(('completeness', CompletenessMetric()))
                logger.info("Eval metric enabled: completeness")
            except Exception as e:
                logger.warning(f"Completeness metric init failed: {e}")
        
        # Field Accuracy (needs ground truth)
        fa_config = self.metrics_config.get('field_accuracy', {})
        if isinstance(fa_config, dict) and fa_config.get('enabled', False):
            try:
                from evaluation.metrics.field_accuracy import FieldAccuracyMetric
                gt_path = fa_config.get('ground_truth_path', '')
                self.metrics.append(('field_accuracy', FieldAccuracyMetric(gt_path)))
                logger.info(f"Eval metric enabled: field_accuracy (ground_truth: {gt_path})")
            except Exception as e:
                logger.warning(f"Field accuracy metric init failed: {e}")
        
        # Azure AI Evaluation SDK
        azure_config = self.metrics_config.get('azure_ai_eval', {})
        if isinstance(azure_config, dict) and azure_config.get('enabled', False):
            try:
                from evaluation.metrics.azure_ai_eval import AzureAIEvalMetric
                self.metrics.append(('azure_ai_eval', AzureAIEvalMetric(azure_config)))
                logger.info("Eval metric enabled: azure_ai_eval")
            except Exception as e:
                logger.warning(f"Azure AI Eval init failed: {e}")
        
        logger.info(f"Evaluation initialized: {len(self.metrics)} metrics active")
    
    def evaluate_and_enrich(self, extracted_data: dict, context: dict = None) -> dict:
        """
        Run all enabled metrics and add evaluation results to extracted_data.
        
        Args:
            extracted_data: The aggregated extraction results
            context: {"ocr_texts": [...], "provider_name": "...", "rag_contexts": {...}}
        
        Returns:
            enriched extracted_data with 'evaluation' key per field
        """
        if not self.enabled or not self.metrics:
            return extracted_data
        
        if context is None:
            context = {}
        
        for field_name, field_data in extracted_data.items():
            
            # Single-value field
            if isinstance(field_data, dict) and 'value' in field_data:
                eval_results = self._evaluate_single(field_name, field_data, context)
                field_data['evaluation'] = eval_results
            
            # Multi-value field
            elif isinstance(field_data, list):
                for item in field_data:
                    if not isinstance(item, dict):
                        continue
                    for sub_field, sub_data in item.items():
                        if sub_field == 'id':
                            continue
                        if isinstance(sub_data, dict) and 'value' in sub_data:
                            eval_results = self._evaluate_single(
                                f"{field_name}.{sub_field}", sub_data, context
                            )
                            sub_data['evaluation'] = eval_results
        
        return extracted_data
    
    def _evaluate_single(self, field_name: str, field_data: dict, 
                         context: dict) -> dict:
        """Run all metrics on a single field value."""
        eval_results = {}
        value = field_data.get('value', '')
        
        if not value:
            return {}
        
        for metric_name, metric in self.metrics:
            try:
                if metric_name == 'llm_judge':
                    # LLM Judge has its own interface
                    result = self._run_llm_judge(metric, field_name, field_data)
                elif metric_name == 'azure_ai_eval':
                    # Azure AI returns multiple sub-metrics
                    result = metric.evaluate_field(field_name, field_data, context)
                    if result:
                        # Merge azure sub-metrics into eval_results
                        for sub_metric, sub_result in result.items():
                            eval_results[sub_metric] = sub_result
                        continue
                elif metric_name == 'completeness':
                    continue  # completeness is provider-level, not field-level
                else:
                    result = metric.evaluate_field(field_name, field_data, context)
                
                if result is not None:
                    eval_results[metric_name] = result
                    
            except Exception as e:
                logger.warning(f"Metric {metric_name} failed for {field_name}: {e}")
        
        return eval_results
    
    def _run_llm_judge(self, judge, field_name: str, field_data: dict) -> dict:
        """Run LLM judge on a single field."""
        result = judge._evaluate_value(
            field_name, field_data.get('value', ''),
            judge.guidelines.get(field_name.split('.')[0], {})
        )
        return {"score": result['score'], "description": result['description']}
    
    def get_provider_summary(self, extracted_data: dict, context: dict = None) -> dict:
        """
        Generate provider-level evaluation summary.
        
        Returns:
            {
                "hallucination_rate": 0.05,
                "completeness": {"score": 0.82, ...},
                "avg_groundedness": 4.2,
                "avg_relevance": 4.5,
                "avg_retrieval": 3.8,
                "fields_evaluated": 28,
                "fields_with_issues": 3
            }
        """
        summary = {}
        
        # Completeness (provider-level metric)
        for metric_name, metric in self.metrics:
            if metric_name == 'completeness':
                summary['completeness'] = metric.evaluate_provider(extracted_data)
        
        # Aggregate field-level scores
        hallucination_scores = []
        groundedness_scores = []
        relevance_scores = []
        retrieval_scores = []
        llm_judge_scores = []
        fields_evaluated = 0
        fields_with_issues = 0
        
        for field_data in extracted_data.values():
            eval_data = self._collect_eval_data(field_data)
            for ev in eval_data:
                if not ev:
                    continue
                fields_evaluated += 1
                has_issue = False
                
                if 'hallucination' in ev:
                    hallucination_scores.append(ev['hallucination'].get('score', 1.0))
                    if ev['hallucination'].get('score', 1.0) < 1.0:
                        has_issue = True
                
                if 'groundedness' in ev:
                    groundedness_scores.append(ev['groundedness'].get('score', 0))
                    if ev['groundedness'].get('score', 0) < 3:
                        has_issue = True
                
                if 'relevance' in ev:
                    relevance_scores.append(ev['relevance'].get('score', 0))
                
                if 'retrieval' in ev:
                    retrieval_scores.append(ev['retrieval'].get('score', 0))
                
                if 'llm_judge' in ev:
                    llm_judge_scores.append(ev['llm_judge'].get('score', 1.0))
                    if ev['llm_judge'].get('score', 1.0) < 1.0:
                        has_issue = True
                
                if has_issue:
                    fields_with_issues += 1
        
        if hallucination_scores:
            non_hallucinated = sum(1 for s in hallucination_scores if s >= 1.0)
            summary['hallucination_rate'] = round(
                1 - (non_hallucinated / len(hallucination_scores)), 3
            )
        
        if groundedness_scores:
            summary['avg_groundedness'] = round(
                sum(groundedness_scores) / len(groundedness_scores), 2
            )
        
        if relevance_scores:
            summary['avg_relevance'] = round(
                sum(relevance_scores) / len(relevance_scores), 2
            )
        
        if retrieval_scores:
            summary['avg_retrieval'] = round(
                sum(retrieval_scores) / len(retrieval_scores), 2
            )
        
        if llm_judge_scores:
            summary['avg_llm_judge'] = round(
                sum(llm_judge_scores) / len(llm_judge_scores), 3
            )
        
        summary['fields_evaluated'] = fields_evaluated
        summary['fields_with_issues'] = fields_with_issues
        
        return summary
    
    def _collect_eval_data(self, field_data) -> list:
        """Collect evaluation dicts from field data (handles single + multi)."""
        results = []
        
        if isinstance(field_data, dict) and 'evaluation' in field_data:
            results.append(field_data['evaluation'])
        elif isinstance(field_data, list):
            for item in field_data:
                if isinstance(item, dict):
                    for k, v in item.items():
                        if k == 'id':
                            continue
                        if isinstance(v, dict) and 'evaluation' in v:
                            results.append(v['evaluation'])
        
        return results
