"""
MEDICAL CREDENTIALS EXTRACTION - FOLDER-LEVEL OPTIMIZED
========================================================
Features:
- Folder-level extraction (process specific folders across all providers)
- Priority chunking (semantic chunking before indexing)
- Document Intelligence v1.0.0b4
- Both text and multimodal RAG modes
- Universal index with provider+folder filtering
"""

import json
import logging
import os
from datetime import datetime
from collections import Counter
from typing import Dict, List, Tuple

# Import optimized modules
from helper import BlobManager, OpenAIManager, SearchManager, generate_document_id
from documentintelligence_ocr import DocumentIntelligenceOCR
from semantic_chunker import process_for_chunking
from costtracking import CostTracker
from logging_config import setup_logging
from prompt_builder import build_extraction_prompt


def load_config() -> dict:
    """Load configuration from config.json"""
    with open('config.json', 'r') as f:
        return json.load(f)


def get_folder_config(config: dict, folder_name: str) -> dict:
    """
    Get configuration for a specific folder
    
    Args:
        config: Full configuration
        folder_name: Folder name to look up
    
    Returns:
        Folder configuration (fields, description) or None if not found
    """
    # Check if folder has specific config
    if folder_name in config.get('folder_configs', {}):
        return config['folder_configs'][folder_name]
    
    # No config found
    return None


def match_folder_to_config(folder_path: str, folder_configs: dict) -> Tuple[str, dict]:
    """
    Match a folder path to configured folder
    
    Args:
        folder_path: Full folder path (e.g., "Personal/2024" or "Licenses")
        folder_configs: Configured folders from config.json
    
    Returns:
        Tuple of (matched_config_name, config_dict)
    """
    # Exact match first
    if folder_path in folder_configs:
        return folder_path, folder_configs[folder_path]
    
    # Check if folder path starts with any configured folder
    for config_name in folder_configs:
        if folder_path.startswith(config_name):
            return config_name, folder_configs[config_name]
    
    # No match - return None
    return None, None


def process_document(doc_info: dict, blob_manager: BlobManager, ocr: DocumentIntelligenceOCR,
                    openai_manager: OpenAIManager, search_manager: SearchManager,
                    folder_config: dict, rag_config: dict, cost_tracker: CostTracker,
                    logger: logging.Logger) -> Dict:
    """Process single document with chunking and RAG"""
    
    doc_name = doc_info['filename']
    provider = doc_info['provider']
    folder = doc_info['folder']
    
    logger.info(f"Processing: {provider}/{folder}/{doc_name}")
    
    # Download document
    doc_bytes = blob_manager.download_blob(
        config['azure_blob']['inputcontainer'],
        doc_info['blob_name']
    )
    
    if not doc_bytes:
        logger.error(f"Failed to download: {doc_name}")
        return None
    
    # OCR extraction
    text, pages, success = ocr.extract_text(doc_bytes, doc_info['extension'])
    
    if not success:
        logger.error(f"OCR failed for: {doc_name}")
        return None
    
    cost_tracker.add_ocr(pages)
    
    # Check minimum text length
    if len(text) < config['extraction']['min_text_length']:
        logger.info(f"Skipping (insufficient text): {doc_name}")
        return None
    
    # Generate content hash for uniqueness (prevents overwrite on re-upload)
    import hashlib
    content_hash = hashlib.md5(text.encode('utf-8', errors='ignore')).hexdigest()
    
    # Priority chunking
    needs_chunking, chunks, strategy = process_for_chunking(
        text, rag_config, f"{provider}_{folder}_{doc_name}"
    )
    
    if needs_chunking:
        logger.info(f"Chunking: {len(chunks)} chunks created for {doc_name}")
        
        # Index all chunks
        for chunk in chunks:
            vector = openai_manager.generate_embedding(chunk['text'])
            doc_id = generate_document_id(provider, folder, doc_name, 
                                          chunk['chunk_index'], content_hash)
            
            search_manager.upload_document(
                doc_id=doc_id,
                content=chunk['text'],
                vector=vector,
                provider=provider,
                folder=folder,
                document_name=doc_name,
                chunk_index=chunk['chunk_index'],
                total_chunks=chunk['total_chunks']
            )
        
        # Use first chunk for extraction
        extraction_text = chunks[0]['text']
    else:
        # Index full document
        vector = openai_manager.generate_embedding(text)
        doc_id = generate_document_id(provider, folder, doc_name, 
                                      content_hash=content_hash)
        
        search_manager.upload_document(
            doc_id=doc_id,
            content=text,
            vector=vector,
            provider=provider,
            folder=folder,
            document_name=doc_name
        )
        
        extraction_text = text
    
    # RAG search (provider + folder filtered)
    search_vector = openai_manager.generate_embedding(extraction_text)
    similar_docs = search_manager.search_similar(
        search_vector, provider, folder, rag_config['top_k']
    )
    
    # Determine RAG mode from global config
    rag_mode = config['rag']['mode']  # "text" or "multimodal"
    is_image = doc_info['extension'] in ['.jpg', '.jpeg', '.png', '.tiff', '.bmp', '.gif', '.webp']
    
    # Use multimodal only if: (1) mode is multimodal AND (2) file is image
    use_multimodal = (rag_mode == 'multimodal') and is_image
    
    # Build prompt
    prompt = build_extraction_prompt(
        text=extraction_text,
        fields=folder_config['fields'],
        rag_examples=similar_docs,
        folder_description=folder_config.get('description', '')
    )
    
    # Extract fields
    if use_multimodal:
        import base64
        image_base64 = base64.b64encode(doc_bytes).decode('utf-8')
        extracted_data, tokens = openai_manager.extract_fields(
            prompt, use_vision=True, image_base64=image_base64
        )
        logger.info(f"Used MULTIMODAL RAG for {doc_name}")
    else:
        extracted_data, tokens = openai_manager.extract_fields(prompt)
        logger.info(f"Used TEXT RAG for {doc_name}")
    
    cost_tracker.add_gpt4o(tokens['input_tokens'], tokens['output_tokens'])
    cost_tracker.add_embedding(len(extraction_text) // 4)  # Estimate
    
    return {
        'document_name': doc_name,
        'fields': extracted_data,
        'rag_mode': 'multimodal' if use_multimodal else 'text',
        'chunked': needs_chunking,
        'chunks_count': len(chunks) if needs_chunking else 1
    }


def calculate_best_values(documents: List[Dict], fields: List[str], 
                          confidence_threshold: float = 0.50) -> Tuple[Dict, str]:
    """
    Calculate best values using frequency selection
    
    Args:
        documents: List of processed documents
        fields: List of field names
        confidence_threshold: Minimum confidence for highconfidence category
    
    Returns:
        Tuple of (best_values dict, category string)
    """
    best_values = {}
    min_confidence = 1.0
    
    for field in fields:
        values = []
        confidences = []
        
        for doc in documents:
            if field in doc['fields']:
                field_data = doc['fields'][field]
                
                # Handle both dict format and string format
                if isinstance(field_data, dict):
                    value = field_data.get('value', 'NA')
                    confidence = field_data.get('confidence', 0.5)
                else:
                    # field_data is a string (direct value)
                    value = field_data if field_data else 'NA'
                    confidence = 0.5  # Default confidence
                
                if value != 'NA':
                    values.append(value)
                    confidences.append(confidence)
        
        # Frequency-based selection
        if values:
            value_counts = Counter(values)
            most_common = value_counts.most_common(1)[0][0]
            avg_confidence = sum(confidences) / len(confidences)
            
            best_values[field] = {
                'value': most_common,
                'confidence': round(avg_confidence, 2)
            }
            min_confidence = min(min_confidence, avg_confidence)
        else:
            best_values[field] = {'value': 'NA', 'confidence': 0.5}
            min_confidence = 0.5
    
    # Use the configurable threshold
    category = 'highconfidence' if min_confidence >= confidence_threshold else 'lowconfidence'
    return best_values, category


def save_provider_results(blob_manager: BlobManager, provider: str, 
                         all_folders_data: Dict[str, Dict],
                         config: dict, cost_tracker, logger: logging.Logger):
    """
    Save results for entire provider (all folders combined)
    ONE ROW in CSV per provider
    
    Structure:
      {category}/
        {provider}/
          ProcessedJSONResult/{provider}_{timestamp}.json
          ProcessedCSVResult/{provider}_{timestamp}.csv
          ProcessedEstimateCostTracking/{provider}_{timestamp}.json
    
    Args:
        all_folders_data: Dict of {folder_name: {documents, best_values, category}}
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Determine overall category (if ANY folder is low confidence, entire provider is low)
    categories = [data['category'] for data in all_folders_data.values()]
    overall_category = 'lowconfidence' if 'lowconfidence' in categories else 'highconfidence'
    
    # Base path
    base_path = f"{overall_category}/{provider}"
    
    # Collect all fields from all folders
    all_fields = {}
    total_documents = 0
    
    for folder_name, folder_data in all_folders_data.items():
        total_documents += len(folder_data['documents'])
        # Merge best values from all folders
        for field, field_data in folder_data['best_values'].items():
            # Use the highest confidence value if field appears in multiple folders
            if field not in all_fields or field_data['confidence'] > all_fields[field]['confidence']:
                # Find which document had this value
                source_file = 'Unknown'
                for doc in folder_data['documents']:
                    if field in doc.get('fields', {}):
                        doc_field_data = doc['fields'][field]
                        doc_value = doc_field_data.get('value', '') if isinstance(doc_field_data, dict) else doc_field_data
                        if str(doc_value) == str(field_data['value']):
                            source_file = doc.get('document_name', 'Unknown')
                            break
                
                all_fields[field] = {
                    'value': field_data['value'],
                    'confidence': field_data['confidence'],
                    'folder': folder_name,
                    'file': source_file
                }
    
    # JSON result - Complete data
    json_result = {
        'provider': provider,
        'timestamp': timestamp,
        'total_documents_processed': total_documents,
        'folders': all_folders_data,
        'combined_fields': all_fields,
        'category': overall_category
    }
    
    json_path = f"{base_path}/ProcessedJSONResult/{provider}_{timestamp}.json"
    blob_manager.upload_blob(
        config['azure_blob']['outputcontainer'],
        json_path,
        json.dumps(json_result, indent=2),
        'application/json'
    )
    logger.info(f"Saved JSON: {json_path}")
    
    # CSV result - ONE ROW for entire provider
    csv_lines = []
    
    # Build headers
    headers = [
        'provider_name',
        'provider_id',
        'extraction_datetime',
        'total_documents_processed',
        'folders_processed'
    ]
    
    # Add field columns
    for field in sorted(all_fields.keys()):
        headers.append(f'{field}')
        headers.append(f'{field}_confidence')
        headers.append(f'{field}_source_folder')
        headers.append(f'{field}_source_file')
    
    csv_lines.append(','.join(headers))
    
    # Build ONE row for the provider
    extraction_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    folders_list = '|'.join(all_folders_data.keys())
    
    row_values = [
        provider,  # provider_name
        provider,  # provider_id
        extraction_datetime,  # extraction_datetime
        str(total_documents),  # total_documents_processed
        folders_list  # folders_processed
    ]
    
    # Add field values
    for field in sorted(all_fields.keys()):
        field_data = all_fields[field]
        row_values.append(str(field_data['value']))
        row_values.append(str(field_data['confidence']))
        row_values.append(str(field_data['folder']))
        row_values.append(str(field_data['file']))
    
    csv_lines.append(','.join(row_values))
    
    csv_path = f"{base_path}/ProcessedCSVResult/{provider}_{timestamp}.csv"
    blob_manager.upload_blob(
        config['azure_blob']['outputcontainer'],
        csv_path,
        '\n'.join(csv_lines),
        'text/csv'
    )
    logger.info(f"Saved CSV: {csv_path}")
    
    # Cost tracking
    cost_summary = cost_tracker.get_summary()
    cost_path = f"{base_path}/ProcessedEstimateCostTracking/{provider}_{timestamp}.json"
    blob_manager.upload_blob(
        config['azure_blob']['outputcontainer'],
        cost_path,
        json.dumps(cost_summary, indent=2),
        'application/json'
    )
    logger.info(f"Saved Cost: {cost_path}")


def main():
    """Main execution"""
    global config
    
    # Load config
    config = load_config()
    logger = setup_logging(config)
    
    logger.info("="*80)
    logger.info("MEDICAL CREDENTIALS EXTRACTION - FOLDER-LEVEL OPTIMIZED")
    logger.info("="*80)
    
    # Initialize managers
    logger.info("Initializing managers...")
    logger.info(f"RAG Mode: {config['rag']['mode']}")  # Show global RAG mode
    
    blob_manager = BlobManager(config['azure_blob']['connection_string'])
    
    ocr = DocumentIntelligenceOCR(
        config['azure_document_intelligence']['endpoint'],
        config['azure_document_intelligence']['key']
    )
    
    openai_manager = OpenAIManager(
        config['azure_openai_gpt'],
        config['azure_openai_embedding']
    )
    
    search_manager = SearchManager(
        config['azure_search']['endpoint'],
        config['azure_search']['api_key'],
        config['azure_search']['universal_index_name'],
        config['azure_openai_embedding']['dimension']
    )
    
    cost_tracker = CostTracker(config)
    
    # Create universal index
    logger.info("Setting up universal index...")
    if search_manager.create_universal_index():
        logger.info("✓ Index created")
    else:
        logger.info("✓ Index exists")
    
    # Auto-cleanup
    if config['azure_search']['enable_auto_cleanup']:
        logger.info("Running auto-cleanup...")
        deleted = search_manager.delete_old_documents(config['azure_search']['auto_delete_days'])
        logger.info(f"✓ Deleted {deleted} old documents")
    
    # Get folder structure
    logger.info("Analyzing folder structure...")
    folder_structure = blob_manager.get_folder_structure(config['azure_blob']['inputcontainer'])
    
    total_providers = len(folder_structure)
    logger.info(f"Found {total_providers} providers")
    
    # Process each provider
    total_docs_processed = 0
    
    for provider, provider_folders in folder_structure.items():
        logger.info(f"\n{'='*80}")
        logger.info(f"PROVIDER: {provider}")
        logger.info(f"{'='*80}")
        logger.info(f"Found {len(provider_folders)} folders: {provider_folders}")
        
        # Collect all folder results for this provider
        provider_folders_data = {}
        
        # Process each folder
        for folder in provider_folders:
            # Match folder to config
            config_name, folder_config = match_folder_to_config(folder, config.get('folder_configs', {}))
            
            # Skip if not configured
            if not folder_config:
                logger.info(f"Skipping unconfigured folder: {folder}")
                continue
            
            logger.info(f"\n--- Folder: {folder} (Config: {config_name}) ---")
            logger.info(f"Fields: {folder_config['fields']}")
            logger.info(f"Description: {folder_config.get('description', 'N/A')}")
            
            # Get documents in folder
            documents_list = blob_manager.list_folder_documents(
                config['azure_blob']['inputcontainer'],
                provider,
                folder
            )
            
            # Filter by supported formats
            supported = config['extraction']['supported_formats']
            documents_list = [d for d in documents_list if d['extension'] in supported]
            
            logger.info(f"Found {len(documents_list)} documents to process")
            
            # Process documents
            processed_docs = []
            for doc_info in documents_list:
                result = process_document(
                    doc_info, blob_manager, ocr, openai_manager, search_manager,
                    folder_config, config['rag'], cost_tracker, logger
                )
                
                if result:
                    processed_docs.append(result)
                    total_docs_processed += 1
            
            # Calculate best values for this folder
            if processed_docs:
                best_values, category = calculate_best_values(
                    processed_docs, 
                    folder_config['fields'],
                    config['extraction']['confidence_threshold']
                )
                
                # Store folder data (don't save yet - collect all folders first)
                provider_folders_data[folder] = {
                    'documents': processed_docs,
                    'best_values': best_values,
                    'category': category
                }
        
        # Save ALL folders for this provider at once (ONE CSV row per provider)
        if provider_folders_data:
            save_provider_results(
                blob_manager, provider, provider_folders_data,
                config, cost_tracker, logger
            )
    
    # Final summary
    logger.info(f"\n{'='*80}")
    logger.info("PROCESSING COMPLETE")
    logger.info(f"{'='*80}")
    logger.info(f"Total providers: {total_providers}")
    logger.info(f"Total documents processed: {total_docs_processed}")
    
    # Log cost summary
    cost_summary = cost_tracker.get_summary()
    logger.info(f"Total cost: ${cost_summary['total']:.4f}")
    logger.info(f"Breakdown: {cost_summary['breakdown']}")
    logger.info(f"✓ Cost tracking saved per provider/folder")


if __name__ == "__main__":
    main()
