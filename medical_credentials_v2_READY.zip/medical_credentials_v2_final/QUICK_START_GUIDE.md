# Quick Start Guide

## 🎯 How to Change Mode

### **Step 1: Open config.json**
```bash
nano config.json
# OR open in any text editor
```

### **Step 2: Find the "rag" section**
```json
{
  "rag": {
    "mode": "multimodal"  ← Change this line!
  }
}
```

### **Step 3: Change the mode**

**Option 1: Text Mode (All files use text)**
```json
{
  "rag": {
    "mode": "text"  ← Change to "text"
  }
}
```

**Option 2: Multimodal Mode (PDFs/images use vision)**
```json
{
  "rag": {
    "mode": "multimodal"  ← Change to "multimodal"
  }
}
```

### **Step 4: Save and run**
```bash
# Save the file (Ctrl+O, Enter, Ctrl+X in nano)
# Run the system
python main.py
```

---

## ⚠️ **Embedding Error: "unsupported data type"**

### **Error Message:**
```
❌ embedding failed: unsupported data type
```

### **Root Cause:**
The embedding is being sent binary data (PDF/DOC bytes) instead of text!

### **Fix:**

**Open main.py and find line ~349:**

```python
# CURRENT (WRONG):
embedding = openai_manager.get_embedding(processed_text[:2000])

# If processed_text contains binary data → ERROR!
```

**Should be (CORRECT):**
```python
# ALWAYS use document_text (OCR extracted text) for embedding
embedding = openai_manager.get_embedding(document_text[:2000])
```

---

## 🔧 **Apply the Fix:**

**Option 1: Manual fix**
```bash
# Edit main.py around line 349
nano main.py

# Find:
embedding = openai_manager.get_embedding(processed_text[:2000])

# Change to:
embedding = openai_manager.get_embedding(document_text[:2000])
```

**Option 2: I'll provide the fixed file below**

---

## 📊 **Mode Comparison**

| Mode | PDF | Images | DOC/DOCX | TXT |
|------|-----|--------|----------|-----|
| **"text"** | OCR text | OCR text | OCR text | Text content |
| **"multimodal"** | Vision (image) | Vision (image) | Vision or Text | Text |

---

## ✅ **Recommended Setup**

### **For Mixed File Types (PDFs + Images + DOCs):**
```json
{
  "rag": {
    "mode": "text"  ← START WITH THIS!
  }
}
```

**Why text mode first?**
- ✅ Works for ALL file types
- ✅ No image conversion needed
- ✅ No embedding errors
- ✅ Faster processing
- ✅ Cheaper cost

**After text mode works, you can try multimodal if needed.**

---

## 🚀 **Complete Workflow**

### **1. Set Text Mode**
```json
{
  "rag": {
    "mode": "text"
  }
}
```

### **2. Run**
```bash
python main.py
```

### **3. Check Logs**
```
[1/10] license.pdf
  Mode: TEXT (user preference)
  ✓ OCR extracted: 2547 chars
  ✓ Embedding generated: 3072 dimensions  ← Should work!
  ✓ Extraction successful
```

### **4. Verify Output**
```
highconfidence/Provider1/
├── processedjsonresult/
├── processedcsvresult/
└── estimationcost/
```

---

## 🔍 **Troubleshooting**

### **Still Getting Embedding Error?**

**Check what's being sent to embedding:**

```python
# Add debug logging before embedding call
print(f"DEBUG: Text type: {type(document_text)}")
print(f"DEBUG: Text length: {len(document_text)}")
print(f"DEBUG: First 100 chars: {document_text[:100]}")

embedding = openai_manager.get_embedding(document_text[:2000])
```

**Expected:**
```
DEBUG: Text type: <class 'str'>
DEBUG: Text length: 2547
DEBUG: First 100 chars: Medical License
State License Number: A12345
Expiration: 12/31/2025
```

**If you see binary/bytes:**
```
DEBUG: Text type: <class 'bytes'>  ← WRONG!
```

**Then the OCR text is not being extracted properly!**

---

## ✅ **Summary**

**To change mode:**
1. Open config.json
2. Find "rag" → "mode"
3. Change to "text" or "multimodal"
4. Save and run

**To fix embedding error:**
1. Use "text" mode first
2. Ensure embedding uses document_text (not processed_text or binary data)
3. Check logs for "Embedding generated: 3072 dimensions"

**Start with TEXT mode - it works for everything!** ✅
