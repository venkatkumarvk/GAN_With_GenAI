# Correct Processing Workflow

## 📊 Complete Flow: Input → Output

### **Step-by-Step Process:**

```
┌─────────────────────────────────────────────────────┐
│ 1. INPUT: Blob Storage                             │
│    inputcontainer/Provider1/1. GEN & HR/license.pdf│
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ 2. OCR: Azure Document Intelligence                │
│    license.pdf → Extract text (2547 chars)         │
│    ✓ Text extracted successfully                    │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ 3. MODE SELECTION: Check config                    │
│    config['rag']['mode'] = "multimodal"            │
│    → Use Vision processing                          │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ 4. IMAGE CONVERSION (CRITICAL!)                    │
│    PDF bytes → PyMuPDF → PNG image                 │
│    ✓ PNG image created (not raw PDF!)             │
│    ✓ Converted to base64                           │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ 5. EMBEDDING: OpenAI Embeddings                    │
│    OCR text → Generate embedding (3072 dimensions) │
│    ✓ Embedding created                             │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ 6. AI SEARCH: Azure AI Search                      │
│    Upload: doc_id + text + embedding               │
│    ✓ Document indexed                              │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ 7. RAG: Retrieve Similar Documents                 │
│    Search index → Get 3 similar documents          │
│    ✓ RAG examples retrieved                        │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ 8. PROMPT: Build Extraction Prompt                 │
│    Combine: prompt + RAG examples + PNG image      │
│    ✓ Prompt ready                                   │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ 9. EXTRACTION: GPT-4o Vision                       │
│    Send PNG image + prompt → GPT-4o                │
│    ✓ Fields extracted                              │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ 10. OUTPUT: Save Results                           │
│     → CSV  (highconfidence/Provider1_GEN & HR/)   │
│     → JSON (processedjsonresult/)                  │
│     → COST (processedestimationcost/)              │
│     ✓ All files saved                              │
└─────────────────────────────────────────────────────┘
```

---

## ⚠️ CRITICAL: PDF Must Become PNG!

### **Wrong (Causes Error):**
```python
# ❌ This sends raw PDF to GPT-4o
pdf_bytes → base64.encode(pdf_bytes) → GPT-4o
# Result: "unsupported document type" error
```

### **Correct (Works):**
```python
# ✓ This sends PNG image to GPT-4o
pdf_bytes → PyMuPDF → PNG image → base64.encode(png) → GPT-4o
# Result: Success!
```

---

## 🔧 Fixed Implementation

### **In convert_to_base64():**

```python
elif file_type == 'pdf':
    import fitz  # PyMuPDF
    
    # Open PDF
    pdf_document = fitz.open(stream=file_bytes, filetype="pdf")
    page = pdf_document[0]
    
    # Render to PNG (NOT raw PDF!)
    mat = fitz.Matrix(2, 2)
    pix = page.get_pixmap(matrix=mat)
    png_bytes = pix.tobytes("png")  # ← PNG format!
    
    # Verify it's PNG
    assert png_bytes.startswith(b'\x89PNG')  # PNG magic bytes
    
    # Convert PNG to base64
    return base64.b64encode(png_bytes).decode('utf-8')
```

---

## 📋 Logs You Should See

### **Correct Logs (Working):**

```
[1/10] license.pdf
  File type: pdf
  OCR extraction...
  ✓ OCR extracted: 2547 chars
  Mode: MULTIMODAL
  Converting PDF to image...
  ✓ PDF converted to PNG image (524288 bytes)
  Generating embedding...
  ✓ Embedding generated: 3072 dimensions
  Uploading to index: Provider1_GEN_and_HR_license.pdf
  ✓ Uploaded to Azure AI Search
  Extracting fields...
  ✓ Extraction successful: 12 fields
✓ Successfully processed

✅ Saved JSON: highconfidence/Provider1_GEN & HR/processedjsonresult/...
✅ Saved CSV: highconfidence/Provider1_GEN & HR/processedcsvresult/...
✅ Saved Cost: highconfidence/Provider1_GEN & HR/processedestimationcost/...
```

### **Wrong Logs (Error):**

```
[1/10] license.pdf
  ✓ OCR extracted: 2547 chars
  Mode: MULTIMODAL
  ❌ Embedding failed: unsupported document type
⏭️  Skipping license.pdf: embedding failed
```

---

## ✅ Verification Checklist

After running, verify each step worked:

- [x] **OCR**: ✓ OCR extracted: XXX chars
- [x] **Mode**: Mode: MULTIMODAL
- [x] **Conversion**: ✓ PDF converted to PNG image
- [x] **Embedding**: ✓ Embedding generated: 3072 dimensions
- [x] **Index**: ✓ Uploaded to Azure AI Search
- [x] **Extraction**: ✓ Extraction successful
- [x] **Output**: ✅ Saved JSON, CSV, Cost

**All checkmarks = Working!** ✅

---

## 🐛 If You See "unsupported document type"

### **Diagnosis:**

```python
# Check logs for:
"WARNING: PyMuPDF (fitz) not installed"
# OR
"Error rendering PDF with PyMuPDF"
# OR
Missing log: "✓ PDF converted to PNG image"
```

### **Solution:**

```bash
# 1. Verify PyMuPDF installed
python -c "import fitz; print('✅', fitz.version)"

# 2. Test PDF rendering
python -c "
import fitz
import base64

# Create test PDF
pdf = fitz.open()
page = pdf.new_page()
page.insert_text((50, 50), 'Test')

# Render to PNG
pix = page.get_pixmap()
png = pix.tobytes('png')

# Verify PNG
assert png.startswith(b'\x89PNG')
print('✅ PyMuPDF can render PDFs to PNG')
"

# 3. If test fails
pip install --upgrade PyMuPDF
```

---

## 💡 File Type Processing

| File Type | Multimodal Processing | Requirement |
|-----------|----------------------|-------------|
| **PDF** | PyMuPDF → PNG → Base64 | ✅ PyMuPDF required |
| **JPG/PNG** | PIL → PNG → Base64 | ✅ Pillow (included) |
| **GIF/BMP** | PIL → PNG → Base64 | ✅ Pillow (included) |
| **DOC/DOCX** | ❌ Cannot convert | Use TEXT mode instead |
| **TXT** | ❌ No image | Use TEXT mode instead |

---

## 🎯 Recommended Setup

### **For Medical Credentials (PDFs + Images):**

**Config:**
```json
{
  "rag": {
    "mode": "multimodal"
  }
}
```

**Requirements:**
```bash
pip install PyMuPDF  # For PDF → PNG conversion
pip install Pillow   # For image processing
```

**File Organization:**
```
Provider1/
├── 1. GEN & HR/
│   ├── license.pdf    ← Multimodal (PNG conversion)
│   ├── card.jpg       ← Multimodal (direct)
│   └── notes.txt      ⚠️ Skip or use TEXT mode
```

---

## 🚀 Quick Test

```python
# test_pdf_conversion.py
import fitz
import base64

# Open any PDF
pdf = fitz.open("test.pdf")
page = pdf[0]

# Render to PNG
mat = fitz.Matrix(2, 2)
pix = page.get_pixmap(matrix=mat)
png_bytes = pix.tobytes("png")

# Verify
print(f"PNG size: {len(png_bytes)} bytes")
print(f"PNG magic: {png_bytes[:4]}")  # Should be: b'\x89PNG'
print(f"Valid PNG: {png_bytes.startswith(b'\x89PNG')}")

# Base64
b64 = base64.b64encode(png_bytes).decode('utf-8')
print(f"Base64 length: {len(b64)} chars")
print("✅ Ready for GPT-4o!")
```

---

## ✅ Summary

**Correct Flow:**
```
PDF bytes → PyMuPDF → PNG image → Base64 → GPT-4o ✅
```

**Wrong Flow:**
```
PDF bytes → Base64 → GPT-4o ❌ (unsupported document type)
```

**Key Point:** GPT-4o Vision ONLY accepts images (PNG, JPEG, etc.), NOT raw PDFs!

**Your system now:** ALWAYS converts PDFs to PNG before sending to GPT-4o ✅
