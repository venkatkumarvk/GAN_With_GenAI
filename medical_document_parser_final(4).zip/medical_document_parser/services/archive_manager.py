"""
Archive Manager - Blob-to-Blob Document Archiving

After processing, moves provider documents from input container to
archive container, organized by confidence routing:

  archivecontainer/
    processedprovider/        (high confidence - all fields above threshold)
      SMITH-JOHN/
        cred_20250324_103000.zip
    unprocessedprovider/      (low confidence - needs human review)
      DOE-JANE/
        cred_20250324_103000.zip

The zip contains all original documents from the provider's input folder.
After archiving, the original blobs are deleted from input container.
"""

import io
import zipfile
import logging
from datetime import datetime
from azure.storage.blob import BlobServiceClient

logger = logging.getLogger(__name__)


class ArchiveManager:
    """
    Archive processed provider documents from input to archive container.
    
    All operations are blob-to-blob (no local filesystem needed).
    Uses in-memory zip creation via BytesIO.
    """
    
    def __init__(self, blob_manager, config: dict, doctype: str):
        """
        Initialize archive manager.
        
        Args:
            blob_manager: BlobManager instance (from services/azure_clients.py)
            config: Full config dict
            doctype: Document type name (e.g., "cred")
        """
        self.blob_manager = blob_manager
        self.config = config
        self.doctype = doctype
        
        self.input_container = config['azure_blob']['inputcontainer']
        self.archive_container = config['azure_blob'].get(
            'archivecontainer', 
            config.get('archive', {}).get('container', 'archivecontainer')
        )
    
    def archive_provider(
        self,
        provider: str,
        documents: list,
        confidence_routing: str
    ) -> bool:
        """
        Archive a provider's documents after processing.
        
        Workflow:
          1. Download all provider documents from input container (in memory)
          2. Create zip file in memory
          3. Upload zip to archive container under correct folder
          4. Delete original blobs from input container
        
        Args:
            provider: Provider name
            documents: List of blob objects that were processed
            confidence_routing: "highconfidence" or "lowconfidence"
                Maps to: processedprovider/ or unprocessedprovider/
        
        Returns:
            True if archive succeeded
        """
        if not documents:
            logger.warning(f"   Archive: No documents to archive for {provider}")
            return False
        
        # Map confidence routing to archive folder
        if confidence_routing == "highconfidence":
            archive_folder = "processedprovider"
        else:
            archive_folder = "unprocessedprovider"
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        zip_filename = f"{self.doctype}_{timestamp}.zip"
        
        logger.info(
            f"   Archive: {provider} -> {archive_folder}/{provider}/{zip_filename} "
            f"({len(documents)} documents)"
        )
        
        try:
            # Step 1: Create zip in memory
            zip_buffer = io.BytesIO()
            
            with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for doc_blob in documents:
                    blob_name = doc_blob.name
                    filename = blob_name.split('/')[-1]
                    
                    # Download blob content
                    doc_bytes = self.blob_manager.download_blob(
                        self.input_container, blob_name
                    )
                    
                    if doc_bytes:
                        # Preserve folder structure inside zip
                        # e.g., "1. GEN & HR/subfolder/file.pdf"
                        relative_path = blob_name.replace(
                            f"{provider}/", "", 1
                        )
                        zipf.writestr(relative_path, doc_bytes)
                        logger.debug(f"     Added to zip: {relative_path}")
                    else:
                        logger.warning(
                            f"     Could not download {blob_name}, skipping"
                        )
            
            # Step 2: Upload zip to archive container
            zip_buffer.seek(0)
            zip_blob_path = f"{archive_folder}/{provider}/{zip_filename}"
            
            success = self.blob_manager.upload_blob(
                self.archive_container,
                zip_blob_path,
                zip_buffer.getvalue(),
                content_type='application/zip'
            )
            
            if not success:
                logger.error(
                    f"   Archive: Failed to upload zip to {zip_blob_path}"
                )
                return False
            
            logger.info(f"   Archive: Uploaded {zip_blob_path}")
            
            # Step 3: Delete originals from input container
            deleted_count = 0
            for doc_blob in documents:
                try:
                    blob_client = (
                        self.blob_manager.blob_service_client
                        .get_blob_client(self.input_container, doc_blob.name)
                    )
                    blob_client.delete_blob()
                    deleted_count += 1
                except Exception as e:
                    logger.warning(
                        f"     Could not delete {doc_blob.name}: {e}"
                    )
            
            logger.info(
                f"   Archive: Deleted {deleted_count}/{len(documents)} "
                f"blobs from input container"
            )
            
            return True
            
        except Exception as e:
            logger.error(f"   Archive: Failed for {provider}: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False
